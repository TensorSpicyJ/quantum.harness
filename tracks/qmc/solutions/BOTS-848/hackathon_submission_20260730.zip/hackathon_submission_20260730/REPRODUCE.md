# 复现指南

本指南把复现分成“代码正确性”“小系统物理基准”“正式一次量子化 NQS”“Laughlin 配对比较”和“专题物理结果”五层。所有科学脚本均复制自原工作区；建议把新输出写入单独目录，不覆盖提交包中保存的结果。

以下命令假定当前目录为 `hackathon_submission_20260730/`。

## 1. 环境

参考环境：

```bash
python --version
# Python 3.11.14

python -m pip install -r requirements.txt
```

GPU 运行前检查：

```bash
python -c "import jax; print(jax.__version__, jax.devices())"
```

正式 GPU 复算应看到 CUDA 设备。若只看到 CPU，请先安装与本机 CUDA 匹配的 JAX wheel。

建议设置：

```bash
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export PYTHONPATH="$PWD/code:$PYTHONPATH"
```

## 2. 第零层：无需重算，审计已保存结果

最重要的 NQS-Laughlin 配对表：

```bash
column -s, -t \
  data/laughlin_comparison/laughlin_vmc_comparison_formal_20260730/first_quantized_paired.csv
```

正式 \(N=20,30,40\) 的训练/验证能量、ESS 和 gap：

```bash
column -s, -t data/main_nqs_runs/strict_fq_streaming_N20_N40_benchmark_20260730.csv
```

AR Fock-NQS 的 \(L^2\) 污染：

```bash
column -s, -t data/failure_and_boundary/summary.csv
```

注意：`data/failure_and_boundary/summary.csv` 来自
`fock_ar_nqs_symmetry_v5_N10_N20`；它的目标 \(L^2\) 应为基态 0、激发态 6，而保存结果为数百到数千。

## 3. 第一层：快速代码测试

```bash
cd code
pytest -q \
  test_laughlin_vmc_comparison.py \
  test_strict_first_quantized_streaming.py \
  test_strict_first_quantized_stabilized.py \
  test_strict_first_quantized_hmc.py
```

这些测试覆盖：

- 配对 ratio/jackknife 统计；
- NQS 与 Laughlin 相同波函数时差值严格为零；
- 流式 pair contraction 与旧显式核逐点等价；
- 大 \(N\) 多项式稳定化不改变特征；
- 球面 geodesic HMC 的基本分布与几何更新。

## 4. 第二层：小系统严格 SU(2) tensor/ED 基准

从提交包根目录运行：

```bash
python code/chiral_graviton_su2_tensor_route.py \
  --sizes 4,5,6,7,8 \
  --lmax 4 \
  --ed-max 8 \
  --steps 30 \
  --samples 4096 \
  --eval-samples 131072 \
  --seed 20260729 \
  --output-root reproduced/su2_tensor_smallN
```

预期核心检查：

- \(N=4\) 到 \(7\) 的 NQS gap 与 ED 达到机器精度；
- \(N=8\) gap 约为 \(0.128787\,E_C\)；
- 基态 \(\langle L^2\rangle\approx0\)，激发态 \(\langle L^2\rangle\approx6\)；
- 能量方差和 lowering-tower residual 记录在结果 JSON/CSV。

已保存基准见：

```text
data/exact_tensor_benchmark/summary.csv
data/exact_tensor_benchmark/summary.json
```

## 5. 第三层：正式一次量子化 NQS

### 5.1 \(N=20\) 高统计

```bash
python code/strict_first_quantized_nqs_streaming_driver.py \
  --sizes 20 \
  --lmax 5 \
  --chains 256 \
  --burn-sweeps 750 \
  --training-records 64 \
  --validation-records 64 \
  --thin-sweeps 8 \
  --feature-batch 24 \
  --tolerances 1e-4,1e-5,1e-6,1e-7,1e-8 \
  --seed 20261002 \
  --output-dir reproduced/strict_fq_N20_seed20261002
```

原运行在 RTX 4090 Laptop GPU 上约 147 秒，独立训练/验证集各 16384 个构型。

### 5.2 \(N=30\)

```bash
python code/strict_first_quantized_nqs_streaming_driver.py \
  --sizes 30 \
  --lmax 5 \
  --chains 128 \
  --burn-sweeps 600 \
  --training-records 48 \
  --validation-records 48 \
  --thin-sweeps 6 \
  --feature-batch 16 \
  --tolerances 1e-4,1e-5,1e-6,1e-7,1e-8 \
  --seed 20261103 \
  --output-dir reproduced/strict_fq_N30_seed20261103
```

原运行约 148 秒。第二种子把 `--seed` 改为 `20261204`。

### 5.3 \(N=40\)

```bash
python code/strict_first_quantized_nqs_streaming_driver.py \
  --sizes 40 \
  --lmax 5 \
  --chains 128 \
  --burn-sweeps 700 \
  --training-records 48 \
  --validation-records 48 \
  --thin-sweeps 7 \
  --feature-batch 8 \
  --tolerances 1e-4,1e-5,1e-6,1e-7,1e-8 \
  --seed 20261103 \
  --output-dir reproduced/strict_fq_N40_seed20261103
```

原运行约 369 秒。第二种子把 `--seed` 改为 `20261204`。

接受一个大尺寸结果前，应同时满足：

1. training 与 validation 链独立；
2. 基态/激发态解析严格为 \(L^2=0/6\)；
3. retained rank 稳定；
4. validation ESS 不出现崩溃；
5. 多种子 gap 相容；
6. 更大 \(\ell_{\max}\) 的选择依据 validation，而不是只看 training energy。

## 6. 第四层：直接复现“NQS 比 Laughlin 低”

先完成或直接使用提交包中保存的 NQS `results.json`，再运行：

```bash
python code/laughlin_vmc_comparison.py \
  --sizes 12,16,20,30,40 \
  --first-nqs-results \
    data/main_nqs_runs/strict_fq_streaming_N12_N16_l5_seed20260730/results.json \
    data/main_nqs_runs/strict_fq_streaming_N20_l5_highstat_seed20261002/results.json \
    data/main_nqs_runs/strict_fq_streaming_N30_l5_seed20261103/results.json \
    data/main_nqs_runs/strict_fq_streaming_N30_l5_seed20261204/results.json \
    data/main_nqs_runs/strict_fq_streaming_N40_l5_seed20261103/results.json \
    data/main_nqs_runs/strict_fq_streaming_N40_l5_seed20261204/results.json \
  --sampler metropolis \
  --chains 128 \
  --records 64 \
  --burn-sweeps 750 \
  --thin-sweeps 8 \
  --initial-scale 0.9 \
  --feature-batch 24 \
  --seed 20262002 \
  --output-dir reproduced/laughlin_vmc_paired
```

协议要点：

- 每个尺寸使用 \(128\times64=8192\) 个新构型；
- 纯 Laughlin 与 NQS 在同一批样本上估计，因此差值保留协方差；
- 误差用 delete-one-independent-chain jackknife；
- ESS fraction 应保持约 \(0.92\) 到 \(0.97\)；
- 判断的是基态总能量 \(E_{\rm NQS}-E_{\rm Laughlin}\)，不是 gap。

预期方向：

- \(N=12\)：负差值，单次约 \(1.68\sigma\)；
- \(N=16\)：负差值，约 \(3.88\sigma\)；
- \(N=20\)：负差值，约 \(7.32\sigma\)；
- \(N=30\)：两个训练种子均为负，约 \(4.05\sigma\) 与 \(3.39\sigma\)；
- \(N=40\)：两个训练种子均为负，约 \(1.19\sigma\) 与 \(3.45\sigma\)。

小尺寸纯 Laughlin 高统计基准：

```bash
python code/laughlin_vmc_comparison.py \
  --sizes 8,9,10 \
  --chains 512 \
  --records 256 \
  --burn-sweeps 750 \
  --thin-sweeps 6 \
  --seed 20262004 \
  --output-dir reproduced/laughlin_smallN_highstat
```

## 7. 第五层：几何谱、手性、QGT、峰宽和 Moore-Read

### 7.1 几何谱主线

```bash
cd experiments/geometry_chirality_study_20260729
OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
python ed_geometry_suite.py \
  --sizes 4 5 6 7 8 9 \
  --path-sizes 4 6 8 \
  --lanczos-steps 180

OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
python story_completion_suite.py \
  --path-lanczos-steps 140 \
  --convergence-steps 80 120 160 180 220

OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
python endpoint_n10_suite.py \
  --lanczos-steps 140 \
  --convergence-steps 60 100 140 180
```

更完整的原运行清单见该目录的 `RUN_MANIFEST.md`。提交包未复制 367 MB 的可再生 ED cache；首次运行会重建它。

### 7.2 QGT 对称扇区修正

```bash
cd experiments/case_questions_20260730_followup
python dense_qgt_scan_robust.py \
  --output-dir reproduced/qgt_dense_robust
```

预期 crossing 为 \(\lambda_c=0.7684404954\)，而不是把网格相关的 fidelity susceptibility 峰高当作普适量。

### 7.3 Moore-Read 三分支

```bash
cd experiments/case_questions_20260730_followup
python train_moore_read_variational_nqs.py \
  ../case_questions_20260730/results/moore_read_teacher_states.npz \
  --output-dir reproduced/mr_variational_nqs
```

三个分支属于不同粒子数/角动量 Hilbert 空间：偶 \(N=6\) 的 \(L=0,2\)，奇 \(N=7\) 的 \(L=3/2\)。不能把它们错误地塞入同一个固定 \(N\) 三头网络。

### 7.4 DeepHall-style 最小实验

```bash
cd experiments/deephall_l2_minimal_20260730
pytest -q test_minimal.py
python ed_softened_gap.py -N 4 --widths 0 0.5 1.0 \
  --output reproduced/ed_width_scan_N4.json
```

保存的 DeepHall pilot 没有满足目标 \(L^2=0/6\)，因此它是负结果/优化诊断，不是正式 gap。完整解释见该目录 `README.md`。

## 8. 复现成功的最低判据

复算得到接近的中心值仍不够。至少应核对：

- Hamiltonian、磁通、球半径和能量单位一致；
- 是否含中和背景常数；本主比较不含，但同态差值不受其影响；
- \(L^2=0/6\) 是结构保证或被明确验证；
- 输出来自独立 validation；
- ESS、接受率和 retained rank 未失效；
- 多种子和截断变化与保存结果相容；
- gap、基态降能、transport gap、roton energy 没有混用。

