#!/usr/bin/env python3
"""Render the submission's REPORT.md to REPORT.pdf."""

from pathlib import Path

import build_report_texfix as fixed


SUBMISSION = Path(__file__).resolve().parents[1]
fixed.base.SOURCE = SUBMISSION / "REPORT.md"
fixed.base.OUTPUT = SUBMISSION / "REPORT.pdf"


if __name__ == "__main__":
    fixed.base.main()
