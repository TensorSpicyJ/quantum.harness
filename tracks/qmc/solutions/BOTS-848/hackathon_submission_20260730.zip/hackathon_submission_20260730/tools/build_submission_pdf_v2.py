#!/usr/bin/env python3
"""Render REPORT.md with normalized PDF headers and combinatorics."""

from __future__ import annotations

import re
from pathlib import Path

import build_report_texfix as fixed


SUBMISSION = Path(__file__).resolve().parents[1]
ORIGINAL_NORMALIZE = fixed.normalize_fixed
ORIGINAL_REPORT_DOC = fixed.base.ReportDoc


def normalize_submission(text: str) -> str:
    text = re.sub(
        r"\\binom\{([^{}]+)\}\{([^{}]+)\}",
        r"C(\1,\2)",
        text,
    )
    return ORIGINAL_NORMALIZE(text)


class SubmissionReportDoc(ORIGINAL_REPORT_DOC):
    def __init__(self, filename, header, **kwargs):
        header = normalize_submission(header)
        if "title" in kwargs:
            kwargs["title"] = normalize_submission(kwargs["title"])
        super().__init__(filename, header, **kwargs)


fixed.normalize_fixed = normalize_submission
fixed.base.normalize = normalize_submission
fixed.base.ReportDoc = SubmissionReportDoc
fixed.base.SOURCE = SUBMISSION / "REPORT.md"
fixed.base.OUTPUT = SUBMISSION / "REPORT.pdf"


if __name__ == "__main__":
    fixed.base.main()
