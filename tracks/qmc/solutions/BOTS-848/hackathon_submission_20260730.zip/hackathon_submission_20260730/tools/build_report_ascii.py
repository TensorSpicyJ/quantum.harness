#!/usr/bin/env python3
"""Render the consolidated Markdown report to PDF (ASCII-only source)."""

from __future__ import annotations

import html
import os
import re
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    CondPageBreak,
    Flowable,
    Frame,
    HRFlowable,
    Image,
    KeepTogether,
    LongTable,
    PageBreak,
    PageTemplate,
    Paragraph,
    Preformatted,
    Spacer,
    TableStyle,
)
from reportlab.platypus.tableofcontents import TableOfContents


ROOT = Path(__file__).resolve().parents[2]
SOURCE = max((ROOT / "output").glob("*20260730.md"), key=lambda p: p.stat().st_size)
OUTPUT = ROOT / "output" / "pdf" / f"{SOURCE.stem}.pdf"
FONT = (
    Path("C:/Windows/Fonts/simhei.ttf")
    if os.name == "nt"
    else Path("/mnt/c/Windows/Fonts/simhei.ttf")
)

INK = colors.HexColor("#17213A")
BLUE = colors.HexColor("#2457A7")
CYAN = colors.HexColor("#22A6A1")
LIGHT_BLUE = colors.HexColor("#EAF1FB")
PALE = colors.HexColor("#F5F7FB")
LINE = colors.HexColor("#CBD5E4")
MUTED = colors.HexColor("#5C667A")

MATH = {
    r"\Delta": "\u0394",
    r"\Psi": "\u03a8",
    r"\Phi": "\u03a6",
    r"\Gamma": "\u0393",
    r"\lambda": "\u03bb",
    r"\alpha": "\u03b1",
    r"\ell": "\u2113",
    r"\rho": "\u03c1",
    r"\sigma": "\u03c3",
    r"\chi": "\u03c7",
    r"\kappa": "\u03ba",
    r"\theta": "\u03b8",
    r"\omega": "\u03c9",
    r"\epsilon": "\u03b5",
    r"\pi": "\u03c0",
    r"\pm": "\u00b1",
    r"\times": "\u00d7",
    r"\approx": "\u2248",
    r"\to": "\u2192",
    r"\rightarrow": "\u2192",
    r"\le": "\u2264",
    r"\ge": "\u2265",
    r"\langle": "\u27e8",
    r"\rangle": "\u27e9",
    r"\infty": "\u221e",
    r"\sum": "\u03a3",
    r"\propto": "\u221d",
    r"\simeq": "\u2248",
    r"\partial": "\u2202",
}


def register_fonts():
    pdfmetrics.registerFont(TTFont("CJK", str(FONT)))
    pdfmetrics.registerFont(TTFont("CJKBold", str(FONT)))


def normalize(text: str) -> str:
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = text.replace(r"\(", "").replace(r"\)", "")
    text = text.replace(r"\[", "").replace(r"\]", "")
    for old, new in MATH.items():
        text = text.replace(old, new)
    text = re.sub(r"\\(?:rm|mathrm|text|operatorname)\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\frac\{([^{}]+)\}\{([^{}]+)\}", r"(\1)/(\2)", text)
    text = text.replace(r"\,", " ").replace(r"\;", " ").replace(r"\!", "")
    text = text.replace("&", " and ")
    text = re.sub(r"\^\{([^{}]+)\}", r"^(\1)", text)
    text = re.sub(r"_\{([^{}]+)\}", r"_(\1)", text)
    return text.replace("{", "").replace("}", "")


def markup(text: str) -> str:
    text = normalize(text)
    codes = []

    def keep_code(match):
        codes.append(match.group(1))
        return f"@@C{len(codes)-1}@@"

    text = re.sub(r"`([^`]+)`", keep_code, text)
    text = html.escape(text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", text)
    for idx, value in enumerate(codes):
        text = text.replace(
            f"@@C{idx}@@",
            f'<font color="#2457A7">{html.escape(value)}</font>',
        )
    return text


class ReportDoc(BaseDocTemplate):
    def __init__(self, filename, header, **kwargs):
        self.header = header
        super().__init__(filename, **kwargs)
        frame = Frame(
            self.leftMargin,
            self.bottomMargin,
            self.width,
            self.height,
            leftPadding=0,
            rightPadding=0,
            topPadding=0,
            bottomPadding=0,
            id="main",
        )
        self.addPageTemplates(PageTemplate(id="content", frames=[frame], onPage=self.page))

    def page(self, canvas, doc):
        canvas.saveState()
        page = canvas.getPageNumber()
        if page > 1:
            canvas.setStrokeColor(LINE)
            canvas.setLineWidth(0.4)
            canvas.line(
                doc.leftMargin,
                A4[1] - 12 * mm,
                A4[0] - doc.rightMargin,
                A4[1] - 12 * mm,
            )
            canvas.setFont("CJK", 7.3)
            canvas.setFillColor(MUTED)
            canvas.drawString(doc.leftMargin, A4[1] - 9.2 * mm, self.header)
            canvas.drawRightString(A4[0] - doc.rightMargin, 9.5 * mm, str(page))
        canvas.restoreState()

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph):
            level = getattr(flowable, "_toc_level", None)
            if level is not None:
                title = flowable.getPlainText()
                key = f"section-{self.seq.nextf('section')}"
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(title, key, level=level, closed=False)
                self.notify("TOCEntry", (level, title, self.page, key))


class CoverBand(Flowable):
    def __init__(self, width):
        super().__init__()
        self.width = width
        self.height = 18 * mm

    def draw(self):
        c = self.canv
        c.setFillColor(BLUE)
        c.roundRect(0, 0, self.width, self.height, 4 * mm, fill=1, stroke=0)
        c.setFillColor(CYAN)
        c.rect(0, 0, 4 * mm, self.height, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.setFont("CJKBold", 10.5)
        c.drawString(10 * mm, 10.5 * mm, "CORE OUTCOME")
        c.setFont("CJK", 8.1)
        c.drawString(
            10 * mm,
            5.0 * mm,
            "Strict LLL-SU(2) NQS: validated to N=40; geometry-spectrum reorganization is the central physics result.",
        )


def styles():
    base = getSampleStyleSheet()
    return {
        "body": ParagraphStyle(
            "body",
            parent=base["BodyText"],
            fontName="CJK",
            fontSize=9.1,
            leading=14.1,
            textColor=INK,
            alignment=TA_JUSTIFY,
            spaceAfter=3.8 * mm,
            wordWrap="CJK",
        ),
        "small": ParagraphStyle(
            "small",
            fontName="CJK",
            fontSize=7.6,
            leading=10.6,
            textColor=MUTED,
            wordWrap="CJK",
        ),
        "h1": ParagraphStyle(
            "h1",
            fontName="CJKBold",
            fontSize=17,
            leading=22,
            textColor=BLUE,
            spaceBefore=4 * mm,
            spaceAfter=4.5 * mm,
            keepWithNext=True,
            wordWrap="CJK",
        ),
        "h2": ParagraphStyle(
            "h2",
            fontName="CJKBold",
            fontSize=13.2,
            leading=17.5,
            textColor=BLUE,
            spaceBefore=5 * mm,
            spaceAfter=3 * mm,
            keepWithNext=True,
            wordWrap="CJK",
        ),
        "h3": ParagraphStyle(
            "h3",
            fontName="CJKBold",
            fontSize=10.8,
            leading=14.5,
            textColor=INK,
            leftIndent=2 * mm,
            borderColor=CYAN,
            borderLeft=2,
            borderPadding=4,
            spaceBefore=3.2 * mm,
            spaceAfter=2.2 * mm,
            keepWithNext=True,
            wordWrap="CJK",
        ),
        "bullet": ParagraphStyle(
            "bullet",
            fontName="CJK",
            fontSize=8.9,
            leading=13.2,
            leftIndent=6 * mm,
            firstLineIndent=-3.2 * mm,
            bulletIndent=2 * mm,
            textColor=INK,
            spaceAfter=1.5 * mm,
            wordWrap="CJK",
        ),
        "quote": ParagraphStyle(
            "quote",
            fontName="CJK",
            fontSize=8.8,
            leading=13.3,
            leftIndent=7 * mm,
            rightIndent=6 * mm,
            borderColor=CYAN,
            borderLeft=2,
            borderPadding=6,
            backColor=PALE,
            textColor=INK,
            spaceBefore=2 * mm,
            spaceAfter=3 * mm,
            wordWrap="CJK",
        ),
        "eq": ParagraphStyle(
            "eq",
            fontName="CJK",
            fontSize=9.2,
            leading=13,
            alignment=TA_CENTER,
            textColor=BLUE,
            backColor=LIGHT_BLUE,
            borderPadding=6,
            spaceBefore=2 * mm,
            spaceAfter=3 * mm,
            wordWrap="CJK",
        ),
        "caption": ParagraphStyle(
            "caption",
            fontName="CJK",
            fontSize=7.6,
            leading=10.5,
            alignment=TA_CENTER,
            textColor=MUTED,
            spaceBefore=1.5 * mm,
            spaceAfter=4 * mm,
            wordWrap="CJK",
        ),
        "cover": ParagraphStyle(
            "cover",
            fontName="CJKBold",
            fontSize=24,
            leading=33,
            alignment=TA_LEFT,
            textColor=INK,
            wordWrap="CJK",
        ),
        "cover_sub": ParagraphStyle(
            "cover_sub",
            fontName="CJK",
            fontSize=10.5,
            leading=16.5,
            textColor=MUTED,
            wordWrap="CJK",
        ),
        "toc_title": ParagraphStyle(
            "toc_title",
            fontName="CJKBold",
            fontSize=18,
            leading=22,
            textColor=BLUE,
            spaceAfter=7 * mm,
        ),
    }


def make_table(lines, st, width):
    rows = []
    for line in lines:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells):
            continue
        rows.append(cells)
    ncols = max(len(row) for row in rows)
    for row in rows:
        row.extend([""] * (ncols - len(row)))
    fs = 7.4 if ncols <= 5 else 6.4
    cell = ParagraphStyle(
        f"cell-{ncols}-{len(rows)}",
        fontName="CJK",
        fontSize=fs,
        leading=fs + 2.6,
        textColor=INK,
        wordWrap="CJK",
    )
    head = ParagraphStyle(
        f"head-{ncols}-{len(rows)}",
        parent=cell,
        fontName="CJKBold",
        textColor=colors.white,
        alignment=TA_CENTER,
    )
    data = [
        [Paragraph(markup(c), head if ridx == 0 else cell) for c in row]
        for ridx, row in enumerate(rows)
    ]
    table = LongTable(data, colWidths=[width / ncols] * ncols, repeatRows=1)
    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), BLUE),
        ("GRID", (0, 0), (-1, -1), 0.35, LINE),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3.5),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ]
    commands.extend(
        ("BACKGROUND", (0, ridx), (-1, ridx), PALE)
        for ridx in range(2, len(data), 2)
    )
    table.setStyle(TableStyle(commands))
    return table


def make_image(path, caption, st, width):
    if not path.exists():
        return Paragraph(html.escape(str(path)), st["quote"])
    w, h = ImageReader(str(path)).getSize()
    scale = min(width / w, 104 * mm / h, 1.0)
    image = Image(str(path), width=w * scale, height=h * scale)
    image.hAlign = "CENTER"
    return KeepTogether(
        [
            Spacer(1, 2 * mm),
            image,
            Paragraph(markup(caption), st["caption"]),
        ]
    )


def markdown_story(text, st, width, source_dir):
    lines = text.splitlines()
    start = next(
        (idx + 1 for idx, line in enumerate(lines[1:], 1) if line.strip() == "---"),
        0,
    )
    lines = lines[start:]
    out = []
    para = []
    table = []
    code = []
    eq = []
    in_code = False
    in_eq = False

    def flush_para():
        nonlocal para
        if para:
            joined = " ".join(x.strip() for x in para if x.strip())
            if joined:
                out.append(Paragraph(markup(joined), st["body"]))
            para = []

    def flush_table():
        nonlocal table
        if table:
            out.append(make_table(table, st, width))
            out.append(Spacer(1, 3.2 * mm))
            table = []

    for line in lines:
        s = line.strip()
        if s.startswith("```"):
            flush_para()
            flush_table()
            if in_code:
                code_st = ParagraphStyle(
                    "code",
                    fontName="CJK",
                    fontSize=7.2,
                    leading=10,
                    leftIndent=4 * mm,
                    rightIndent=4 * mm,
                    textColor=INK,
                    backColor=PALE,
                    borderColor=LINE,
                    borderWidth=0.5,
                    borderPadding=6,
                )
                out.extend([Preformatted("\n".join(code), code_st), Spacer(1, 3 * mm)])
                code = []
                in_code = False
            else:
                in_code = True
            continue
        if in_code:
            code.append(line)
            continue
        if s == r"\[":
            flush_para()
            flush_table()
            in_eq = True
            eq = []
            continue
        if s == r"\]" and in_eq:
            out.append(Paragraph(markup(" ".join(eq)), st["eq"]))
            eq = []
            in_eq = False
            continue
        if in_eq:
            eq.append(s)
            continue
        image_match = re.match(r"!\[([^\]]*)\]\(([^)]+)\)", s)
        if image_match:
            flush_para()
            flush_table()
            caption, raw = image_match.groups()
            out.append(make_image((source_dir / raw).resolve(), caption, st, width))
            continue
        if s.startswith("|"):
            flush_para()
            table.append(s)
            continue
        flush_table()
        if not s:
            flush_para()
            continue
        if s == "---":
            flush_para()
            out.extend(
                [
                    Spacer(1, 1.5 * mm),
                    HRFlowable(width="100%", thickness=0.45, color=LINE),
                    Spacer(1, 1.5 * mm),
                ]
            )
            continue
        hmatch = re.match(r"^(#{1,4})\s+(.*)", s)
        if hmatch:
            flush_para()
            level = len(hmatch.group(1))
            key = "h1" if level == 1 else "h2" if level == 2 else "h3"
            heading = Paragraph(markup(hmatch.group(2)), st[key])
            heading._toc_level = 0 if level <= 2 else 1
            out.extend([CondPageBreak(25 * mm), heading])
            continue
        if s.startswith(">"):
            flush_para()
            out.append(Paragraph(markup(s.lstrip(">").strip()), st["quote"]))
            continue
        bullet = re.match(r"^[-*]\s+(.*)", s)
        number = re.match(r"^(\d+)\.\s+(.*)", s)
        if bullet:
            flush_para()
            out.append(Paragraph(markup(bullet.group(1)), st["bullet"], bulletText="\u2022"))
            continue
        if number:
            flush_para()
            out.append(
                Paragraph(markup(number.group(2)), st["bullet"], bulletText=f"{number.group(1)}.")
            )
            continue
        para.append(s)
    flush_para()
    flush_table()
    return out


def main():
    register_fonts()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    text = SOURCE.read_text(encoding="utf-8")
    first = next(line[2:].strip() for line in text.splitlines() if line.startswith("# "))
    parts = first.split("\uff1a", 1)
    cover_title = parts[0]
    cover_subtitle = parts[1] if len(parts) == 2 else ""
    st = styles()
    doc = ReportDoc(
        str(OUTPUT),
        header=cover_title,
        pagesize=A4,
        leftMargin=17 * mm,
        rightMargin=17 * mm,
        topMargin=18 * mm,
        bottomMargin=16 * mm,
        title=first,
        author="Codex",
        subject="Haldane sphere chiral graviton NQS research synthesis",
    )
    story = [
        Spacer(1, 22 * mm),
        Paragraph(markup(cover_title), st["cover"]),
        Spacer(1, 3 * mm),
        Paragraph(markup(cover_subtitle), st["cover"]),
        Spacer(1, 10 * mm),
        HRFlowable(width="26%", thickness=3, color=CYAN, hAlign="LEFT"),
        Spacer(1, 9 * mm),
        Paragraph(
            "Research synthesis for advisor comparison<br/>"
            "Haldane sphere / nu=1/3 / strict LLL / SU(2) tensor NQS<br/>"
            "2026-07-30",
            st["cover_sub"],
        ),
        Spacer(1, 28 * mm),
        CoverBand(doc.width),
        Spacer(1, 28 * mm),
        Paragraph(
            "Evidence labels: A confirmed / B conditional / C negative or failed / D pending.",
            st["small"],
        ),
        PageBreak(),
        Paragraph("CONTENTS / \u76ee\u5f55", st["toc_title"]),
    ]
    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle(
            "toc0",
            fontName="CJK",
            fontSize=9.2,
            leading=14,
            textColor=INK,
            spaceAfter=1.5 * mm,
        ),
        ParagraphStyle(
            "toc1",
            fontName="CJK",
            fontSize=8,
            leading=11.5,
            textColor=MUTED,
            leftIndent=8 * mm,
        ),
    ]
    story.extend([toc, PageBreak()])
    story.extend(markdown_story(text, st, doc.width, SOURCE.parent))
    doc.multiBuild(story)
    print(OUTPUT)


if __name__ == "__main__":
    main()
