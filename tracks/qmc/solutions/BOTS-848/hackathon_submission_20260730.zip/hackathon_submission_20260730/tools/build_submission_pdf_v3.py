#!/usr/bin/env python3
"""Render REPORT.md with robust plain-text math normalization."""

from __future__ import annotations

from pathlib import Path

import build_report_texfix as fixed


SUBMISSION = Path(__file__).resolve().parents[1]
ORIGINAL_NORMALIZE = fixed.normalize_fixed
ORIGINAL_REPORT_DOC = fixed.base.ReportDoc


def braced_argument(text: str, start: int) -> tuple[str, int] | None:
    if start >= len(text) or text[start] != "{":
        return None
    depth = 0
    for index in range(start, len(text)):
        character = text[index]
        if character == "{":
            depth += 1
        elif character == "}":
            depth -= 1
            if depth == 0:
                return text[start + 1 : index], index + 1
    return None


def replace_two_argument_command(
    text: str,
    command: str,
    formatter,
) -> str:
    cursor = 0
    while True:
        index = text.find(command, cursor)
        if index < 0:
            return text
        first = braced_argument(text, index + len(command))
        if first is None:
            cursor = index + len(command)
            continue
        second = braced_argument(text, first[1])
        if second is None:
            cursor = first[1]
            continue
        replacement = formatter(first[0], second[0])
        text = text[:index] + replacement + text[second[1] :]
        cursor = index + len(replacement)


def replace_one_argument_command(
    text: str,
    command: str,
    formatter,
) -> str:
    cursor = 0
    while True:
        index = text.find(command, cursor)
        if index < 0:
            return text
        argument = braced_argument(text, index + len(command))
        if argument is None:
            cursor = index + len(command)
            continue
        replacement = formatter(argument[0])
        text = text[:index] + replacement + text[argument[1] :]
        cursor = index + len(replacement)


def normalize_submission(text: str) -> str:
    text = replace_two_argument_command(
        text,
        r"\frac",
        lambda numerator, denominator: f"({numerator})/({denominator})",
    )
    text = replace_two_argument_command(
        text,
        r"\binom",
        lambda top, bottom: f"C({top},{bottom})",
    )
    text = replace_one_argument_command(
        text,
        r"\sqrt",
        lambda argument: f"sqrt({argument})",
    )
    text = text.replace(r"\bar\rho", "rho_bar")
    text = text.replace(r"\ell", "l")
    text = text.replace(r"\hbar", "hbar")
    return ORIGINAL_NORMALIZE(text)


class SubmissionReportDoc(ORIGINAL_REPORT_DOC):
    def __init__(self, filename, header, **kwargs):
        header = normalize_submission(header)
        if "title" in kwargs:
            kwargs["title"] = normalize_submission(kwargs["title"])
        super().__init__(filename, header, **kwargs)


fixed.normalize_fixed = normalize_submission
fixed.base.normalize = normalize_submission
fixed.base.ReportDoc = SubmissionReportDoc
fixed.base.SOURCE = SUBMISSION / "REPORT.md"
fixed.base.OUTPUT = SUBMISSION / "REPORT.pdf"


if __name__ == "__main__":
    fixed.base.main()
