﻿#!/usr/bin/env python3
"""Rebuild the report with complete TeX-to-Unicode normalization."""

from __future__ import annotations

import html
import re

import build_report_ascii as base


EXTRA = {
    r"\eta": "\u03b7",
    r"\nu": "\u03bd",
    r"\hbar": "\u210f",
    r"\phi": "\u03c6",
    r"\otimes": "\u2297",
    r"\dagger": "\u2020",
    r"\delta": "\u03b4",
    r"\prod": "\u220f",
    r"\ker": "ker",
    r"\max": "max",
    r"\min": "min",
    r"\qquad": "  ",
    r"\left": "",
    r"\right": "",
}


def normalize_fixed(text: str) -> str:
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = text.replace(r"\(", "").replace(r"\)", "")
    text = text.replace(r"\[", "").replace(r"\]", "")
    text = text.replace(r"\bar\rho", "\u03c1\u0304")
    text = re.sub(r"\\sqrt\{([^{}]+)\}", "\u221a(\\1)", text)
    text = re.sub(r"\\sqrt\s*([A-Za-z0-9_\[\].]+)", "\u221a(\\1)", text)
    text = re.sub(r"\\frac\{([^{}]+)\}\{([^{}]+)\}", r"(\1)/(\2)", text)
    text = re.sub(r"\\frac\{([^{}]+)\}([A-Za-z0-9]+)", r"(\1)/(\2)", text)
    for old, new in {**base.MATH, **EXTRA}.items():
        text = text.replace(old, new)
    text = re.sub(r"\\(?:rm|mathrm|text|operatorname)\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\(?:rm|mathrm)\s*", "", text)
    text = text.replace(r"\bar", "bar ")
    text = text.replace(r"\,", " ").replace(r"\;", " ").replace(r"\!", "")
    text = text.replace("\\ ", " ")
    text = text.replace("&", " and ")
    text = re.sub(r"\^\{([^{}]+)\}", r"^(\1)", text)
    text = re.sub(r"_\{([^{}]+)\}", r"_(\1)", text)
    text = text.replace("{", "").replace("}", "")
    text = re.sub(r"\\([A-Za-z]+)", r"\1", text)
    return text.replace("\\", "")


def markup_fixed(text: str) -> str:
    text = normalize_fixed(text)
    codes = []

    def keep_code(match):
        codes.append(match.group(1))
        return f"@@C{len(codes)-1}@@"

    text = re.sub(r"`([^`]+)`", keep_code, text)
    text = html.escape(text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", text)
    text = re.sub(r"\^\(([^()]*)\)", r"<super>\1</super>", text)
    text = re.sub(r"_\(([^()]*)\)", r"<sub>\1</sub>", text)
    text = re.sub(r"\^([0-9]+)", r"<super>\1</super>", text)
    text = re.sub(r"_([0-9]+)", r"<sub>\1</sub>", text)
    for idx, value in enumerate(codes):
        text = text.replace(
            f"@@C{idx}@@",
            f'<font color="#2457A7">{html.escape(value)}</font>',
        )
    return text


base.normalize = normalize_fixed
base.markup = markup_fixed


if __name__ == "__main__":
    base.main()

