#!/usr/bin/env python3
"""A compact DeepHall-style NNVMC experiment for the neutral L=2 mode.

The ansatz follows Qian et al. (PRL 134, 176503):

* Cartesian electron features on the Haldane sphere;
* two Psiformer self-attention blocks;
* LLL monopole-harmonic envelopes;
* one determinant of permutation-equivariant many-electron orbitals;
* the parallel-spin Coulomb-cusp Jastrow used by the public DeepHall code.

This is a deliberately small, dependency-light reimplementation.  It uses Adam
instead of the paper's KFAC optimizer because the current environment already
contains JAX/Flax/Optax but not kfac-jax.  The physical ansatz is unchanged.

For the excited state, the paper's angular-momentum penalty machinery is used:
target M=Lz=2 and a small positive L^2 penalty select the lowest L=2 state.
The final reported energy never includes the penalty.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, NamedTuple

import flax.linen as nn
import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax import serialization
from scipy.special import comb


jax.config.update("jax_enable_x64", True)

Array = jax.Array
PyTree = Any


def angles_to_xyz(electrons: Array) -> Array:
    theta, phi = electrons[..., 0], electrons[..., 1]
    return jnp.stack(
        [
            jnp.sin(theta) * jnp.cos(phi),
            jnp.sin(theta) * jnp.sin(phi),
            jnp.cos(theta),
        ],
        axis=-1,
    )


def xyz_to_angles(xyz: Array) -> Array:
    xyz = xyz / jnp.linalg.norm(xyz, axis=-1, keepdims=True)
    theta = jnp.arccos(jnp.clip(xyz[..., 2], -1.0, 1.0))
    phi = jnp.arctan2(xyz[..., 1], xyz[..., 0])
    return jnp.stack([theta, phi], axis=-1)


class DeepHallPsiformer(nn.Module):
    """Public DeepHall Psiformer ansatz, restricted to fully polarized states."""

    particles: int
    two_q: int
    num_heads: int = 4
    head_dim: int = 16
    num_layers: int = 2

    @nn.compact
    def __call__(self, electrons: Array) -> Array:
        theta, phi = electrons[..., 0], electrons[..., 1]
        xyz = angles_to_xyz(electrons)
        spins = jnp.ones((self.particles, 1), dtype=xyz.dtype)
        one_electron = jnp.concatenate([xyz, spins], axis=-1)

        attention_dim = self.num_heads * self.head_dim
        h = nn.Dense(
            attention_dim, use_bias=False, name="input_projection"
        )(one_electron)
        for layer in range(self.num_layers):
            attn = nn.MultiHeadAttention(
                num_heads=self.num_heads,
                qkv_features=attention_dim,
                out_features=attention_dim,
                name=f"attention_{layer}",
            )(h)
            h = nn.LayerNorm(
                epsilon=1.0e-5, name=f"attention_norm_{layer}"
            )(
                h
                + nn.Dense(
                    attention_dim,
                    use_bias=False,
                    name=f"attention_projection_{layer}",
                )(attn)
            )
            h = nn.LayerNorm(
                epsilon=1.0e-5, name=f"mlp_norm_{layer}"
            )(
                h
                + jnp.tanh(
                    nn.Dense(attention_dim, name=f"mlp_{layer}")(h)
                )
            )

        norbitals = self.two_q + 1
        real_weights = nn.DenseGeneral(
            features=(norbitals, self.particles),
            name="orbital_weights_real",
        )(h)
        imag_weights = nn.DenseGeneral(
            features=(norbitals, self.particles),
            name="orbital_weights_imag",
        )(h)
        weights = real_weights + 1j * imag_weights

        q = self.two_q / 2.0
        m = jnp.arange(-q, q + 1)
        norm_factor = jnp.asarray(
            np.sqrt(comb(self.two_q, q - np.arange(-q, q + 1))),
            dtype=theta.dtype,
        )
        u = (
            jnp.cos(theta / 2.0) * jnp.exp(0.5j * phi)
        )[..., jnp.newaxis]
        v = (
            jnp.sin(theta / 2.0) * jnp.exp(-0.5j * phi)
        )[..., jnp.newaxis]
        envelope = norm_factor * u ** (q + m) * v ** (q - m)
        orbital_matrix = jnp.sum(
            weights * envelope[..., jnp.newaxis], axis=1
        )

        # The installed CUDA plugin lacks the small-matrix cuSolver custom
        # call used by jnp.linalg.slogdet.  For the intended N=4 validation,
        # the exact Leibniz formula is inexpensive and mathematically
        # identical to a one-determinant ansatz.
        permutations = np.asarray(
            list(itertools.permutations(range(self.particles))), dtype=np.int32
        )
        signs = np.asarray(
            [
                -1.0
                if sum(
                    permutation[i] > permutation[j]
                    for i in range(self.particles)
                    for j in range(i + 1, self.particles)
                )
                % 2
                else 1.0
                for permutation in permutations
            ]
        )
        rows = jnp.arange(self.particles)[jnp.newaxis, :]
        determinant = jnp.sum(
            jnp.asarray(signs)
            * jnp.prod(orbital_matrix[rows, jnp.asarray(permutations)], axis=1)
        )
        logdet = jnp.log(determinant)

        # Same parallel-spin cusp factor as public DeepHall.  Distances here
        # are unit-sphere chord distances, matching the official code.
        pair_i, pair_j = jnp.triu_indices(self.particles, k=1)
        upper = jnp.linalg.norm(xyz[pair_i] - xyz[pair_j], axis=-1)
        cusp_a = self.param("cusp_a", nn.initializers.ones, (1,))
        jastrow = jnp.sum(-(0.25 * cusp_a**2) / (cusp_a + upper))
        return logdet + jastrow


class AngularObservables(NamedTuple):
    kinetic: Array
    lz: Array
    lz2: Array
    l2: Array


def local_kinetic_and_angular(
    apply_fn: Any,
    params: PyTree,
    electrons: Array,
    two_q: int,
) -> AngularObservables:
    """DeepHall local kinetic energy and total-angular-momentum diagnostics."""

    q = two_q / 2.0
    radius = jnp.sqrt(q)
    theta, phi = electrons[..., 0], electrons[..., 1]
    safe_sin = jnp.maximum(jnp.sin(theta), 1.0e-8)
    safe_tan = jnp.where(
        jnp.abs(jnp.tan(theta)) < 1.0e-8,
        jnp.sign(jnp.tan(theta)) * 1.0e-8 + 1.0e-8,
        jnp.tan(theta),
    )

    real_log = lambda x: apply_fn(params, x).real
    imag_log = lambda x: apply_fn(params, x).imag
    grad_real = jax.grad(real_log)(electrons)
    grad_imag = jax.grad(imag_log)(electrons)
    hess_real = jax.hessian(real_log)(electrons)
    hess_imag = jax.hessian(imag_log)(electrons)
    grad_theta = grad_real[..., 0] + 1j * grad_imag[..., 0]
    grad_phi = grad_real[..., 1] + 1j * grad_imag[..., 1]
    hess_logpsi = hess_real + 1j * hess_imag

    square_grad = jnp.sum(
        grad_theta**2 + grad_phi**2 / safe_sin**2
    )
    lapl_log = jnp.sum(
        grad_theta / safe_tan
        + jnp.diagonal(hess_logpsi[:, 0, :, 0])
        + jnp.diagonal(hess_logpsi[:, 1, :, 1]) / safe_sin**2
    )
    magnetic = jnp.sum(
        (q / safe_tan) ** 2
        + 2j * q * jnp.cos(theta) / safe_sin**2 * grad_phi
    )
    kinetic = (-lapl_log - square_grad + magnetic) / (2.0 * radius**2)

    r_hat = jnp.stack(
        [
            jnp.sin(theta) * jnp.cos(phi),
            jnp.sin(theta) * jnp.sin(phi),
            jnp.cos(theta),
        ]
    )
    phi_hat = jnp.stack(
        [-jnp.sin(phi), jnp.cos(phi), jnp.zeros_like(phi)]
    )
    theta_hat_prime = jnp.stack(
        [
            jnp.cos(phi) / safe_tan,
            jnp.sin(phi) / safe_tan,
            -jnp.ones_like(theta),
        ]
    )
    hess_theta_theta = (
        hess_logpsi[:, 0, :, 0]
        + grad_theta[..., :, jnp.newaxis] * grad_theta[..., jnp.newaxis, :]
    )
    hess_theta_phi = (
        hess_logpsi[:, 0, :, 1]
        + grad_theta[..., :, jnp.newaxis] * grad_phi[..., jnp.newaxis, :]
    )
    hess_phi_phi = (
        hess_logpsi[:, 1, :, 1]
        + grad_phi[..., :, jnp.newaxis] * grad_phi[..., jnp.newaxis, :]
    )
    magnetic_term = q * (
        theta_hat_prime * jnp.cos(theta) + r_hat
    )
    l2 = jnp.sum(
        2
        * phi_hat[..., :, jnp.newaxis]
        * theta_hat_prime[..., jnp.newaxis, :]
        * hess_theta_phi
        - phi_hat[..., :, jnp.newaxis]
        * phi_hat[..., jnp.newaxis, :]
        * hess_theta_theta
        - theta_hat_prime[..., :, jnp.newaxis]
        * theta_hat_prime[..., jnp.newaxis, :]
        * hess_phi_phi
        - 2j
        * magnetic_term[..., jnp.newaxis, :]
        * (
            phi_hat[..., :, jnp.newaxis]
            * grad_theta[..., :, jnp.newaxis]
            - theta_hat_prime[..., :, jnp.newaxis]
            * grad_phi[..., :, jnp.newaxis]
        )
        + magnetic_term[..., :, jnp.newaxis]
        * magnetic_term[..., jnp.newaxis, :]
    ) - jnp.sum(grad_theta / safe_tan)

    return AngularObservables(
        kinetic=kinetic,
        lz=jnp.sum(grad_phi).imag,
        lz2=-jnp.sum(hess_phi_phi).real,
        l2=l2.real,
    )


def potential_energy(
    electrons: Array,
    two_q: int,
    width_lB: float,
) -> Array:
    """Pair interaction in e^2/(epsilon*l_B)."""

    xyz = angles_to_xyz(electrons)
    cosine = xyz @ xyz.T
    radius2 = two_q / 2.0
    distance2 = radius2 * jnp.maximum(2.0 - 2.0 * cosine, 0.0)
    softened = jnp.sqrt(distance2 + width_lB**2)
    return jnp.sum(jnp.triu(1.0 / softened, k=1))


def local_energy_and_observables(
    apply_fn: Any,
    params: PyTree,
    electrons: Array,
    two_q: int,
    kappa: float,
    width_lB: float,
) -> tuple[Array, AngularObservables, Array]:
    observables = local_kinetic_and_angular(
        apply_fn, params, electrons, two_q
    )
    potential = potential_energy(electrons, two_q, width_lB)
    energy = observables.kinetic + kappa * potential
    return energy, observables, potential


def uniform_configurations(
    key: Array, batch: int, particles: int
) -> Array:
    key_z, key_phi = jax.random.split(key)
    z = jax.random.uniform(
        key_z, (batch, particles), minval=-1.0, maxval=1.0
    )
    phi = jax.random.uniform(
        key_phi, (batch, particles), minval=-jnp.pi, maxval=jnp.pi
    )
    return jnp.stack([jnp.arccos(z), phi], axis=-1)


def propose_geodesic(
    key: Array, electrons: Array, step_size: float
) -> Array:
    """Symmetric isotropic random rotations for all electrons."""

    key_direction, key_angle = jax.random.split(key)
    xyz = angles_to_xyz(electrons)
    noise = jax.random.normal(key_direction, xyz.shape)
    tangent = noise - jnp.sum(noise * xyz, axis=-1, keepdims=True) * xyz
    tangent /= jnp.maximum(
        jnp.linalg.norm(tangent, axis=-1, keepdims=True), 1.0e-12
    )
    angle = step_size * jax.random.normal(
        key_angle, xyz.shape[:-1] + (1,)
    )
    proposal = jnp.cos(angle) * xyz + jnp.sin(angle) * tangent
    return xyz_to_angles(proposal)


@dataclass
class RunConfig:
    sector: str = "ground"
    particles: int = 4
    kappa: float = 1.0
    width_lB: float = 0.0
    num_heads: int = 4
    head_dim: int = 16
    num_layers: int = 2
    batch_size: int = 64
    burn_in: int = 100
    mcmc_steps: int = 5
    iterations: int = 400
    learning_rate: float = 2.0e-3
    step_size: float = 0.08
    lz_penalty: float = 0.20
    l2_penalty: float = 0.02
    eval_blocks: int = 100
    eval_mcmc_steps: int = 10
    seed: int = 20260730

    @property
    def two_q(self) -> int:
        return 3 * (self.particles - 1)

    @property
    def target_lz(self) -> float:
        return 0.0 if self.sector == "ground" else 2.0

    @property
    def active_lz_penalty(self) -> float:
        return 0.0 if self.sector == "ground" else self.lz_penalty


def iqr_clip_real(x: Array, scale: float = 100.0) -> Array:
    """DeepHall's robust clipping of a local observable."""
    q1 = jnp.nanquantile(x, 0.25)
    q3 = jnp.nanquantile(x, 0.75)
    iqr = q3 - q1
    return jnp.clip(x, q1 - scale * iqr, q3 + scale * iqr)


def iqr_clip(x: Array, scale: float = 100.0) -> Array:
    return iqr_clip_real(x.real, scale) + 1j * iqr_clip_real(x.imag, scale)

def make_runtime(config: RunConfig):
    model = DeepHallPsiformer(
        particles=config.particles,
        two_q=config.two_q,
        num_heads=config.num_heads,
        head_dim=config.head_dim,
        num_layers=config.num_layers,
    )
    local_one = lambda params, x: local_energy_and_observables(
        model.apply,
        params,
        x,
        config.two_q,
        config.kappa,
        config.width_lB,
    )
    local_batch = jax.vmap(local_one, in_axes=(None, 0))
    log_batch = jax.vmap(model.apply, in_axes=(None, 0))

    def mcmc_step(
        params: PyTree, data: Array, key: Array, step_size: Array
    ) -> tuple[Array, Array]:
        proposal = propose_geodesic(key, data, step_size)
        old_logabs = log_batch(params, data).real
        new_logabs = log_batch(params, proposal).real
        key_accept = jax.random.fold_in(key, 1)
        log_uniform = jnp.log(
            jax.random.uniform(key_accept, old_logabs.shape)
        )
        accept = log_uniform < 2.0 * (new_logabs - old_logabs)
        selected = jnp.where(
            accept[:, jnp.newaxis, jnp.newaxis], proposal, data
        )
        return selected, jnp.mean(accept)

    optimizer = optax.chain(
        optax.clip_by_global_norm(5.0),
        optax.adam(config.learning_rate),
    )

    def train_step(
        params: PyTree, opt_state: PyTree, data: Array
    ) -> tuple[PyTree, PyTree, dict[str, Array]]:
        energy, angular, potential = local_batch(params, data)
        energy = jax.lax.stop_gradient(energy)
        angular = jax.tree.map(jax.lax.stop_gradient, angular)
        potential = jax.lax.stop_gradient(potential)

        lz_objective = (
            angular.lz2
            - 2.0 * config.target_lz * angular.lz
            + config.target_lz**2
        )
        local_objective = (
            energy
            + config.active_lz_penalty * lz_objective
            + config.l2_penalty * angular.l2
        )
        clipped_mean = jnp.nanmean(iqr_clip(local_objective))
        centered = jax.lax.stop_gradient(
            iqr_clip(local_objective - clipped_mean)
        )

        def surrogate(current_params: PyTree) -> Array:
            logpsi = log_batch(current_params, data)
            return 2.0 * jnp.nanmean(
                jnp.real(centered * jnp.conj(logpsi))
            )

        gradients = jax.grad(surrogate)(params)
        updates, opt_state = optimizer.update(
            gradients, opt_state, params
        )
        params = optax.apply_updates(params, updates)
        stats = {
            "energy": jnp.nanmean(energy.real),
            "energy_imag": jnp.nanmean(energy.imag),
            "variance": jnp.nanvar(energy.real),
            "kinetic": jnp.nanmean(angular.kinetic.real),
            "potential": jnp.nanmean(potential),
            "lz": jnp.nanmean(angular.lz),
            "lz2": jnp.nanmean(angular.lz2),
            "l2": jnp.nanmean(angular.l2),
            "penalized_objective": jnp.nanmean(local_objective.real),
        }
        return params, opt_state, stats

    return (
        model,
        local_batch,
        jax.jit(mcmc_step),
        optimizer,
        jax.jit(train_step),
    )


def adapt_step_size(
    step_size: float, acceptance: float, target: float = 0.55
) -> float:
    return float(
        np.clip(step_size * math.exp(0.05 * (acceptance - target)), 0.005, 0.5)
    )


def run(config: RunConfig, output_dir: Path, restore_path: Path | None = None) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    model, local_batch, mcmc_step, optimizer, train_step = make_runtime(config)
    key = jax.random.PRNGKey(config.seed)
    key, data_key, params_key = jax.random.split(key, 3)
    data = uniform_configurations(
        data_key, config.batch_size, config.particles
    )
    params = model.init(params_key, data[0])
    if restore_path is not None:
        params = serialization.from_bytes(params, restore_path.read_bytes())
        print(f"restored parameters: {restore_path.resolve()}")
    opt_state = optimizer.init(params)
    parameter_count = sum(x.size for x in jax.tree.leaves(params))
    step_size = config.step_size

    # Compile before timing.
    key, subkey = jax.random.split(key)
    data, acceptance = mcmc_step(params, data, subkey, step_size)
    jax.block_until_ready(data)

    for _ in range(config.burn_in):
        key, subkey = jax.random.split(key)
        data, acceptance = mcmc_step(params, data, subkey, step_size)
        step_size = adapt_step_size(step_size, float(acceptance))

    history_path = output_dir / "training.csv"
    start = time.perf_counter()
    with history_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "iteration",
                "energy",
                "energy_imag",
                "variance",
                "kinetic",
                "potential",
                "lz",
                "lz2",
                "l2",
                "penalized_objective",
                "acceptance",
                "step_size",
            ],
        )
        writer.writeheader()
        for iteration in range(config.iterations):
            acceptances = []
            for _ in range(config.mcmc_steps):
                key, subkey = jax.random.split(key)
                data, acceptance = mcmc_step(
                    params, data, subkey, step_size
                )
                acceptances.append(float(acceptance))
            mean_acceptance = float(np.mean(acceptances))
            step_size = adapt_step_size(step_size, mean_acceptance)
            params, opt_state, stats = train_step(params, opt_state, data)
            stats = {
                name: float(np.asarray(value)) for name, value in stats.items()
            }
            writer.writerow(
                {
                    "iteration": iteration,
                    **stats,
                    "acceptance": mean_acceptance,
                    "step_size": step_size,
                }
            )
            if iteration % 25 == 0 or iteration + 1 == config.iterations:
                print(
                    f"{config.sector:6s} step={iteration:4d} "
                    f"E={stats['energy']:.7f} "
                    f"K={stats['kinetic']:.6f} "
                    f"V={stats['potential']:.6f} "
                    f"<Lz>={stats['lz']:.4f} "
                    f"<L2>={stats['l2']:.4f} "
                    f"acc={mean_acceptance:.3f}"
                )

    eval_rows = []
    for block in range(config.eval_blocks):
        block_acceptance = []
        for _ in range(config.eval_mcmc_steps):
            key, subkey = jax.random.split(key)
            data, acceptance = mcmc_step(
                params, data, subkey, step_size
            )
            block_acceptance.append(float(acceptance))
        energy, angular, potential = local_batch(params, data)
        eval_rows.append(
            {
                "block": block,
                "energy": float(jnp.nanmean(energy.real)),
                "energy_imag": float(jnp.nanmean(energy.imag)),
                "kinetic": float(jnp.nanmean(angular.kinetic.real)),
                "potential": float(jnp.nanmean(potential)),
                "lz": float(jnp.nanmean(angular.lz)),
                "lz2": float(jnp.nanmean(angular.lz2)),
                "l2": float(jnp.nanmean(angular.l2)),
                "acceptance": float(np.mean(block_acceptance)),
            }
        )

    eval_path = output_dir / "evaluation_blocks.csv"
    with eval_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(eval_rows[0]))
        writer.writeheader()
        writer.writerows(eval_rows)

    def mean_error(name: str) -> tuple[float, float]:
        values = np.asarray([row[name] for row in eval_rows])
        return float(values.mean()), float(values.std(ddof=1) / math.sqrt(len(values)))

    energy_mean, energy_stderr = mean_error("energy")
    summary = {
        "config": asdict(config),
        "two_q": config.two_q,
        "sphere_radius_lB": math.sqrt(config.two_q / 2.0),
        "paper_density_factor": math.sqrt(
            config.two_q / (3.0 * config.particles)
        ),
        "parameter_count": parameter_count,
        "runtime_seconds": time.perf_counter() - start,
        "energy": energy_mean,
        "energy_stderr": energy_stderr,
        "kinetic": mean_error("kinetic")[0],
        "potential": mean_error("potential")[0],
        "lz": mean_error("lz")[0],
        "lz2": mean_error("lz2")[0],
        "l2": mean_error("l2")[0],
        "acceptance": mean_error("acceptance")[0],
        "note": (
            "Reported energy excludes Lz/L2 penalties. width_lB=0 is the "
            "paper Hamiltonian; nonzero width is an optional toy finite-"
            "thickness interaction."
        ),
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    (output_dir / "checkpoint.msgpack").write_bytes(
        serialization.to_bytes(params)
    )
    print(json.dumps(summary, indent=2))
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sector", choices=["ground", "l2"], required=True)
    parser.add_argument("-N", "--particles", type=int, default=4)
    parser.add_argument("--kappa", type=float, default=1.0)
    parser.add_argument("--width-lB", type=float, default=0.0)
    parser.add_argument("--num-heads", type=int, default=4)
    parser.add_argument("--head-dim", type=int, default=16)
    parser.add_argument("--num-layers", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--burn-in", type=int, default=100)
    parser.add_argument("--mcmc-steps", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=400)
    parser.add_argument("--learning-rate", type=float, default=2.0e-3)
    parser.add_argument("--step-size", type=float, default=0.08)
    parser.add_argument("--lz-penalty", type=float, default=0.20)
    parser.add_argument("--l2-penalty", type=float, default=0.02)
    parser.add_argument("--eval-blocks", type=int, default=100)
    parser.add_argument("--eval-mcmc-steps", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--restore", type=Path, default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = RunConfig(
        sector=args.sector,
        particles=args.particles,
        kappa=args.kappa,
        width_lB=args.width_lB,
        num_heads=args.num_heads,
        head_dim=args.head_dim,
        num_layers=args.num_layers,
        batch_size=args.batch_size,
        burn_in=args.burn_in,
        mcmc_steps=args.mcmc_steps,
        iterations=args.iterations,
        learning_rate=args.learning_rate,
        step_size=args.step_size,
        lz_penalty=args.lz_penalty,
        l2_penalty=args.l2_penalty,
        eval_blocks=args.eval_blocks,
        eval_mcmc_steps=args.eval_mcmc_steps,
        seed=args.seed,
    )
    run(config, args.output_dir, args.restore)


if __name__ == "__main__":
    main()
