# DeepHall 两层 ansatz 的最小 \(L=2\) 实验

这个目录回答一个很具体的问题：此前严格 LLL–\(SU(2)\) NQS 是否做得过于复杂；若固定使用陈基组 DeepHall 的实空间 ansatz，在最小的
\(N=4,\nu=1/3,2Q=9\) case 上，能否稳定得到 \(L=0\) 基态、\(L=2\)
中性激发和 gap？

## 物理定义

论文 ansatz 为

\[
\Psi_\theta=e^{J}\det[\varphi_i(\mathbf r_j;\{\mathbf r_{\ne j}\})],
\]

\[
\varphi_i=\sum_{k,m}w_{ikm}f_k(\mathbf r_j;\{\mathbf r_{\ne j}\})
u_j^{Q+m}v_j^{Q-m}.
\]

本目录固定：

- 两层 Psiformer；
- 单 determinant；
- LLL monopole-harmonic envelope；
- DeepHall 的平行自旋 Coulomb-cusp Jastrow；
- 基态用正的 \(L^2\) penalty 稳定到 \(L=0\)；
- 激发态用 \((L_z-2)^2\) 加正的 \(L^2\) penalty，选最低
  \(M=2,L=2\) 态；
- 最终能量不含 penalty。

论文 Hamiltonian 的相互作用仍然是球面 chord-distance Coulomb：

\[
V_0(r)=1/r.
\]

论文中出现的根号主要来自

\[
R=\sqrt{Q}\ell_B,\quad
E_{\rm bg}=-\frac{N^2}{2\sqrt Q}E_C,\quad
E_c=\sqrt{\frac{2Q\nu}{N}}(E_v+E_{\rm bg}-N\omega_c/2).
\]

它们是几何、背景电荷与有限尺寸 density correction，不是 soft
Coulomb。为了检验实验有限厚度的可能影响，代码另提供一个明确标注为
toy model 的可选势：

\[
V_w(r)=\frac{1}{\sqrt{r^2+w^2}}.
\]

## 文件

- `deephall_minimal.py`：两层 DeepHall-style NNVMC；
- `ed_softened_gap.py`：纯 Coulomb/有限厚度势的 LLL ED 基准；
- `summarize_gap.py`：合并独立的 ground 与 \(L=2\) 结果；
- `test_minimal.py`：反对称性、势能和投影相互作用测试。

当前环境缺少 `kfac-jax`，因此最小实现用 Adam；ansatz 没变，但优化器与论文不同。默认 `head_dim=16` 是为了快速验证；论文公开代码默认
`4 heads × 64 dimensions × 2 layers × 1 determinant`，正式复算时可用
`--head-dim 64`。

## 运行

```bash
python ed_softened_gap.py -N 4 --widths 0 0.5 1.0 \
  --output results/ed_width_scan_N4.json

python deephall_minimal.py --sector ground -N 4 --kappa 1 \
  --width-lB 0 --output-dir results/coulomb_ground

python deephall_minimal.py --sector l2 -N 4 --kappa 1 \
  --width-lB 0 --output-dir results/coulomb_l2

python summarize_gap.py \
  results/coulomb_ground/summary.json \
  results/coulomb_l2/summary.json \
  --output results/coulomb_gap.json
```

有限厚度实验把两条 NNVMC 命令中的 `--width-lB 0` 同时改成例如
`--width-lB 0.5`，并重新训练两个 sector。

## 解释限制

DeepHall 原论文计算的是基态、准粒子/准空穴和 transport gap，没有报告
同磁通的中性 \(L=2\) graviton gap。本目录对 \(L=2\) 的选择是沿用其公开
代码已有的 \(L_z\) 与 \(L^2\) penalty 机制。只有当最终
\(\langle L_z\rangle\approx2\) 且 \(\langle L^2\rangle\approx6\) 时，所得
能量差才可解释为 neutral \(L=2\) gap。
