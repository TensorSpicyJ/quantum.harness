#!/usr/bin/env python3
"""Strict-L=2 LLL cross-check for the softened interaction.

This is not the DeepHall/Psiformer ansatz.  It reuses the repository's
symmetry-exact two-channel (lmax=2) first-quantized tensor NQS so that a failed
angular-momentum penalty optimization cannot be mistaken for a physical gap.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from strict_first_quantized_tensor_nqs import (  # noqa: E402
    collect_laughlin_samples,
    estimate_matrices,
    make_feature_function,
    solve_linear_method,
    weighted_statistics,
)


def softened_potential(spinors: jax.Array, two_q: int, width_lB: float) -> jax.Array:
    """Return sum 1/sqrt(r_ij^2+w^2) in e^2/(epsilon*l_B)."""

    u, v = spinors[..., 0], spinors[..., 1]
    pair_i, pair_j = jnp.triu_indices(spinors.shape[-2], k=1)
    chord_squared = 4.0 * jnp.abs(
        u[..., pair_i] * v[..., pair_j] - v[..., pair_i] * u[..., pair_j]
    ) ** 2
    radius_squared = two_q / 2.0
    distance_squared = radius_squared * chord_squared
    return jnp.sum(
        1.0 / jnp.sqrt(distance_squared + width_lB**2), axis=-1
    )


def run_width(
    coordinates: np.ndarray,
    features: np.ndarray,
    width_lB: float,
    particles: int,
    chains: int,
    records: int,
    training_records: int,
    whitening_tolerance: float,
) -> dict[str, float | int]:
    potential = np.asarray(
        jax.device_get(
            softened_potential(
                jnp.asarray(coordinates), 3 * (particles - 1), width_lB
            )
        )
    )
    split = training_records * chains
    training_features, validation_features = features[:split], features[split:]
    training_potential, validation_potential = potential[:split], potential[split:]
    overlap, hamiltonian = estimate_matrices(
        training_features, training_potential
    )
    _, coefficients, rank = solve_linear_method(
        overlap, hamiltonian, whitening_tolerance
    )
    excited, excited_stderr, _, validation_fraction = weighted_statistics(
        validation_features,
        validation_potential,
        coefficients,
        chains,
        records - training_records,
    )
    validation_records = records - training_records
    ground_by_chain = validation_potential.reshape(
        validation_records, chains
    ).mean(axis=0)
    ground = float(ground_by_chain.mean())
    ground_stderr = float(
        ground_by_chain.std(ddof=1) / math.sqrt(chains)
    )
    amplitude = validation_features @ coefficients
    weights = np.square(np.abs(amplitude)).reshape(
        validation_records, chains
    )
    potential_by_record_chain = validation_potential.reshape(
        validation_records, chains
    )
    excited_by_chain = np.sum(
        weights * potential_by_record_chain, axis=0
    ) / np.maximum(np.sum(weights, axis=0), 1.0e-300)
    correlated_gap_stderr = float(
        np.std(excited_by_chain - ground_by_chain, ddof=1)
        / math.sqrt(chains)
    )
    return {
        "width_lB": width_lB,
        "ground_energy": ground,
        "ground_stderr": ground_stderr,
        "excited_energy": excited,
        "excited_stderr": excited_stderr,
        "gap": excited - ground,
        "gap_stderr_independent": math.hypot(
            ground_stderr, excited_stderr
        ),
        "gap_stderr_correlated_chain": correlated_gap_stderr,
        "retained_rank": rank,
        "validation_ess_fraction": validation_fraction,
        "ground_L2": 0.0,
        "excited_L2": 6.0,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--widths", nargs="+", type=float, default=[0.0, 1.5])
    parser.add_argument("--particles", type=int, default=4)
    parser.add_argument("--chains", type=int, default=128)
    parser.add_argument("--burn-sweeps", type=int, default=500)
    parser.add_argument("--records", type=int, default=256)
    parser.add_argument("--training-records", type=int, default=128)
    parser.add_argument("--thin-sweeps", type=int, default=5)
    parser.add_argument("--feature-batch", type=int, default=128)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-9)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not 0 < args.training_records < args.records:
        raise ValueError("training-records must lie strictly inside records")

    started = time.perf_counter()
    feature_function, labels = make_feature_function(args.particles, lmax=2)
    coordinates, _, acceptance = collect_laughlin_samples(
        args.particles,
        args.chains,
        args.burn_sweeps,
        args.records,
        args.thin_sweeps,
        0.9,
        args.seed,
    )
    batches = []
    for start in range(0, len(coordinates), args.feature_batch):
        batches.append(
            np.asarray(
                jax.device_get(
                    feature_function(
                        jnp.asarray(coordinates[start : start + args.feature_batch])
                    )
                )
            )
        )
    features = np.concatenate(batches)
    results = [
        run_width(
            coordinates,
            features,
            width,
            args.particles,
            args.chains,
            args.records,
            args.training_records,
            args.whitening_tolerance,
        )
        for width in args.widths
    ]
    payload = {
        "method": "strict symmetry cross-check; not the DeepHall ansatz",
        "ansatz": "Laughlin ground and lmax=2 two-channel tensor NQS excited state",
        "channel_labels": labels,
        "particles": args.particles,
        "two_q": 3 * (args.particles - 1),
        "acceptance": acceptance,
        "runtime_seconds": time.perf_counter() - started,
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    for row in results:
        print(
            f"w={row['width_lB']:.3f} "
            f"E0={row['ground_energy']:.8f} "
            f"E2={row['excited_energy']:.8f} "
            f"gap={row['gap']:.8f} +/- "
            f"{row['gap_stderr_correlated_chain']:.2e} "
            f"ESS={row['validation_ess_fraction']:.3f}"
        )
    print(f"saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()
