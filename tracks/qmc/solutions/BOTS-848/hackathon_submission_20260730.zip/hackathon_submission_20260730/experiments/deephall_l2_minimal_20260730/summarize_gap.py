#!/usr/bin/env python3
"""Combine independently evaluated ground and L=2 DeepHall runs."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ground", type=Path)
    parser.add_argument("excited", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    ground = json.loads(args.ground.read_text(encoding="utf-8"))
    excited = json.loads(args.excited.read_text(encoding="utf-8"))
    if ground["config"]["particles"] != excited["config"]["particles"]:
        raise ValueError("particle counts differ")
    if ground["config"]["width_lB"] != excited["config"]["width_lB"]:
        raise ValueError("potentials differ")
    if ground["config"]["kappa"] != excited["config"]["kappa"]:
        raise ValueError("kappa values differ")

    gap = excited["energy"] - ground["energy"]
    gap_stderr = math.hypot(
        excited["energy_stderr"], ground["energy_stderr"]
    )
    factor = ground["paper_density_factor"]
    result = {
        "particles": ground["config"]["particles"],
        "two_q": ground["two_q"],
        "kappa": ground["config"]["kappa"],
        "width_lB": ground["config"]["width_lB"],
        "ground_energy_hbar_omega_c": ground["energy"],
        "excited_energy_hbar_omega_c": excited["energy"],
        "gap_hbar_omega_c": gap,
        "gap_stderr_hbar_omega_c": gap_stderr,
        "gap_Ec": gap / ground["config"]["kappa"],
        "gap_stderr_Ec": gap_stderr / ground["config"]["kappa"],
        "paper_density_factor": factor,
        "gap_density_corrected_Ec": factor
        * gap
        / ground["config"]["kappa"],
        "gap_density_corrected_stderr_Ec": factor
        * gap_stderr
        / ground["config"]["kappa"],
        "ground_L2": ground["l2"],
        "excited_Lz": excited["lz"],
        "excited_L2": excited["l2"],
        "warning": (
            "A valid neutral L=2 interpretation requires excited_Lz≈2 and "
            "excited_L2≈6. The paper itself did not report this neutral gap."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
