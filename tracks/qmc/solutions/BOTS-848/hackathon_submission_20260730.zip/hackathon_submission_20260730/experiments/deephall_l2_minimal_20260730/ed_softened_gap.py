#!/usr/bin/env python3
"""Small LLL exact-diagonalization reference for softened spherical Coulomb.

This file deliberately reuses the transparent angular-momentum algebra in the
parent project.  The only new ingredient is a Legendre expansion of

    V_w(r_12) = 1 / sqrt(r_12**2 + w**2),

where distances are measured in magnetic lengths.  ``w=0`` is the
chord-distance Coulomb interaction used in the DeepHall paper.  Non-zero ``w``
is an optional finite-thickness toy model; it is not part of the paper.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from numpy.polynomial.legendre import leggauss, legval


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from chiral_graviton_ed import (  # noqa: E402
    _phase,
    antisymmetric_pair_matrix,
    clebsch_gordan2,
    coulomb_pseudopotentials,
    fock_basis,
    lowest_with_L,
    many_body_hamiltonian,
    orbital_two_m,
    solve_sector,
    wigner_3j2,
)


def soft_coulomb_legendre_weights(
    two_q: int,
    width_lB: float,
    quadrature_order: int = 512,
) -> np.ndarray:
    """Return multipole weights relative to spherical chord Coulomb.

    The generating function gives

        1 / sqrt(2 - 2 x) = sum_k P_k(x),

    so all Coulomb weights are exactly one.  For finite ``width_lB``, the
    dimensionless softening entering the unit-sphere kernel is w/R.
    """

    if two_q <= 0:
        raise ValueError("two_q must be positive")
    if width_lB < 0:
        raise ValueError("width_lB must be non-negative")
    if width_lB == 0:
        return np.ones(two_q + 1)

    radius_lB = math.sqrt(two_q / 2.0)
    delta = width_lB / radius_lB
    x, weight = leggauss(quadrature_order)
    kernel = 1.0 / np.sqrt(2.0 - 2.0 * x + delta**2)
    result = np.empty(two_q + 1)
    for k in range(two_q + 1):
        coefficients = np.zeros(k + 1)
        coefficients[-1] = 1.0
        pk = legval(x, coefficients)
        result[k] = 0.5 * (2 * k + 1) * np.sum(weight * pk * kernel)
    return result


def central_product_element(
    two_q: int,
    tma: int,
    tmb: int,
    tmc: int,
    tmd: int,
    multipole_weights: np.ndarray,
) -> float:
    """Projected product-basis matrix element for a central interaction."""

    if tma + tmb != tmc + tmd:
        return 0.0
    if len(multipole_weights) < two_q + 1:
        raise ValueError("need multipole weights through k=2Q")

    transfer = (tmc - tma) // 2
    phase_exponent = two_q - (tma + tmb) // 2
    prefactor = (two_q + 1.0) ** 2 / math.sqrt(two_q / 2.0)
    total = 0.0
    for k in range(two_q + 1):
        charge_symbol = wigner_3j2(two_q, 2 * k, two_q, -two_q, 0, two_q)
        if abs(charge_symbol) < 1.0e-16:
            continue
        first = wigner_3j2(two_q, 2 * k, two_q, tma, 2 * transfer, -tmc)
        second = wigner_3j2(two_q, 2 * k, two_q, tmb, -2 * transfer, -tmd)
        total += (
            multipole_weights[k]
            * _phase(-transfer)
            * first
            * second
            * charge_symbol**2
        )
    return prefactor * _phase(phase_exponent) * total


def central_pseudopotentials(
    two_q: int, multipole_weights: np.ndarray
) -> dict[int, float]:
    """Compute spherical pair pseudopotentials V_J."""

    two_ms = orbital_two_m(two_q)
    result: dict[int, float] = {}
    for pair_L in range(two_q + 1):
        pair_two_M = 2 * pair_L
        product_states = [
            (tma, tmb)
            for tma in two_ms
            for tmb in two_ms
            if tma + tmb == pair_two_M
        ]
        coefficients = np.asarray(
            [
                clebsch_gordan2(
                    two_q, tma, two_q, tmb, 2 * pair_L, pair_two_M
                )
                for tma, tmb in product_states
            ]
        )
        value = 0.0
        for i, (tma, tmb) in enumerate(product_states):
            for j, (tmc, tmd) in enumerate(product_states):
                value += (
                    coefficients[i]
                    * central_product_element(
                        two_q,
                        tma,
                        tmb,
                        tmc,
                        tmd,
                        multipole_weights,
                    )
                    * coefficients[j]
                )
        result[pair_L] = float(value)
    return result


def solve_gap(
    particles: int,
    width_lB: float,
    quadrature_order: int = 512,
) -> dict[str, float | int | list[float]]:
    """Solve the lowest L=0 and L=2 states at nu=1/3."""

    two_q = 3 * (particles - 1)
    if width_lB == 0:
        pseudopotentials = coulomb_pseudopotentials(two_q)
        weights = np.ones(two_q + 1)
    else:
        weights = soft_coulomb_legendre_weights(
            two_q, width_lB, quadrature_order
        )
        pseudopotentials = central_pseudopotentials(two_q, weights)

    pairs, pair_matrix = antisymmetric_pair_matrix(two_q, pseudopotentials)
    result, _, _ = solve_sector(particles, two_q, 0, pairs, pair_matrix)
    index0, energy0 = lowest_with_L(result, 0)
    index2, energy2 = lowest_with_L(result, 2)
    raw_gap = energy2 - energy0
    density_factor = math.sqrt(two_q / (3.0 * particles))

    return {
        "particles": particles,
        "two_q": two_q,
        "width_lB": width_lB,
        "sphere_radius_lB": math.sqrt(two_q / 2.0),
        "energy_L0": energy0,
        "energy_L2": energy2,
        "gap_raw_Ec": raw_gap,
        "paper_density_factor": density_factor,
        "gap_density_corrected_Ec": density_factor * raw_gap,
        "L2_ground": float(result.l2_expectations[index0]),
        "L2_excited": float(result.l2_expectations[index2]),
        "multipole_weights": weights.tolist(),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("-N", "--particles", type=int, default=4)
    parser.add_argument(
        "--widths",
        type=float,
        nargs="+",
        default=[0.0, 0.5, 1.0],
        help="finite-thickness widths w/l_B; zero is paper Coulomb",
    )
    parser.add_argument("--quadrature-order", type=int, default=512)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = [
        solve_gap(args.particles, width, args.quadrature_order)
        for width in args.widths
    ]
    print(
        "width/lB       E(L=0)       E(L=2)       gap raw      "
        "gap density-corrected"
    )
    for row in rows:
        print(
            f"{row['width_lB']:8.3f}  "
            f"{row['energy_L0']:12.8f}  "
            f"{row['energy_L2']:12.8f}  "
            f"{row['gap_raw_Ec']:12.8f}  "
            f"{row['gap_density_corrected_Ec']:12.8f}"
        )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(
            json.dumps(rows, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()
