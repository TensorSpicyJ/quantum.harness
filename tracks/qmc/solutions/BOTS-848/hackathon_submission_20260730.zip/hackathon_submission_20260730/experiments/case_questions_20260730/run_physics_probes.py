#!/usr/bin/env python3
"""Validated numerical probes for Questions 5, 9, 10, and 12.

The script deliberately separates observables that are well defined on a
finite Haldane sphere from claims that require a planar helicity operator, a
continuum limit, or a two-dimensional twisted-boundary parameter space.

Outputs are written to ``case_questions_20260730/results``:

* spherical M=+/-2 covariance (a null test, not a helicity measurement);
* finite-size spectral fragmentation and resolution-dependent FWHM;
* gauge-invariant fidelity susceptibility along a V1/Coulomb path;
* Moore--Read angular-momentum parity and a small three-body-parent pilot;
* exact teacher vectors for the GPU Fock-NQS pilot.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import sys
import time
from pathlib import Path
from typing import Any, Iterable

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import eigsh


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
GEOMETRY_DIR = ROOT / "geometry_chirality_study_20260729"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(GEOMETRY_DIR) not in sys.path:
    sys.path.insert(0, str(GEOMETRY_DIR))

from chiral_graviton_ed import (  # noqa: E402
    _annihilate,
    _create,
    angular_momentum_squared,
    coulomb_pseudopotentials,
    fock_basis,
    orbital_two_m,
)
from chiral_graviton_nqs_vmc_sparse import SparseSectorCache  # noqa: E402
from ed_geometry_suite import (  # noqa: E402
    StateData,
    hamiltonian,
    lanczos_spectrum,
    structure_factor,
    targeted_state,
)


Array = np.ndarray
Sparse = sparse.csr_matrix


def json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(type(value).__name__)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    fields: list[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def normalized(vector: Array) -> Array:
    result = np.asarray(vector, dtype=np.complex128)
    result /= max(float(np.linalg.norm(result)), 1.0e-300)
    pivot = int(np.argmax(np.abs(result)))
    phase = result[pivot] / max(abs(result[pivot]), 1.0e-300)
    return result / phase


def physical_poles(spectrum: dict[str, Any]) -> tuple[Array, Array]:
    omega = np.asarray(spectrum["omega"], dtype=float)
    weights = np.asarray(spectrum["weights"], dtype=float)
    threshold = max(1.0e-14, 1.0e-10 * float(weights.sum()))
    mask = (omega > 1.0e-10) & (weights > threshold)
    return omega[mask], weights[mask]


def apparent_fwhm(
    omega: Array, weights: Array, eta: float, grid_points: int = 24000
) -> float:
    """FWHM after applying a user-chosen Lorentzian resolution eta."""

    lower = max(0.0, float(np.min(omega)) - 12.0 * eta)
    upper = float(np.max(omega)) + 12.0 * eta
    grid = np.linspace(lower, upper, grid_points)
    intensity = np.sum(
        weights[None, :]
        * (eta / math.pi)
        / (np.square(grid[:, None] - omega[None, :]) + eta**2),
        axis=1,
    )
    peak = int(np.argmax(intensity))
    half = 0.5 * float(intensity[peak])
    left = peak
    while left > 0 and intensity[left] >= half:
        left -= 1
    right = peak
    while right + 1 < len(grid) and intensity[right] >= half:
        right += 1
    return float(grid[right] - grid[left])


def spectrum_diagnostics(
    H: Sparse,
    cache: SparseSectorCache,
    ground: StateData,
    lanczos_steps: int,
    etas: Iterable[float],
) -> dict[str, Any]:
    seed = cache.rho(0, 2, 0) @ ground.vector
    spectrum = lanczos_spectrum(
        H,
        ground.energy,
        seed,
        lanczos_steps,
        reorthogonalize=True,
    )
    omega, weights = physical_poles(spectrum)
    total = float(weights.sum())
    probabilities = weights / total
    centroid = float(np.sum(probabilities * omega))
    variance = float(np.sum(probabilities * np.square(omega - centroid)))
    strongest = int(np.argmax(weights))
    lowest = int(np.argmin(omega))
    result: dict[str, Any] = {
        "lowest_pole": float(omega[lowest]),
        "lowest_fraction": float(probabilities[lowest]),
        "strongest_pole": float(omega[strongest]),
        "strongest_fraction": float(probabilities[strongest]),
        "centroid": centroid,
        "fragmentation_sigma": math.sqrt(max(variance, 0.0)),
        "effective_poles": float(1.0 / np.sum(np.square(probabilities))),
        "physical_pole_count": int(len(omega)),
        "lanczos_dimension": int(spectrum["lanczos_dimension"]),
    }
    for eta in etas:
        result[f"apparent_fwhm_eta_{eta:g}"] = apparent_fwhm(
            omega, weights, eta
        )
    return result


def endpoint_probes(
    sizes: Iterable[int],
    interactions: Iterable[str],
    cache_dir: Path,
    lanczos_steps: int,
    column_chunk_size: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    chirality_rows: list[dict[str, Any]] = []
    width_rows: list[dict[str, Any]] = []
    for particles in sizes:
        two_q = 3 * (particles - 1)
        cache = SparseSectorCache(particles, two_q)
        for interaction in interactions:
            H = hamiltonian(
                cache,
                0,
                interaction,
                cache_dir,
                column_chunk_size,
            )
            ground = targeted_state(H, cache, 0, 0)
            minus = cache.rho(0, 2, -2) @ ground.vector
            plus = cache.rho(0, 2, +2) @ ground.vector
            weight_minus = float(np.vdot(minus, minus).real)
            weight_plus = float(np.vdot(plus, plus).real)
            chirality_rows.append(
                {
                    "N": particles,
                    "twoQ": two_q,
                    "interaction": interaction,
                    "weight_M_minus2": weight_minus,
                    "weight_M_plus2": weight_plus,
                    "Mminus_over_Mplus": weight_minus
                    / max(weight_plus, 1.0e-300),
                    "relative_covariance_error": abs(
                        weight_minus - weight_plus
                    )
                    / max(0.5 * (weight_minus + weight_plus), 1.0e-300),
                    "interpretation": (
                        "SO(3) covariance null test; not circular helicity"
                    ),
                }
            )
            width_rows.append(
                {
                    "N": particles,
                    "twoQ": two_q,
                    "interaction": interaction,
                    **spectrum_diagnostics(
                        H,
                        cache,
                        ground,
                        lanczos_steps,
                        etas=(0.0025, 0.005, 0.01),
                    ),
                    "interpretation": (
                        "fragmentation is physical finite-size information; "
                        "FWHM depends on chosen eta"
                    ),
                }
            )
            print(
                f"endpoint N={particles} {interaction}: "
                f"M-/M+={chirality_rows[-1]['Mminus_over_Mplus']:.12f}, "
                f"main={width_rows[-1]['strongest_fraction']:.3%}",
                flush=True,
            )
    return chirality_rows, width_rows


def lambda_scan(
    particles: int,
    lambdas: Array,
    cache_dir: Path,
    column_chunk_size: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Physical fidelity susceptibility for V1(lambda) around Coulomb."""

    two_q = 3 * (particles - 1)
    cache = SparseSectorCache(particles, two_q)
    hc0 = hamiltonian(cache, 0, "coulomb", cache_dir, column_chunk_size)
    hv10 = hamiltonian(cache, 0, "v1", cache_dir, column_chunk_size)
    hc2 = hamiltonian(cache, 2, "coulomb", cache_dir, column_chunk_size)
    hv12 = hamiltonian(cache, 2, "v1", cache_dir, column_chunk_size)
    v1_coulomb = coulomb_pseudopotentials(two_q)[two_q - 1]
    laughlin = targeted_state(hv10, cache, 0, 0)

    states: list[Array] = []
    rows: list[dict[str, Any]] = []
    previous0: Array | None = laughlin.vector.real
    previous2: Array | None = None
    for value in lambdas:
        value = float(value)
        H0 = (hc0 + (value - 1.0) * v1_coulomb * hv10).tocsr()
        H2 = (hc2 + (value - 1.0) * v1_coulomb * hv12).tocsr()
        ground = targeted_state(H0, cache, 0, 0, initial=previous0)
        excited = targeted_state(
            H2,
            cache,
            2,
            2,
            initial=previous2,
            penalty=0.2,
        )
        previous0 = ground.vector.real
        previous2 = excited.vector.real
        states.append(normalized(ground.vector))
        s2, covariance = structure_factor(cache, ground.vector, 2)
        rows.append(
            {
                "N": particles,
                "lambda": value,
                "E0": ground.energy,
                "gap_L2": excited.energy - ground.energy,
                "laughlin_fidelity": float(
                    abs(np.vdot(laughlin.vector, ground.vector)) ** 2
                ),
                "S_L2": s2,
                "M_covariance_relative_error": covariance,
                "physical_fidelity_susceptibility": float("nan"),
            }
        )
        print(
            f"lambda scan N={particles} lambda={value:.3f}: "
            f"F_L={rows[-1]['laughlin_fidelity']:.8f}, "
            f"gap={rows[-1]['gap_L2']:.8f}",
            flush=True,
        )

    for index in range(1, len(rows) - 1):
        delta = float(lambdas[index + 1] - lambdas[index - 1])
        fidelity = float(
            abs(np.vdot(states[index - 1], states[index + 1])) ** 2
        )
        rows[index]["physical_fidelity_susceptibility"] = (
            1.0 - fidelity
        ) / (delta**2)

    finite = [
        row
        for row in rows
        if np.isfinite(row["physical_fidelity_susceptibility"])
    ]
    peak = max(
        finite, key=lambda row: row["physical_fidelity_susceptibility"]
    )
    summary = {
        "N": particles,
        "lambda_peak": peak["lambda"],
        "chi_peak": peak["physical_fidelity_susceptibility"],
        "minimum_gap": min(row["gap_L2"] for row in rows),
        "minimum_laughlin_fidelity": min(
            row["laughlin_fidelity"] for row in rows
        ),
        "qgt_definition": (
            "g_lambda_lambda=(1-|<psi(lambda-d)|psi(lambda+d)>|^2)/(2d)^2"
        ),
        "neural_trace_warning": (
            "Tr Q in raw neural parameters is reparameterization-dependent; "
            "the Hamiltonian-parameter fidelity susceptibility is invariant."
        ),
    }
    return rows, summary


def apply_triple_operator(
    state: int,
    created: tuple[int, int, int],
    annihilated: tuple[int, int, int],
) -> tuple[int, int] | None:
    """Apply c†_a c†_b c†_c c_f c_e c_d for ordered triples."""

    sign = 1
    current = state
    for orbital in annihilated:
        result = _annihilate(current, orbital)
        if result is None:
            return None
        current, local = result
        sign *= local
    for orbital in reversed(created):
        result = _create(current, orbital)
        if result is None:
            return None
        current, local = result
        sign *= local
    return current, sign


def three_body_projector(
    two_q: int,
) -> tuple[
    dict[int, tuple[tuple[tuple[int, int, int], ...], Array]],
    dict[str, Any],
]:
    """Project three fermions onto relative angular momentum three.

    The Moore--Read parent penalizes the unique maximum allowed total
    angular momentum J=3Q-3 of a fermion triplet.
    """

    two_ms = orbital_two_m(two_q)
    target_two_j = 3 * two_q - 6
    target_j = 0.5 * target_two_j
    triples = tuple(itertools.combinations(range(two_q + 1), 3))
    groups: dict[int, list[tuple[int, int, int]]] = {}
    for triple in triples:
        groups.setdefault(sum(two_ms[i] for i in triple), []).append(triple)

    blocks: dict[int, tuple[tuple[tuple[int, int, int], ...], Array]] = {}
    maximum_l2_error = 0.0
    selected_dimensions: list[int] = []
    for two_m, local_triples in sorted(groups.items()):
        if abs(two_m) > target_two_j:
            continue
        M = 0.5 * two_m
        basis = fock_basis(3, two_q, M)
        expected = tuple(
            sum(1 << orbital for orbital in triple)
            for triple in local_triples
        )
        if basis != expected:
            raise RuntimeError("three-particle basis ordering mismatch")
        l2 = angular_momentum_squared(basis, 3, two_q, M)
        values, vectors = np.linalg.eigh(l2)
        target = target_j * (target_j + 1.0)
        mask = np.abs(values - target) < 1.0e-8
        selected = vectors[:, mask]
        if selected.shape[1] != 1:
            raise RuntimeError(
                f"expected one Moore-Read triplet at 2M={two_m}, "
                f"found {selected.shape[1]}"
            )
        maximum_l2_error = max(
            maximum_l2_error,
            float(np.max(np.abs(values[mask] - target))),
        )
        selected_dimensions.append(selected.shape[1])
        blocks[two_m] = (
            tuple(local_triples),
            np.asarray(selected @ selected.T, dtype=float),
        )
    return blocks, {
        "twoQ": two_q,
        "target_twoJ": target_two_j,
        "target_J": target_j,
        "blocks": len(blocks),
        "maximum_L2_error": maximum_l2_error,
        "projector_rank_per_M": sorted(set(selected_dimensions)),
    }


def three_body_hamiltonian(
    basis: tuple[int, ...],
    two_q: int,
    blocks: dict[
        int, tuple[tuple[tuple[int, int, int], ...], Array]
    ],
) -> Sparse:
    index = {state: position for position, state in enumerate(basis)}
    two_ms = orbital_two_m(two_q)
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    for ket_index, state in enumerate(basis):
        occupied = tuple(
            orbital for orbital in range(two_q + 1) if (state >> orbital) & 1
        )
        for annihilated in itertools.combinations(occupied, 3):
            two_m = sum(two_ms[i] for i in annihilated)
            block = blocks.get(two_m)
            if block is None:
                continue
            triples, matrix = block
            source = triples.index(annihilated)
            for target, created in enumerate(triples):
                element = float(matrix[target, source])
                if abs(element) < 1.0e-14:
                    continue
                applied = apply_triple_operator(
                    state, created, annihilated
                )
                if applied is None:
                    continue
                final, sign = applied
                bra = index.get(final)
                if bra is not None:
                    rows.append(bra)
                    columns.append(ket_index)
                    data.append(sign * element)
    H = sparse.coo_matrix(
        (data, (rows, columns)), shape=(len(basis), len(basis))
    ).tocsr()
    return (0.5 * (H + H.T)).tocsr()


def occupations(
    basis: tuple[int, ...], orbitals: int
) -> Array:
    return np.asarray(
        [
            [(state >> orbital) & 1 for orbital in range(orbitals)]
            for state in basis
        ],
        dtype=np.float32,
    )


def moore_read_pilot(
    output_dir: Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    parity_rows: list[dict[str, Any]] = []
    for particles in range(5, 11):
        two_q = 2 * particles - 3
        half_integer = (particles * two_q) % 2 == 1
        probe_M = 1.5 if half_integer else 0
        basis = fock_basis(particles, two_q, probe_M)
        parity_rows.append(
            {
                "N": particles,
                "twoQ": two_q,
                "single_particle_Q": 0.5 * two_q,
                "total_L_class": (
                    "half-integer" if half_integer else "integer"
                ),
                "allows_L0_and_L2": not half_integer,
                "allows_L3_over_2": half_integer,
                "probe_M": probe_M,
                "probe_sector_dimension": len(basis),
            }
        )

    # Small exact parent-Hamiltonian teachers: even-N ground/graviton and
    # adjacent odd-N neutral-fermion branch.
    even_N = 6
    even_two_q = 2 * even_N - 3
    blocks_even, projector_even = three_body_projector(even_two_q)
    cache_even = SparseSectorCache(even_N, even_two_q)
    basis0 = cache_even.basis(0)
    basis2 = cache_even.basis(2)
    H0 = three_body_hamiltonian(basis0, even_two_q, blocks_even)
    H2 = three_body_hamiltonian(basis2, even_two_q, blocks_even)
    ground = targeted_state(H0, cache_even, 0, 0, penalty=0.5)
    graviton = targeted_state(H2, cache_even, 2, 2, penalty=0.5)
    seed = cache_even.rho(0, 2, 0) @ ground.vector
    spectrum = lanczos_spectrum(
        H0, ground.energy, seed, min(100, H0.shape[0])
    )
    even_spectrum = spectrum_diagnostics(
        H0,
        cache_even,
        ground,
        min(100, H0.shape[0]),
        etas=(0.005,),
    )

    odd_N = 7
    odd_two_q = 2 * odd_N - 3
    blocks_odd, projector_odd = three_body_projector(odd_two_q)
    cache_odd = SparseSectorCache(odd_N, odd_two_q)
    odd_M = 1.5
    basis_odd = cache_odd.basis(odd_M)
    H_odd = three_body_hamiltonian(basis_odd, odd_two_q, blocks_odd)
    neutral_fermion_candidate = targeted_state(
        H_odd,
        cache_odd,
        odd_M,
        1.5,
        penalty=0.5,
    )

    teacher_path = output_dir / "moore_read_teacher_states.npz"
    np.savez_compressed(
        teacher_path,
        even_N=even_N,
        even_twoQ=even_two_q,
        occupations_ground=occupations(basis0, even_two_q + 1),
        psi_ground=normalized(ground.vector),
        occupations_graviton=occupations(basis2, even_two_q + 1),
        psi_graviton=normalized(graviton.vector),
        odd_N=odd_N,
        odd_twoQ=odd_two_q,
        occupations_neutral_fermion_candidate=occupations(basis_odd, odd_two_q + 1),
        psi_neutral_fermion_candidate=normalized(neutral_fermion_candidate.vector),
    )
    payload = {
        "parent_definition": (
            "three-body projector onto triplet relative angular momentum 3"
        ),
        "even_branch": {
            "N": even_N,
            "twoQ": even_two_q,
            "dimension_M0": H0.shape[0],
            "dimension_M2": H2.shape[0],
            "ground_energy": ground.energy,
            "ground_L2": ground.l2,
            "graviton_energy": graviton.energy,
            "graviton_gap": graviton.energy - ground.energy,
            "graviton_L2": graviton.l2,
            "density_spectrum": even_spectrum,
            "seed_norm2": float(np.vdot(seed, seed).real),
            "raw_lanczos_dimension": spectrum["lanczos_dimension"],
            "projector": projector_even,
        },
        "odd_branch": {
            "N": odd_N,
            "twoQ": odd_two_q,
            "dimension_M3_over_2": H_odd.shape[0],
            "neutral_fermion_candidate_energy_parent_units": neutral_fermion_candidate.energy,
            "neutral_fermion_candidate_L2": neutral_fermion_candidate.l2,
            "projector": projector_odd,
        },
        "simultaneous_resolution": False,
        "reason": (
            "At 2Q=2N-3, even N has integer total L and odd N has "
            "half-integer total L. L=0,2 and L=3/2 are therefore not states "
            "of one fixed-N Hilbert space."
        ),
        "corrected_protocol": (
            "compare the even-N ground/graviton branch with the adjacent "
            "odd-N neutral-fermion branch using parity-staggered energies"
        ),
        "teacher_file": str(teacher_path),
    }
    return parity_rows, payload


def plot_lambda_scan(rows: list[dict[str, Any]], path: Path) -> None:
    sizes = sorted({int(row["N"]) for row in rows})
    fig, axes = plt.subplots(3, 1, figsize=(7.2, 8.6), sharex=True)
    for particles in sizes:
        local = [row for row in rows if int(row["N"]) == particles]
        x = np.asarray([row["lambda"] for row in local])
        axes[0].plot(
            x,
            [row["physical_fidelity_susceptibility"] for row in local],
            marker="o",
            label=f"N={particles}",
        )
        axes[1].plot(
            x,
            [row["gap_L2"] for row in local],
            marker="o",
            label=f"N={particles}",
        )
        axes[2].plot(
            x,
            [row["laughlin_fidelity"] for row in local],
            marker="o",
            label=f"N={particles}",
        )
    axes[0].set_ylabel(r"$\chi_F$")
    axes[1].set_ylabel(r"$\Delta_{L=2}$")
    axes[2].set_ylabel("Laughlin fidelity")
    axes[2].set_xlabel(r"$\lambda=V_1/V_1^{\rm Coulomb}$")
    axes[0].legend()
    for axis in axes:
        axis.grid(alpha=0.25)
    fig.suptitle("Gauge-invariant Hamiltonian-parameter geometry")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_spectral_width(rows: list[dict[str, Any]], path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.8))
    interactions = sorted({str(row["interaction"]) for row in rows})
    for interaction in interactions:
        local = sorted(
            (row for row in rows if row["interaction"] == interaction),
            key=lambda row: int(row["N"]),
        )
        axes[0].plot(
            [row["N"] for row in local],
            [row["strongest_fraction"] for row in local],
            marker="o",
            label=interaction,
        )
        axes[1].plot(
            [row["N"] for row in local],
            [row["fragmentation_sigma"] for row in local],
            marker="o",
            label=interaction,
        )
    axes[0].set_ylabel("dominant pole fraction")
    axes[1].set_ylabel("weighted fragmentation sigma")
    for axis in axes:
        axis.set_xlabel("N")
        axis.grid(alpha=0.25)
        axis.legend()
    fig.suptitle("Finite-size spectral fragmentation (eta-independent)")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[6, 8, 10])
    parser.add_argument(
        "--lambda-sizes", type=int, nargs="+", default=[6, 8]
    )
    parser.add_argument("--lambda-min", type=float, default=0.6)
    parser.add_argument("--lambda-max", type=float, default=1.4)
    parser.add_argument("--lambda-points", type=int, default=17)
    parser.add_argument("--lanczos-steps", type=int, default=140)
    parser.add_argument("--column-chunk-size", type=int, default=256)
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=GEOMETRY_DIR / "cache" / "ed",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=HERE / "results"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    chirality_rows, width_rows = endpoint_probes(
        args.sizes,
        interactions=("v1", "coulomb"),
        cache_dir=args.cache_dir,
        lanczos_steps=args.lanczos_steps,
        column_chunk_size=args.column_chunk_size,
    )
    lambdas = np.linspace(
        args.lambda_min, args.lambda_max, args.lambda_points
    )
    qgt_rows: list[dict[str, Any]] = []
    qgt_summaries: list[dict[str, Any]] = []
    for particles in args.lambda_sizes:
        local_rows, local_summary = lambda_scan(
            particles,
            lambdas,
            args.cache_dir,
            args.column_chunk_size,
        )
        qgt_rows.extend(local_rows)
        qgt_summaries.append(local_summary)

    parity_rows, moore_read = moore_read_pilot(args.output_dir)
    write_csv(args.output_dir / "chirality_null_test.csv", chirality_rows)
    write_csv(args.output_dir / "spectral_fragmentation.csv", width_rows)
    write_csv(args.output_dir / "qgt_fidelity_scan.csv", qgt_rows)
    write_csv(args.output_dir / "moore_read_parity.csv", parity_rows)
    plot_lambda_scan(qgt_rows, args.output_dir / "qgt_fidelity_scan.png")
    plot_spectral_width(
        width_rows, args.output_dir / "spectral_fragmentation.png"
    )

    payload = {
        "provenance": {
            "script": str(Path(__file__).resolve()),
            "runtime_seconds": time.perf_counter() - started,
            "sizes": args.sizes,
            "lambda_sizes": args.lambda_sizes,
            "lambdas": lambdas,
            "lanczos_steps": args.lanczos_steps,
        },
        "question5_chirality": {
            "rows": chirality_rows,
            "conclusion": (
                "rho_2,+2 and rho_2,-2 are equal by SO(3) covariance; "
                "their ratio cannot be used as the requested helicity ratio."
            ),
            "required_next_operator": (
                "planar/local-frame circular stress or metric-deformation "
                "operator with an explicit orientation convention"
            ),
        },
        "question9_width": {
            "rows": width_rows,
            "conclusion": (
                "A finite Hermitian spectrum has delta-function poles. "
                "Eta-independent fragmentation is measurable; Lorentzian "
                "FWHM is resolution-dependent and is not yet a lifetime."
            ),
        },
        "question10_qgt": {
            "summaries": qgt_summaries,
            "rows": qgt_rows,
            "conclusion": (
                "Use Hamiltonian-parameter fidelity susceptibility. Raw "
                "neural-parameter Tr(Q) is coordinate-dependent, and a Chern "
                "number requires two boundary-twist parameters, not a 1D "
                "V1 scan."
            ),
            "shift_warning": (
                "Raw total energies at different flux are not directly "
                "comparable without background/chemical-potential terms; "
                "the proposed finite-difference kappa is not used."
            ),
        },
        "question12_moore_read": {
            "parity_rows": parity_rows,
            **moore_read,
        },
    }
    (args.output_dir / "physics_probes.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, default=json_default),
        encoding="utf-8",
    )
    print(
        f"completed physics probes in {time.perf_counter()-started:.1f}s; "
        f"output={args.output_dir.resolve()}",
        flush=True,
    )


if __name__ == "__main__":
    main()
