#!/usr/bin/env python3
"""Exact full-sector overlap of a small autoregressive Fock-NQS checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

import chiral_graviton_fock_ar_nqs as fock


def occupations(states: np.ndarray, orbitals: int) -> np.ndarray:
    return (
        (states[:, None] >> np.arange(orbitals, dtype=np.uint64))
        & np.uint64(1)
    ).astype(np.int32)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("teacher", type=Path)
    parser.add_argument("--hidden", type=int, default=128)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    checkpoint = np.load(args.checkpoint)
    teacher = np.load(args.teacher)
    params = {
        key.removeprefix("param__"): jnp.asarray(checkpoint[key])
        for key in checkpoint.files
        if key.startswith("param__")
    }
    basis0 = np.asarray(teacher["basis_M0"], dtype=np.uint64)
    basis2 = np.asarray(teacher["basis_M2"], dtype=np.uint64)
    psi0 = np.asarray(teacher["psi_ground"], dtype=np.complex128)
    psi2 = np.asarray(teacher["psi_excited_M2"], dtype=np.complex128)
    particles = int(int(basis0[0]).bit_count())
    orbitals = 3 * particles - 2
    log_psi, _ = fock.make_wavefunction_functions(
        particles, args.hidden
    )
    evaluate = jax.jit(log_psi)

    def overlap(
        basis: np.ndarray, target: np.ndarray, sector_M: int
    ) -> float:
        logs = np.asarray(
            evaluate(
                params,
                jnp.asarray(occupations(basis, orbitals)),
                sector_M,
            )
        )
        model = np.exp(logs.astype(np.complex128))
        model /= np.linalg.norm(model)
        target = target / np.linalg.norm(target)
        return float(abs(np.vdot(target, model)) ** 2)

    payload = {
        "checkpoint": str(args.checkpoint.resolve()),
        "teacher": str(args.teacher.resolve()),
        "jax_devices": [str(device) for device in jax.devices()],
        "particles": particles,
        "ground_overlap": overlap(basis0, psi0, 0),
        "excited_M2_overlap": overlap(basis2, psi2, 2),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2), flush=True)


if __name__ == "__main__":
    main()
