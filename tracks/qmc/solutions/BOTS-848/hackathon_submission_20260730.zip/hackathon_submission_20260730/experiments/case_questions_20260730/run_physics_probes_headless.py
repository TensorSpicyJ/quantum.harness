#!/usr/bin/env python3
"""Run the physics probes when the numerical conda env lacks Matplotlib."""

from __future__ import annotations

import sys
import types


matplotlib = types.ModuleType("matplotlib")
matplotlib.use = lambda *_args, **_kwargs: None
pyplot = types.ModuleType("matplotlib.pyplot")
matplotlib.pyplot = pyplot
sys.modules["matplotlib"] = matplotlib
sys.modules["matplotlib.pyplot"] = pyplot

import run_physics_probes as probes  # noqa: E402


probes.plot_lambda_scan = lambda _rows, _path: None
probes.plot_spectral_width = lambda _rows, _path: None


if __name__ == "__main__":
    probes.main()
