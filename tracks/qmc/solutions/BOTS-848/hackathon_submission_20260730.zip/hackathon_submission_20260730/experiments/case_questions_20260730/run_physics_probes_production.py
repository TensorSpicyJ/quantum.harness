#!/usr/bin/env python3
"""Production wrapper with unrestricted ground-state angular momentum."""

from __future__ import annotations

import math
import sys
import types

import numpy as np
from scipy.sparse.linalg import eigsh


matplotlib = types.ModuleType("matplotlib")
matplotlib.use = lambda *_args, **_kwargs: None
pyplot = types.ModuleType("matplotlib.pyplot")
matplotlib.pyplot = pyplot
sys.modules["matplotlib"] = matplotlib
sys.modules["matplotlib.pyplot"] = pyplot

import run_physics_probes as probes  # noqa: E402
from chiral_graviton_nqs_vmc_sparse import (  # noqa: E402
    sparse_raising_operator,
)


def unrestricted_ground(H, cache, initial=None):
    """Return the true M=0 ground and measure, rather than assume, L."""

    _, vectors = eigsh(
        H,
        k=1,
        which="SA",
        tol=1.0e-11,
        maxiter=max(20000, 20 * H.shape[0]),
        v0=initial,
    )
    vector = probes.normalized(vectors[:, 0])
    hvec = H @ vector
    energy = float(np.vdot(vector, hvec).real)
    raising = sparse_raising_operator(cache, 0)
    l2vec = raising.T @ (raising @ vector)
    l2 = float(np.vdot(vector, l2vec).real)
    residual = float(np.linalg.norm(hvec - energy * vector))
    return probes.StateData(energy, vector, l2, residual)


def lambda_scan(particles, lambdas, cache_dir, column_chunk_size):
    """Physical fidelity scan that permits symmetry-changing ground states."""

    two_q = 3 * (particles - 1)
    cache = probes.SparseSectorCache(particles, two_q)
    hc0 = probes.hamiltonian(
        cache, 0, "coulomb", cache_dir, column_chunk_size
    )
    hv10 = probes.hamiltonian(cache, 0, "v1", cache_dir, column_chunk_size)
    hc2 = probes.hamiltonian(
        cache, 2, "coulomb", cache_dir, column_chunk_size
    )
    hv12 = probes.hamiltonian(cache, 2, "v1", cache_dir, column_chunk_size)
    v1_coulomb = probes.coulomb_pseudopotentials(two_q)[two_q - 1]
    laughlin = probes.targeted_state(hv10, cache, 0, 0)

    states = []
    rows = []
    previous0 = laughlin.vector.real
    previous2 = None
    for value in lambdas:
        value = float(value)
        H0 = (hc0 + (value - 1.0) * v1_coulomb * hv10).tocsr()
        H2 = (hc2 + (value - 1.0) * v1_coulomb * hv12).tocsr()
        ground = unrestricted_ground(H0, cache, initial=previous0)
        excited = probes.targeted_state(
            H2,
            cache,
            2,
            2,
            initial=previous2,
            penalty=0.2,
        )
        previous0 = ground.vector.real
        previous2 = excited.vector.real
        states.append(probes.normalized(ground.vector))
        s2, covariance = probes.structure_factor(
            cache, ground.vector, 2
        )
        inferred_l = 0.5 * (
            math.sqrt(max(0.0, 1.0 + 4.0 * ground.l2)) - 1.0
        )
        rows.append(
            {
                "N": particles,
                "lambda": value,
                "E0": ground.energy,
                "ground_L2": ground.l2,
                "ground_L_inferred": inferred_l,
                "gap_L2": excited.energy - ground.energy,
                "laughlin_fidelity": float(
                    abs(np.vdot(laughlin.vector, ground.vector)) ** 2
                ),
                "S_L2": s2,
                "M_covariance_relative_error": covariance,
                "physical_fidelity_susceptibility": float("nan"),
            }
        )
        print(
            f"lambda scan N={particles} lambda={value:.3f}: "
            f"L={inferred_l:.3f}, "
            f"F_L={rows[-1]['laughlin_fidelity']:.8f}, "
            f"gap={rows[-1]['gap_L2']:.8f}",
            flush=True,
        )

    for index in range(1, len(rows) - 1):
        delta = float(lambdas[index + 1] - lambdas[index - 1])
        fidelity = float(
            abs(np.vdot(states[index - 1], states[index + 1])) ** 2
        )
        rows[index]["physical_fidelity_susceptibility"] = (
            1.0 - fidelity
        ) / (delta**2)

    finite = [
        row
        for row in rows
        if np.isfinite(row["physical_fidelity_susceptibility"])
    ]
    peak = max(
        finite, key=lambda row: row["physical_fidelity_susceptibility"]
    )
    summary = {
        "N": particles,
        "lambda_peak": peak["lambda"],
        "chi_peak": peak["physical_fidelity_susceptibility"],
        "peak_ground_L": peak["ground_L_inferred"],
        "minimum_gap": min(row["gap_L2"] for row in rows),
        "minimum_laughlin_fidelity": min(
            row["laughlin_fidelity"] for row in rows
        ),
        "symmetry_changes_present": any(
            abs(row["ground_L_inferred"]) > 1.0e-5 for row in rows
        ),
        "qgt_definition": (
            "g_lambda_lambda=(1-|<psi(lambda-d)|psi(lambda+d)>|^2)/(2d)^2"
        ),
        "neural_trace_warning": (
            "Tr Q in raw neural parameters is reparameterization-dependent; "
            "the Hamiltonian-parameter fidelity susceptibility is invariant."
        ),
    }
    return rows, summary


probes.lambda_scan = lambda_scan
probes.plot_lambda_scan = lambda _rows, _path: None
probes.plot_spectral_width = lambda _rows, _path: None


if __name__ == "__main__":
    probes.main()
