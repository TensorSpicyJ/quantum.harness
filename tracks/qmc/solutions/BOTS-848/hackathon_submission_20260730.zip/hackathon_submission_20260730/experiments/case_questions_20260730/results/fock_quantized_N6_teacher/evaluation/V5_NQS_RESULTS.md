# V5 NQS 几何观测量与 ED 对照

这里使用最新 `symmetry_v5` 自回归架构的 M=0 波函数，并通过`ker(L_+)` 做严格正交的 L=0 投影。投影前后对照将角动量泄漏与L=0 子空间内部误差分开。

| N | E_NQS | E_ED | relative_energy_error | energy_variance | fidelity_ED | L2 | L0_weight | fidelity_ED_projected_L0 | L2_projected_L0 | S_L2_NQS | S_L2_ED | S_L2_relative_error | S_L2_relative_error_projected_L0 | S_L3_relative_error | S_L3_relative_error_projected_L0 | S_L4_relative_error | S_L4_relative_error_projected_L0 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6 | 3.8741938 | 3.8716349 | 0.00066092949 | 0.0015214652 | 0.99397682 | 0.72973299 | 0.994073 | 0.99990324 | 4.445552e-23 | 0.10830138 | 0.10519172 | 0.029561854 | 0.0019741793 | 0.0064356092 | 0.0042692547 | -0.0094826733 | -0.0066257618 |

能量接近并不保证结构因子正确；只有 fidelity、方差、L² 污染和 S_L 同时通过，才能说 NQS 学到了导引中心几何。
