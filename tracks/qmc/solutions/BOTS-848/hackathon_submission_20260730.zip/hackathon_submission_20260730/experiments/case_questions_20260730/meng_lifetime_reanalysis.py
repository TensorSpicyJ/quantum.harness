#!/usr/bin/env python3
# Meng-style multi-eta extrapolation for finite-size ED graviton spectra.

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
GEOMETRY = ROOT / 'geometry_chirality_study_20260729'
for location in (ROOT, GEOMETRY):
    if str(location) not in sys.path:
        sys.path.insert(0, str(location))

from chiral_graviton_nqs_vmc_sparse import SparseSectorCache
from ed_geometry_suite import hamiltonian, lanczos_spectrum, targeted_state


def physical_poles(spectrum: dict) -> tuple[np.ndarray, np.ndarray]:
    omega = np.asarray(spectrum['omega'], dtype=float)
    weights = np.asarray(spectrum['weights'], dtype=float)
    threshold = max(1.0e-14, 1.0e-10 * float(weights.sum()))
    mask = (omega > 1.0e-10) & (weights > threshold)
    return omega[mask], weights[mask]


def apparent_fwhm(omega: np.ndarray, weights: np.ndarray, eta: float, grid_points: int) -> float:
    lower = max(0.0, float(np.min(omega)) - 12.0 * eta)
    upper = float(np.max(omega)) + 12.0 * eta
    grid = np.linspace(lower, upper, grid_points)
    intensity = np.sum(
        weights[None, :] * (eta / np.pi)
        / (np.square(grid[:, None] - omega[None, :]) + eta**2),
        axis=1,
    )
    peak = int(np.argmax(intensity))
    half = 0.5 * float(intensity[peak])
    left = peak
    while left > 0 and intensity[left] >= half:
        left -= 1
    right = peak
    while right + 1 < len(grid) and intensity[right] >= half:
        right += 1
    return float(grid[right] - grid[left])


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze_one(particles: int, interaction: str, arguments) -> tuple[dict, list[dict]]:
    two_q = 3 * (particles - 1)
    cache = SparseSectorCache(particles, two_q)
    H = hamiltonian(cache, 0, interaction, arguments.cache_dir, arguments.column_chunk_size)
    ground = targeted_state(H, cache, 0, 0)
    seed = cache.rho(0, 2, 0) @ ground.vector
    spectrum = lanczos_spectrum(
        H, ground.energy, seed, arguments.lanczos_steps, reorthogonalize=True
    )
    omega, weights = physical_poles(spectrum)
    peak = int(np.argmax(weights))
    peak_energy = float(omega[peak])
    eta_values = np.asarray(arguments.etas, dtype=float)
    widths = np.asarray([
        apparent_fwhm(omega, weights, float(eta), arguments.grid_points)
        for eta in eta_values
    ])
    detail_rows = []
    fits = []
    for eta, width in zip(eta_values, widths):
        detail_rows.append({
            'N': particles,
            'interaction': interaction,
            'eta': float(eta),
            'apparent_fwhm': float(width),
            'fwhm_over_2eta': float(width / (2.0 * eta)),
        })
    for count in range(3, len(eta_values) + 1):
        slope, intercept = np.polyfit(eta_values[:count], widths[:count], 1)
        fitted = slope * eta_values[:count] + intercept
        residual = float(np.sqrt(np.mean(np.square(widths[:count] - fitted))))
        fits.append({
            'eta_count': count,
            'slope': float(slope),
            'intercept_fwhm': float(intercept),
            'gamma_physical_raw': float(0.5 * intercept),
            'gamma_physical_nonnegative': float(max(0.0, 0.5 * intercept)),
            'fit_rms': residual,
        })
    raw_gammas = np.asarray([fit['gamma_physical_raw'] for fit in fits])
    slopes = np.asarray([fit['slope'] for fit in fits])
    summary = {
        'N': particles,
        'twoQ': two_q,
        'interaction': interaction,
        'ground_energy': float(ground.energy),
        'strongest_pole': peak_energy,
        'strongest_fraction': float(weights[peak] / np.sum(weights)),
        'physical_poles': int(len(omega)),
        'gamma_physical_raw_median': float(np.median(raw_gammas)),
        'gamma_physical_upper_estimate': float(max(0.0, np.median(raw_gammas))),
        'relative_gamma_upper': float(max(0.0, np.median(raw_gammas)) / peak_energy),
        'eta_slope_median': float(np.median(slopes)),
        'expected_resolution_slope': 2.0,
        'fit_spread_gamma': float(np.max(raw_gammas) - np.min(raw_gammas)),
        'fits': fits,
        'poles_omega': omega.tolist(),
        'poles_weight': weights.tolist(),
    }
    return summary, detail_rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--sizes', type=int, nargs='+', default=[6, 8, 10])
    parser.add_argument('--interactions', nargs='+', default=['v1', 'coulomb'])
    parser.add_argument('--etas', type=float, nargs='+', default=[0.00125, 0.0025, 0.005, 0.0075, 0.01])
    parser.add_argument('--grid-points', type=int, default=48000)
    parser.add_argument('--lanczos-steps', type=int, default=140)
    parser.add_argument('--column-chunk-size', type=int, default=256)
    parser.add_argument('--cache-dir', type=Path, default=GEOMETRY / 'cache' / 'ed')
    parser.add_argument('--output-dir', type=Path, default=HERE / 'results' / 'meng_lifetime')
    arguments = parser.parse_args()
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    summaries = []
    details = []
    for particles in arguments.sizes:
        for interaction in arguments.interactions:
            summary, local_details = analyze_one(particles, interaction, arguments)
            summaries.append(summary)
            details.extend(local_details)
            gamma_raw = summary['gamma_physical_raw_median']
            slope_value = summary['eta_slope_median']
            print(f'N={particles} {interaction}: gamma_raw={gamma_raw:.6g}, slope={slope_value:.5f}', flush=True)
    flat = [{key: value for key, value in row.items() if key not in ('fits', 'poles_omega', 'poles_weight')} for row in summaries]
    write_csv(arguments.output_dir / 'summary.csv', flat)
    write_csv(arguments.output_dir / 'eta_scan.csv', details)
    payload = {
        'method': 'multi-eta extrapolation FWHM(eta)=2 Gamma_physical + c eta',
        'finite_system_caveat': 'A closed finite Hermitian ED system has delta poles; a positive intercept is only an upper estimate until bath or thermodynamic-continuum physics is present.',
        'arguments': {**vars(arguments), 'cache_dir': str(arguments.cache_dir), 'output_dir': str(arguments.output_dir)},
        'summaries': summaries,
    }
    (arguments.output_dir / 'results.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(f'wrote {arguments.output_dir.resolve()}', flush=True)


if __name__ == '__main__':
    main()
