# V5 NQS 几何观测量与 ED 对照

这里使用最新 `symmetry_v5` 自回归架构的 M=0 波函数，并通过`ker(L_+)` 做严格正交的 L=0 投影。投影前后对照将角动量泄漏与L=0 子空间内部误差分开。

| N | E_NQS | E_ED | relative_energy_error | energy_variance | fidelity_ED | L2 | L0_weight | fidelity_ED_projected_L0 | L2_projected_L0 | S_L2_NQS | S_L2_ED | S_L2_relative_error | S_L2_relative_error_projected_L0 | S_L3_relative_error | S_L3_relative_error_projected_L0 | S_L4_relative_error | S_L4_relative_error_projected_L0 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 6 | 4.3945516 | 3.8716349 | 0.13506353 | 0.15897814 | 0.043386802 | 209.21406 | 0.047166274 | 0.91986919 | 3.5429354e-24 | 0.4992592 | 0.10519172 | 3.7461834 | 0.62541453 | 0.12940928 | 0.086377621 | -0.47204076 | -0.047225323 |

能量接近并不保证结构因子正确；只有 fidelity、方差、L² 污染和 S_L 同时通过，才能说 NQS 学到了导引中心几何。
