# Run manifest

Date: 2026-07-29 (Asia/Hong_Kong)

## Hardware and environments

- GPU: NVIDIA GeForce RTX 4090 Laptop GPU, 16 GB.
- ED: `/home/zyz/miniconda3/envs/vmc_gpu/bin/python` (SciPy sparse CPU).
- V5 NQS: `/home/zyz/miniconda3/envs/nk_env/bin/python` with JAX 0.9.0 and `CudaDevice(id=0)`.
- The `vmc_gpu` environment had `jaxlib=0.5.3` with CUDA plugin 0.6.2 and therefore fell back to CPU. No result in this study labels that fallback as GPU.

## ED production command

```bash
cd /home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/geometry_chirality_study_20260729
OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
  /home/zyz/miniconda3/envs/vmc_gpu/bin/python ed_geometry_suite.py \
  --sizes 4 5 6 7 8 9 --path-sizes 4 6 8 --lanczos-steps 180
```

## V5 multi-size diagnostic run

The run used the best existing N=8 BCE teacher independently at every size;
this intentionally tested transfer and did not claim exact supervision at
N=4--7.

```bash
cd /home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS
/home/zyz/miniconda3/envs/nk_env/bin/python \
  chiral_graviton_fock_ar_nqs_symmetry_v5.py \
  --sizes 4 5 6 7 8 --hidden 128 --batch 32 --hops 64 --steps 1000 \
  --learning-rate 1e-6 --warmup 200 --highest-weight-penalty 10 \
  --lplus-hops 128 --pretrain-steps 0 \
  --load-pretrained-params runs/fock_ar_nqs_teacher_N8_bce/teacher_pretrained_params.npz \
  --no-progressive-transfer --amplitude-init-scale 1.0 \
  --entropy-temperature 0.0 --skip-self-test \
  --output-dir geometry_chirality_study_20260729/runs/v5_geometry \
  --cache-dir geometry_chirality_study_20260729/cache/v5_interactions
```

## High-fidelity N=8 control

- exact-teacher pretraining: 12,000 steps;
- teacher ground fidelity before weak VMC: 0.98212158;
- teacher excited fidelity before weak VMC: 0.96494431;
- V5 weak fine-tuning: 200 steps at learning rate `1e-7`.

The exact post-training geometry evaluation is stored in
`results/highfidelity/v5_geometry.csv`.

## Validation

- All Python entry points pass `py_compile`.
- Density-tensor M-component covariance errors are at or below about `1e-11`.
- Coulomb particle-hole L=2 gaps agree to `2.2e-16` at `2Q=9`.
- Hamiltonian eigenstate residuals are recorded in the CSV/JSON outputs.
- Raw ill-conditioned S4/S6 fits are retained; the primary Coulomb S4 result
  uses the same-N Coulomb/V1 L=2 ratio calibrated to Laughlin `S4=1/4`.

## Story-completion calculations

```bash
cd /home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/geometry_chirality_study_20260729
OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
  /home/zyz/miniconda3/envs/vmc_gpu/bin/python story_completion_suite.py \
  --path-lanczos-steps 140 --convergence-steps 80 120 160 180 220

OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 \
  /home/zyz/miniconda3/envs/vmc_gpu/bin/python endpoint_n10_suite.py \
  --lanczos-steps 140 --convergence-steps 60 100 140 180
```

The N=8 crossover window was refined separately on 21 equally spaced points
from alpha=0.75 to 0.85 (step 0.005); the resulting rows are stored in
`results/dense_path_N8_crossover.csv`.

## Exact L=0 projection evaluation

```bash
/home/zyz/miniconda3/envs/nk_env/bin/python evaluate_v5_geometry.py \
  --sizes 4 5 6 7 8 --checkpoint-root runs/v5_geometry \
  --results-dir results --cache-dir cache/ed
/home/zyz/miniconda3/envs/nk_env/bin/python evaluate_v5_geometry.py \
  --sizes 8 --checkpoint-root runs/v5_geometry_highfidelity \
  --results-dir results/highfidelity --cache-dir cache/ed
```

The projector is the orthogonal null-space projector of L_+ in M=0, solved by
LSMR.  Its null residual, fidelity identity error, and projected L2 are stored
for every checkpoint.
