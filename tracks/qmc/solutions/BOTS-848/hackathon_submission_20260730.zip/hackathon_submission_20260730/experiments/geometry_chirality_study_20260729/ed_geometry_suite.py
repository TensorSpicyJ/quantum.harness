#!/usr/bin/env python3
"""Sparse-ED study of geometry, spectra, interpolation, PH, and quenches.

All operators reuse the conventions in the parent repository.  Numerical
tables are written as CSV, JSON, and Markdown under ``results/``.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from scipy import sparse
from scipy.linalg import eigh
from scipy.sparse.linalg import eigsh

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from chiral_graviton_ed import (  # noqa: E402
    antisymmetric_pair_matrix,
    clebsch_gordan2,
    interaction_pseudopotentials,
)
from chiral_graviton_nqs_vmc import TensorHeadTerm  # noqa: E402
from chiral_graviton_nqs_vmc_sparse import (  # noqa: E402
    SparseSectorCache,
    apply_l2,
    apply_rank2,
    cached_hamiltonian,
    sparse_many_body_hamiltonian,
    sparse_raising_operator,
)


Array = np.ndarray
Sparse = sparse.csr_matrix


@dataclass
class StateData:
    energy: float
    vector: Array
    l2: float
    residual: float


def _json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def markdown_table(rows: list[dict[str, Any]], columns: list[str]) -> str:
    if not rows:
        return "_No data._\n"

    def fmt(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, float):
            if not np.isfinite(value):
                return str(value)
            return f"{value:.8g}"
        return str(value).replace("|", "\\|")

    lines = [
        "| " + " | ".join(columns) + " |",
        "|" + "|".join("---" for _ in columns) + "|",
    ]
    lines.extend(
        "| " + " | ".join(fmt(row.get(column)) for column in columns) + " |"
        for row in rows
    )
    return "\n".join(lines) + "\n"


def pair_hamiltonian_data(two_q: int, interaction: str):
    pp = interaction_pseudopotentials(two_q, interaction)
    return antisymmetric_pair_matrix(two_q, pp)


def hamiltonian(
    cache: SparseSectorCache,
    M: int,
    interaction: str,
    cache_dir: Path,
    column_chunk_size: int,
) -> Sparse:
    basis = cache.basis(M)
    pairs, pair_matrix = pair_hamiltonian_data(cache.two_q, interaction)
    path = cache_dir / (
        f"H_{interaction}_N{cache.particles}_2Q{cache.two_q}_M{M:+d}.npz"
    )
    return cached_hamiltonian(
        path,
        basis,
        pairs,
        pair_matrix,
        cache.two_q,
        column_chunk_size,
        f"{interaction} N={cache.particles} M={M:+d}",
    )


def normalize_phase(vector: Array) -> Array:
    vector = np.asarray(vector, dtype=np.complex128)
    index = int(np.argmax(np.abs(vector)))
    phase = vector[index] / max(abs(vector[index]), 1.0e-300)
    return vector / phase


def targeted_state(
    H: Sparse,
    cache: SparseSectorCache,
    M: int,
    target_L: int,
    penalty: float = 0.2,
    tolerance: float = 1.0e-11,
    initial: Array | None = None,
) -> StateData:
    """Lowest state in an L irrep.

    For the M=0 ground state the physical Hamiltonian is diagonalized directly
    and L2 is only a validation.  For a highest-weight M=L sector,
    L2-L(L+1)=L_-L_+ is positive semidefinite, so a *linear* penalty is enough.
    Avoiding a squared L2 operator greatly improves ARPACK conditioning.
    """

    raising = sparse_raising_operator(cache, M)
    constant = float(M * (M + 1))
    target = float(target_L * (target_L + 1))

    def l2_apply(vector: Array) -> Array:
        return raising.T @ (raising @ vector) + constant * vector

    if M == 0 and target_L == 0:
        op = H
    elif M == target_L:
        def matvec(vector: Array) -> Array:
            return H @ vector + penalty * (l2_apply(vector) - target * vector)

        op = sparse.linalg.LinearOperator(
            H.shape, matvec=matvec, dtype=np.float64
        )
    else:
        raise ValueError(
            "targeted_state supports the M=0,L=0 ground or highest-weight M=L"
        )
    _, vectors = eigsh(
        op,
        k=1,
        which="SA",
        tol=tolerance,
        maxiter=max(20000, 20 * H.shape[0]),
        v0=initial,
    )
    vector = normalize_phase(vectors[:, 0])
    hvec = H @ vector
    energy = float(np.vdot(vector, hvec).real)
    l2vec = l2_apply(vector)
    l2 = float(np.vdot(vector, l2vec).real)
    residual = float(np.linalg.norm(hvec - energy * vector))
    if abs(l2 - target) > 2.0e-7:
        raise RuntimeError(
            f"N={cache.particles} M={M}: target L={target_L}, got L2={l2}"
        )
    return StateData(energy, vector, l2, residual)


def structure_factor(
    cache: SparseSectorCache, ground: Array, ell: int
) -> tuple[float, float]:
    """Return normalized S_L and the maximum M-covariance deviation."""

    weights = np.asarray(
        [
            np.vdot(
                cache.rho(0, ell, m) @ ground,
                cache.rho(0, ell, m) @ ground,
            ).real
            for m in range(-ell, ell + 1)
        ]
    )
    factor = (cache.two_q + 1.0) / cache.particles
    value = float(factor * np.mean(weights))
    covariance = float(
        np.max(np.abs(weights - np.mean(weights)))
        / max(float(np.mean(weights)), 1.0e-300)
    )
    return value, covariance


def lanczos_spectrum(
    H: Sparse,
    ground_energy: float,
    seed: Array,
    steps: int,
    reorthogonalize: bool = True,
) -> dict[str, Any]:
    """Zero-temperature spectral measure from a normalized probe seed."""

    norm2 = float(np.vdot(seed, seed).real)
    if norm2 < 1.0e-24:
        raise RuntimeError("spectral seed has zero norm")
    q = np.asarray(seed / math.sqrt(norm2), dtype=np.complex128)
    previous = np.zeros_like(q)
    beta_previous = 0.0
    alphas: list[float] = []
    betas: list[float] = []
    vectors: list[Array] = []
    for iteration in range(min(steps, H.shape[0])):
        if reorthogonalize:
            vectors.append(q.copy())
        z = H @ q - beta_previous * previous
        alpha = float(np.vdot(q, z).real)
        z = z - alpha * q
        if reorthogonalize:
            for old in vectors:
                z -= np.vdot(old, z) * old
        beta = float(np.linalg.norm(z))
        alphas.append(alpha)
        if beta < 1.0e-13 or iteration + 1 == min(steps, H.shape[0]):
            break
        betas.append(beta)
        previous, q = q, z / beta
        beta_previous = beta
    tri = np.diag(alphas)
    if betas:
        off = np.asarray(betas[: len(alphas) - 1])
        tri += np.diag(off, 1) + np.diag(off, -1)
    values, eigenvectors = eigh(tri)
    weights = norm2 * np.square(np.abs(eigenvectors[0, :]))
    excitation = values - ground_energy
    order = np.argsort(excitation)
    return {
        "omega": excitation[order],
        "weights": weights[order],
        "sum_weight": float(weights.sum()),
        "lanczos_dimension": len(alphas),
    }


def spectral_summary(
    H: Sparse,
    cache: SparseSectorCache,
    ground: StateData,
    ell: int,
    lanczos_steps: int,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    seed = cache.rho(0, ell, 0) @ ground.vector
    spectrum = lanczos_spectrum(
        H, ground.energy, seed, lanczos_steps, reorthogonalize=True
    )
    omega = spectrum["omega"]
    weights = spectrum["weights"]
    threshold = max(1.0e-12, 1.0e-10 * float(weights.sum()))
    physical = np.flatnonzero((omega > 1.0e-10) & (weights > threshold))
    if not len(physical):
        raise RuntimeError("no nonzero spectral poles")
    strongest = int(physical[np.argmax(weights[physical])])
    lowest = int(physical[np.argmin(omega[physical])])
    total = float(weights[physical].sum())
    summary = {
        "N": cache.particles,
        "interaction": "",
        "L_probe": ell,
        "total_weight_M0": total,
        "lowest_pole": float(omega[lowest]),
        "lowest_pole_fraction": float(weights[lowest] / total),
        "strongest_pole": float(omega[strongest]),
        "strongest_pole_fraction": float(weights[strongest] / total),
        "spectral_centroid": float(
            np.sum(omega[physical] * weights[physical]) / total
        ),
        "lanczos_dimension": spectrum["lanczos_dimension"],
    }
    poles = [
        {
            "N": cache.particles,
            "interaction": "",
            "L_probe": ell,
            "omega": float(omega[index]),
            "weight": float(weights[index]),
            "fraction": float(weights[index] / total),
        }
        for index in physical
    ]
    poles.sort(key=lambda row: row["weight"], reverse=True)
    return summary, poles[:20]


def fit_long_wave(
    rows: list[dict[str, Any]],
    interaction: str,
    min_N: int,
    max_L: int,
) -> dict[str, Any]:
    """Joint x and 1/N fit with leave-one-size-out uncertainty."""

    selected = [
        row
        for row in rows
        if row["interaction"] == interaction
        and row["N"] >= min_N
        and row["L"] <= max_L
    ]
    if len(selected) < 7:
        raise RuntimeError("not enough structure-factor points")

    def design(sample: list[dict[str, Any]]) -> tuple[Array, Array]:
        x = np.asarray([row["x_q2"] for row in sample])
        inv_n = np.asarray([1.0 / row["N"] for row in sample])
        matrix = np.column_stack(
            [x**2, x**3, x**4, inv_n * x**2, inv_n * x**3]
        )
        target = np.asarray([row["S_L"] for row in sample])
        return matrix, target

    matrix, target = design(selected)
    coefficients, _, _, singular = np.linalg.lstsq(matrix, target, rcond=None)
    prediction = matrix @ coefficients
    rms = float(np.sqrt(np.mean(np.square(target - prediction))))
    jackknife = []
    sizes = sorted({int(row["N"]) for row in selected})
    for omitted in sizes:
        sample = [row for row in selected if row["N"] != omitted]
        if len(sample) < matrix.shape[1]:
            continue
        local_matrix, local_target = design(sample)
        local, *_ = np.linalg.lstsq(local_matrix, local_target, rcond=None)
        jackknife.append(local)
    jackknife_array = np.asarray(jackknife)
    errors = (
        np.sqrt((len(jackknife) - 1) * np.var(jackknife_array, axis=0))
        if len(jackknife) > 1
        else np.full_like(coefficients, np.nan)
    )
    return {
        "interaction": interaction,
        "min_N": min_N,
        "max_L": max_L,
        "points": len(selected),
        "model": "S=(S4+b4/N)x^2+(S6+b6/N)x^3+S8*x^4",
        "S4": float(coefficients[0]),
        "S4_jackknife": float(errors[0]),
        "S6": float(coefficients[1]),
        "S6_jackknife": float(errors[1]),
        "S8": float(coefficients[2]),
        "b4": float(coefficients[3]),
        "b6": float(coefficients[4]),
        "rms_residual": rms,
        "condition_number": float(singular[0] / singular[-1]),
    }


def calibrated_s4_ratio(
    rows: list[dict[str, Any]], bound: float = 0.25
) -> dict[str, Any]:
    """Calibrate Coulomb S4 by the same-size Laughlin L=2 structure factor.

    The ratio cancels the density-tensor normalization and the dominant
    spherical curvature factor.  A quadratic 1/N extrapolation is primary; a
    linear fit excluding the smallest size supplies a model-spread error.
    """

    by_key = {
        (row["interaction"], int(row["N"])): row
        for row in rows
        if int(row["L"]) == 2
    }
    sizes = sorted(
        N
        for interaction, N in by_key
        if interaction == "v1" and ("coulomb", N) in by_key
    )
    if len(sizes) < 4:
        raise RuntimeError("calibrated S4 needs at least four common sizes")
    n = np.asarray(sizes, dtype=float)
    ratios = np.asarray(
        [by_key[("coulomb", N)]["S_L"] / by_key[("v1", N)]["S_L"] for N in sizes]
    )

    def extrapolate(use_n: Array, values: Array, order: int) -> tuple[float, float]:
        design = np.column_stack(
            [np.power(1.0 / use_n, power) for power in range(order + 1)]
        )
        coefficients, _, _, singular = np.linalg.lstsq(
            design, values, rcond=None
        )
        return float(coefficients[0]), float(singular[0] / singular[-1])

    ratio_quadratic, condition = extrapolate(n, ratios, 2)
    mask = n > np.min(n)
    ratio_linear, _ = extrapolate(n[mask], ratios[mask], 1)
    leave_one_out = []
    for index in range(len(n)):
        keep = np.arange(len(n)) != index
        leave_one_out.append(extrapolate(n[keep], ratios[keep], 2)[0])
    loo = np.asarray(leave_one_out)
    jackknife = float(
        math.sqrt((len(loo) - 1) * float(np.var(loo, ddof=0)))
    )
    model_spread = abs(ratio_quadratic - ratio_linear)
    ratio_error = math.hypot(jackknife, model_spread)
    calibrated = bound * ratio_quadratic
    calibrated_error = bound * ratio_error
    proxy = integrated_chirality_proxy(calibrated, bound)
    return {
        "method": "same-N Coulomb/V1 L=2 ratio; quadratic 1/N",
        "sizes": ",".join(map(str, sizes)),
        "laughlin_S4_calibration": bound,
        "ratio_thermodynamic": ratio_quadratic,
        "ratio_jackknife": jackknife,
        "ratio_linear_model": ratio_linear,
        "ratio_model_spread": model_spread,
        "ratio_total_error": ratio_error,
        "S4_coulomb_calibrated": calibrated,
        "S4_coulomb_error": calibrated_error,
        "condition_number": condition,
        **proxy,
    }

def integrated_chirality_proxy(
    fitted_s4: float, bound: float = 0.25
) -> dict[str, float]:
    """Kumar--Haldane sum-rule proxy, not a resolved polarization spectrum."""

    strong = 0.5 * (fitted_s4 + bound)
    weak = 0.5 * (fitted_s4 - bound)
    return {
        "haldane_bound": bound,
        "strong_weight_proxy": strong,
        "weak_weight_proxy": weak,
        "weak_to_strong_proxy": weak / strong if strong > 0.0 else float("nan"),
    }


def endpoint_study(
    sizes: Iterable[int],
    interactions: Iterable[str],
    max_L: int,
    cache_dir: Path,
    lanczos_steps: int,
    column_chunk_size: int,
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[tuple[int, str], tuple[SparseSectorCache, Sparse, StateData]],
]:
    structure_rows: list[dict[str, Any]] = []
    spectrum_rows: list[dict[str, Any]] = []
    pole_rows: list[dict[str, Any]] = []
    states: dict[
        tuple[int, str], tuple[SparseSectorCache, Sparse, StateData]
    ] = {}
    for N in sizes:
        two_q = 3 * (N - 1)
        cache = SparseSectorCache(N, two_q)
        Q = two_q / 2.0
        for interaction in interactions:
            H = hamiltonian(
                cache, 0, interaction, cache_dir, column_chunk_size
            )
            ground = targeted_state(H, cache, 0, 0)
            states[(N, interaction)] = (cache, H, ground)
            for ell in range(2, max_L + 1):
                value, covariance = structure_factor(cache, ground.vector, ell)
                structure_rows.append(
                    {
                        "N": N,
                        "twoQ": two_q,
                        "dimension_M0": H.shape[0],
                        "interaction": interaction,
                        "L": ell,
                        "x_q2": ell * (ell + 1.0) / Q,
                        "S_L": value,
                        "M_covariance_relative_error": covariance,
                        "ground_residual": ground.residual,
                    }
                )
            summary, poles = spectral_summary(
                H, cache, ground, 2, lanczos_steps
            )
            summary["interaction"] = interaction
            for pole in poles:
                pole["interaction"] = interaction
            spectrum_rows.append(summary)
            pole_rows.extend(poles)
            print(
                f"endpoint N={N} {interaction}: E0={ground.energy:.10f}, "
                f"S2={structure_rows[-(max_L-1)]['S_L']:.7g}, "
                f"peak={summary['strongest_pole']:.8f}",
                flush=True,
            )
    return structure_rows, spectrum_rows, pole_rows, states


def interpolation_study(
    sizes: Iterable[int],
    alphas: Iterable[float],
    states: dict[tuple[int, str], tuple[SparseSectorCache, Sparse, StateData]],
    cache_dir: Path,
    column_chunk_size: int,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for N in sizes:
        cache, Hv1, laughlin = states[(N, "v1")]
        _, Hc, coulomb = states[(N, "coulomb")]
        Hv1_M2 = hamiltonian(
            cache, 2, "v1", cache_dir, column_chunk_size
        )
        Hc_M2 = hamiltonian(
            cache, 2, "coulomb", cache_dir, column_chunk_size
        )
        previous0 = laughlin.vector
        previous2: Array | None = None
        for alpha in alphas:
            H = ((1.0 - alpha) * Hv1 + alpha * Hc).tocsr()
            H_M2 = (
                (1.0 - alpha) * Hv1_M2 + alpha * Hc_M2
            ).tocsr()
            ground = targeted_state(H, cache, 0, 0, initial=previous0)
            excited = targeted_state(
                H_M2, cache, 2, 2, initial=previous2, penalty=0.2
            )
            previous0 = ground.vector.real
            previous2 = excited.vector.real
            overlap = float(abs(np.vdot(laughlin.vector, ground.vector)) ** 2)
            S2, _ = structure_factor(cache, ground.vector, 2)
            S3, _ = structure_factor(cache, ground.vector, 3)
            spectrum, _ = spectral_summary(H, cache, ground, 2, 100)
            rows.append(
                {
                    "N": N,
                    "alpha": alpha,
                    "E0": ground.energy,
                    "E2": excited.energy,
                    "gap_L2": excited.energy - ground.energy,
                    "laughlin_fidelity": overlap,
                    "S_L2": S2,
                    "S_L3": S3,
                    "main_peak_fraction": spectrum[
                        "strongest_pole_fraction"
                    ],
                    "main_peak_omega": spectrum["strongest_pole"],
                    "ground_residual": ground.residual,
                    "L2_residual": excited.residual,
                }
            )
            print(
                f"path N={N} alpha={alpha:.2f}: gap={rows[-1]['gap_L2']:.8f}, "
                f"F={overlap:.8f}",
                flush=True,
            )
    return rows


def all_M_blocks(
    cache: SparseSectorCache, interaction: str
) -> tuple[list[int], list[tuple[int, ...]], Sparse, dict[int, slice]]:
    """Full fixed-N space arranged in M blocks; intended for N=4."""

    max_M = cache.particles * cache.two_q // 2
    Ms = [M for M in range(-max_M, max_M + 1) if cache.basis(M)]
    bases = [cache.basis(M) for M in Ms]
    pairs, pair_matrix = pair_hamiltonian_data(cache.two_q, interaction)
    blocks = [
        sparse_many_body_hamiltonian(
            basis,
            pairs,
            pair_matrix,
            cache.two_q,
            column_chunk_size=max(1, len(basis)),
            progress_label=f"full {interaction} M={M:+d}",
        )
        for M, basis in zip(Ms, bases)
    ]
    offsets = np.cumsum([0] + [len(basis) for basis in bases])
    slices = {
        M: slice(int(offsets[i]), int(offsets[i + 1]))
        for i, M in enumerate(Ms)
    }
    return Ms, bases, sparse.block_diag(blocks, format="csr"), slices


def coupled_density(
    cache: SparseSectorCache,
    source_M: int,
    l1: int,
    l2: int,
    J: int,
    K: int,
) -> Sparse:
    """[rho_l1 x rho_l2]_(J,K) from an arbitrary source-M sector."""

    result = sparse.csr_matrix(
        (
            len(cache.basis(source_M + K)),
            len(cache.basis(source_M)),
        ),
        dtype=np.float64,
    )
    for m2 in range(-l2, l2 + 1):
        m1 = K - m2
        if abs(m1) > l1:
            continue
        cg = clebsch_gordan2(
            2 * l1, 2 * m1, 2 * l2, 2 * m2, 2 * J, 2 * K
        )
        if abs(cg) < 1.0e-15:
            continue
        result += cg * (
            cache.rho(source_M + m2, l1, m1)
            @ cache.rho(source_M, l2, m2)
        )
    return result.tocsr()


def full_tensor_component(
    cache: SparseSectorCache,
    Ms: list[int],
    slices: dict[int, slice],
    J: int,
    K: int,
    l1: int = 2,
    l2: int = 2,
) -> Sparse:
    dimension = max(section.stop for section in slices.values())
    rows: list[int] = []
    columns: list[int] = []
    data: list[complex] = []
    for M in Ms:
        if M + K not in slices:
            continue
        block = coupled_density(cache, M, l1, l2, J, K).tocoo()
        target = slices[M + K]
        source = slices[M]
        rows.extend((block.row + target.start).tolist())
        columns.extend((block.col + source.start).tolist())
        data.extend(block.data.tolist())
    return sparse.coo_matrix(
        (data, (rows, columns)), shape=(dimension, dimension)
    ).tocsr()


def anisotropy_and_quench(
    N: int, couplings: Iterable[float], quench_coupling: float
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    two_q = 3 * (N - 1)
    cache = SparseSectorCache(N, two_q)
    Ms, _, H_sparse, slices = all_M_blocks(cache, "coulomb")
    H = H_sparse.toarray()
    Oplus = full_tensor_component(cache, Ms, slices, 2, 2)
    Qx = 0.5 * (Oplus + Oplus.getH())
    Qy = (Oplus - Oplus.getH()) / (2.0j)
    hermiticity_x = float(sparse.linalg.norm(Qx - Qx.getH()))
    hermiticity_y = float(sparse.linalg.norm(Qy - Qy.getH()))
    values0, vectors0 = eigh(H)
    psi0 = vectors0[:, 0]
    scale = float(np.linalg.norm(Qx @ psi0))
    if scale < 1.0e-12:
        raise RuntimeError("anisotropy probe annihilates the ground state")
    Qx = Qx / scale
    Qy = Qy / scale
    rows: list[dict[str, Any]] = []
    for coupling in couplings:
        values, vectors = eigh(H + coupling * Qx.toarray())
        ground = vectors[:, 0]
        rows.append(
            {
                "N": N,
                "lambda": coupling,
                "E0": float(values[0]),
                "gap_1": float(values[1] - values[0]),
                "gap_2": float(values[2] - values[0]),
                "fidelity_isotropic": float(
                    abs(np.vdot(psi0, ground)) ** 2
                ),
                "Qx_expectation": float(
                    np.vdot(ground, Qx @ ground).real
                ),
                "Qy_expectation": float(
                    np.vdot(ground, Qy @ ground).real
                ),
            }
        )

    post_values, post_vectors = eigh(H + quench_coupling * Qx.toarray())
    amplitudes = post_vectors.conj().T @ psi0
    isotropic_gap = float(values0[1] - values0[0])
    max_time = max(400.0, 20.0 * 2.0 * math.pi / max(isotropic_gap, 1e-6))
    times = np.linspace(0.0, max_time, 2048)
    qx_values = []
    qy_values = []
    for time_value in times:
        state = post_vectors @ (
            np.exp(-1j * post_values * time_value) * amplitudes
        )
        qx_values.append(float(np.vdot(state, Qx @ state).real))
        qy_values.append(float(np.vdot(state, Qy @ state).real))
    centered = np.asarray(qx_values) - np.mean(qx_values)
    frequencies = 2.0 * math.pi * np.fft.rfftfreq(
        len(times), d=times[1] - times[0]
    )
    power = np.abs(np.fft.rfft(centered)) ** 2
    dominant_index = int(np.argmax(power[1:]) + 1)
    quench_rows = [
        {
            "time": float(t),
            "Qx": x,
            "Qy": y,
        }
        for t, x, y in zip(times, qx_values, qy_values)
    ]
    diagnostics = {
        "N": N,
        "operator": "Hermitian part of [rho_2 x rho_2]_(2,+2)",
        "operator_scale_original_ground_norm": scale,
        "Qx_hermiticity_error": hermiticity_x,
        "Qy_hermiticity_error": hermiticity_y,
        "quench_lambda": quench_coupling,
        "dominant_angular_frequency": float(frequencies[dominant_index]),
        "isotropic_first_gap": isotropic_gap,
        "max_abs_Qy": float(np.max(np.abs(qy_values))),
        "interpretation": (
            "frequency probe only; Qy=0/equal-helicity behavior on the "
            "SO(3) sphere is not a circular-polarization measurement"
        ),
    }
    return rows, quench_rows, diagnostics


def particle_hole_study(N: int) -> list[dict[str, Any]]:
    two_q = 3 * (N - 1)
    orbitals = two_q + 1
    rows: list[dict[str, Any]] = []
    endpoint: dict[int, tuple[float, float, float, float]] = {}
    for particles in (N, orbitals - N):
        cache = SparseSectorCache(particles, two_q)
        pairs, pair_matrix = pair_hamiltonian_data(two_q, "coulomb")
        H = sparse_many_body_hamiltonian(
            cache.basis(0),
            pairs,
            pair_matrix,
            two_q,
            column_chunk_size=1024,
            progress_label=f"PH N={particles}",
        )
        H2 = sparse_many_body_hamiltonian(
            cache.basis(2),
            pairs,
            pair_matrix,
            two_q,
            column_chunk_size=1024,
            progress_label=f"PH N={particles} M=2",
        )
        ground = targeted_state(H, cache, 0, 0)
        excited = targeted_state(H2, cache, 2, 2)
        weights = []
        for m in (-2, 2):
            probe = cache.rho(0, 2, m) @ ground.vector
            weights.append(float(np.vdot(probe, probe).real))
        total = float(
            sum(
                np.vdot(
                    cache.rho(0, 2, m) @ ground.vector,
                    cache.rho(0, 2, m) @ ground.vector,
                ).real
                for m in range(-2, 3)
            )
        )
        endpoint[particles] = (
            ground.energy,
            excited.energy - ground.energy,
            weights[0],
            weights[1],
        )
        rows.append(
            {
                "particles": particles,
                "holes": orbitals - particles,
                "twoQ": two_q,
                "dimension_M0": H.shape[0],
                "E0": ground.energy,
                "gap_L2": excited.energy - ground.energy,
                "rho_2_minus2_weight": weights[0],
                "rho_2_plus2_weight": weights[1],
                "circular_weight_relative_difference": (
                    weights[1] - weights[0]
                )
                / max(0.5 * (weights[1] + weights[0]), 1.0e-300),
                "total_rank2_weight": total,
                "per_flux_rank2_weight": total / orbitals,
            }
        )
    first, second = endpoint[N], endpoint[orbitals - N]
    rows.append(
        {
            "particles": "PH comparison",
            "holes": "",
            "twoQ": two_q,
            "dimension_M0": "",
            "E0": second[0] - first[0],
            "gap_L2": second[1] - first[1],
            "rho_2_minus2_weight": second[2] - first[2],
            "rho_2_plus2_weight": second[3] - first[3],
            "circular_weight_relative_difference": "",
            "total_rank2_weight": "",
            "per_flux_rank2_weight": "",
        }
    )
    return rows


def build_report(
    results_dir: Path,
    structure_rows: list[dict[str, Any]],
    spectrum_rows: list[dict[str, Any]],
    fits: list[dict[str, Any]],
    calibrated_s4: dict[str, Any],
    interpolation_rows: list[dict[str, Any]],
    anisotropy_rows: list[dict[str, Any]],
    quench_diagnostics: dict[str, Any],
    ph_rows: list[dict[str, Any]],
) -> None:
    proxies = []
    for fit in fits:
        proxy = integrated_chirality_proxy(fit["S4"])
        proxies.append({**fit, **proxy})
    lines = [
        "# ED 几何、谱权重与扩展物理结果",
        "",
        "## 1. 结构因子原始数据",
        "",
        "归一化与 `README.md` 一致；`M_covariance_relative_error` 是球面张量"
        "各分量等权的数值检验。",
        "",
        markdown_table(
            structure_rows,
            [
                "N",
                "twoQ",
                "interaction",
                "L",
                "x_q2",
                "S_L",
                "M_covariance_relative_error",
            ],
        ),
        "## 2. 联合长波拟合",
        "",
        markdown_table(
            proxies,
            [
                "interaction",
                "min_N",
                "max_L",
                "S4",
                "S4_jackknife",
                "S6",
                "S6_jackknife",
                "rms_residual",
                "condition_number",
                "haldane_bound",
                "weak_to_strong_proxy",
            ],
        ),
        (
            "`weak_to_strong_proxy` 由 Haldane/Kumar–Haldane 积分 sum rule "
            "反演，只是总反手性权重代理，不是频率分辨的圆偏振谱。若拟合 "
            "S4 低于 bound，说明当前有限尺寸拟合不能用于该反演。"
        ),
        "",
        "### Laughlin 同尺寸比值校准（主结果）",
        "",
        markdown_table([calibrated_s4], list(calibrated_s4)),
        "",
        (
            "主结果使用同一 N、同一 L=2 的 Coulomb/V1 比值，再以精确 "
            "Laughlin S4=1/4 标定；这会消去共同的密度张量 convention 和主要 "
            "球面曲率因子。误差合并 leave-one-size-out 与线性/二次模型差。"
        ),
        "",        "## 3. \(L=2\) 动态谱",
        "",
        markdown_table(
            spectrum_rows,
            [
                "N",
                "interaction",
                "total_weight_M0",
                "lowest_pole",
                "lowest_pole_fraction",
                "strongest_pole",
                "strongest_pole_fraction",
                "spectral_centroid",
            ],
        ),
        (
            "这里的谱由 Lanczos/Krylov continued fraction 获得。主峰占比回答"
            "“最低/最强 L=2 态是否承载大部分几何谱权重”；它不把 "
            "\(M=+2\) 与 \(M=-2\) 误认成两种 helicity。"
        ),
        "",
        "## 4. \(V_1\\rightarrow\) Coulomb 连续路径",
        "",
        markdown_table(
            interpolation_rows,
            [
                "N",
                "alpha",
                "gap_L2",
                "laughlin_fidelity",
                "S_L2",
                "S_L3",
                "main_peak_fraction",
                "main_peak_omega",
            ],
        ),
        "",
        "## 5. 各向异性与 nematic 软化探针（N=4）",
        "",
        markdown_table(
            anisotropy_rows,
            [
                "lambda",
                "gap_1",
                "gap_2",
                "fidelity_isotropic",
                "Qx_expectation",
                "Qy_expectation",
            ],
        ),
        "",
        "该探针是归一化的球面 rank-2 两体密度张量，属于受控的模型"
        "各向异性；它不是完整 generalized-pseudopotential 厚度/质量度规模型。",
        "",
        "## 6. 几何 quench",
        "",
        markdown_table([quench_diagnostics], list(quench_diagnostics)),
        "",
        "## 7. 粒子–空穴检查",
        "",
        markdown_table(
            ph_rows,
            [
                "particles",
                "holes",
                "gap_L2",
                "rho_2_minus2_weight",
                "rho_2_plus2_weight",
                "circular_weight_relative_difference",
                "per_flux_rank2_weight",
            ],
        ),
        (
            "PH 共轭能谱可校验，但球面 \(\rho_{2,\pm2}\) 等权，因此这个"
            "密度探针不能显示实验圆偏振手性翻转。这是 null result，也是对"
            "“M=±2 即 helicity”错误识别的直接反证。"
        ),
        "",
    ]
    (results_dir / "ED_RESULTS.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[4, 5, 6, 7, 8, 9])
    parser.add_argument("--max-L", type=int, default=4)
    parser.add_argument("--lanczos-steps", type=int, default=160)
    parser.add_argument("--column-chunk-size", type=int, default=1024)
    parser.add_argument(
        "--path-sizes", type=int, nargs="+", default=[4, 6, 8]
    )
    parser.add_argument(
        "--alphas",
        type=float,
        nargs="+",
        default=[0.0, 0.25, 0.5, 0.75, 1.0],
    )
    parser.add_argument("--anisotropy-N", type=int, default=4)
    parser.add_argument(
        "--anisotropy-couplings",
        type=float,
        nargs="+",
        default=[-0.08, -0.04, -0.02, 0.0, 0.02, 0.04, 0.08],
    )
    parser.add_argument("--quench-coupling", type=float, default=0.03)
    parser.add_argument("--results-dir", type=Path, default=HERE / "results")
    parser.add_argument("--cache-dir", type=Path, default=HERE / "cache" / "ed")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.results_dir.mkdir(parents=True, exist_ok=True)
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    structure_rows, spectrum_rows, pole_rows, states = endpoint_study(
        args.sizes,
        ["v1", "coulomb"],
        args.max_L,
        args.cache_dir,
        args.lanczos_steps,
        args.column_chunk_size,
    )
    fits = [
        fit_long_wave(
            structure_rows,
            interaction,
            min_N=max(4, min(args.sizes)),
            max_L=min(3, args.max_L),
        )
        for interaction in ("v1", "coulomb")
    ]
    calibrated_s4 = calibrated_s4_ratio(structure_rows)
    interpolation_rows = interpolation_study(
        [N for N in args.path_sizes if N in args.sizes],
        args.alphas,
        states,
        args.cache_dir,
        args.column_chunk_size,
    )
    anisotropy_rows, quench_rows, quench_diagnostics = (
        anisotropy_and_quench(
            args.anisotropy_N,
            args.anisotropy_couplings,
            args.quench_coupling,
        )
    )
    ph_rows = particle_hole_study(args.anisotropy_N)

    tables = {
        "structure_factor.csv": structure_rows,
        "spectral_summary.csv": spectrum_rows,
        "spectral_poles.csv": pole_rows,
        "long_wave_fits.csv": fits,
        "s4_calibrated.csv": [calibrated_s4],
        "interpolation.csv": interpolation_rows,
        "anisotropy.csv": anisotropy_rows,
        "quench_timeseries.csv": quench_rows,
        "particle_hole.csv": ph_rows,
    }
    for filename, rows in tables.items():
        write_csv(args.results_dir / filename, rows)
    payload = {
        "cli": {
            **vars(args),
            "results_dir": str(args.results_dir),
            "cache_dir": str(args.cache_dir),
        },
        "elapsed_seconds": time.perf_counter() - started,
        "structure_factor": structure_rows,
        "spectral_summary": spectrum_rows,
        "spectral_poles": pole_rows,
        "long_wave_fits": fits,
        "calibrated_s4": [calibrated_s4],
        "interpolation": interpolation_rows,
        "anisotropy": anisotropy_rows,
        "quench_diagnostics": quench_diagnostics,
        "particle_hole": ph_rows,
    }
    (args.results_dir / "ed_results.json").write_text(
        json.dumps(payload, indent=2, default=_json_default), encoding="utf-8"
    )
    build_report(
        args.results_dir,
        structure_rows,
        spectrum_rows,
        fits,
        calibrated_s4,
        interpolation_rows,
        anisotropy_rows,
        quench_diagnostics,
        ph_rows,
    )
    print(
        f"ED suite completed in {payload['elapsed_seconds']:.1f}s; "
        f"results={args.results_dir}",
        flush=True,
    )


if __name__ == "__main__":
    main()

