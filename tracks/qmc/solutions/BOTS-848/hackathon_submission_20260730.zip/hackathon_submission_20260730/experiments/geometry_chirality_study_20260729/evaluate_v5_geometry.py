#!/usr/bin/env python3
"""Evaluate trained V5 autoregressive NQS checkpoints on ED geometry tests."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np
from scipy.sparse.linalg import eigsh, lsmr

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import chiral_graviton_fock_ar_nqs as ar  # noqa: E402
from chiral_graviton_ed import (  # noqa: E402
    antisymmetric_pair_matrix,
    interaction_pseudopotentials,
)
from chiral_graviton_nqs_vmc_sparse import (  # noqa: E402
    SparseSectorCache,
    apply_l2,
    cached_hamiltonian,
    sparse_raising_operator,
    sparse_many_body_hamiltonian,
)


def load_params(path: Path) -> dict[str, Any]:
    restored = np.load(path)
    return {
        name.removeprefix("param__"): ar.jnp.asarray(restored[name])
        for name in restored.files
        if name.startswith("param__")
    }


def occupations(basis: tuple[int, ...], orbitals: int) -> np.ndarray:
    return np.asarray(
        [[(state >> orbital) & 1 for orbital in range(orbitals)] for state in basis],
        dtype=np.int32,
    )


def structure_factor(
    cache: SparseSectorCache, wavefunction: np.ndarray, ell: int
) -> float:
    weights = [
        np.vdot(
            cache.rho(0, ell, m) @ wavefunction,
            cache.rho(0, ell, m) @ wavefunction,
        ).real
        for m in range(-ell, ell + 1)
    ]
    return float((cache.two_q + 1.0) / cache.particles * np.mean(weights))


def exact_ground(H):
    values, vectors = eigsh(H, k=1, which="SA", tol=1.0e-12)
    return float(values[0]), vectors[:, 0]


def project_l0(
    cache: SparseSectorCache, wavefunction: np.ndarray
) -> tuple[np.ndarray, dict[str, float | int]]:
    """Orthogonally project an M=0 vector into ker(L_+) = L=0.

    In the M=0 sector every L>0 multiplet has a nonzero L_+ image, while an
    L=0 state is annihilated.  The row-space subtraction is therefore the
    exact Hilbert-space projector, up to the reported LSMR tolerance.
    """

    raising = sparse_raising_operator(cache, 0)
    solution = lsmr(
        raising.T,
        np.asarray(wavefunction, dtype=np.complex128),
        atol=1.0e-13,
        btol=1.0e-13,
        conlim=1.0e14,
        maxiter=max(1000, 4 * raising.shape[0]),
    )
    projected = wavefunction - raising.T @ solution[0]
    weight = float(np.vdot(projected, projected).real)
    if weight < 1.0e-15:
        raise RuntimeError("L=0 projection has numerically zero weight")
    projected /= math.sqrt(weight)
    null_residual = float(np.linalg.norm(raising @ projected))
    return projected, {
        "L0_weight": weight,
        "L0_projection_removed_weight": max(0.0, 1.0 - weight),
        "L0_projection_null_residual": null_residual,
        "L0_projection_lsmr_iterations": int(solution[2]),
        "L0_projection_lsmr_normar": float(solution[4]),
        "L0_projection_lsmr_conda": float(solution[6]),
    }


def evaluate_one(
    N: int, checkpoint: Path, hidden: int, cache_dir: Path
) -> dict[str, Any]:
    two_q = 3 * (N - 1)
    orbitals = two_q + 1
    cache = SparseSectorCache(N, two_q)
    basis = cache.basis(0)
    params = load_params(checkpoint)
    log_psi, _ = ar.make_wavefunction_functions(N, hidden)
    configs = occupations(basis, orbitals)
    chunks = []
    for start in range(0, len(configs), 2048):
        values = log_psi(
            params, ar.jnp.asarray(configs[start : start + 2048]), 0
        )
        chunks.append(np.asarray(ar.jax.device_get(values)))
    logs = np.concatenate(chunks)
    shift = float(np.max(np.real(logs)))
    psi = np.exp(logs - shift)
    psi /= np.linalg.norm(psi)

    pp = interaction_pseudopotentials(two_q, "coulomb")
    pairs, pair_matrix = antisymmetric_pair_matrix(two_q, pp)
    cache_dir.mkdir(parents=True, exist_ok=True)
    H = cached_hamiltonian(
        cache_dir / f"H_coulomb_N{N}_2Q{two_q}_M+0.npz",
        basis,
        pairs,
        pair_matrix,
        two_q,
        1024,
        f"NQS eval H N={N}",
    )
    exact_energy, exact = exact_ground(H)
    hpsi = H @ psi
    energy = float(np.vdot(psi, hpsi).real)
    variance = float(np.vdot(hpsi, hpsi).real - energy**2)
    l2psi = apply_l2(cache, 0, psi)
    l2 = float(np.vdot(psi, l2psi).real)
    l2_variance = float(np.vdot(l2psi, l2psi).real - l2**2)
    fidelity = float(abs(np.vdot(exact, psi)) ** 2)
    projected, projection = project_l0(cache, psi)
    hprojected = H @ projected
    projected_energy = float(np.vdot(projected, hprojected).real)
    projected_variance = float(
        np.vdot(hprojected, hprojected).real - projected_energy**2
    )
    projected_l2_vector = apply_l2(cache, 0, projected)
    projected_l2 = float(np.vdot(projected, projected_l2_vector).real)
    projected_fidelity = float(abs(np.vdot(exact, projected)) ** 2)
    row: dict[str, Any] = {
        "N": N,
        "twoQ": two_q,
        "dimension_M0": len(basis),
        "checkpoint": str(checkpoint),
        "E_NQS": energy,
        "E_ED": exact_energy,
        "relative_energy_error": (energy - exact_energy)
        / max(abs(exact_energy), 1.0e-15),
        "energy_variance": max(0.0, variance),
        "fidelity_ED": fidelity,
        "L2": l2,
        "L2_variance": max(0.0, l2_variance),
        **projection,
        "E_projected_L0": projected_energy,
        "relative_energy_error_projected_L0": (
            projected_energy - exact_energy
        )
        / max(abs(exact_energy), 1.0e-15),
        "energy_variance_projected_L0": max(0.0, projected_variance),
        "fidelity_ED_projected_L0": projected_fidelity,
        "fidelity_projection_identity_error": abs(
            projected_fidelity
            - fidelity / max(projection["L0_weight"], 1.0e-300)
        ),
        "L2_projected_L0": projected_l2,
    }
    for ell in (2, 3, 4):
        nqs_s = structure_factor(cache, psi, ell)
        projected_s = structure_factor(cache, projected, ell)
        ed_s = structure_factor(cache, exact, ell)
        row[f"S_L{ell}_NQS"] = nqs_s
        row[f"S_L{ell}_projected_L0"] = projected_s
        row[f"S_L{ell}_ED"] = ed_s
        row[f"S_L{ell}_relative_error"] = (nqs_s - ed_s) / ed_s
        row[f"S_L{ell}_relative_error_projected_L0"] = (
            projected_s - ed_s
        ) / ed_s
    return row


def write_outputs(results_dir: Path, rows: list[dict[str, Any]]) -> None:
    results_dir.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0])
    with (results_dir / "v5_geometry.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    (results_dir / "v5_geometry.json").write_text(
        json.dumps(rows, indent=2), encoding="utf-8"
    )
    display = [
        "N",
        "E_NQS",
        "E_ED",
        "relative_energy_error",
        "energy_variance",
        "fidelity_ED",
        "L2",
        "L0_weight",
        "fidelity_ED_projected_L0",
        "L2_projected_L0",
        "S_L2_NQS",
        "S_L2_ED",
        "S_L2_relative_error",
        "S_L2_relative_error_projected_L0",
        "S_L3_relative_error",
        "S_L3_relative_error_projected_L0",
        "S_L4_relative_error",
        "S_L4_relative_error_projected_L0",
    ]
    lines = [
        "# V5 NQS 几何观测量与 ED 对照",
        "",
        "这里使用最新 `symmetry_v5` 自回归架构的 M=0 波函数，并通过"
        "`ker(L_+)` 做严格正交的 L=0 投影。投影前后对照将角动量泄漏与"
        "L=0 子空间内部误差分开。",
        "",
        "| " + " | ".join(display) + " |",
        "|" + "|".join("---" for _ in display) + "|",
    ]
    for row in rows:
        values = []
        for key in display:
            value = row[key]
            values.append(f"{value:.8g}" if isinstance(value, float) else str(value))
        lines.append("| " + " | ".join(values) + " |")
    lines.extend(
        [
            "",
            "能量接近并不保证结构因子正确；只有 fidelity、方差、L² 污染和 "
            "S_L 同时通过，才能说 NQS 学到了导引中心几何。",
            "",
        ]
    )
    (results_dir / "V5_NQS_RESULTS.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=int, nargs="+", default=[4, 5, 6, 7, 8])
    parser.add_argument("--hidden", type=int, default=128)
    parser.add_argument(
        "--checkpoint-root", type=Path, default=HERE / "runs" / "v5_geometry"
    )
    parser.add_argument("--results-dir", type=Path, default=HERE / "results")
    parser.add_argument("--cache-dir", type=Path, default=HERE / "cache" / "nqs_eval")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for N in args.sizes:
        checkpoint = args.checkpoint_root / f"N{N}" / "checkpoint.npz"
        if not checkpoint.exists():
            print(f"skip N={N}: missing {checkpoint}", flush=True)
            continue
        row = evaluate_one(N, checkpoint, args.hidden, args.cache_dir)
        rows.append(row)
        print(
            f"N={N}: fidelity={row['fidelity_ED']:.8f}, "
            f"L0={row['L0_weight']:.8f}, "
            f"Fproj={row['fidelity_ED_projected_L0']:.8f}, "
            f"S2err={row['S_L2_relative_error']:.3%}->"
            f"{row['S_L2_relative_error_projected_L0']:.3%}",
            flush=True,
        )
    if not rows:
        raise FileNotFoundError("no V5 checkpoints found")
    write_outputs(args.results_dir, rows)


if __name__ == "__main__":
    main()

