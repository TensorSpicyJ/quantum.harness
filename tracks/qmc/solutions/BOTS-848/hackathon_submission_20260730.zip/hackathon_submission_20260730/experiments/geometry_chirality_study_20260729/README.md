# Geometry and chirality study for the spherical \(\nu=1/3\) NQS

This directory is an isolated follow-up study built on the implementations in
the parent directory.  It does not modify prior runs.

The study has two validation tracks:

1. sparse exact diagonalization (ED), which supplies symmetry-clean reference
   states and spectra for small systems;
2. the latest scalable autoregressive Fock NQS (`symmetry_v5`), evaluated with
   exactly the same projected-density observables.

## Commands

Run the ED geometry, spectrum, interpolation, anisotropy, particle-hole, and
quench suite:

```bash
python ed_geometry_suite.py --sizes 4 5 6 7 8 9
```

Train the latest V5 architecture (from the parent directory):

```bash
python ../chiral_graviton_fock_ar_nqs_symmetry_v5.py \
  --sizes 4 5 6 7 8 --hidden 128 --steps 1500 \
  --output-dir runs/v5_geometry --cache-dir cache/v5_interactions
```

Evaluate those checkpoints against ED:

```bash
python evaluate_v5_geometry.py \
  --checkpoint-root runs/v5_geometry --sizes 4 5 6 7 8
```

Resolve the dense N=8 spectral flow and N=9 Krylov convergence:

```bash
python story_completion_suite.py
```

Reproduce the N=10 endpoint and its independent Krylov convergence check:

```bash
python endpoint_n10_suite.py
```

Build the report-ready Chinese story:

```bash
python build_summary.py
```

`evaluate_v5_geometry.py` now reports both the raw M=0 NQS and its exact
orthogonal projection into `ker(L_+)`, i.e. the strict L=0 subspace.

## Normalization

The parent repository defines the spherical projected density tensor
\(\rho_{LM}\) with \(\rho_{00}=N/\sqrt{2Q+1}\).  We therefore report

\[
S_L = \frac{2Q+1}{N(2L+1)}
      \sum_{M=-L}^{L}
      \langle \rho_{LM}^\dagger\rho_{LM}\rangle .
\]

For an \(L=0\) state, Wigner--Eckart reduces this to

\[
S_L = \frac{2Q+1}{N}\Vert\rho_{L0}\lvert0\rangle\Vert^2.
\]

The long-wave coordinate is \(x=(q\ell_B)^2=L(L+1)/Q\), so the fitted form is
\(S_L=S_4x^2+S_6x^3+\cdots\).  Raw values and fit design matrices are retained;
the thermodynamic coefficients are never inferred from one \(L=2\) point.

## Important chirality limitation

The spherical components \(M=+2\) and \(M=-2\) belong to one SO(3) tensor and
are related by rotations.  Their equal spectral weight is a covariance check,
not a helicity measurement.  This study consequently distinguishes:

- the resolved \(L=2\) density spectral function;
- an integrated opposite-chirality proxy inferred from excess above the
  Haldane \(S_4\) bound;
- a direct circular-polarization observable, which is **not** claimed without
  an additional planar/local-frame stress operator.

