#!/usr/bin/env python3
"""Reproduce the N=10 endpoint, S4 update, and Krylov convergence checks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from ed_geometry_suite import (
    calibrated_s4_ratio,
    endpoint_study,
    markdown_table,
    write_csv,
)
from story_completion_suite import krylov_convergence

HERE = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--N", type=int, default=10)
    parser.add_argument("--lanczos-steps", type=int, default=140)
    parser.add_argument(
        "--convergence-steps", type=int, nargs="+", default=[60, 100, 140, 180]
    )
    parser.add_argument("--column-chunk-size", type=int, default=512)
    parser.add_argument("--cache-dir", type=Path, default=HERE / "cache" / "ed")
    parser.add_argument("--results-dir", type=Path, default=HERE / "results")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    args.results_dir.mkdir(parents=True, exist_ok=True)
    structure, spectra, poles, _ = endpoint_study(
        [args.N],
        ["v1", "coulomb"],
        4,
        args.cache_dir,
        args.lanczos_steps,
        args.column_chunk_size,
    )
    convergence = krylov_convergence(
        args.N,
        "coulomb",
        args.convergence_steps,
        args.cache_dir,
        args.column_chunk_size,
    )
    previous = json.loads(
        (args.results_dir / "ed_results.json").read_text(encoding="utf-8")
    )["structure_factor"]
    calibrated = calibrated_s4_ratio(previous + structure)

    write_csv(args.results_dir / f"endpoint_N{args.N}_structure.csv", structure)
    write_csv(args.results_dir / f"endpoint_N{args.N}_spectrum.csv", spectra)
    write_csv(args.results_dir / f"endpoint_N{args.N}_poles.csv", poles)
    write_csv(
        args.results_dir / f"krylov_convergence_N{args.N}.csv", convergence
    )
    write_csv(
        args.results_dir / f"s4_calibrated_N4_N{args.N}.csv", [calibrated]
    )
    payload = {
        "structure_factor": structure,
        "spectral_summary": spectra,
        "spectral_poles": poles,
        f"calibrated_s4_N4_N{args.N}": calibrated,
    }
    (args.results_dir / f"endpoint_N{args.N}.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    (args.results_dir / f"krylov_convergence_N{args.N}.json").write_text(
        json.dumps(convergence, indent=2), encoding="utf-8"
    )
    lines = [
        f"# N={args.N} 端点与收敛复核",
        "",
        "## 结构因子",
        "",
        markdown_table(
            structure,
            ["interaction", "L", "S_L", "M_covariance_relative_error", "ground_residual"],
        ),
        "## 谱权重",
        "",
        markdown_table(
            spectra,
            ["interaction", "lowest_pole", "lowest_pole_fraction", "strongest_pole", "strongest_pole_fraction"],
        ),
        "## Coulomb Krylov 收敛",
        "",
        markdown_table(
            convergence,
            ["requested_steps", "strongest_pole", "strongest_pole_fraction", "sumrule_m2_relative_error"],
        ),
        "## 更新后的 S4",
        "",
        markdown_table([calibrated], list(calibrated)),
    ]
    (args.results_dir / f"N{args.N}_ENDPOINT.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
