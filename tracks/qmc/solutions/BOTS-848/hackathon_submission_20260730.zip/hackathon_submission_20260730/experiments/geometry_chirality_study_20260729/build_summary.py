#!/usr/bin/env python3
"""Build the report-ready Chinese story from all validated calculations."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"


def load_json(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))


def fmt(value: Any) -> str:
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, float):
        if not np.isfinite(value):
            return str(value)
        if abs(value) < 1.0e-4 and value != 0.0:
            return f"{value:.3e}"
        return f"{value:.7g}"
    return str(value)


def table(rows: list[dict[str, Any]], columns: list[str]) -> str:
    lines = [
        "| " + " | ".join(columns) + " |",
        "|" + "|".join("---" for _ in columns) + "|",
    ]
    for row in rows:
        lines.append(
            "| " + " | ".join(fmt(row.get(column, "")) for column in columns) + " |"
        )
    return "\n".join(lines)


def linear_crossing(
    rows: list[dict[str, Any]], key: str, target: float
) -> tuple[float, float, float]:
    ordered = sorted(rows, key=lambda row: row["alpha"])
    for left, right in zip(ordered, ordered[1:]):
        yl = left[key] - target
        yr = right[key] - target
        if yl <= 0.0 <= yr and yr != yl:
            estimate = left["alpha"] + (right["alpha"] - left["alpha"]) * (
                -yl / (yr - yl)
            )
            return float(left["alpha"]), float(right["alpha"]), float(estimate)
    raise RuntimeError(f"no crossing for {key}={target}")


def main() -> None:
    ed = load_json(RESULTS / "ed_results.json")
    story = load_json(RESULTS / "story_completion.json")
    refined = load_json(RESULTS / "dense_path_N8_crossover.json")
    endpoint10 = load_json(RESULTS / "endpoint_N10.json")
    conv10 = load_json(RESULTS / "krylov_convergence_N10.json")
    nqs = load_json(RESULTS / "v5_geometry.json")
    highfidelity = load_json(RESULTS / "highfidelity" / "v5_geometry.json")

    old_cal = ed["calibrated_s4"][0]
    cal = endpoint10["calibrated_s4_N4_N10"]
    bound = float(cal["haldane_bound"])
    s4 = float(cal["S4_coulomb_calibrated"])
    s4_error = float(cal["S4_coulomb_error"])
    excess_z = (s4 - bound) / s4_error
    upper_s4 = s4 + 1.96 * s4_error
    weak_ratio_central = max(0.0, (s4 - bound) / (s4 + bound))
    weak_ratio_upper = max(0.0, (upper_s4 - bound) / (upper_s4 + bound))

    spectra = ed["spectral_summary"] + endpoint10["spectral_summary"]
    finite_rows = []
    for N in (8, 9, 10):
        for interaction in ("v1", "coulomb"):
            row = next(
                item
                for item in spectra
                if int(item["N"]) == N and item["interaction"] == interaction
            )
            finite_rows.append(
                {
                    "N": N,
                    "interaction": interaction,
                    "lowest ω": row["lowest_pole"],
                    "lowest fraction": row["lowest_pole_fraction"],
                    "strongest ω": row["strongest_pole"],
                    "strongest fraction": row["strongest_pole_fraction"],
                }
            )
    coulomb = [row for row in spectra if row["interaction"] == "coulomb"]
    min_coulomb = min(row["lowest_pole_fraction"] for row in coulomb)

    path = story["dense_path"]
    path0 = min(path, key=lambda row: abs(row["alpha"]))
    path1 = min(path, key=lambda row: abs(row["alpha"] - 1.0))
    alpha_switch = linear_crossing(
        refined, "lowest_minus_competitor_fraction", 0.0
    )
    alpha_half = linear_crossing(refined, "lowest_pole_fraction", 0.5)
    max_sumrule = max(
        max(
            row["sumrule_m0_relative_error"],
            row["sumrule_m1_relative_error"],
            row["sumrule_m2_relative_error"],
        )
        for row in path + story["krylov_convergence"] + conv10
    )
    conv9_delta = max(
        abs(story["krylov_convergence"][-2]["strongest_pole"]
            - story["krylov_convergence"][-1]["strongest_pole"]),
        abs(story["krylov_convergence"][-2]["strongest_pole_fraction"]
            - story["krylov_convergence"][-1]["strongest_pole_fraction"]),
    )
    conv10_delta = max(
        abs(conv10[-2]["strongest_pole"] - conv10[-1]["strongest_pole"]),
        abs(conv10[-2]["strongest_pole_fraction"]
            - conv10[-1]["strongest_pole_fraction"]),
    )

    baseline8 = next(row for row in nqs if int(row["N"]) == 8)
    high8 = highfidelity[0]
    nqs_rows = []
    for name, row in (("baseline", baseline8), ("high-fidelity", high8)):
        nqs_rows.append(
            {
                "run": name,
                "L0 weight": row["L0_weight"],
                "fidelity before": row["fidelity_ED"],
                "fidelity after": row["fidelity_ED_projected_L0"],
                "energy err before": row["relative_energy_error"],
                "energy err after": row["relative_energy_error_projected_L0"],
                "S2 err before": row["S_L2_relative_error"],
                "S2 err after": row["S_L2_relative_error_projected_L0"],
                "S3 err after": row["S_L3_relative_error_projected_L0"],
                "S4 err after": row["S_L4_relative_error_projected_L0"],
                "projected L2": row["L2_projected_L0"],
            }
        )
    projection_max_identity = max(
        baseline8["fidelity_projection_identity_error"],
        high8["fidelity_projection_identity_error"],
    )
    projection_max_null = max(
        baseline8["L0_projection_null_residual"],
        high8["L0_projection_null_residual"],
    )

    s4_rows = [
        {
            "sizes": "N=4–9",
            "S4": old_cal["S4_coulomb_calibrated"],
            "combined error": old_cal["S4_coulomb_error"],
            "S4-bound": old_cal["S4_coulomb_calibrated"] - bound,
        },
        {
            "sizes": "N=4–10",
            "S4": s4,
            "combined error": s4_error,
            "S4-bound": s4 - bound,
        },
    ]

    endpoint_rows = [
        {
            "alpha": path0["alpha"],
            "Laughlin fidelity": path0["laughlin_fidelity"],
            "lowest L2 gap": path0["gap_lowest_L2"],
            "lowest fraction": path0["lowest_pole_fraction"],
            "strongest fraction": path0["strongest_pole_fraction"],
            "effective poles": path0["effective_pole_number"],
        },
        {
            "alpha": path1["alpha"],
            "Laughlin fidelity": path1["laughlin_fidelity"],
            "lowest L2 gap": path1["gap_lowest_L2"],
            "lowest fraction": path1["lowest_pole_fraction"],
            "strongest fraction": path1["strongest_pole_fraction"],
            "effective poles": path1["effective_pole_number"],
        },
    ]

    quench = ed["quench_diagnostics"]
    anisotropy = ed["anisotropy"]
    zero_aniso = min(anisotropy, key=lambda row: abs(row["lambda"]))
    edge_aniso = min(anisotropy, key=lambda row: abs(abs(row["lambda"]) - 0.08))

    lines = [
        "# Laughlin 几何模：可直接汇报的确定性主线",
        "",
        "## 一句话结论",
        "",
        "在有限尺寸 N=4–10 内，Coulomb 基态始终与 Laughlin 相连续；真正发生"
        "显著变化的不是拓扑基态，而是 L=2 几何谱权重：沿 V1→Coulomb 路径，"
        "最低极点从几乎暗的低能态变成承载 82%–89% 权重的相干主峰。最新 V5 NQS "
        "在严格 L=0 投影后可把 N=8 的 S2 误差从 15%–24% 压到 0.3%，说明此前"
        "主要失败来自很小但高角动量的对称性泄漏，而不是网络无法表达正确 L=0 几何。",
        "",
        "## 1. 主 story：同一 Laughlin 相中的几何谱重组",
        "",
        table(endpoint_rows, list(endpoint_rows[0])),
        "",
        f"N=8 整条路径的最小 Laughlin fidelity 为 {path1['laughlin_fidelity']:.8f}；"
        f"S2 只变化 {(path1['S_L2']/path0['S_L2']-1):.2%}，但最低极点权重从 "
        f"{path0['lowest_pole_fraction']:.3%} 增至 {path1['lowest_pole_fraction']:.3%}。",
        "",
        f"加密到 Δα=0.005 后，最低极点与原几何主峰在 "
        f"α∈[{alpha_switch[0]:.3f},{alpha_switch[1]:.3f}] 交换主导地位，"
        f"局部线性估计 α×={alpha_switch[2]:.5f}；其权重跨过 50% 位于 "
        f"α∈[{alpha_half[0]:.3f},{alpha_half[1]:.3f}]，估计 α50={alpha_half[2]:.5f}。"
        "这是谱权重的连续重排，不是基态相变。",
        "",
        "## 2. 尺寸和 Krylov 检验：Coulomb 最低模是稳定相干峰",
        "",
        table(finite_rows, list(finite_rows[0])),
        "",
        f"Coulomb 在 N=4–10 的最低极点占比下限为 {min_coulomb:.3%}。"
        "特别是新加入的 N=10：最低极点占 82.719%，而 V1 同尺寸最低极点仅占 "
        "0.622%，最强权重仍在更高能极点。",
        "",
        f"直接 m0/m1/m2 谱矩与 Krylov 离散谱的最大相对 sum-rule 残差为 "
        f"{max_sumrule:.2e}。N=9 的 180→220 步主峰最大变化为 {conv9_delta:.2e}；"
        f"N=10 的 140→180 步最大变化为 {conv10_delta:.2e}。因此 82%–89% 主峰"
        "不是 Krylov 截断伪影。",
        "",
        "## 3. NQS 的确定性诊断：问题是 symmetry leakage",
        "",
        table(nqs_rows, list(nqs_rows[0])),
        "",
        "投影使用 M=0 sector 中 ker(L+) 的正交补空间，不是重新训练，也不是调"
        "penalty。两套独立 checkpoint 都得到同一结果：只去掉 1.70%–3.11% 范数，"
        "fidelity 即升至 0.9987–0.9991，S2 误差降至 0.285%–0.332%，能量相对"
        "误差降至 2.9e-5–4.2e-5。",
        "",
        f"投影恒等式最大误差为 {projection_max_identity:.2e}，"
        f"||L+P0ψ|| 最大为 {projection_max_null:.2e}。结论是：V5 在 N=8 已学到"
        "高质量的 L=0 内部波函数，但当前软惩罚允许少量高-L 尾巴；结构因子对"
        "这类尾巴远比能量敏感。后续架构应把 P0 投影或严格 SU(2) 等变性放进"
        "训练/采样，而不是只延长 VMC。",
        "",
        "## 4. S4 与反手性：能说的是饱和一致性和上界",
        "",
        table(s4_rows, list(s4_rows[0])),
        "",
        f"加入 N=10 后，校准结果为 S4={s4:.6f}±{s4_error:.6f}，"
        f"相对 Haldane bound 1/4 的偏离只有 {excess_z:.2f} 个组合误差。"
        "因此数据与饱和相容，不能声称 Coulomb 已显著非饱和。",
        "",
        f"若采用 Kumar–Haldane 积分 sum-rule 代理，反/主手性中心比为 "
        f"{weak_ratio_central:.2%}；由于误差覆盖零，更稳妥的汇报是：在 "
        f"S4+1.96σ 的保守模型误差包络下，反/主手性比 < {weak_ratio_upper:.2%}。"
        "这仍不是频率分辨的圆偏振测量。",
        "",
        "## 5. 原来七个问题现在能回答到什么程度",
        "",
        f"1. **最低 L=2 是否主导？** 对 Coulomb 的 N=4–10：是，有限尺寸下至少 "
        f"{min_coulomb:.1%}；对 V1 的 N=8–10：否，最低态仅占 0.6%–2.7%。",
        "2. **圆偏振手性是什么？** 仍不能由球面 M=±2 判定；PH null test 已证明"
        "二者等权只是 SO(3) 协变性。",
        f"3. **弱反手性分支？** 未显著探测到；sum-rule 意义下可给保守上界 "
        f"{weak_ratio_upper:.1%}，不能给频率位置。",
        f"4. **Coulomb 是否饱和 bound？** S4={s4:.5f}±{s4_error:.5f}，与 1/4"
        f"相差 {excess_z:.2f}σ；结论是“与饱和一致”，不是“证明精确饱和”。",
        "5. **NQS 是否复现 S4/S6？** 严格投影后的 N=8 已复现 S2,S3,S4 到"
        "0.3%、2.0%、0.8%；但缺少多个可靠大 N checkpoint，尚不能声称完成"
        "NQS 热力学 S4/S6 外推。",
        "6. **是否进入双-roton 连续谱？** N≤10 没有这种迹象：Coulomb 主峰仍"
        "大于 82%。这排除了“已在可达尺寸进入连续谱”，但不能替代热力学证明。",
        "7. **有限厚度与 LL mixing？** 本轮仍未引入真实 form factor 与两/三体"
        "有效赝势，因此不作数值结论；这是下一阶段，不应混入当前主 story。",
        "",
        "## 6. 可作为附录的支持结果",
        "",
        f"- rank-2 各向异性探针在 N=4 将第一隙从 {zero_aniso['gap_1']:.6f} "
        f"软化到 {edge_aniso['gap_1']:.6f}（|λ|=0.08），支持 nematic 软化方向。",
        f"- 几何 quench 主频 {quench['dominant_angular_frequency']:.6f}，与"
        f"各向同性第一隙 {quench['isotropic_first_gap']:.6f} 相差 "
        f"{abs(quench['dominant_angular_frequency']/quench['isotropic_first_gap']-1):.2%}。",
        "- PH 共轭 gap 在数值精度内相同，同时 ρ2,+2 与 ρ2,-2 等权；这是对错误"
        "helicity 识别的有用 null result。",
        "",
        "## 7. 汇报建议",
        "",
        "主标题建议：**Topological continuity with a dynamical geometry-mode "
        "reorganization from V1 to Coulomb**。正文只讲三张表/图：加密谱流、"
        "N=4–10 主峰占比、NQS 严格投影前后对照。S4/手性放成“接近饱和并给"
        "反手性上界”；各向异性、quench、PH 放附录。这样核心结论互相支撑，"
        "同时不会把尚未实现的 planar chiral stress probe 包装成确定测量。",
        "",
        "## 8. 结果文件",
        "",
        "- `STORY_COMPLETION.md`, `dense_path_N8.csv`, "
        "`dense_path_N8_crossover.csv`：加密谱流与转折。",
        "- `endpoint_N10_*.csv`, `krylov_convergence_N9.csv`, "
        "`krylov_convergence_N10.csv`：大尺寸与 Krylov 收敛。",
        "- `V5_NQS_RESULTS.md`, `highfidelity/V5_NQS_RESULTS.md`：严格 L=0 投影"
        "前后对照。",
        "- `s4_calibrated_N4_N10.csv`：N=4–10 的主 S4 结果。",
        "- `ED_RESULTS.md`：其余 ED、各向异性、quench 与 PH 全表。",
        "",
    ]
    (RESULTS / "FINAL_SUMMARY.md").write_text("\n".join(lines), encoding="utf-8")
    print(RESULTS / "FINAL_SUMMARY.md")


if __name__ == "__main__":
    main()
