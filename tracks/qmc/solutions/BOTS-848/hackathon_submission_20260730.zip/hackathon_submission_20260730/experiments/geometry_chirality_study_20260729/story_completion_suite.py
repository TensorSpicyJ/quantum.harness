#!/usr/bin/env python3
"""Calculations that close the main geometry/chirality story.

This script resolves the V1-to-Coulomb spectral reorganization on a dense
N=8 path, verifies the spectral measure through exact moments, and performs a
single-chain Krylov convergence study at N=9.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.linalg import eigh_tridiagonal

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ed_geometry_suite import (  # noqa: E402
    StateData,
    hamiltonian,
    lanczos_spectrum,
    markdown_table,
    structure_factor,
    targeted_state,
    write_csv,
)
from chiral_graviton_nqs_vmc_sparse import SparseSectorCache  # noqa: E402


def exact_moments(H, ground: StateData, seed: np.ndarray) -> dict[str, float]:
    """Exact zeroth through second moments of (H-E0) for a probe seed."""

    shifted = H @ seed - ground.energy * seed
    m0 = float(np.vdot(seed, seed).real)
    m1 = float(np.vdot(seed, shifted).real)
    m2 = float(np.vdot(shifted, shifted).real)
    centroid = m1 / m0
    variance = max(0.0, m2 / m0 - centroid**2)
    return {
        "moment_m0_exact": m0,
        "moment_m1_exact": m1,
        "moment_m2_exact": m2,
        "spectral_centroid_exact": centroid,
        "spectral_sigma_exact": math.sqrt(variance),
    }


def analyze_spectrum(
    omega: np.ndarray,
    weights: np.ndarray,
    exact: dict[str, float],
) -> dict[str, Any]:
    """Pole diagnostics plus independent moment sum-rule residuals."""

    total_all = float(np.sum(weights))
    threshold = max(1.0e-13, 1.0e-11 * total_all)
    physical = np.flatnonzero((omega > 1.0e-10) & (weights > threshold))
    if not len(physical):
        raise RuntimeError("no physical spectral poles")
    physical_total = float(np.sum(weights[physical]))
    probabilities = weights[physical] / physical_total
    lowest = int(physical[np.argmin(omega[physical])])
    strength_order = physical[np.argsort(weights[physical])[::-1]]
    strongest = int(strength_order[0])
    second = int(strength_order[1]) if len(strength_order) > 1 else strongest
    centroid = float(np.sum(omega[physical] * weights[physical]) / physical_total)
    second_raw = float(
        np.sum(np.square(omega[physical]) * weights[physical]) / physical_total
    )
    sigma = math.sqrt(max(0.0, second_raw - centroid**2))
    m1_lanczos = float(np.sum(omega * weights))
    m2_lanczos = float(np.sum(np.square(omega) * weights))
    return {
        "physical_pole_count": int(len(physical)),
        "effective_pole_number": float(1.0 / np.sum(np.square(probabilities))),
        "lowest_pole": float(omega[lowest]),
        "lowest_pole_fraction": float(weights[lowest] / physical_total),
        "strongest_pole": float(omega[strongest]),
        "strongest_pole_fraction": float(weights[strongest] / physical_total),
        "second_strongest_pole": float(omega[second]),
        "second_strongest_fraction": float(weights[second] / physical_total),
        "lowest_is_strongest": bool(lowest == strongest),
        "spectral_centroid_lanczos": centroid,
        "spectral_sigma_lanczos": sigma,
        "sumrule_m0_relative_error": abs(total_all - exact["moment_m0_exact"])
        / exact["moment_m0_exact"],
        "sumrule_m1_relative_error": abs(m1_lanczos - exact["moment_m1_exact"])
        / max(abs(exact["moment_m1_exact"]), 1.0e-300),
        "sumrule_m2_relative_error": abs(m2_lanczos - exact["moment_m2_exact"])
        / max(abs(exact["moment_m2_exact"]), 1.0e-300),
        "centroid_exact_difference": centroid
        - exact["spectral_centroid_exact"],
        "sigma_exact_difference": sigma - exact["spectral_sigma_exact"],
    }


def dense_path(
    N: int,
    alphas: np.ndarray,
    cache_dir: Path,
    lanczos_steps: int,
    column_chunk_size: int,
) -> list[dict[str, Any]]:
    cache = SparseSectorCache(N, 3 * (N - 1))
    hv1 = hamiltonian(cache, 0, "v1", cache_dir, column_chunk_size)
    hc = hamiltonian(cache, 0, "coulomb", cache_dir, column_chunk_size)
    hv1_m2 = hamiltonian(cache, 2, "v1", cache_dir, column_chunk_size)
    hc_m2 = hamiltonian(cache, 2, "coulomb", cache_dir, column_chunk_size)
    laughlin = targeted_state(hv1, cache, 0, 0)
    previous0 = laughlin.vector.real
    previous2 = None
    rows: list[dict[str, Any]] = []
    for alpha in alphas:
        alpha = float(alpha)
        H = ((1.0 - alpha) * hv1 + alpha * hc).tocsr()
        H2 = ((1.0 - alpha) * hv1_m2 + alpha * hc_m2).tocsr()
        ground = targeted_state(H, cache, 0, 0, initial=previous0)
        excited = targeted_state(
            H2, cache, 2, 2, initial=previous2, penalty=0.2
        )
        previous0 = ground.vector.real
        previous2 = excited.vector.real
        seed = cache.rho(0, 2, 0) @ ground.vector
        moments = exact_moments(H, ground, seed)
        spectrum = lanczos_spectrum(
            H, ground.energy, seed, lanczos_steps, reorthogonalize=True
        )
        diagnostics = analyze_spectrum(
            np.asarray(spectrum["omega"]),
            np.asarray(spectrum["weights"]),
            moments,
        )
        s2, covariance = structure_factor(cache, ground.vector, 2)
        row = {
            "N": N,
            "alpha": alpha,
            "E0": ground.energy,
            "gap_lowest_L2": excited.energy - ground.energy,
            "laughlin_fidelity": float(
                abs(np.vdot(laughlin.vector, ground.vector)) ** 2
            ),
            "S_L2": s2,
            "M_covariance_relative_error": covariance,
            "ground_residual": ground.residual,
            "L2_residual": excited.residual,
            "lanczos_dimension": spectrum["lanczos_dimension"],
            **moments,
            **diagnostics,
        }
        rows.append(row)
        print(
            f"dense path alpha={alpha:.2f}: F={row['laughlin_fidelity']:.8f}, "
            f"gap={row['gap_lowest_L2']:.8f}, "
            f"low={row['lowest_pole_fraction']:.3%}, "
            f"main={row['strongest_pole_fraction']:.3%}, "
            f"same={row['lowest_is_strongest']}",
            flush=True,
        )
    return rows


def lanczos_chain(H, seed: np.ndarray, steps: int) -> dict[str, Any]:
    """One fully reorthogonalized chain reusable at many truncation lengths."""

    norm2 = float(np.vdot(seed, seed).real)
    q = np.asarray(seed / math.sqrt(norm2), dtype=np.complex128)
    previous = np.zeros_like(q)
    beta_previous = 0.0
    alphas: list[float] = []
    betas: list[float] = []
    vectors: list[np.ndarray] = []
    for iteration in range(min(steps, H.shape[0])):
        vectors.append(q.copy())
        z = H @ q - beta_previous * previous
        alpha = float(np.vdot(q, z).real)
        z -= alpha * q
        for old in vectors:
            z -= np.vdot(old, z) * old
        beta = float(np.linalg.norm(z))
        alphas.append(alpha)
        if beta < 1.0e-13 or iteration + 1 == min(steps, H.shape[0]):
            break
        betas.append(beta)
        previous, q = q, z / beta
        beta_previous = beta
        if (iteration + 1) % 40 == 0:
            print(f"Krylov chain: {iteration + 1}/{steps}", flush=True)
    return {
        "norm2": norm2,
        "alphas": np.asarray(alphas),
        "betas": np.asarray(betas),
    }


def truncated_spectrum(
    chain: dict[str, Any], ground_energy: float, steps: int
) -> tuple[np.ndarray, np.ndarray]:
    dimension = min(steps, len(chain["alphas"]))
    values, vectors = eigh_tridiagonal(
        chain["alphas"][:dimension], chain["betas"][: dimension - 1]
    )
    weights = chain["norm2"] * np.square(np.abs(vectors[0]))
    order = np.argsort(values)
    return values[order] - ground_energy, weights[order]


def krylov_convergence(
    N: int,
    interaction: str,
    truncations: list[int],
    cache_dir: Path,
    column_chunk_size: int,
) -> list[dict[str, Any]]:
    cache = SparseSectorCache(N, 3 * (N - 1))
    H = hamiltonian(cache, 0, interaction, cache_dir, column_chunk_size)
    ground = targeted_state(H, cache, 0, 0)
    seed = cache.rho(0, 2, 0) @ ground.vector
    exact = exact_moments(H, ground, seed)
    chain = lanczos_chain(H, seed, max(truncations))
    rows = []
    for steps in truncations:
        omega, weights = truncated_spectrum(chain, ground.energy, steps)
        rows.append(
            {
                "N": N,
                "interaction": interaction,
                "requested_steps": steps,
                "chain_dimension": min(steps, len(chain["alphas"])),
                **exact,
                **analyze_spectrum(omega, weights, exact),
            }
        )
    reference = rows[-1]
    for row in rows:
        row["strongest_pole_delta_from_max_steps"] = (
            row["strongest_pole"] - reference["strongest_pole"]
        )
        row["strongest_fraction_delta_from_max_steps"] = (
            row["strongest_pole_fraction"]
            - reference["strongest_pole_fraction"]
        )
        row["lowest_fraction_delta_from_max_steps"] = (
            row["lowest_pole_fraction"] - reference["lowest_pole_fraction"]
        )
    return rows


def build_report(
    results_dir: Path,
    path_rows: list[dict[str, Any]],
    convergence_rows: list[dict[str, Any]],
    elapsed: float,
) -> None:
    switches = [row for row in path_rows if row["lowest_is_strongest"]]
    first_same = switches[0] if switches else None
    dominant = [
        row
        for row in path_rows
        if row["lowest_is_strongest"] and row["lowest_pole_fraction"] > 0.5
    ]
    first_dominant = dominant[0] if dominant else None
    max_sumrule = max(
        max(
            row["sumrule_m0_relative_error"],
            row["sumrule_m1_relative_error"],
            row["sumrule_m2_relative_error"],
        )
        for row in path_rows + convergence_rows
    )
    last_two = convergence_rows[-2:]
    convergence_delta = max(
        abs(last_two[0]["strongest_pole"] - last_two[1]["strongest_pole"]),
        abs(
            last_two[0]["strongest_pole_fraction"]
            - last_two[1]["strongest_pole_fraction"]
        ),
    )
    lines = [
        "# 把主线锁定的补充计算",
        "",
        "## 1. N=8 的 21 点 V1→Coulomb 加密谱流",
        "",
        markdown_table(
            path_rows,
            [
                "alpha",
                "laughlin_fidelity",
                "gap_lowest_L2",
                "S_L2",
                "lowest_pole",
                "lowest_pole_fraction",
                "strongest_pole",
                "strongest_pole_fraction",
                "lowest_is_strongest",
                "effective_pole_number",
                "spectral_centroid_exact",
                "spectral_sigma_exact",
            ],
        ),
        "每个点都直接计算 `m0,m1,m2`，并与 Krylov 离散谱逐项核对。",
        "",
    ]
    if first_same:
        lines.append(
            f"在当前 Δα=0.05 网格上，最低极点第一次成为最强极点位于 "
            f"α={first_same['alpha']:.2f}。"
        )
    if first_dominant:
        lines.append(
            f"最低极点第一次超过总几何权重 50% 位于 "
            f"α={first_dominant['alpha']:.2f}。"
        )
    lines.extend(
        [
            f"所有谱矩 sum-rule 的最大相对残差为 {max_sumrule:.3e}。",
            "",
            "## 2. N=9 单链 Krylov 收敛",
            "",
            markdown_table(
                convergence_rows,
                [
                    "requested_steps",
                    "lowest_pole",
                    "lowest_pole_fraction",
                    "strongest_pole",
                    "strongest_pole_fraction",
                    "effective_pole_number",
                    "sumrule_m2_relative_error",
                    "strongest_pole_delta_from_max_steps",
                    "strongest_fraction_delta_from_max_steps",
                ],
            ),
            f"最后两个截断之间的最坏主峰变化为 {convergence_delta:.3e}。",
            "",
            "## 3. 可用于汇报的逻辑",
            "",
            "- 基态沿路径保持 Laughlin 相，可由高 fidelity 连续性说明。",
            "- 激发谱却发生清晰的权重重组：V1 端的最低 L=2 极点不是主要几何模，"
            "而 Coulomb 端的最低极点成为相干主峰。",
            "- 主峰结论同时通过直接谱矩 sum rule 与 N=9 Krylov 截断收敛检查，"
            "不依赖单次 Lanczos 的视觉判断。",
            "",
            f"总运行时间：{elapsed:.1f} s。",
            "",
        ]
    )
    (results_dir / "STORY_COMPLETION.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--path-N", type=int, default=8)
    parser.add_argument("--alpha-points", type=int, default=21)
    parser.add_argument("--path-lanczos-steps", type=int, default=140)
    parser.add_argument("--convergence-N", type=int, default=9)
    parser.add_argument(
        "--convergence-steps", type=int, nargs="+", default=[80, 120, 160, 180, 220]
    )
    parser.add_argument("--column-chunk-size", type=int, default=1024)
    parser.add_argument("--cache-dir", type=Path, default=HERE / "cache" / "ed")
    parser.add_argument("--results-dir", type=Path, default=HERE / "results")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    args.results_dir.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    path_rows = dense_path(
        args.path_N,
        np.linspace(0.0, 1.0, args.alpha_points),
        args.cache_dir,
        args.path_lanczos_steps,
        args.column_chunk_size,
    )
    convergence_rows = krylov_convergence(
        args.convergence_N,
        "coulomb",
        args.convergence_steps,
        args.cache_dir,
        args.column_chunk_size,
    )
    elapsed = time.perf_counter() - started
    write_csv(args.results_dir / "dense_path_N8.csv", path_rows)
    write_csv(args.results_dir / "krylov_convergence_N9.csv", convergence_rows)
    payload = {
        "cli": {
            **vars(args),
            "cache_dir": str(args.cache_dir),
            "results_dir": str(args.results_dir),
        },
        "elapsed_seconds": elapsed,
        "dense_path": path_rows,
        "krylov_convergence": convergence_rows,
    }
    (args.results_dir / "story_completion.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    build_report(args.results_dir, path_rows, convergence_rows, elapsed)


if __name__ == "__main__":
    main()
