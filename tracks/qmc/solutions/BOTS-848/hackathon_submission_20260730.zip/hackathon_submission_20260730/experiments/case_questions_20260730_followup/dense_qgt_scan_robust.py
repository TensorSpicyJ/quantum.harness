#!/usr/bin/env python3
"""Robust entry point for the symmetry-resolved dense QGT scan.

At an exact angular-momentum crossing, reusing the previous unrestricted
eigenvector can trap ARPACK inside that invariant L sector.  This entry point
forces every unrestricted solve to start across sectors while retaining
same-sector continuation for the explicitly targeted L=0 and L=2 branches.
"""

from __future__ import annotations

import dense_qgt_scan as scan


_original_true_ground = scan.true_ground


def cross_sector_true_ground(H, cache, initial=None):
    del initial
    return _original_true_ground(H, cache, initial=None)


scan.true_ground = cross_sector_true_ground


if __name__ == "__main__":
    scan.main()
