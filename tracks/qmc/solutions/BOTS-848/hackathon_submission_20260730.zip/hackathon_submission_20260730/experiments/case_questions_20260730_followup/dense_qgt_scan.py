#!/usr/bin/env python3
"""Dense, symmetry-resolved fidelity scan near the N=8 transition.

The coarse production scan identified a re-entrant L=2 ground-state window.
This follow-up resolves the upper L=2 -> L=0 crossing by tracking the physical
L=0 and L=2 branches separately.  It also reports two fidelity
susceptibilities:

* ``chi_true`` for the actual ground state (singular/grid-dependent at an exact
  symmetry crossing);
* ``chi_L0`` for the smooth L=0 branch (a regular quantum-metric diagnostic).

The distinction prevents a level crossing from being misreported as a broad,
finite QGT peak.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import types
from pathlib import Path
from typing import Any

import numpy as np
from scipy import sparse
from scipy.optimize import brentq
from scipy.sparse.linalg import eigsh


# ``run_physics_probes`` only needs matplotlib for its optional plotting
# helpers.  The ED environment is intentionally headless and has no matplotlib.
matplotlib = types.ModuleType("matplotlib")
matplotlib.use = lambda *_args, **_kwargs: None
pyplot = types.ModuleType("matplotlib.pyplot")
matplotlib.pyplot = pyplot
sys.modules.setdefault("matplotlib", matplotlib)
sys.modules.setdefault("matplotlib.pyplot", pyplot)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CASE_DIR = ROOT / "case_questions_20260730"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(CASE_DIR) not in sys.path:
    sys.path.insert(0, str(CASE_DIR))

import run_physics_probes as probes  # noqa: E402
from chiral_graviton_nqs_vmc_sparse import (  # noqa: E402
    sparse_raising_operator,
)


Array = np.ndarray
Sparse = sparse.csr_matrix


def normalize_phase(vector: Array) -> Array:
    """Normalize an eigenvector and make its largest entry real-positive."""

    result = np.asarray(vector, dtype=np.complex128)
    result /= np.linalg.norm(result)
    pivot = int(np.argmax(np.abs(result)))
    if abs(result[pivot]) > 0.0:
        result *= np.exp(-1j * np.angle(result[pivot]))
    return result


def infer_L(l2: float) -> float:
    return 0.5 * (math.sqrt(max(0.0, 1.0 + 4.0 * l2)) - 1.0)


def true_ground(H: Sparse, cache: Any, initial: Array | None = None):
    """Unrestricted M=0 ground state with measured total angular momentum."""

    _, vectors = eigsh(
        H,
        k=1,
        which="SA",
        tol=1.0e-12,
        maxiter=max(20000, 20 * H.shape[0]),
        v0=initial,
    )
    vector = normalize_phase(vectors[:, 0])
    hvec = H @ vector
    energy = float(np.vdot(vector, hvec).real)
    raising = sparse_raising_operator(cache, 0)
    l2vec = raising.T @ (raising @ vector)
    l2 = float(np.vdot(vector, l2vec).real)
    residual = float(np.linalg.norm(hvec - energy * vector))
    return probes.StateData(energy, vector, l2, residual)


def l0_branch(
    H: Sparse,
    cache: Any,
    penalty: float,
    initial: Array | None = None,
):
    """Lowest *L=0* state even when the unrestricted ground has L>0."""

    raising = sparse_raising_operator(cache, 0)

    def matvec(vector: Array) -> Array:
        return H @ vector + penalty * (raising.T @ (raising @ vector))

    operator = sparse.linalg.LinearOperator(
        H.shape, matvec=matvec, dtype=np.float64
    )
    _, vectors = eigsh(
        operator,
        k=1,
        which="SA",
        tol=1.0e-12,
        maxiter=max(20000, 20 * H.shape[0]),
        v0=initial,
    )
    vector = normalize_phase(vectors[:, 0])
    hvec = H @ vector
    energy = float(np.vdot(vector, hvec).real)
    l2vec = raising.T @ (raising @ vector)
    l2 = float(np.vdot(vector, l2vec).real)
    residual = float(np.linalg.norm(hvec - energy * vector))
    if abs(l2) > 2.0e-7:
        raise RuntimeError(f"L=0 targeting failed: <L2>={l2}")
    return probes.StateData(energy, vector, l2, residual)


def fidelity_susceptibility(
    rows: list[dict[str, Any]],
    states: list[Array],
    field: str,
) -> None:
    for index in range(1, len(rows) - 1):
        delta = rows[index + 1]["lambda"] - rows[index - 1]["lambda"]
        fidelity = float(
            abs(np.vdot(states[index - 1], states[index + 1])) ** 2
        )
        rows[index][field] = (1.0 - fidelity) / (delta * delta)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def scan_size(
    particles: int,
    lambdas: Array,
    cache_dir: Path,
    column_chunk_size: int,
    l0_penalty: float,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    two_q = 3 * (particles - 1)
    cache = probes.SparseSectorCache(particles, two_q)
    hc0 = probes.hamiltonian(
        cache, 0, "coulomb", cache_dir, column_chunk_size
    )
    hv10 = probes.hamiltonian(
        cache, 0, "v1", cache_dir, column_chunk_size
    )
    hc2 = probes.hamiltonian(
        cache, 2, "coulomb", cache_dir, column_chunk_size
    )
    hv12 = probes.hamiltonian(
        cache, 2, "v1", cache_dir, column_chunk_size
    )
    v1_coulomb = probes.coulomb_pseudopotentials(two_q)[two_q - 1]

    rows: list[dict[str, Any]] = []
    states_true: list[Array] = []
    states_l0: list[Array] = []
    previous_true: Array | None = None
    previous_l0: Array | None = None
    previous_l2: Array | None = None
    branch_vectors: list[tuple[Array, Array]] = []

    def matrices(value: float) -> tuple[Sparse, Sparse]:
        H0 = (hc0 + (value - 1.0) * v1_coulomb * hv10).tocsr()
        H2 = (hc2 + (value - 1.0) * v1_coulomb * hv12).tocsr()
        return H0, H2

    for value_raw in lambdas:
        value = float(value_raw)
        H0, H2 = matrices(value)
        state_true = true_ground(H0, cache, previous_true)
        state_l0 = l0_branch(H0, cache, l0_penalty, previous_l0)
        state_l2 = probes.targeted_state(
            H2,
            cache,
            2,
            2,
            penalty=l0_penalty,
            tolerance=1.0e-12,
            initial=previous_l2,
        )
        previous_true = state_true.vector.real
        previous_l0 = state_l0.vector.real
        previous_l2 = state_l2.vector.real
        states_true.append(normalize_phase(state_true.vector))
        states_l0.append(normalize_phase(state_l0.vector))
        branch_vectors.append((state_l0.vector.real, state_l2.vector.real))
        branch_gap = state_l2.energy - state_l0.energy
        lower_branch = "L0" if branch_gap >= 0.0 else "L2"
        lower_energy = min(state_l0.energy, state_l2.energy)
        rows.append(
            {
                "N": particles,
                "lambda": value,
                "E_true": state_true.energy,
                "L_true": infer_L(state_true.l2),
                "E_L0": state_l0.energy,
                "E_L2": state_l2.energy,
                "E_L2_minus_E_L0": branch_gap,
                "lower_branch": lower_branch,
                "two_branch_ground_error": lower_energy - state_true.energy,
                "residual_true": state_true.residual,
                "residual_L0": state_l0.residual,
                "residual_L2": state_l2.residual,
                "chi_true": float("nan"),
                "chi_L0": float("nan"),
            }
        )
        print(
            f"N={particles} lambda={value:.5f} "
            f"Ltrue={rows[-1]['L_true']:.6f} "
            f"E2-E0={branch_gap:+.10e}",
            flush=True,
        )

    fidelity_susceptibility(rows, states_true, "chi_true")
    fidelity_susceptibility(rows, states_l0, "chi_L0")

    brackets: list[tuple[int, float, float]] = []
    for index in range(len(rows) - 1):
        left = rows[index]["E_L2_minus_E_L0"]
        right = rows[index + 1]["E_L2_minus_E_L0"]
        if left == 0.0 or left * right < 0.0:
            brackets.append(
                (index, rows[index]["lambda"], rows[index + 1]["lambda"])
            )

    roots: list[dict[str, Any]] = []
    for index, left, right in brackets:
        left0, left2 = branch_vectors[index]
        right0, right2 = branch_vectors[index + 1]

        def branch_gap_at(value: float) -> float:
            H0, H2 = matrices(value)
            fraction = (value - left) / (right - left)
            guess0 = (1.0 - fraction) * left0 + fraction * right0
            guess2 = (1.0 - fraction) * left2 + fraction * right2
            state0 = l0_branch(H0, cache, l0_penalty, guess0)
            state2 = probes.targeted_state(
                H2,
                cache,
                2,
                2,
                penalty=l0_penalty,
                tolerance=1.0e-12,
                initial=guess2,
            )
            return state2.energy - state0.energy

        root = float(
            brentq(
                branch_gap_at,
                left,
                right,
                xtol=2.0e-11,
                rtol=2.0e-11,
                maxiter=50,
            )
        )
        roots.append(
            {
                "lambda_crossing": root,
                "bracket_left": left,
                "bracket_right": right,
                "bracket_width": right - left,
                "residual_gap": branch_gap_at(root),
            }
        )

    finite_true = [row["chi_true"] for row in rows if np.isfinite(row["chi_true"])]
    finite_l0 = [row["chi_L0"] for row in rows if np.isfinite(row["chi_L0"])]
    summary = {
        "N": particles,
        "twoQ": two_q,
        "lambda_min": float(lambdas[0]),
        "lambda_max": float(lambdas[-1]),
        "lambda_step": float(lambdas[1] - lambdas[0]),
        "crossings": roots,
        "upper_crossing": roots[-1] if roots else None,
        "max_chi_true": max(finite_true),
        "max_chi_L0": max(finite_l0),
        "max_two_branch_ground_error_abs": max(
            abs(row["two_branch_ground_error"]) for row in rows
        ),
        "max_eigensolver_residual": max(
            max(row["residual_true"], row["residual_L0"], row["residual_L2"])
            for row in rows
        ),
        "interpretation": (
            "chi_true is grid-dependent at an exact L-changing crossing; "
            "the branch crossing and smooth chi_L0 are the robust observables"
        ),
    }
    return rows, summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", nargs="+", type=int, default=[6, 8])
    parser.add_argument("--lambda-min", type=float, default=0.75)
    parser.add_argument("--lambda-max", type=float, default=0.90)
    parser.add_argument("--lambda-step", type=float, default=0.005)
    parser.add_argument("--column-chunk-size", type=int, default=256)
    parser.add_argument("--l0-penalty", type=float, default=0.5)
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=ROOT / "geometry_chirality_study_20260729" / "cache" / "ed",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=HERE / "results" / "qgt_dense",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.lambda_step <= 0.0:
        raise ValueError("--lambda-step must be positive")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    points = int(
        round((args.lambda_max - args.lambda_min) / args.lambda_step)
    )
    lambdas = args.lambda_min + args.lambda_step * np.arange(points + 1)
    if abs(lambdas[-1] - args.lambda_max) > 1.0e-10:
        raise ValueError("lambda range must be divisible by lambda step")

    all_rows: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for particles in args.sizes:
        rows, summary = scan_size(
            particles,
            lambdas,
            args.cache_dir,
            args.column_chunk_size,
            args.l0_penalty,
        )
        all_rows.extend(rows)
        summaries.append(summary)

    write_csv(args.output_dir / "dense_qgt_scan.csv", all_rows)
    payload = {
        "method": "symmetry-resolved exact diagonalization",
        "sizes": args.sizes,
        "summaries": summaries,
        "qgt_definition": (
            "chi=(1-|<psi(lambda-h)|psi(lambda+h)>|^2)/(2h)^2"
        ),
        "crossing_definition": "E_L2(lambda_c)=E_L0(lambda_c)",
        "raw_neural_qgt_warning": (
            "Tr(Q) in raw neural parameters is reparameterization-dependent"
        ),
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2), flush=True)


if __name__ == "__main__":
    main()
