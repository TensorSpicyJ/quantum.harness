#!/usr/bin/env python3
"""Aggregate the baseline plus completed multi-seed NQS result directories."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import run_multiseed_nqs as driver


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[20260730, 20260731],
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=driver.HERE / "results" / "multiseed_nqs",
    )
    parser.add_argument("--baseline-seed", type=int, default=20260729)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    fq_rows = [
        driver.first_quantized_row(
            args.baseline_seed,
            driver.BASELINE / "first_quantized_N6" / "result.json",
        )
    ]
    fock_rows = [
        driver.fock_row(
            args.baseline_seed,
            driver.BASELINE / "fock_quantized_N6_teacher",
        )
    ]
    for seed in args.seeds:
        fq_rows.append(
            driver.first_quantized_row(
                seed,
                args.results_dir
                / f"first_quantized_seed{seed}"
                / "result.json",
            )
        )
        fock_rows.append(
            driver.fock_row(
                seed,
                args.results_dir / f"second_quantized_seed{seed}",
            )
        )

    rows = fq_rows + fock_rows
    driver.write_csv(args.results_dir / "runs.csv", rows)
    payload = {
        "comparison_basis": (
            "N=6 Coulomb gap; identical architecture and budget per seed"
        ),
        "baseline_seed_reused": args.baseline_seed,
        "new_gpu_seeds": args.seeds,
        "first_quantized": driver.summarize_method(fq_rows),
        "second_quantized": driver.summarize_method(fock_rows),
        "selection_rule": (
            "prefer the route with smaller across-seed gap scatter and "
            "smaller exact-contraction error; retain the other as cross-check"
        ),
    }
    (args.results_dir / "summary.json").write_text(
        json.dumps(payload, indent=2, allow_nan=True), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2, allow_nan=True), flush=True)


if __name__ == "__main__":
    main()
