#!/usr/bin/env python3
"""Robust entry point for the multi-seed NQS driver.

Child scripts live in different subdirectories.  Python sets ``sys.path[0]``
to the child script directory, so the repository root must be propagated in
``PYTHONPATH`` for exact-overlap evaluation imports.
"""

from __future__ import annotations

import os
import subprocess

import run_multiseed_nqs as driver


def run_with_repository_path(command: list[str]) -> None:
    print("RUN:", " ".join(command), flush=True)
    environment = os.environ.copy()
    existing = environment.get("PYTHONPATH", "")
    root = str(driver.ROOT)
    environment["PYTHONPATH"] = (
        root if not existing else root + os.pathsep + existing
    )
    subprocess.run(
        command,
        cwd=driver.ROOT,
        env=environment,
        check=True,
    )


driver.run = run_with_repository_path


if __name__ == "__main__":
    driver.main()
