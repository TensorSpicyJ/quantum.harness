#!/usr/bin/env python3
"""Run and aggregate same-budget multi-seed NQS validation on local GPU.

The previous report contained one production seed for each quantization route.
This driver reuses that baseline and launches two additional independent seeds
at the identical budget.  It then reports across-seed mean/std together with
within-run Monte Carlo standard errors and exact-contraction validation.
"""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASELINE = ROOT / "case_questions_20260730" / "results"


def run(command: list[str]) -> None:
    print("RUN:", " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def mean_std(values: list[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    return {
        "mean": float(array.mean()),
        "std_across_seeds": float(array.std(ddof=1)),
        "min": float(array.min()),
        "max": float(array.max()),
    }


def first_quantized_row(seed: int, result_path: Path) -> dict[str, Any]:
    result = load_json(result_path)
    exact = result["same_state_exact_contraction"]
    mc = result["coordinate_monte_carlo"]
    ed = result["ed_benchmark"]
    return {
        "method": "first_quantized",
        "seed": seed,
        "gap": exact["gap"],
        "gap_standard_error": mc["gap_stderr"],
        "gap_mc": mc["gap"],
        "ed_gap": ed["gap"],
        "relative_gap_error": abs(exact["gap"] - ed["gap"]) / abs(ed["gap"]),
        "ground_overlap": exact["ground_overlap_ED"],
        "excited_overlap": exact["excited_overlap_ED"],
        "multiplet_energy_spread": result["symmetry"][
            "multiplet_energy_spread"
        ],
        "runtime_seconds": result["runtime_seconds"],
        "source": str(result_path.resolve()),
    }


def fock_row(seed: int, run_dir: Path) -> dict[str, Any]:
    result = load_json(run_dir / "N6" / "result.json")
    overlap = load_json(run_dir / "exact_overlaps.json")
    ed_gap = 0.13168841196505632
    return {
        "method": "second_quantized",
        "seed": seed,
        "gap": result["gap"],
        "gap_standard_error": result["gap_standard_error"],
        "gap_mc": result["gap"],
        "ed_gap": ed_gap,
        "relative_gap_error": abs(result["gap"] - ed_gap) / abs(ed_gap),
        "ground_overlap": overlap["ground_overlap"],
        "excited_overlap": overlap["excited_M2_overlap"],
        "multiplet_energy_spread": float("nan"),
        "runtime_seconds": result["training_seconds"],
        "source": str((run_dir / "N6" / "result.json").resolve()),
    }


def summarize_method(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "seeds": [row["seed"] for row in rows],
        "gap": mean_std([row["gap"] for row in rows]),
        "reported_mc_standard_error": mean_std(
            [row["gap_standard_error"] for row in rows]
        ),
        "relative_gap_error": mean_std(
            [row["relative_gap_error"] for row in rows]
        ),
        "ground_overlap": mean_std(
            [row["ground_overlap"] for row in rows]
        ),
        "excited_overlap": mean_std(
            [row["excited_overlap"] for row in rows]
        ),
        "runtime_seconds": mean_std(
            [row["runtime_seconds"] for row in rows]
        ),
        "runs": rows,
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--new-seeds", nargs="+", type=int, default=[20260730, 20260731]
    )
    parser.add_argument("--baseline-seed", type=int, default=20260729)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=HERE / "results" / "multiseed_nqs",
    )
    parser.add_argument("--skip-first-quantized", action="store_true")
    parser.add_argument("--skip-second-quantized", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    python = sys.executable
    teacher = (
        ROOT / "runs" / "su2_tensor_route_20260729" / "N6" / "final_states.npz"
    )

    fq_rows = [
        first_quantized_row(
            args.baseline_seed,
            BASELINE / "first_quantized_N6" / "result.json",
        )
    ]
    fock_rows = [
        fock_row(
            args.baseline_seed,
            BASELINE / "fock_quantized_N6_teacher",
        )
    ]

    for seed in args.new_seeds:
        if not args.skip_first_quantized:
            run_dir = args.output_dir / f"first_quantized_seed{seed}"
            run(
                [
                    python,
                    str(ROOT / "run_first_quantized_projected.py"),
                    "-N",
                    "6",
                    "--lmax",
                    "4",
                    "--scalar-depth",
                    "2",
                    "--channel-rank",
                    "3",
                    "--steps",
                    "80",
                    "--walkers",
                    "256",
                    "--burn-in",
                    "200",
                    "--moves-per-step",
                    "2",
                    "--eval-burn-in",
                    "100",
                    "--eval-steps",
                    "300",
                    "--learning-rate",
                    "0.001",
                    "--proposal-scale",
                    "0.35",
                    "--determinant-chunk",
                    "128",
                    "--seed",
                    str(seed),
                    "--log-every",
                    "10",
                    "--output-dir",
                    str(run_dir),
                ]
            )
            fq_rows.append(
                first_quantized_row(seed, run_dir / "result.json")
            )

        if not args.skip_second_quantized:
            run_dir = args.output_dir / f"second_quantized_seed{seed}"
            run(
                [
                    python,
                    str(ROOT / "chiral_graviton_fock_ar_nqs_symmetry_v5.py"),
                    "--amplitude-init-scale",
                    "1.0",
                    "--entropy-temperature",
                    "0.0",
                    "--sizes",
                    "6",
                    "--hidden",
                    "128",
                    "--batch",
                    "32",
                    "--hops",
                    "64",
                    "--steps",
                    "100",
                    "--learning-rate",
                    "1e-7",
                    "--warmup",
                    "25",
                    "--seed",
                    str(seed),
                    "--log-every",
                    "25",
                    "--eval-batches",
                    "24",
                    "--eval-batch",
                    "128",
                    "--eval-hops",
                    "256",
                    "--highest-weight-penalty",
                    "10.0",
                    "--lplus-hops",
                    "128",
                    "--eval-lplus-hops",
                    "256",
                    "--teacher-path",
                    str(teacher),
                    "--pretrain-steps",
                    "4000",
                    "--pretrain-batch",
                    "512",
                    "--pretrain-learning-rate",
                    "0.001",
                    "--pretrain-phase-weight",
                    "2.0",
                    "--output-dir",
                    str(run_dir),
                    "--cache-dir",
                    str(ROOT / "runs" / "fock_ar_nqs_interaction_cache"),
                    "--skip-self-test",
                ]
            )
            run(
                [
                    python,
                    str(
                        ROOT
                        / "case_questions_20260730"
                        / "evaluate_fock_overlap.py"
                    ),
                    str(run_dir / "N6" / "checkpoint.npz"),
                    str(teacher),
                    "--hidden",
                    "128",
                    "--output",
                    str(run_dir / "exact_overlaps.json"),
                ]
            )
            fock_rows.append(fock_row(seed, run_dir))

    all_rows = fq_rows + fock_rows
    write_csv(args.output_dir / "runs.csv", all_rows)
    payload = {
        "comparison_basis": (
            "N=6 Coulomb gap; identical architecture and budget per seed"
        ),
        "baseline_seed_reused": args.baseline_seed,
        "new_gpu_seeds": args.new_seeds,
        "first_quantized": summarize_method(fq_rows),
        "second_quantized": summarize_method(fock_rows),
        "selection_rule": (
            "prefer the route with smaller across-seed gap scatter and "
            "smaller exact-contraction error; retain the other as cross-check"
        ),
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(payload, indent=2, allow_nan=True), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2, allow_nan=True), flush=True)


if __name__ == "__main__":
    main()
