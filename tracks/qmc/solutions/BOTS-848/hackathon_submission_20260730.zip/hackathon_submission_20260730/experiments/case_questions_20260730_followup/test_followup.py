#!/usr/bin/env python3
"""Small numerical/unit tests for the follow-up analysis utilities."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {filename}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_normalize_phase() -> None:
    qgt = load_module("dense_qgt_scan_test", "dense_qgt_scan.py")
    vector = np.asarray([1j, -2j, 0.5 + 0.5j])
    normalized = qgt.normalize_phase(vector)
    assert abs(np.linalg.norm(normalized) - 1.0) < 1.0e-14
    pivot = normalized[int(np.argmax(np.abs(normalized)))]
    assert abs(pivot.imag) < 1.0e-14
    assert pivot.real > 0.0


def test_moore_read_references() -> None:
    mr = load_module(
        "mr_variational_test", "train_moore_read_variational_nqs.py"
    )
    teacher = (
        HERE.parent
        / "case_questions_20260730"
        / "results"
        / "moore_read_teacher_states.npz"
    )
    problems = mr.build_problems(teacher)
    assert [problem["basis_dimension"] for problem in problems] == [18, 16, 48]
    expected = {
        "ground": 0.0,
        "graviton": 1.363200481952189,
        "gravitino": 0.9855136070569147,
    }
    for problem in problems:
        assert np.max(np.abs(problem["H"] - problem["H"].T)) < 1.0e-12
        assert np.max(np.abs(problem["L2"] - problem["L2"].T)) < 1.0e-12
        reference = mr.exact_reference(problem, 0.5)
        assert reference["teacher_fidelity"] > 1.0 - 1.0e-10
        assert (
            abs(reference["physical_energy"] - expected[problem["name"]])
            < 1.0e-10
        )


def main() -> None:
    test_normalize_phase()
    test_moore_read_references()
    print("follow-up tests passed")


if __name__ == "__main__":
    main()
