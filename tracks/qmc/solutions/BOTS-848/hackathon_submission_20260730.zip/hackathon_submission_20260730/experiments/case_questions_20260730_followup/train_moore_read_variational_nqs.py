#!/usr/bin/env python3
"""Hamiltonian-driven Moore--Read Fock-NQS with exact-summation gradients.

Unlike the earlier supervised representation pilot, the target wavefunctions
are never used in the loss.  Each neural state is optimized by a Rayleigh
quotient of the three-body parent Hamiltonian.  Highest-weight angular-momentum
penalties isolate the even-N L=2 graviton and odd-N L=3/2 gravitino branches.
Exact teacher eigenvectors are used only after training for blind validation.

The Hilbert spaces (16--48 basis states) are deliberately small, so every
expectation value and variance is summed exactly on the GPU.  This is a
variational NQS benchmark, not a large-system stochastic VMC claim.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
import types
from pathlib import Path
from typing import Any

import jax

jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp
import numpy as np
import optax


matplotlib = types.ModuleType("matplotlib")
matplotlib.use = lambda *_args, **_kwargs: None
pyplot = types.ModuleType("matplotlib.pyplot")
matplotlib.pyplot = pyplot
sys.modules.setdefault("matplotlib", matplotlib)
sys.modules.setdefault("matplotlib.pyplot", pyplot)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CASE_DIR = ROOT / "case_questions_20260730"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(CASE_DIR) not in sys.path:
    sys.path.insert(0, str(CASE_DIR))

import run_physics_probes as probes  # noqa: E402
from chiral_graviton_ed import angular_momentum_squared, fock_basis  # noqa: E402


PyTree = Any


def init_params(key: jax.Array, orbitals: int, hidden: int) -> PyTree:
    keys = jax.random.split(key, 4)
    scale1 = 1.0 / math.sqrt(orbitals)
    scale2 = 1.0 / math.sqrt(hidden)
    return {
        "w1": scale1
        * jax.random.normal(keys[0], (orbitals, hidden), dtype=jnp.float64),
        "b1": jnp.zeros((hidden,), dtype=jnp.float64),
        "w2": scale2
        * jax.random.normal(keys[1], (hidden, hidden), dtype=jnp.float64),
        "b2": jnp.zeros((hidden,), dtype=jnp.float64),
        "wout": scale2
        * jax.random.normal(keys[2], (hidden, 2), dtype=jnp.float64),
        "bout": 0.01
        * jax.random.normal(keys[3], (2,), dtype=jnp.float64),
    }


def wavefunction(params: PyTree, x: jax.Array) -> jax.Array:
    centered = 2.0 * x - 1.0
    hidden1 = jnp.tanh(centered @ params["w1"] + params["b1"])
    hidden2 = jnp.tanh(hidden1 @ params["w2"] + params["b2"])
    output = hidden2 @ params["wout"] + params["bout"]
    raw = output[:, 0] + 1j * output[:, 1]
    return raw / jnp.maximum(jnp.linalg.norm(raw), 1.0e-15)


def build_problems(teacher_file: Path) -> list[dict[str, Any]]:
    teacher = np.load(teacher_file)
    even_n = int(teacher["even_N"])
    even_two_q = int(teacher["even_twoQ"])
    odd_n = int(teacher["odd_N"])
    odd_two_q = int(teacher["odd_twoQ"])

    even_blocks, _ = probes.three_body_projector(even_two_q)
    odd_blocks, _ = probes.three_body_projector(odd_two_q)
    specifications = [
        (
            "ground",
            even_n,
            even_two_q,
            0.0,
            0.0,
            "occupations_ground",
            "psi_ground",
            even_blocks,
        ),
        (
            "graviton",
            even_n,
            even_two_q,
            2.0,
            2.0,
            "occupations_graviton",
            "psi_graviton",
            even_blocks,
        ),
        (
            "gravitino",
            odd_n,
            odd_two_q,
            1.5,
            1.5,
            "occupations_gravitino",
            "psi_gravitino",
            odd_blocks,
        ),
    ]

    problems: list[dict[str, Any]] = []
    for (
        name,
        particles,
        two_q,
        M,
        target_L,
        occupations_key,
        psi_key,
        blocks,
    ) in specifications:
        basis = fock_basis(particles, two_q, M)
        H = probes.three_body_hamiltonian(basis, two_q, blocks).toarray()
        L2 = angular_momentum_squared(basis, particles, two_q, M)
        x = np.asarray(teacher[occupations_key], dtype=np.float64)
        target = np.asarray(teacher[psi_key], dtype=np.complex128)
        if x.shape[0] != len(basis) or target.shape[0] != len(basis):
            raise RuntimeError(f"{name}: teacher/basis dimension mismatch")
        problems.append(
            {
                "name": name,
                "particles": particles,
                "twoQ": two_q,
                "M": M,
                "target_L": target_L,
                "target_L2": target_L * (target_L + 1.0),
                "basis_dimension": len(basis),
                "occupations": x,
                "target": target / np.linalg.norm(target),
                "H": np.asarray(H, dtype=np.float64),
                "L2": np.asarray(L2, dtype=np.float64),
            }
        )
    return problems


def exact_reference(problem: dict[str, Any], penalty: float) -> dict[str, float]:
    target_l2 = problem["target_L2"]
    effective = problem["H"] + penalty * (
        problem["L2"] - target_l2 * np.eye(problem["basis_dimension"])
    )
    values, vectors = np.linalg.eigh(effective)
    state = vectors[:, 0]
    physical_energy = float(np.vdot(state, problem["H"] @ state).real)
    l2 = float(np.vdot(state, problem["L2"] @ state).real)
    fidelity = float(abs(np.vdot(problem["target"], state)) ** 2)
    return {
        "effective_energy": float(values[0]),
        "physical_energy": physical_energy,
        "L2": l2,
        "teacher_fidelity": fidelity,
    }


def train_seed(
    problem: dict[str, Any],
    hidden: int,
    steps: int,
    learning_rate: float,
    penalty: float,
    seed: int,
    log_every: int,
) -> tuple[dict[str, Any], PyTree, np.ndarray]:
    x = jnp.asarray(problem["occupations"], dtype=jnp.float64)
    H = jnp.asarray(problem["H"], dtype=jnp.float64)
    L2 = jnp.asarray(problem["L2"], dtype=jnp.float64)
    target_l2 = float(problem["target_L2"])
    params = init_params(jax.random.PRNGKey(seed), x.shape[1], hidden)
    schedule = optax.cosine_decay_schedule(
        init_value=learning_rate,
        decay_steps=max(steps, 1),
        alpha=0.05,
    )
    optimizer = optax.chain(
        optax.clip_by_global_norm(5.0),
        optax.adam(schedule),
    )
    opt_state = optimizer.init(params)

    def objective(values: PyTree):
        psi = wavefunction(values, x)
        Hpsi = H @ psi
        L2psi = L2 @ psi
        energy = jnp.real(jnp.vdot(psi, Hpsi))
        l2 = jnp.real(jnp.vdot(psi, L2psi))
        effective = energy + penalty * (l2 - target_l2)
        variance = jnp.real(jnp.vdot(Hpsi, Hpsi)) - energy * energy
        return effective, (energy, l2, variance)

    @jax.jit
    def update(values: PyTree, state: PyTree):
        (loss, aux), gradients = jax.value_and_grad(
            objective, has_aux=True
        )(values)
        updates, state = optimizer.update(gradients, state, values)
        values = optax.apply_updates(values, updates)
        return values, state, loss, aux

    best_loss = float("inf")
    best_params = params
    history: list[dict[str, float | int]] = []
    started = time.perf_counter()
    for step in range(1, steps + 1):
        params, opt_state, loss, aux = update(params, opt_state)
        if step == 1:
            jax.block_until_ready(loss)
        loss_value = float(loss)
        if loss_value < best_loss:
            best_loss = loss_value
            best_params = jax.tree_util.tree_map(lambda value: value, params)
        if step == 1 or step % log_every == 0 or step == steps:
            energy, l2, variance = (float(value) for value in aux)
            history.append(
                {
                    "step": step,
                    "objective": loss_value,
                    "energy": energy,
                    "L2": l2,
                    "variance": max(0.0, variance),
                }
            )
            print(
                f"{problem['name']} seed={seed} step={step:5d} "
                f"E={energy:.12f} L2={l2:.9f} "
                f"var={max(0.0, variance):.3e}",
                flush=True,
            )

    psi = np.asarray(
        jax.device_get(wavefunction(best_params, x)), dtype=np.complex128
    )
    H_host = problem["H"]
    L2_host = problem["L2"]
    Hpsi = H_host @ psi
    energy = float(np.vdot(psi, Hpsi).real)
    l2 = float(np.vdot(psi, L2_host @ psi).real)
    variance = max(0.0, float(np.vdot(Hpsi, Hpsi).real - energy * energy))
    residual = float(np.linalg.norm(Hpsi - energy * psi))
    fidelity = float(abs(np.vdot(problem["target"], psi)) ** 2)
    result = {
        "name": problem["name"],
        "seed": seed,
        "particles": problem["particles"],
        "twoQ": problem["twoQ"],
        "M": problem["M"],
        "target_L": problem["target_L"],
        "basis_dimension": problem["basis_dimension"],
        "hidden": hidden,
        "steps": steps,
        "learning_rate": learning_rate,
        "angular_momentum_penalty": penalty,
        "parameter_count": int(
            sum(value.size for value in jax.tree_util.tree_leaves(best_params))
        ),
        "variational_energy": energy,
        "L2": l2,
        "energy_variance": variance,
        "eigen_residual": residual,
        "teacher_fidelity_posthoc": fidelity,
        "best_objective": best_loss,
        "runtime_seconds": time.perf_counter() - started,
        "history": history,
    }
    return result, best_params, psi


def aggregate(
    problem: dict[str, Any],
    reference: dict[str, float],
    rows: list[dict[str, Any]],
) -> dict[str, Any]:
    energies = np.asarray([row["variational_energy"] for row in rows])
    fidelities = np.asarray([row["teacher_fidelity_posthoc"] for row in rows])
    variances = np.asarray([row["energy_variance"] for row in rows])
    l2_errors = np.asarray(
        [abs(row["L2"] - problem["target_L2"]) for row in rows]
    )
    return {
        "name": problem["name"],
        "particles": problem["particles"],
        "target_L": problem["target_L"],
        "basis_dimension": problem["basis_dimension"],
        "exact_reference": reference,
        "seeds": [row["seed"] for row in rows],
        "energy_mean": float(energies.mean()),
        "energy_std_across_seeds": float(energies.std(ddof=1)),
        "energy_error_mean": float(energies.mean() - reference["physical_energy"]),
        "energy_error_max_abs": float(
            np.max(np.abs(energies - reference["physical_energy"]))
        ),
        "fidelity_mean": float(fidelities.mean()),
        "fidelity_min": float(fidelities.min()),
        "variance_mean": float(variances.mean()),
        "variance_max": float(variances.max()),
        "L2_error_max_abs": float(l2_errors.max()),
        "runs": rows,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("teacher_file", type=Path)
    parser.add_argument("--hidden", type=int, default=64)
    parser.add_argument("--steps", type=int, default=3000)
    parser.add_argument("--learning-rate", type=float, default=3.0e-3)
    parser.add_argument("--angular-momentum-penalty", type=float, default=0.5)
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[20260730, 20260731, 20260732, 20260733, 20260734],
    )
    parser.add_argument("--log-every", type=int, default=500)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=HERE / "results" / "mr_variational_nqs",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"JAX devices: {jax.devices()}", flush=True)
    problems = build_problems(args.teacher_file)
    summaries: list[dict[str, Any]] = []
    for problem in problems:
        reference = exact_reference(
            problem, args.angular_momentum_penalty
        )
        if reference["teacher_fidelity"] < 1.0 - 1.0e-8:
            raise RuntimeError(
                f"{problem['name']}: effective ground does not match teacher "
                f"(fidelity={reference['teacher_fidelity']})"
            )
        rows: list[dict[str, Any]] = []
        for seed in args.seeds:
            result, params, psi = train_seed(
                problem,
                args.hidden,
                args.steps,
                args.learning_rate,
                args.angular_momentum_penalty,
                seed,
                args.log_every,
            )
            rows.append(result)
            np.savez_compressed(
                args.output_dir / f"{problem['name']}_seed{seed}.npz",
                **{
                    f"param__{key}": np.asarray(value)
                    for key, value in params.items()
                },
                psi=psi,
            )
            (
                args.output_dir
                / f"{problem['name']}_seed{seed}_result.json"
            ).write_text(json.dumps(result, indent=2), encoding="utf-8")
        summaries.append(aggregate(problem, reference, rows))

    payload = {
        "method": (
            "GPU exact-summation variational complex Fock-NQS; "
            "Hamiltonian Rayleigh quotient only; teacher used post-hoc"
        ),
        "jax_devices": [str(device) for device in jax.devices()],
        "teacher_file": str(args.teacher_file.resolve()),
        "seeds": args.seeds,
        "summaries": summaries,
        "minimum_fidelity": min(
            summary["fidelity_min"] for summary in summaries
        ),
        "maximum_energy_error_abs": max(
            summary["energy_error_max_abs"] for summary in summaries
        ),
        "maximum_variance": max(
            summary["variance_max"] for summary in summaries
        ),
        "claim_boundary": (
            "small-system variational benchmark with exact summation; "
            "not a scalable stochastic VMC result"
        ),
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2), flush=True)


if __name__ == "__main__":
    main()
