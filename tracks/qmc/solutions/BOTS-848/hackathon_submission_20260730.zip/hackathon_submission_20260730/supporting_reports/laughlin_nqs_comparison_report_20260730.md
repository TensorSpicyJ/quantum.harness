# Laughlin VMC 与一次/二次量子化 NQS 能量比较

日期：2026-07-30

## 统一的比较协议

- 几何：Haldane sphere。
- 填充：费米 Laughlin `nu=1/3`，`2Q=3(N-1)`。
- Hamiltonian：电子-电子 Coulomb 相互作用。
- 能量单位：`e^2/(epsilon l_B)`。
- 球半径：`R=sqrt(Q) l_B`。
- 这里没有加入中和背景常数；Laughlin 与 NQS 使用完全相同的
  Hamiltonian，因此能量差不受该常数影响。
- 正式大尺寸比较使用 128 条独立 Markov 链、每链 64 个记录，
  每个尺寸共 8192 个新样本，接受率约 0.45。
- 一次量子化 NQS 写成 `Psi_NQS=Psi_L sum_a c_a F_a`。在同一批新
  Laughlin 样本上同时计算纯 Laughlin 能量和 NQS 重加权能量，
  用 delete-one-chain jackknife 计算配对差值误差。

## 严格一次量子化结果

| N | run/seed | E_Laughlin | E_NQS（新样本） | E_NQS-E_L | 配对误差 | NQS 更低的显著性 |
|---:|---|---:|---:|---:|---:|---:|
| 12 | seed 20260730 | 12.585819 | 12.584175 | -0.001644 | 0.000981 | 1.68 sigma |
| 16 | seed 20260730 | 20.208862 | 20.204968 | -0.003894 | 0.001004 | 3.88 sigma |
| 20 | high-stat seed 20261002 | 29.049103 | 29.044182 | -0.004922 | 0.000673 | 7.32 sigma |
| 30 | seed 20261103 | 55.722700 | 55.719610 | -0.003090 | 0.000762 | 4.05 sigma |
| 30 | seed 20261204 | 55.722700 | 55.719569 | -0.003131 | 0.000923 | 3.39 sigma |
| 40 | seed 20261103 | 87.995965 | 87.994550 | -0.001415 | 0.001185 | 1.19 sigma |
| 40 | seed 20261204 | 87.995965 | 87.993007 | -0.002958 | 0.000858 | 3.45 sigma |

所有重加权 ESS fraction 均在 0.921--0.965，说明这些差值不是少量极端
权重造成的。

结论：

- N=16、20、30 上，训练后一次量子化 NQS 比 Laughlin 低，且达到
  3.4--7.3 sigma。
- N=12 方向相同，但单次新测试只有 1.68 sigma。
- N=40 两个训练种子方向相同；一个为 3.45 sigma，另一个只有
  1.19 sigma，说明降能尚有种子/有限通道敏感性。
- 因而“能量稍低一点”已经得到直接数值支持，但不能把每个尺寸都描述为
  同样稳健。

## 严格二次量子化 tensor/SU(2) 路线

高统计 Laughlin VMC（每点 131072 个样本）与
`runs/su2_tensor_route_20260729/summary.csv` 比较：

| N | E_Laughlin | Laughlin 误差 | 严格二次量子化 E0 | E0-E_L | 显著性 |
|---:|---:|---:|---:|---:|---:|
| 8 | 6.364545 | 0.000368 | 6.362650 | -0.001895 | 5.15 sigma |
| 9 | 7.773216 | 0.000403 | 7.771022 | -0.002195 | 5.45 sigma |
| 10 | 9.283003 | 0.000445 | 9.279895 | -0.003108 | 6.99 sigma |

这一严格二次量子化路线满足基态 `L^2≈0`，相应结果还具有近零能量方差；
所以它相对 Laughlin 的降能是可信的。

## Autoregressive Fock-space NQS

当前 autoregressive 二次量子化结果不能用来声称优于 Laughlin：

- V3, N=8：`E0=6.37834(52)`，`L^2≈12.07`，能量高于 Laughlin。
- V4, N=8：`E0=6.38385(48)`，`L^2≈8.16`，能量高于 Laughlin。
- V5, N=10：`E0=10.0464(126)`，`L^2≈618.69`，而 Laughlin 为
  `9.28300(45)`。
- V5 随 N 增大出现 `L^2≈10^3`、较高 ratio-clip fraction，某些尺寸
  甚至出现负 gap。因此这些值是失稳诊断，不是目标角动量 sector 的
  物理基准。

## 文件

- `laughlin_vmc_comparison.py`：独立 Laughlin VMC、配对 NQS 重加权和
  delete-one-chain jackknife。
- `test_laughlin_vmc_comparison.py`：配对统计核心测试。
- `runs/laughlin_vmc_comparison_formal_20260730/`：N=12--40 正式结果。
- `runs/laughlin_vmc_smallN_highstat_20260730/`：N=8--10 高统计 Laughlin
  基准。
