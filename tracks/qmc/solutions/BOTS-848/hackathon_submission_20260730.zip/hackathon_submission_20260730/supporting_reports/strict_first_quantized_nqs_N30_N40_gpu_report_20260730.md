# 严格一次量子化 NQS 扩展到 N=30、40：本地 GPU 报告

日期：2026-07-30  
设备：NVIDIA GeForce RTX 4090 Laptop GPU，16376 MiB  
能量单位：\(e^2/(\epsilon\ell_B)\)

## 1. 结论

严格一次量子化 LLL/SU(2) tensor-feature NQS 已经在本地 GPU 上完成
\(N=30\) 和 \(N=40\) 的正式 VMC 训练、独立验证和双随机种子复核。
两个尺寸均未发生显存溢出、NaN、白化秩异常或对称性污染。

采用稳定的 \(\ell_{\max}=5\) ansatz，两种子逆方差加权结果为

\[
\boxed{\Delta_{L=2}(N=30)=0.154760(470)_{\rm stat}}
\]

\[
\boxed{\Delta_{L=2}(N=40)=0.149894(480)_{\rm stat}}.
\]

种子一致性：

\[
\chi^2/{\rm dof}=0.000/1\quad(N=30),
\qquad
\chi^2/{\rm dof}=0.496/1\quad(N=40).
\]

所有基态解析严格满足 \(L^2=0\)，所有激发态解析严格满足 \(L^2=6\)。
因此当前严格训练边界已经从 N=20 实际推进到至少 N=40。

这仍是“固定精确 SU(2) 等变特征层 + 可训练复线性头”的浅层
tensor-feature NQS，不是深层 FermiNet/attention NQS。SMA 只用于
激发态 importance sampling，不是最终波函数。

## 2. 计算协议

Laughlin 反对称核为

\[
\Phi_{\rm L}=\prod_{i<j}(u_i v_j-v_i u_j)^3,
\qquad 2Q=3(N-1).
\]

基态使用 5 个 scalar 原始通道：

\[
1,\quad [\rho_\ell\times\rho_\ell]_{00},
\quad \ell=2,\ldots,5.
\]

激发态使用

\[
\rho_{22},\qquad
[\rho_{\ell_1}\times\rho_{\ell_2}]_{22},
\quad \ell_1,\ell_2=2,\ldots,5
\]

共 15 个原始通道。除去解析线性依赖后，ground/excited 保留秩为
5/10。系数由 Monte Carlo overlap 和 Hamiltonian 矩阵的广义本征问题

\[
Hc=ESc
\]

优化。

每个正式运行使用：

- 128 条独立 GPU Markov 链；
- 独立训练集 \(128\times48=6144\) 个构型；
- 独立验证集 \(128\times48=6144\) 个构型；
- N=30：burn-in 600 sweeps、thin 6；
- N=40：burn-in 700 sweeps、thin 7；
- overlap 白化阈值扫描 \(10^{-8}\) 到 \(10^{-4}\)；
- 训练和验证采用不同随机种子与不同 Markov 链。

所有报告能量均来自验证集，不使用训练能量冒充最终结果。

## 3. N=30 正式结果

\(N=30,\ 2Q=87\)，单粒子轨道数为 88。

| seed | \(E_0^{\rm valid}\) | \(E_2^{\rm valid}\) | gap | ground ESS | excited ESS | runtime |
|---:|---:|---:|---:|---:|---:|---:|
| 20261103 | 55.711690(423) | 55.866517(490) | 0.154828(648) | 0.962 | 0.756 | 148.0 s |
| 20261204 | 55.717207(360) | 55.871891(579) | 0.154684(682) | 0.950 | 0.796 | 149.9 s |

两种子 gap 几乎完全重合：

\[
\Delta_{30}=0.1547596\pm0.0046965.
\]

分别对 \(E_0,E_2\) 做逆方差加权得到

\[
E_0=55.714893(274),\qquad
E_2=55.868759(374).
\]

注意：独立加权后的 \(E_2-E_0\) 与直接对 gap 加权不必严格相同，因为
三个量使用不同统计权重；最终 gap 采用直接 gap 的加权值。

## 4. N=40 正式结果

\(N=40,\ 2Q=117\)，单粒子轨道数为 118。

| seed | \(E_0^{\rm valid}\) | \(E_2^{\rm valid}\) | gap | ground ESS | excited ESS | runtime |
|---:|---:|---:|---:|---:|---:|---:|
| 20261103 | 87.994624(400) | 88.141286(530) | 0.146662(664) | 0.954 | 0.893 | 368.7 s |
| 20261204 | 87.993364(448) | 88.146787(530) | 0.153423(694) | 0.966 | 0.866 | 373.5 s |

两种子相差约 \(0.70\sigma\)，统计相容。加权结果：

\[
\Delta_{40}=0.1498936\pm0.0047964,
\]

\[
E_0=87.994066(298),\qquad
E_2=88.144039(375).
\]

N=40 的 excited ESS 比 N=20、30 更高，说明使用 SMA 作为 importance
distribution 在这个尺寸上没有恶化，反而覆盖了训练态的主要权重区域。

## 5. 与固定 SMA 的比较

此前固定 SMA 的高统计结果：

| N | 固定 SMA gap | 训练 NQS gap | 差值（训练-SMA） |
|---:|---:|---:|---:|
| 20 | 0.145503(264) | 0.144724(259) | \(-0.00078\) |
| 30 | 0.147250(309) | 0.154760(470) | \(+0.00751\) |
| 40 | 0.148372(348) | 0.149894(480) | \(+0.00152\) |

N=20、40 与固定 SMA 完全相容。N=30 高约 \(1.6\sigma\)，尚不足以证明
存在真实非单调尺寸效应。gap 不是单一 sector 的变分上界；基态和激发态
分别降能后，其差可以向任一方向移动。

N=30 两种子 gap 的高度一致说明该偏移不是单个随机种子异常，但当前
误差仍不足以区分以下两种解释：

1. ground/excited 的有限通道变分修正没有完全抵消；
2. N=30 的有限尺寸 gap 确实略高。

因此不能根据当前 N=30 点单独做热力学外推。

## 6. \(\ell_{\max}=6\) 截断检查

在 N=30、seed 20261103 上增加到 \(\ell_{\max}=6\)：

| ansatz | ground rank | excited rank | gap | ground ESS | excited ESS |
|---:|---:|---:|---:|---:|---:|
| \(\ell_{\max}=5\) | 5 | 10 | 0.154828(648) | 0.962 | 0.756 |
| \(\ell_{\max}=6\) | 6 | 13 | 0.160720(730) | 0.936 | 0.409 |

\(\ell_{\max}=6\) 的训练激发能下降，但验证激发能没有改善，excited ESS
下降到 0.409。这说明额外通道在当前采样预算和 SMA importance
distribution 下加重了重加权方差/训练过拟合。

因此正式结果保留 \(\ell_{\max}=5\)，不依据较低的训练能量选择
\(\ell_{\max}=6\)。根据 N=20、30 的 cutoff 变化，保守 ansatz 系统误差
可取约 \(0.006\)：

\[
\Delta_{30}=0.1548\pm0.0047_{\rm stat}\pm0.006_{\rm ansatz},
\]

\[
\Delta_{40}=0.1499\pm0.0048_{\rm stat}\pm0.006_{\rm ansatz}.
\]

N=40 没有继续运行低 ESS 的 \(\ell_{\max}=6\)，避免用更昂贵但验证质量
更差的配置消耗 GPU 时间。

## 7. 尺寸趋势

推荐 \(\ell_{\max}=5\) 训练结果：

| N | trained gap | 备注 |
|---:|---:|---|
| 12 | 0.130401(667) | 单 seed，excited ESS 0.20 |
| 16 | 0.141196(576) | 单 seed，excited ESS 0.30 |
| 20 | 0.144724(259) | 三 seed |
| 30 | 0.154760(470) | 两 seed |
| 40 | 0.149894(480) | 两 seed |

N=20--40 的结果整体与约 0.145--0.150 的大尺寸 gap 相容。N=30 中心值
偏高，但加入统计和 ansatz 系统误差后不能认为出现显著非单调行为。

## 8. 规模与性能

流式 pair contraction 不构造 \(D\times D\) 双电子多项式块，中间存储
保持 \(O(N^2D)\)。本轮实测：

| N | feature batch | 单次完整正式运行 | 状态 |
|---:|---:|---:|---|
| 20 | 24--32 | 57--147 s | 无 OOM |
| 30 | 16 | 148--150 s | 无 OOM |
| 40 | 8 | 369--374 s | 无 OOM |

这里的“完整运行”包括 ground/excited、training/validation 四套采样与
特征、首次 JAX 编译和广义本征求解。

对应未约化二次量子化 Fock 维数为

\[
{88\choose30}
=297\,489\,479\,369\,949\,289\,157\,856
\quad(N=30),
\]

\[
{118\choose40}
=50\,700\,229\,755\,474\,779\,236\,446\,357\,112\,074
\quad(N=40).
\]

连续坐标一次量子化方法不枚举这些基矢，这正是它能够运行到 N=40 的
根本原因。

## 9. 可信结论与限制

可以确认：

- N=30、40 都是经过 VMC 训练的多通道一次量子化 NQS；
- 不是固定 SMA 波函数的能量重采样；
- 训练和验证独立；
- 两尺寸均完成双种子复核；
- \(L^2=0/6\) 由 ansatz 解析严格保证；
- 在 16GB 本地 GPU 上 N=40 可实际完成，单次约 6.2 分钟。

不能据此声称：

- 当前实现是深度神经网络 NQS；
- N=30 中心值高于 SMA 已有统计显著性；
- N=40 是算法硬上限；
- 现有数据足以做高精度热力学外推。

当前硬件上的下一实际目标可以是 N=50，但若要提高物理精度，优先级应是
改进激发态 direct sampling，而不是继续增加 \(\ell_{\max}\) 并依赖 SMA
重加权。

## 10. 数据与复现

正式结果：

- `runs/strict_fq_streaming_N30_l5_seed20261103/results.json`
- `runs/strict_fq_streaming_N30_l5_seed20261204/results.json`
- `runs/strict_fq_streaming_N30_l6_seed20261103/results.json`
- `runs/strict_fq_streaming_N40_l5_seed20261103/results.json`
- `runs/strict_fq_streaming_N40_l5_seed20261204/results.json`
- `runs/strict_fq_streaming_N20_N40_benchmark_20260730.csv`

N=30 示例：

```bash
XLA_PYTHON_CLIENT_PREALLOCATE=false \
/home/zyz/miniconda3/envs/nk_env/bin/python \
strict_first_quantized_nqs_streaming_driver.py \
  --sizes 30 --lmax 5 \
  --chains 128 --burn-sweeps 600 \
  --training-records 48 --validation-records 48 \
  --thin-sweeps 6 --feature-batch 16 \
  --tolerances 1e-4,1e-5,1e-6,1e-7,1e-8 \
  --seed 20261103 \
  --output-dir runs/strict_fq_streaming_N30_l5_seed20261103
```

N=40 示例：

```bash
XLA_PYTHON_CLIENT_PREALLOCATE=false \
/home/zyz/miniconda3/envs/nk_env/bin/python \
strict_first_quantized_nqs_streaming_driver.py \
  --sizes 40 --lmax 5 \
  --chains 128 --burn-sweeps 700 \
  --training-records 48 --validation-records 48 \
  --thin-sweeps 7 --feature-batch 8 \
  --tolerances 1e-4,1e-5,1e-6,1e-7,1e-8 \
  --seed 20261103 \
  --output-dir runs/strict_fq_streaming_N40_l5_seed20261103
```
