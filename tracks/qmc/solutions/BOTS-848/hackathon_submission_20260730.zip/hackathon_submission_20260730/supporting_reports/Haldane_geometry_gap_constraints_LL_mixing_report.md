# 从 gap 约束到 Haldane 几何与 Landau-level mixing

## ——手性引力子 NQS 挑战的深化调研报告

> 本报告同时基于本文件夹中的 ED/NQS 代码和相关原始论文。重点回答四个问题：
>
> 1. 基态和激发态到底用了什么约束？是不是拉格朗日乘子？
> 2. NQS 与 ED 算出的 gap 用什么单位？
> 3. Haldane 为什么要从“几何”而不只是“拓扑”理解量子霍尔效应？这与我们的挑战有什么关系？
> 4. 忽略 Landau-level mixing 是否合理？下一步怎样把它纳入计算？

---

## 0. 一页结论

### 0.1 关于 gap 的约束

本项目**不是**通过在损失函数中加入一个拉格朗日乘子来强迫激发态与基态正交，也不是直接训练
\(\Delta=E_2-E_0\)。

- NQS 基态被构造成总角动量 \(L=0\) 的标量态；
- NQS 激发态被构造成总角动量 \(L=2\) 的张量态；
- 因为 \(L=0\) 与 \(L=2\) 属于不同的旋转群不可约表示，它们自动正交；
- 分别在两个对称性子空间内最小化 \(E_0\) 和 \(E_2\)，最后作差：

\[
\Delta_{2}=E_{L=2}^{\min}-E_{L=0}^{\min}.
\]

这叫作**对称性扇区的硬约束**，不是拉格朗日约束。

稀疏 ED 代码中确实出现了

\[
H_{\mathrm{search}}
=H_C+\lambda\left[L^2-L_{\rm target}(L_{\rm target}+1)\right]^2,
\]

但它只是帮助稀疏本征求解器找到目标 \(L\) 的**正定惩罚项**，不是物理 Hamiltonian，也不是通过变分确定的拉格朗日乘子。最终报告的能量仍然是原始 Coulomb Hamiltonian \(H_C\) 的期望值。

### 0.2 关于单位

代码中的 ED 与 NQS 能量都使用 Coulomb 能标

\[
E_C=\frac{e^2}{4\pi\epsilon_0\epsilon_r\ell_B},
\qquad
\ell_B=\sqrt{\frac{\hbar}{eB}}.
\]

代码和凝聚态文献常把 \(4\pi\epsilon_0\) 省略，写成 \(e^2/(\epsilon\ell_B)\)。所以输出的 gap，例如 \(0.13\)，意思是

\[
\Delta=0.13\,E_C,
\]

而不是 \(0.13\ {\rm meV}\)。

### 0.3 Haldane 几何故事的核心

拓扑告诉我们一个 FQH 态属于什么相、有哪些分数量子数和边界理论；几何则进一步问：

> 这个不可压缩量子液体内部的“相关空穴”是什么形状？当它受到剪切时如何变形？这种形变能否量子化成一个自旋 2 集体模？

Haldane 的回答是：投影到一个 Landau level 后，电子的导引中心坐标本身不对易；相互作用因此不是在普通平面上安排粒子，而是在一个非对易的面积保持几何中组织相关性。FQH 液体具有一个动态的、面积不变的**内禀度规**。它的小振动就是所谓的几何模或“引力子”。

因此，我们真正有潜力讲的故事不是“神经网络把某个 gap 算准了”，而是：

> 用与 Haldane 导引中心几何相同的投影密度张量构造 NQS，研究 Laughlin 拓扑相内部的量子几何、手性自旋 2 模，以及现实效应如何使理想的单手性引力子发生偏离。

### 0.4 Landau-level mixing 的结论

当前代码相当于严格取

\[
\kappa\equiv\frac{E_C}{\hbar\omega_c}=0.
\]

但对 GaAs，

\[
\kappa\simeq\frac{2.52}{\sqrt{B[{\rm T}]}}.
\]

所以 \(B=5,10,15\ {\rm T}\) 时，\(\kappa\) 分别约为 \(1.13,0.80,0.65\)。真实样品中 Landau-level spacing 通常**并没有比 Coulomb 能大很多个数量级**。LLL 投影可作为很好的零阶模型，但要和实验作定量比较，mixing、有限厚度和无序都不能忽略。

最可行的第一步不是立刻扩大到多个 Landau levels，而是在 LLL 中使用微扰下折叠得到的有效 Hamiltonian：

\[
H_{\rm eff}
=H_C
+\kappa\,\delta H^{(2)}
+\kappa\,H^{(3)}
+O(\kappa^2),
\]

其中除了修正二体赝势，还会生成三体相互作用。这样可以保留现有 NQS 的绝大部分结构。

---

# 1. 代码审计：基态、激发态和 gap 究竟怎样定义？

## 1.1 物理体系

代码研究的是 Haldane 球面上的 \(\nu=1/3\) Laughlin 序列：

\[
N_\phi=2Q=3(N-1),
\]

其中 \(N\) 是电子数，球心放置磁单极子，穿过球面的磁通量为 \(N_\phi\) 个磁通量子。最低 Landau level 中单粒子角动量为 \(l=Q\)，轨道数为

\[
N_{\rm orb}=2Q+1.
\]

多体 Hilbert 空间采用占据数基底

\[
|n_{-Q},n_{-Q+1},\ldots,n_Q\rangle,
\qquad n_m=0,1.
\]

物理目标 Hamiltonian 是投影到 LLL 后的球面 Coulomb 相互作用。若用两电子总角动量 \(J\) 的 Haldane 赝势表示，

\[
H_C=\sum_{i<j}\sum_J V_J^{C}\,P_{ij}(J),
\]

其中 \(P_{ij}(J)\) 把电子对投影到总角动量 \(J\) 的通道。

代码中的 Laughlin \(V_1\) 模型 Hamiltonian 主要用于产生精确 Laughlin 零能种子，不是最终需要优化和比较的 Coulomb Hamiltonian。

---

## 1.2 ED 如何寻找 \(L=0\) 与 \(L=2\)？

### 稠密 ED

稠密 ED 在固定 \(M=L_z=0\) 的占据数基底中构造 \(H_C\)，直接对角化，然后利用

\[
L^2=L_-L_++L_z(L_z+1)
\]

识别每个本征矢的总角动量 \(L\)。最后选取：

- 能量最低的 \(L=0\) 态作为基态；
- 能量最低的 \(L=2\) 态作为长波自旋 2 激发态。

此处没有给 Hamiltonian 加额外物理项。\(L\) 只是对本征态进行分类和筛选的好量子数。

### 稀疏 ED

大 Hilbert 空间中，若只让迭代求解器寻找最低几个本征值，目标 \(L=2\) 态可能被其他角动量扇区的低能态挡住。因此代码使用搜索算符

\[
H_{\rm search}
=H_C+\lambda
\left[L^2-L_t(L_t+1)\right]^2 .
\]

对一个总角动量为 \(L\) 的态，这一项贡献

\[
\lambda
\left[L(L+1)-L_t(L_t+1)\right]^2.
\]

因此：

- 当 \(L=L_t\) 时，惩罚严格为零；
- 当 \(L\neq L_t\) 时，能量被人为抬高；
- \(\lambda>0\) 是预先选择的搜索参数，代码默认约为 \(0.05\)；
- 找到本征矢后，物理能量重新按
  \(\langle\psi|H_C|\psi\rangle\) 计算。

### 为什么这不是拉格朗日乘子？

拉格朗日乘子法通常写成

\[
\mathcal L[\psi,\mu]
=\langle H\rangle
+\mu\,C[\psi],
\]

并同时对 \(\psi\) 与乘子 \(\mu\) 求驻值，以精确执行 \(C[\psi]=0\)。

这里的 \(\lambda\)：

- 不参与优化；
- 不是为了定义新的物理模型；
- 只把非目标 \(L\) 扇区数值上移；
- 最终物理能量不包含它。

因此更准确的名字是**谱移位或二次惩罚靶向法**。

---

## 1.3 NQS 如何约束基态？

代码首先用 Laughlin 模型 Hamiltonian 得到球面 Laughlin 种子

\[
|\Psi_{\rm Lgh}\rangle,
\qquad L=0.
\]

然后构造 LLL 投影密度算符

\[
\bar\rho_{\ell M}
=
\sum_{m_1m_2}
\langle Qm_1;\ell M|Qm_2\rangle
c^\dagger_{m_2}c_{m_1},
\]

其在旋转下是秩为 \(\ell\) 的球张量。

将两个相同秩的密度耦合成标量：

\[
S_\ell
=
[\bar\rho_\ell\otimes\bar\rho_\ell]_{00}
=
\sum_{M}
\langle \ell M,\ell {-M}|00\rangle
\bar\rho_{\ell M}\bar\rho_{\ell,-M}.
\]

因为 \(S_\ell\) 是旋转标量，

\[
[L^2,S_\ell]=[L_z,S_\ell]=0.
\]

所以无论对 \(L=0\) 种子作用多少次 \(S_\ell\)，结果仍严格在 \(L=0\) 子空间：

\[
|\Psi_0(\theta)\rangle
=
\mathcal F_\theta(S_2,S_3,\ldots)
|\Psi_{\rm Lgh}\rangle,
\qquad L=0.
\]

这里的 \(\mathcal F_\theta\) 是可训练的线性组合或低深度 backflow/神经量子态变换。最重要的不是网络名称，而是它的所有基态特征都由**旋转标量算符**生成。

因此基态的 \(L=0\) 不是通过损失函数“鼓励”出来的，而是 ansatz 一开始就不允许离开 \(L=0\)。

---

## 1.4 NQS 如何约束激发态？

激发态使用秩 2 张量特征，例如

\[
\bar\rho_{2M}
\]

以及

\[
T^{(2)}_{\ell_1\ell_2;M}
=
[\bar\rho_{\ell_1}\otimes\bar\rho_{\ell_2}]_{2M}
=
\sum_{M_1M_2}
\langle\ell_1M_1,\ell_2M_2|2M\rangle
\bar\rho_{\ell_1M_1}\bar\rho_{\ell_2M_2}.
\]

它们作用在 \(L=0\) 标量态上，得到严格的 \(L=2\) 态：

\[
|\Psi_{2M}(\phi)\rangle
=
\sum_a c_a(\phi)\,T^{(2)}_{aM}
|\Psi_{\rm scalar}(\theta)\rangle .
\]

代码对所有 \(M=-2,\ldots,2\) 使用同一组约化系数 \(c_a\)，因此构成完整的 \(L=2\) 五重态；实际训练可只选一个方便的分量，例如 \(M=2\)。

由于

\[
\langle L=0|L=2,M\rangle=0,
\]

激发态天然与基态正交。代码不需要加入

\[
\lambda|\langle\Psi_0|\Psi_2\rangle|^2
\]

这样的正交惩罚，也不需要逐步 Gram–Schmidt。

---

## 1.5 实际训练目标是什么？

### 当前 V2/稀疏版本

基态与激发态分别最小化各自的 Rayleigh 商：

\[
E_0(\theta)
=
\frac{\langle\Psi_0(\theta)|H_C|\Psi_0(\theta)\rangle}
{\langle\Psi_0(\theta)|\Psi_0(\theta)\rangle},
\]

\[
E_2(\phi,\theta)
=
\frac{\langle\Psi_2(\phi,\theta)|H_C|\Psi_2(\phi,\theta)\rangle}
{\langle\Psi_2(\phi,\theta)|\Psi_2(\phi,\theta)\rangle}.
\]

稀疏版本首先在由这些特征张成的子空间中做 Rayleigh–Ritz：

\[
H_{\rm feat}=F^\dagger H_C F,
\qquad
S_{\rm feat}=F^\dagger F,
\]

解广义本征值问题

\[
H_{\rm feat}c=E\,S_{\rm feat}c.
\]

代码会对白化后的特征子空间进行求解，以处理高度相关甚至近线性相关的特征。这一步从数学上说更接近“对称性适配的变分子空间对角化”；后续 Monte Carlo 优化主要验证采样表示和局域能量估计。

### 旧 V1 版本

旧版本曾使用共享参数并优化

\[
\mathcal L_{\rm old}
=\frac12E_0+\frac12E_2.
\]

这仍不是正交约束或 gap 拉格朗日乘子，而是一个**态平均目标**。共享参数必须在改善基态和激发态之间折中，可能导致两边都不是各自最优。因此 V2 将两个扇区的变分坐标更清楚地分开。

### gap 的统计和变分含义

最终

\[
\Delta_{\rm NQS}=E_2^{\rm NQS}-E_0^{\rm NQS}.
\]

需要特别注意：\(E_0^{\rm NQS}\) 和 \(E_2^{\rm NQS}\) 分别是对应对称性扇区真能量的变分上界，但两个上界之差

\[
\Delta_{\rm NQS}
\]

一般既不保证是真 gap 的上界，也不保证是下界。两个能量的误差还可能相互抵消。因此汇报时必须同时给出：

- \(E_0^{\rm NQS}-E_0^{\rm ED}\)；
- \(E_2^{\rm NQS}-E_2^{\rm ED}\)；
- \(\Delta_{\rm NQS}-\Delta_{\rm ED}\)；
- 两个态的能量方差；
- 若可行，再给 overlap 或子空间保真度。

---

## 1.6 一张表回答“到底是什么约束”

| 方法 | 如何得到基态 | 如何得到 \(L=2\) 态 | 是否拉格朗日乘子？ | 报告的能量属于哪个 Hamiltonian？ |
|---|---|---|---|---|
| 稠密 ED | 对角化后按 \(L^2\) 分类，取最低 \(L=0\) | 取最低 \(L=2\) | 否 | 原始 \(H_C\) |
| 稀疏 ED | 用目标 \(L\) 的谱移位加速搜索 | 同左 | 否；是固定二次惩罚 | 最终仍是原始 \(H_C\) |
| NQS/V2 | 标量算符作用于 \(L=0\) 种子 | 秩 2 张量作用于标量态 | 否；是 ansatz 的硬对称性 | 原始 \(H_C\) |
| gap | 分别最小化 \(E_0\) | 分别最小化 \(E_2\) | 不直接约束 gap | \(\Delta=E_2-E_0\) |

## 1.7 对应的代码位置

- 球面弦距离 Coulomb 矩阵元：[chiral_graviton_ed.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_ed.py:194)
- $L^2$ 构造与 ED 的 $L$ 分类：[chiral_graviton_ed.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_ed.py:362)
- 稠密 ED 选取最低目标 $L$：[chiral_graviton_ed.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_ed.py:422)
- 投影密度、标量与 rank-2 算符：[chiral_graviton_nqs_vmc.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_nqs_vmc.py:69)
- V2 白化与 Rayleigh–Ritz：[chiral_graviton_nqs_vmc_v2.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_nqs_vmc_v2.py:60)
- V2 标量 backbone 与 tensor head：[chiral_graviton_nqs_vmc_v2.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_nqs_vmc_v2.py:106)
- V2 独立 ground/excited 变分坐标：[chiral_graviton_nqs_vmc_v2.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_nqs_vmc_v2.py:198)
- 当前稀疏版本的投影子空间求解：[chiral_graviton_nqs_vmc_sparse.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_nqs_vmc_sparse.py:443)
- 稀疏 ED 的二次惩罚与原始 $H_C$ 能量回算：[chiral_graviton_nqs_vmc_sparse.py](/home/zyz/miniconda3/envs/vmc_gpu/Hardness_NQS/chiral_graviton_nqs_vmc_sparse.py:640)

---

# 2. NQS 与 ED 的 gap 用什么单位？

## 2.1 代码中的自然单位

球面半径为

\[
R=\sqrt Q\,\ell_B.
\]

代码采用球面弦距离 Coulomb 势，并把整体 Coulomb 能标设为 1。因此所有总能、每粒子能量和 gap 都以

\[
E_C=\frac{e^2}{4\pi\epsilon_0\epsilon_r\ell_B}
\]

为单位。

若输出

\[
E_0=-\ldots,\qquad
E_2=-\ldots,\qquad
\Delta=0.13,
\]

则 gap 的物理值为

\[
\Delta_{\rm phys}=0.13
\frac{e^2}{4\pi\epsilon_0\epsilon_r\ell_B}.
\]

NQS 和 ED 使用同一个 Hamiltonian、同一个球面半径与同一个归一化，因此两者的 gap 可以直接比较。

## 2.2 换算为 meV 和 K

磁长约为

\[
\ell_B[{\rm nm}]\simeq\frac{25.66}{\sqrt{B[{\rm T}]}}.
\]

Coulomb 能标为

\[
E_C[{\rm meV}]
\simeq
\frac{56.12}{\epsilon_r}\sqrt{B[{\rm T}]}.
\]

对 GaAs 取 \(\epsilon_r\simeq12.9\)：

\[
E_C[{\rm meV}]\simeq4.35\sqrt{B[{\rm T}]}.
\]

以代码中常见的无量纲 gap \(0.13E_C\) 为例：

| \(B\) | \(\ell_B\) | \(E_C\) | \(0.13E_C\) |
|---:|---:|---:|---:|
| \(5\,{\rm T}\) | \(11.48\,{\rm nm}\) | \(9.73\,{\rm meV}\) | \(1.26\,{\rm meV}\approx14.7\,{\rm K}\) |
| \(10\,{\rm T}\) | \(8.11\,{\rm nm}\) | \(13.76\,{\rm meV}\) | \(1.79\,{\rm meV}\approx20.8\,{\rm K}\) |
| \(15\,{\rm T}\) | \(6.63\,{\rm nm}\) | \(16.85\,{\rm meV}\) | \(2.19\,{\rm meV}\approx25.4\,{\rm K}\) |

这些只是理想二维、零厚度、无无序、无 LL mixing 的裸能标换算，不应直接等同于实验的 activation gap。

## 2.3 背景电荷与有限尺寸修正

球面 Coulomb 总能通常还可能包含：

1. 均匀正背景与电子的相互作用；
2. 正背景自能；
3. 为比较不同 \(N\) 而使用的 density correction。

本项目的 NQS/ED 对比使用相同 \(N,Q\) 和相同约定。对同一个系统的 \(L=0\) 与 \(L=2\)：

- 与量子态无关的背景常数会在 gap 中严格抵消；
- density correction 若启用，会把两个能量和 gap 同时乘一个有限尺寸因子；
- 当前主要比较没有启用这一修正。

因此代码内部的 NQS–ED gap 比较没有单位歧义，但若拿去和其他论文作数值比较，必须先核对背景、球面半径和 density correction 的约定。

---

# 3. Haldane 的完整故事：从球面到量子几何

严格说，Haldane 研究这条问题线索不只是二十年：从 1983 年的球面与赝势，到 2009–2011 年明确提出导引中心几何，再到 2023 年的电四极矩表述，跨度已接近四十年。其思想不是一次完成的，而是逐步把“一个漂亮的试探波函数”发展成“量子霍尔液体的几何动力学”。

## 3.1 1983：球面不是纯粹的数值技巧

Haldane 在 1983 年引入球面几何，目标是消除有边界圆盘带来的边缘效应，并在有限粒子数下保留完整旋转对称性。球面上的旋转群在大半径极限下过渡到平面的平移与旋转对称性。这篇工作同时建立了球面磁单极子、有限尺寸 FQH 序列和赝势语言。[Haldane, PRL 51, 605 (1983)](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.51.605)

### 球面上的 shift

热力学上人们可能只记得

\[
N_\phi\simeq\nu^{-1}N,
\]

但球面上精确关系是

\[
N_\phi=\nu^{-1}N-\mathcal S,
\]

其中 \(\mathcal S\) 是 shift。对 \(\nu=1/3\) Laughlin 态，

\[
\mathcal S=3,
\qquad
N_\phi=3(N-1).
\]

shift 不是普通的有限尺寸误差；它表示粒子数、磁通量和曲率之间的响应，是拓扑相的几何量子数。在连续、旋转不变体系中，总平均轨道自旋满足

\[
\bar s=\frac{\mathcal S}{2}.
\]

所以我们代码中固定的 \(2Q=3(N-1)\) 已经悄悄写入了 Laughlin 态的几何响应。

### 赝势的几何含义

球面上两粒子的相对距离可由它们的总角动量通道描述。旋转不变二体相互作用可以完全展开成 Haldane 赝势：

\[
H=\sum_{i<j}\sum_m V_m P_{ij}(m),
\]

其中 \(m\) 是相对角动量。对费米子只允许奇数 \(m\)。

Laughlin \(\nu=1/3\) 态在任意两粒子接近时有三阶零点，因此完全排除 \(m=1\) 对。于是只取 \(V_1>0\)、其他 \(V_m=0\) 的模型中，它是精确零能基态。

这不只是“短程排斥很强”。更深的意思是：赝势规定了粒子周围相关空穴允许或禁止哪些角动量形状，也就是在选择量子液体的局域相关几何。

---

## 3.2 投影后，电子位置分成两套几何

在磁场中，电子坐标可分解为

\[
\mathbf r=\mathbf R+\widetilde{\mathbf R},
\]

其中：

- \(\widetilde{\mathbf R}\)：回旋运动或 Landau-orbit 坐标；
- \(\mathbf R\)：轨道圆心的导引中心坐标。

二者彼此对易，但各自内部不对易：

\[
[\widetilde R^x,\widetilde R^y]=+i\ell_B^2,
\qquad
[R^x,R^y]=-i\ell_B^2.
\]

这一区分极其重要：

| 部分 | 主要由什么决定？ | LLL 投影后怎样？ |
|---|---|---|
| Landau orbit | 动能、质量张量、单粒子 form factor | 冻结在所选 Landau level 中 |
| Guiding center | 电子间相互作用和多体关联 | 仍然是活跃的多体自由度 |

传统图像容易把 LLL 投影理解成“动能是常数，只剩势能”。Haldane 的几何图像进一步指出：剩下的并不是普通的经典位置，而是一套非对易导引中心代数。

投影密度满足 Girvin–MacDonald–Platzman 型代数。平面上可写为

\[
[\bar\rho_{\mathbf q},\bar\rho_{\mathbf q'}]
=
2i\sin\!\left(
\frac{\ell_B^2\,\mathbf q\times\mathbf q'}{2}
\right)
\bar\rho_{\mathbf q+\mathbf q'} .
\]

长波极限下，这套代数生成面积保持形变。Haldane 2011 年从结构因子的自对偶性和导引中心代数讨论了这种量子几何。[Haldane, arXiv:1112.0990](https://arxiv.org/abs/1112.0990)

这正是本项目使用 \(\bar\rho_{\ell M}\) 作为 NQS 基本积木的深层理由：我们不是随意选了一个神经网络输入，而是在用 FQH 液体自身的几何生成元来构造变分空间。

---

## 3.3 2009–2011：FQH 液体有一个内禀度规

Laughlin 波函数常写为

\[
\Psi_{\rm Lgh}
=\prod_{i<j}(z_i-z_j)^3
e^{-\sum_i|z_i|^2/(4\ell_B^2)}.
\]

表面看它使用欧氏距离 \(x^2+y^2\)。但外界可能有：

- 各向异性的质量张量；
- 各向异性的介电环境；
- 倾斜磁场；
- 晶格或应变；
- 各向异性相互作用。

那么相关空穴为什么一定是圆的？Haldane 的答案是：FQH 液体具有一个自身选择的、行列式为 1 的内禀度规

\[
\bar g_{ab},
\qquad \det\bar g=1.
\]

它描述局域相关空穴或“复合玻色子液滴”的形状。行列式固定表示形变保面积，只改变剪切和方向。

Haldane 在 2009 年把导引中心 Hall viscosity 与内禀度规联系起来，[Haldane, arXiv:0906.1854](https://arxiv.org/abs/0906.1854)；2011 年进一步明确提出，FQH 态的基本集体自由度是描述局域关联形状的动态 unimodular metric，其量子涨落由导引中心自旋控制。[Haldane, PRL 107, 116801 (2011)](https://arxiv.org/abs/1106.3375)

### 直观比喻

可以把每个电子想象成带着一个“不能被其他电子进入的相关空穴”：

- 拓扑告诉你这种液体属于 \(\nu=1/3\) Laughlin 相；
- 内禀度规告诉你相关空穴是圆、椭圆，还是朝哪个方向拉伸；
- 引力子则是所有相关空穴协同做的一次量子化剪切振动。

它与真实时空中的引力波没有直接关系。“引力子”这个名字来自度规涨落的自旋 2 性质。

---

## 3.4 Hall viscosity：对剪切的无耗散响应

普通剪切黏度会耗散能量。破坏时间反演的二维量子霍尔液体还允许一个无耗散的反对称黏度，即 Hall viscosity。

从量子态角度看，它是缓慢改变空间或轨道度规时的 Berry 曲率。对旋转不变的连续 FQH 态，常用约定下

\[
\eta_H=\frac{\hbar\rho\,\mathcal S}{4}.
\]

Haldane 强调，总 Hall viscosity 可以分成：

\[
\eta_H
=\eta_H^{\rm orbit}
+\eta_H^{\rm guiding-center}.
\]

- Landau-orbit 部分与所处 Landau level 有关；
- guiding-center 部分反映真正的多体相关和拓扑序。

Park 与 Haldane 进一步把导引中心 Hall viscosity、边缘偶极矩和轨道纠缠谱联系起来。[Park and Haldane, arXiv:1403.2822](https://arxiv.org/abs/1403.2822)

这说明几何不是拓扑的竞争者。更准确地说：

> 拓扑给出量子化系数和允许的普适响应；几何给出这些响应在局域形变、结构因子、边缘和集体模中的具体表现。

---

## 3.5 为什么长波中第一个内部模是 \(L=2\)？

一个均匀液滴的长波形变可按角动量分类：

- \(L=0\)：整体密度或面积变化；
- \(L=1\)：整体平移或偶极位移；
- \(L=2\)：四极或剪切形变；
- 更高 \(L\)：更细的形状波纹。

对不可压缩、平移不变的 FQH 液体：

- \(L=0\) 低能密度压缩被不可压缩性禁止；
- \(L=1\) 主要对应整体平移，不是内部中性形变；
- \(L=2\) 是第一个真正改变相关空穴形状而不改变面积的内部模。

球面上 \(L=2\) 在热力学极限对应长波：

\[
(q\ell_B)^2
\simeq\frac{L(L+1)}{Q}.
\]

固定 \(L=2\)，令 \(Q\sim N\to\infty\)，就有 \(q\ell_B\to0\)。因此我们计算的最低 \(L=2\) 激发正是长波几何模的自然候选者。

---

## 3.6 结构因子为什么从 \(q^4\) 开始？

投影后的导引中心静态结构因子可写成

\[
\bar S(\mathbf q)
=
\frac1N
\langle
\delta\bar\rho_{-\mathbf q}
\delta\bar\rho_{\mathbf q}
\rangle .
\]

对均匀、不可压缩的 FQH 液体，长波展开不是从 \(q^2\) 开始，而是

\[
\bar S(q)
=S_4(q\ell_B)^4
+S_6(q\ell_B)^6+\cdots.
\]

没有 \(q^2\) 项与导引中心代数、平移不变性和不可压缩性有关。Haldane 证明 \(S_4\) 受到一个由导引中心自旋/Hall viscosity 决定的下界约束；不同文献按“每粒子”还是“每磁通”归一化时系数不同，因此跨文献比较必须先统一 convention。[Haldane, arXiv:0906.1854](https://arxiv.org/abs/0906.1854)

理想 Laughlin 赝势模型饱和该下界。物理意义是长波谱权重可以集中在单一手性的自旋 2 几何模上。

但是 Coulomb 基态即使与 Laughlin 态 overlap 很高，也不一定饱和几何下界。Kumar 与 Haldane 的有限尺寸研究发现，\(\nu=1/3\) Coulomb 态的 \(S_4\) 约高于下界 6%，并据此预言相反手性的弱光谱权重，强度比约为 \(0.03\)。[Kumar and Haldane, SciPost Phys. 16, 117 (2024)](https://arxiv.org/abs/2304.14991)

这是对我们项目特别重要的一点：

> 99% 的波函数 overlap 和很准的基态能量，仍可能漏掉几何响应中几个百分点但概念上非常关键的“非最大手性”。

所以只比较能量 gap 还不足以证明 NQS 学到了正确的引力子物理。

---

## 3.7 单模近似、磁旋子与引力子

传统 Girvin–MacDonald–Platzman 单模近似使用

\[
|\Psi_{\mathbf q}^{\rm SMA}\rangle
\propto\bar\rho_{\mathbf q}|\Psi_0\rangle,
\]

能量为

\[
E_{\rm SMA}(q)
=\frac{f(q)}{\bar S(q)},
\]

其中 \(f(q)\) 是 oscillator strength。中等波矢处，这一分支形成熟悉的 magnetoroton minimum。

在 \(q\to0\) 时，密度算符的非平凡内部作用从二阶矩开始，恰好对应四极剪切。因此磁旋子分支的长波端可重新解释为自旋 2 几何模。

但“最低 \(L=2\) 能量”等同于“一个干净的引力子准粒子”需要额外检查：

1. 该态是否被度规/应力张量算符强烈激发？
2. 谱权重是否集中在一个峰，而不是双 roton 连续谱？
3. 左右圆偏振的手性权重是否高度不对称？
4. 随系统尺寸增加，该态是否保持清晰？

Haldane 的自对偶结构因子分析也指出，Coulomb 情形的长波集体模可能与双 roton 连续谱混合。[Haldane, arXiv:1112.0990](https://arxiv.org/abs/1112.0990)

因此当前项目准确地说是在计算：

> “最低长波 \(L=2\) 中性激发的能量候选”

而要把它无歧义地称作手性引力子，还应计算其几何算符谱权重和手性。

---

## 3.8 从动态度规到实验中的手性引力子

Gromov 与 Son 的 bimetric 理论把背景空间度规与 FQH 液体的内部动态度规同时纳入有效场论，使自旋 2 GMP 模成为显式的动力学场。[Gromov and Son, Phys. Rev. X 7, 041032 (2017)](https://arxiv.org/abs/1705.06739)

Liou、Haldane、Yang 和 Rezayi 随后讨论了这种长波激发的确定手性与圆偏振谱响应，把它解释成量子化内部度规的“手性引力子”。[Liou et al., Phys. Rev. Lett. 123, 146801 (2019)](https://arxiv.org/abs/1904.12231)

2024 年的圆偏振非弹性光散射实验报告了 FQH 长波自旋 2 模的手性选择：

- \(\nu=1/3\) 与 \(2/5\) 显示一种手性；
- 粒子–空穴共轭的 \(2/3\) 与 \(3/5\) 手性翻转。

这把“度规量子”从纯理论概念推进到了可区分圆偏振通道的实验对象。[Nature 628, 78–83 (2024)](https://www.nature.com/articles/s41586-024-07201-w)

实验还说明有限量子阱厚度会显著降低理想零厚度 Coulomb 能标下的色散。因此若目标是与实验数值直接对照，仅有理想 LLL Coulomb 模型还不够。

---

## 3.9 Haldane 2023：量子霍尔液体作为电四极矩液体

Haldane 最近进一步主张，应把一般量子霍尔液体理解成携带本征电四极矩密度的液体；Hall viscosity 和边缘结构可以在没有连续旋转对称性时继续定义。[Haldane, arXiv:2302.12472](https://arxiv.org/abs/2302.12472)

这个视角很适合连接实际材料：

- 真实晶体并不具有连续旋转对称性；
- 质量张量和介电张量可能不同；
- “自旋 2”在低对称性下不再是严格角动量标签；
- 但四极响应、剪切几何和手性谱权重仍有意义。

这提供了一条从理想球面 SU(2) 模型走向各向异性材料和晶格 Chern band 的路线。

---

# 4. “拓扑”与“几何”各自解释什么？

| 问题 | 拓扑描述擅长回答 | 几何描述进一步回答 |
|---|---|---|
| Hall conductance | 为什么量子化为分数 | 空间形变时还会产生什么响应 |
| 准粒子 | 分数电荷、统计 | 准粒子周围的局域形状与偶极/四极矩 |
| 球面 flux | filling 与拓扑 shift | shift 如何表现为曲率耦合 |
| 边缘 | 边缘模数目和手性 | 边缘偶极矩和导引中心 Hall viscosity |
| 基态 | 属于哪个拓扑相 | 相关空穴选择什么内禀度规 |
| 中性激发 | 拓扑理论通常不固定其能量 | 自旋 2 剪切模、色散和谱权重 |
| 各向异性 | 相可能仍不变 | 内禀度规怎样适应外部度规 |

一句话概括：

> 拓扑描述“不能连续改变的全局骨架”，几何描述“同一个拓扑相内部可以形变并具有动力学的局域组织”。

这也是为什么研究引力子值得做：它不是重复验证 Hall conductance，而是在探测拓扑序内部最基本的集体形状自由度。

---

# 5. 当前挑战已经做到了什么，还缺什么？

## 5.1 已经做对的关键点

1. **正确的物理 Hilbert 空间**  
   使用球面 LLL、固定粒子数和磁通量。

2. **正确的目标相**  
   \(\nu=1/3\)、shift \(=3\)，以 Laughlin 零模为种子。

3. **正确的几何算符积木**  
   使用投影密度 \(\bar\rho_{\ell M}\) 及其 Clebsch–Gordan 耦合。

4. **严格的旋转对称性**  
   基态 ansatz 严格为 \(L=0\)，激发 ansatz 严格为 \(L=2\)。

5. **ED 可校验性**  
   小体系中可以逐项比较 \(E_0,E_2,\Delta\) 与波函数。

## 5.2 目前还不能单靠代码结论回答的问题

1. 最低 \(L=2\) 态是否承载大部分几何谱权重？
2. 它的圆偏振手性是什么？
3. 是否存在弱的相反手性分支？
4. Coulomb 态是否饱和 Haldane 的 \(S_4\) 下界？
5. NQS 是否正确复现 \(S_4,S_6\)，而不仅是能量？
6. 该态是否随 \(N\) 增大进入双 roton 连续谱？
7. 有限厚度和 LL mixing 怎样改变 gap 与手性？

最关键的逻辑漏洞是：

> \(L=2\) 只说明角动量，不自动说明“这是手性引力子”。

还需要一个能区分度规剪切方向的探测算符，以及完整或至少低能的 \(L=2\) 谱函数。

---

# 6. 最值得继续挖的物理

## 方向 A：结构因子 \(S_4,S_6\) 与 Haldane bound

这是和现有代码距离最近、物理回报最高的任务。

### 要计算什么？

在球面上计算

\[
S_L
\propto
\frac1N\sum_{M=-L}^{L}
\langle\Psi_0|
\delta\bar\rho_{LM}^\dagger
\delta\bar\rho_{LM}
|\Psi_0\rangle.
\]

用

\[
(q\ell_B)^2\simeq\frac{L(L+1)}Q
\]

将小 \(L\)、多尺寸数据映射成长波展开，拟合 \(S_4,S_6\)。

### 为什么非常适合本项目？

- \(\bar\rho_{\ell M}\) 已经实现；
- ED 与 NQS 都可计算同一观测量；
- 可直接检验 NQS 是否学到了导引中心几何；
- 可以比较 \(V_1\) 精确 Laughlin 与 Coulomb；
- 能接到 Kumar–Haldane 关于非饱和和反手性权重的预言。

### 关键技术提醒

球面有限尺寸有曲率修正，不能只拿一个 \(N\) 的 \(L=2\) 点直接除以 \(q^4\)。应：

- 对多个 \(N\) 同时拟合；
- 明确采用每粒子还是每磁通归一化；
- 先用已知 Laughlin 模型值校准 convention；
- 同时拟合 \(q^4,q^6\) 和 \(1/N\) 修正。

---

## 方向 B：真正计算左右手性谱权重

构造两个相反手性的度规/应力张量算符

\[
\hat O_{+},\qquad \hat O_{-},
\]

并计算动态谱函数

\[
I_\pm(\omega)
=
\sum_n
|\langle n|\hat O_\pm|0\rangle|^2
\delta(\omega-E_n+E_0).
\]

关注：

- 主峰位置：引力子 gap；
- 总谱权重；
- 主峰占总权重的比例；
- 反手性与主手性的比值 \(I_-/I_+\)；
- Coulomb 与 \(V_1\) 模型的区别。

现有 rank-2 density ansatz 对角动量适配，但并未显式区分两种圆偏振手性。下一步应把 rank-2 特征改造成与两种剪切生成元对应的 chiral basis。

如果只训练一个最低 \(L=2\) 态，会漏掉连续谱。因此更合适的方法是：

- ED/Lanczos continued fraction；
- Krylov 子空间谱函数；
- 或多态 NQS，同时求若干个正交 \(L=2\) 态。

---

## 方向 C：从 \(V_1\) 模型连续走向 Coulomb

考虑

\[
H(\alpha)
=(1-\alpha)H_{V_1}+\alpha H_C,
\qquad 0\le\alpha\le1.
\]

沿路径监测：

\[
\Delta_2,\quad S_4,\quad S_6,\quad
I_-/I_+,\quad
|\langle\Psi(\alpha)|\Psi_{\rm Lgh}\rangle|^2.
\]

这可以讲一个很完整的故事：

1. 拓扑相始终是 Laughlin 相，没有发生相变；
2. 波函数 overlap 始终很高；
3. 但几何 bound 从严格饱和变成小幅不饱和；
4. 理想的单手性 graviton 因此出现弱的反手性权重；
5. 说明几何观测量比基态能量和 overlap 更敏感。

这很可能比单独把 gap 精度提高一个小数点更有物理吸引力。

---

## 方向 D：各向异性、内禀度规和 nematic 软化

引入外部度规或各向异性相互作用，例如

\[
V(\mathbf q)
\longrightarrow
V\!\left(\sqrt{g_{\rm ext}^{ab}q_aq_b}\right),
\qquad \det g_{\rm ext}=1.
\]

然后让 NQS 的内禀度规 \(g_{\rm int}\) 成为可优化参数，研究：

- \(g_{\rm int}\) 如何在质量度规与相互作用度规之间折中；
- 自旋 2 模是否分裂；
- graviton gap 是否软化；
- 是否接近 FQH nematic 相变。

这是 Haldane 2011 几何思想最直接的动力学检验。不过球面完整 SU(2) 对称性会被破坏，当前以严格 \(L\) 分类的代码需改成固定 \(M\) 或离散对称性，并使用广义赝势。

---

## 方向 E：粒子–空穴共轭与手性翻转

实验已经看到 \(\nu=1/3,2/5\) 与 \(2/3,3/5\) 的手性相反。可以先从同一 Landau level 内的粒子–空穴变换入手：

- 验证 \(1/3\leftrightarrow2/3\) 的谱权重互换；
- 再扩展到 Jain \(2/5\) 与 \(3/5\)；
- 检查 LL mixing 引起的粒子–空穴对称性破缺。

这条线能把理论、NQS、ED 和 2024 实验直接连接起来。

---

## 方向 F：几何 quench 与实时 graviton

突然改变质量或相互作用度规：

\[
g_{\rm ext}(t<0)=\mathbb 1,
\qquad
g_{\rm ext}(t\ge0)=g'.
\]

随后计算四极矩或内禀度规的振荡。这相当于“敲一下”量子霍尔液滴并观察它的剪切振铃。振荡频率给出 graviton gap，左右旋转方向给出手性。

该方向需要 time-dependent VMC/NQS，但直观性很强，也适合用动画展示。

---

# 7. Landau-level mixing：LLL 投影到底有多可靠？

## 7.1 比较的两个能标

对抛物线色散二维电子气，

\[
\hbar\omega_c=\frac{\hbar eB}{m^*}
\]

是相邻 Landau levels 的间隔；Coulomb 能为

\[
E_C=\frac{e^2}{4\pi\epsilon_0\epsilon_r\ell_B}.
\]

二者之比

\[
\kappa=\frac{E_C}{\hbar\omega_c}
\]

控制 Landau-level mixing。

- \(\kappa\ll1\)：LLL 投影有良好的微扰控制；
- \(\kappa\sim1\)：投影仍是有用的零阶描述，但定量修正不可忽略；
- \(\kappa\gg1\)：微扰下折叠可能失效，需要显式多 Landau level。

## 7.2 GaAs 中的实际大小

取 GaAs

\[
m^*\simeq0.067m_e,\qquad \epsilon_r\simeq12.9,
\]

有

\[
\hbar\omega_c[{\rm meV}]
\simeq1.73B[{\rm T}],
\]

\[
\kappa\simeq\frac{2.52}{\sqrt{B[{\rm T}]}}.
\]

| \(B\) | \(E_C\) | \(\hbar\omega_c\) | \(\kappa\) |
|---:|---:|---:|---:|
| \(5\,{\rm T}\) | \(9.73\,{\rm meV}\) | \(8.65\,{\rm meV}\) | \(1.13\) |
| \(10\,{\rm T}\) | \(13.76\,{\rm meV}\) | \(17.3\,{\rm meV}\) | \(0.80\) |
| \(15\,{\rm T}\) | \(16.85\,{\rm meV}\) | \(25.95\,{\rm meV}\) | \(0.65\) |

所以“Landau-level spacing 远大于 Coulomb 相互作用”对典型 GaAs 磁场并不严格成立。更准确的说法是：

> cyclotron gap 足以使 LLL 投影成为正确的起点，但通常不足以保证 LL mixing 是百分之一量级的小修正。

## 7.3 mixing 在物理上做了什么？

库仑相互作用可以把两个电子虚激发到更高 Landau levels，再回到 LLL。把高能态积分掉，会得到

\[
H_{\rm eff}
=
PHP
-
PHQ\frac{1}{QH_0Q-E_0}QHP
+\cdots,
\]

其中 \(P\) 投影到 LLL，\(Q=1-P\)。

按 \(\kappa\) 展开：

\[
H_{\rm eff}
=
H_C^{\rm LLL}
+\kappa\sum_m\delta V_m^{(2)}P_m^{(2)}
+\kappa\sum_M V_M^{(3)}P_M^{(3)}
+O(\kappa^2).
\]

关键点是：mixing 不只是把 Coulomb 强度整体缩小。

它会：

1. 改变不同相对角动量通道的二体赝势；
2. 生成原本没有的三体相互作用；
3. 在单个 Landau level 的有效理论中破坏粒子–空穴对称性；
4. 改变 neutral gap、roton minimum、结构因子和几何谱权重；
5. 改变基态与理想 Laughlin 态的短程相关，即使拓扑相不变。

Bishara–Nayak 以及 Sodemann–MacDonald 系统推导了 LL mixing 产生的二体和三体有效赝势。[Bishara and Nayak, PRB 80, 121302 (2009)](https://arxiv.org/abs/0906.2516)；[Sodemann and MacDonald, PRB 87, 245425 (2013)](https://arxiv.org/abs/1302.3896)

早期对 \(\nu=1/3\) 的计算已经发现 LL mixing 会降低 excitation gap。[Melik-Alaverdian and Bonesteel, PRB 52, R17032 (1995)](https://arxiv.org/abs/cond-mat/9508060)

## 7.4 mixing 是否会摧毁 Laughlin 相？

不一定。必须区分：

- **拓扑稳定性**：gap 没有关闭，准粒子统计和 Hall conductance 不变；
- **波函数和几何的定量变化**：gap、赝势、结构因子、Hall viscosity 的非普适部分和谱权重改变。

在典型 GaAs 参数下，\(\nu=1/3\) Laughlin 相通常仍相当稳健，但 neutral gap 和几何响应可以有明显修正。对我们的课题，这反而很有意思，因为 graviton 正是一个可能比拓扑量子数更敏感的几何探针。

## 7.5 mixing、有限厚度和无序不是一回事

实验与理想模型的差别至少有三类：

1. **LL mixing**  
   来自 \(E_C/\hbar\omega_c\) 非零，产生有效二体和三体项。

2. **有限量子阱厚度**  
   通过 transverse wavefunction 改变 form factor，使短程相互作用变软。

3. **无序**  
   展宽谱峰、局域化准粒子并降低 transport activation gap。

还可能有：

- 介电环境与屏蔽；
- 自旋或亚带 mixing；
- 倾斜磁场和质量各向异性。

因此不应把所有实验 gap 的降低都归因于 \(\kappa\)。

## 7.6 Graphene 的情况

Graphene 的 Landau level 间隔不是 \(\hbar eB/m^*\)，而是由 Dirac 速度 \(v_F\) 决定。对应 mixing 参数大致为

\[
\kappa_{\rm gr}\sim\frac{e^2}{\epsilon\hbar v_F},
\]

主要由介电环境决定，对磁场近似不敏感，数值也可能是 \(O(1)\)。零 Landau level 具有特殊的粒子–空穴和亚晶格结构，某些一阶修正会有额外抵消，但不能笼统地认为 graphene 中 mixing 总是可忽略。[Peterson and Nayak, PRB 87, 245129 (2013)](https://journals.aps.org/prb/abstract/10.1103/PhysRevB.87.245129)

---

# 8. 怎样把 LL mixing 接到现有 NQS？

## 8.1 路线一：LLL 内的有效 Hamiltonian

这是最推荐的第一阶段。

### 需要做的代码工作

1. 加入 \(\delta V_m^{(2)}(\kappa,w/\ell_B)\)；
2. 实现三体赝势或直接实现三体矩阵元；
3. 构造
   \[
   H_{\rm eff}(\kappa)
   =H_C+\kappa\delta H^{(2)}+\kappa H^{(3)};
   \]
4. 复用现有 LLL 占据数基底；
5. 复用 Laughlin 种子和密度张量 NQS；
6. 用 ED 在 \(N\le8\) 严格 benchmark；
7. 扫描真实区间 \(\kappa=0\) 到约 \(1.5\)。

### 优点

- Hilbert 空间不扩大；
- 现有 ansatz 基本不改；
- 仍保持球面旋转对称性；
- 可以直接研究 gap、\(S_4\)、手性和粒子–空穴破缺；
- 与经典微扰文献容易比较。

### 局限

- 只在 \(\kappa\) 足够小时受控；
- 二阶及更高修正可能重要；
- 有效赝势依赖是否包含有限厚度、screening 和 Landau level 截断。

## 8.2 路线二：显式保留多个 Landau levels

直接研究

\[
H=
\sum_{n,m}n\hbar\omega_c\,
c^\dagger_{nm}c_{nm}
+H_C,
\]

其中球面第 \(n\) 个 Landau level 的单粒子角动量为

\[
l_n=Q+n.
\]

NQS 配置从单一占据数组扩展为

\[
n_{n,m},
\]

并固定总粒子数和总 \(M\)，但允许不同 \(n\) 之间的占据变化。

### 需要重做的部分

- 单粒子轨道标签增加 Landau-level index；
- 二体 Coulomb 矩阵元包含 \(n_1n_2n_3n_4\)；
- 密度张量增加 inter-LL form factor；
- Laughlin 种子只能作为初态，不再是同一 Hilbert 空间中的完整 ansatz；
- 采样需要同时移动轨道和 Landau-level 指标；
- Hilbert 空间增长非常快。

### 何时值得做？

- 有效 Hamiltonian 与实验/高精度小体系明显不符；
- 需要研究 \(\kappa\gtrsim1\) 的非微扰区域；
- 想直接测量高 Landau level 占据；
- 想判断是否存在由特定 inter-LL pair-tunneling 通道主导的新机制。

这里尤其需要避免把未经验证的新结果当作项目依据：一篇 2026 年 5 月、曾声称显式双 Landau level 计算出现反常 pair-tunneling rigidification 的预印本，已经因数据过时和原始结论存在缺陷而由作者撤回。[arXiv:2605.26957 的撤回说明](https://arxiv.org/abs/2605.26957) 因而本报告不采用其物理结论；它反而说明独立实现小体系双 LL benchmark 和完整记录数值检验十分必要。

---

# 9. 一个可形成论文故事的建议方案

## 核心科学问题

> 从理想 \(V_1\) Laughlin 模型走向真实 Coulomb、有限厚度和 LL mixing 时，\(\nu=1/3\) 拓扑相可能保持不变，但它的导引中心量子几何和手性 graviton 怎样变化？

## 建议观测量

\[
\boxed{
E_0,\;
\Delta_2,\;
\mathrm{Var}(H),\;
S_4,\;
S_6,\;
I_+(\omega),\;
I_-(\omega)
}
\]

若资源允许，再加入：

\[
\text{overlap},\quad
\text{entanglement spectrum},\quad
\eta_H,\quad
\text{metric fidelity susceptibility}.
\]

## 参数空间

\[
H(\alpha,\kappa,w)
=
(1-\alpha)H_{V_1}
+\alpha H_C(w)
+\kappa\,\delta H_{\rm LLM}.
\]

- \(\alpha\)：从精确 Laughlin 模型到 Coulomb；
- \(w/\ell_B\)：有限厚度；
- \(\kappa\)：Landau-level mixing。

## 可能出现的主结论

1. 在没有拓扑相变、overlap 仍很高的区域，\(S_4\) 已明显偏离 Haldane bound；
2. 反手性谱权重随 \(\alpha,\kappa,w\) 出现和增强；
3. graviton gap 与谱权重对现实修正的敏感性不同；
4. NQS 能在 ED 不可达尺寸上区分“能量学准确”和“量子几何准确”；
5. LL mixing 的三体项可能产生可测的粒子–空穴不对称和手性变化。

这比“把 NQS 用于另一个 Hamiltonian”更完整，因为它围绕一个明确物理矛盾：

> 拓扑很稳健，但几何并不僵硬；究竟哪些几何量先偏离理想 Laughlin 极限？

---

# 10. 推荐的实际工作顺序

## 第一阶段：不改 Hamiltonian，先补齐几何诊断

1. 在 ED 和 NQS 中实现球面 \(S_L\)；
2. 用 \(V_1\) Laughlin 态校准归一化；
3. 多尺寸拟合 \(S_4,S_6\)；
4. 复现 Coulomb \(S_4\) 对 Haldane bound 的小幅超出；
5. 检查 NQS 的能量精度是否同时意味着结构因子精度。

这是风险最低、最应该立即做的部分。

## 第二阶段：加入 chiral probe

1. 明确构造 \(\hat O_\pm\)；
2. ED/Lanczos 计算 \(I_\pm(\omega)\)；
3. 识别最低 \(L=2\) 态占据多少谱权重；
4. 将 NQS 扩展为多态或 Krylov ansatz；
5. 比较 \(V_1\) 与 Coulomb 的反手性权重。

## 第三阶段：现实相互作用

1. 加入有限厚度 form factor；
2. 加入一阶 LL-mixing 二体与三体赝势；
3. 扫描 GaAs 实际 \(\kappa=0.5\)–\(1.2\)；
4. 比较 gap、\(S_4\) 和 chirality 的响应；
5. 单独区分有限厚度与 mixing。

## 第四阶段：显式双 Landau level

先限制在 \(N=4\)–\(6\)，用于验证微扰有效 Hamiltonian，而不是一开始追求大体系：

1. 检验一阶有效赝势的适用范围；
2. 分解不同 inter-LL scattering channel；
3. 判断 pair tunneling 是否主导；
4. 再决定是否值得开发大规模 multi-LL NQS。

---

# 11. 汇报时可以采用的“完整 story”

### 第一幕：传统问题

FQHE 的拓扑理论极其成功，但它不决定中性激发的能量、相关空穴的形状和对剪切的动态响应。

### 第二幕：Haldane 的转折

Haldane 从球面和赝势开始，发现 LLL 投影后的导引中心不是普通坐标，而是非对易几何。FQH 液体因此具有一个内禀度规和 Hall viscosity。

### 第三幕：引力子

内禀度规的最小面积保持形变是四极剪切，对应长波 \(L=2\) 自旋 2 模。它是量子霍尔液体的“引力子”，具有确定手性，并可由圆偏振谱区分。

### 第四幕：我们的计算

我们用 LLL 投影密度及其 CG 耦合直接构造标量和秩 2 NQS：

- \(L=0\) 基态由标量几何涨落修饰；
- \(L=2\) 激发由四极密度张量生成；
- 对称性由 ansatz 严格保证；
- ED 提供小体系基准；
- gap 是两个对称性扇区最低能量之差。

### 第五幕：真正的挑战

只算准 \(L=2\) gap 还不能证明捕捉了 graviton。必须进一步回答：

- NQS 是否复现 \(q^4\) 结构因子和 Haldane bound？
- 谱权重是否集中在一个手性自旋 2 模？
- Coulomb 相互作用为什么产生弱的反手性？
- finite width 和 LL mixing 如何改变这种几何？

### 最后一幕：可发表的问题

即使 Laughlin 拓扑相和高 overlap 保持稳定，真实相互作用也会使其量子几何偏离理想、最大手性的模型极限。NQS 的价值是把这种几何诊断推进到 ED 无法达到的尺寸和更现实的 Hamiltonian。

---

# 12. 给老师问题的最短回答

### 问题 1：基态和激发态 gap 用了什么约束？

NQS 使用的是**严格角动量 ansatz**：标量特征保证 \(L=0\)，秩 2 张量特征保证 \(L=2\)，二者因对称性自动正交。不是拉格朗日乘子，也不直接最小化 gap。稀疏 ED 中的 \(\lambda[L^2-L_t(L_t+1)]^2\) 只是寻找目标扇区的数值惩罚，最终能量仍按原始 Coulomb Hamiltonian 计算。

### 问题 2：gap 的单位是什么？

\[
e^2/(4\pi\epsilon_0\epsilon_r\ell_B).
\]

代码输出是无量纲系数。NQS 与 ED 完全相同。若 gap 为 0.13，在 GaAs、10 T 下理想换算约为 \(1.79\) meV，但不能直接当实验 activation gap。

### 问题 3：Haldane 几何最有趣的地方是什么？

LLL 投影后，导引中心坐标不对易；FQH 液体的相关空穴具有可变的内禀度规。Hall viscosity、shift、\(q^4\) 结构因子和手性自旋 2 模是同一个导引中心几何的不同表现。我们当前的 density-tensor NQS 正好使用了这套几何的生成元，但还缺 \(S_4\) 和手性谱权重。

### 问题 4：LLL 与 Coulomb 的能标是否真的相差很大？

典型 GaAs 中并不大到可以完全忽略 mixing。\(B=10\) T 时 \(\kappa\approx0.8\)。所以 LLL 投影是正确的零阶起点，但不是最终定量理论。第一步应在 LLL 中加入 mixing 诱导的二体赝势修正和三体项；之后再用显式双 LL 小体系检验其适用范围。

---

# 参考文献与进一步阅读

1. F. D. M. Haldane, “Fractional Quantization of the Hall Effect: A Hierarchy of Incompressible Quantum Fluid States,” [Phys. Rev. Lett. 51, 605 (1983)](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.51.605).
2. F. D. M. Haldane, “Hall viscosity and intrinsic metric of incompressible fractional Hall fluids,” [arXiv:0906.1854](https://arxiv.org/abs/0906.1854).
3. F. D. M. Haldane, “Geometrical Description of the Fractional Quantum Hall Effect,” [arXiv:1106.3375](https://arxiv.org/abs/1106.3375).
4. F. D. M. Haldane, “Self-duality and long-wavelength behavior of the guiding-center structure function,” [arXiv:1112.0990](https://arxiv.org/abs/1112.0990).
5. Y. Park and F. D. M. Haldane, “Guiding-center Hall viscosity and intrinsic dipole moment along edges of incompressible fractional quantum Hall fluids,” [arXiv:1403.2822](https://arxiv.org/abs/1403.2822).
6. A. Gromov and D. T. Son, “Bimetric Theory of Fractional Quantum Hall States,” [arXiv:1705.06739](https://arxiv.org/abs/1705.06739).
7. S.-F. Liou, F. D. M. Haldane, K. Yang, and E. H. Rezayi, “Chiral Gravitons in Fractional Quantum Hall Liquids,” [arXiv:1904.12231](https://arxiv.org/abs/1904.12231).
8. P. Kumar and F. D. M. Haldane, “A numerical study of bounds in the correlations of fractional quantum Hall states,” [arXiv:2304.14991](https://arxiv.org/abs/2304.14991).
9. F. D. M. Haldane, “Incompressible Quantum Hall fluids as Electric Quadrupole fluids,” [arXiv:2302.12472](https://arxiv.org/abs/2302.12472).
10. “Evidence for chiral graviton modes in fractional quantum Hall liquids,” [Nature 628, 78–83 (2024)](https://www.nature.com/articles/s41586-024-07201-w).
11. W. Bishara and C. Nayak, “Effect of Landau level mixing on the effective interaction between electrons in the fractional quantum Hall regime,” [arXiv:0906.2516](https://arxiv.org/abs/0906.2516).
12. I. Sodemann and A. H. MacDonald, “Landau level mixing and the fractional quantum Hall effect,” [arXiv:1302.3896](https://arxiv.org/abs/1302.3896).
13. H. Liu, “Inter-Landau-Level Pair Tunneling Rigidifies the Long-Wavelength Structure Factor of the ν=1/3 Laughlin State,” [arXiv:2605.26957](https://arxiv.org/abs/2605.26957), withdrawn in May 2026; not used as evidence in this report.

