# 严格一次量子化 NQS：N=20 本地 GPU 训练报告

日期：2026-07-30  
设备：NVIDIA GeForce RTX 4090 Laptop GPU，16376 MiB  
能量单位：\(e^2/(\epsilon\ell_B)\)

## 1. 结论摘要

本轮已经在本地 GPU 上完成了 \(N=20,\ 2Q=57\) 的严格一次量子化
LLL/SU(2) NQS 训练，不需要退回到更小尺寸。

推荐 ansatz 为 \(\ell_{\max}=5\) 的浅层 SU(2) 张量特征 NQS。三组独立
随机种子的 gap 加权平均为

\[
\boxed{\Delta_{L=2}(N=20)=0.144724(259)_{\rm stat}}
\]

三组结果的一致性为

\[
\chi^2/{\rm dof}=1.046/2,
\]

没有种子间异常漂移。比较 \(\ell_{\max}=4,5,6\) 后，保守估计当前
ansatz 截断系统误差约为 \(0.005\)。因此更保守的写法是

\[
\Delta_{L=2}(N=20)=0.1447\pm0.0026_{\rm stat}\pm0.005_{\rm ansatz}.
\]

高统计单次运行给出

\[
E_0=29.0415026(19),\qquad
E_2=29.1878485(27),\qquad
\Delta=0.1463459(33).
\]

所有基态严格满足 \(L^2=0\)，所有激发态严格满足 \(L^2=6\)。这不是
训练后测得的近似值，而是由 Clebsch--Gordan 不可约张量构造解析保证。

## 2. “严格一次量子化 NQS”的具体含义

计算变量是球面上的连续电子 spinor

\[
\Omega_i=(u_i,v_i),\qquad |u_i|^2+|v_i|^2=1.
\]

没有构造多体 Fock 基底、CI 向量或二次量子化 Hamiltonian 矩阵。
Laughlin 反对称核为

\[
\Phi_{\rm L}(\Omega)
=\prod_{i<j}(u_i v_j-v_i u_j)^3,
\qquad 2Q=3(N-1).
\]

训练的基态为

\[
\Psi_0(\Omega)=\Phi_{\rm L}(\Omega)
\left[
a_0+\sum_{\ell=2}^{\ell_{\max}}
a_\ell[\rho_\ell\times\rho_\ell]_{00}(\Omega)
\right],
\]

训练的 \(L=2,M=2\) 激发态为

\[
\Psi_{22}(\Omega)=\Phi_{\rm L}(\Omega)
\left[
c_0\rho_{22}(\Omega)
+\sum_{\ell_1,\ell_2=2}^{\ell_{\max}}
c_{\ell_1\ell_2}
[\rho_{\ell_1}\times\rho_{\ell_2}]_{22}(\Omega)
\right].
\]

\(\ell_{\max}=5\) 时，基态有 5 个原始复通道，激发态有 15 个原始复
通道。去除精确线性依赖后，保留秩分别为 5 和 10。所有保留系数都由
VMC 数据优化。

这个实现是“固定精确 SU(2) 等变特征提取器 + 可训练复线性头”的浅层
tensor-feature NQS。它是严格变分训练的 NQS，但不是深层
FermiNet/attention 网络；不能把当前结果描述成大参数深度神经网络结果。

激发态使用 SMA 分布做 importance sampling，只是为了降低采样方差：
SMA 不是最终波函数。最终 10 个独立通道系数由采样得到的广义本征问题

\[
Hc=ESc
\]

共同优化。训练集和验证集使用不同随机种子、不同 Markov 链，报告的能量
全部来自独立验证集。

## 3. 为 N=20 所做的代码优化

旧实现在每个电子对上显式保存一个
\((2Q+1)\times(2Q+1)\) 双变量多项式块，并把电子循环展开进 XLA
计算图。这同时造成 \(O(N^2D^2)\) 中间存储和很大的编译图，其中
\(D=2Q+1\)。

新实现利用三次 Jastrow 因子的精确低秩分解。对电子对 \(i,j\)，双变量
系数块写成四个 shifted outer products：

\[
C_{ij}
=\sum_{s=0}^{3}(-1)^s {3\choose s}
S_s(p_{i\setminus j})\otimes
S_{3-s}(p_{j\setminus i}).
\]

因此

\[
b_i A C_{ij} B^T b_j
\]

可以直接变成四项一维收缩乘积，不再生成 \(D\times D\) pair block。
排除多项式使用 `jax.lax.fori_loop` 构造，避免 Python 循环随 \(N\)
展开。

结果是：

- pair 中间存储从 \(O(N^2D^2)\) 降为 \(O(N^2D)\)；
- N=20 首次编译约 6--13 秒，正式 6144/6144 训练/验证样本运行约
  41--58 秒；
- 高统计 16384/16384 训练/验证样本总运行 146.65 秒；
- 16GB GPU 上没有显存溢出。

算术复杂度仍受多通道密集单粒子张量收缩控制，尚不能据此声称深度
NQS 已经可以无代价扩展到 \(N\gg20\)。

## 4. 正确性检查

### 4.1 新旧坐标核逐点等价

在相同随机连续坐标上，将流式核与旧版显式 pair-polynomial 核逐通道
比较：

| N | rank-2 通道最大相对残差 | scalar 通道最大相对残差 |
|---:|---:|---:|
| 4 | \(6.98\times10^{-14}\) | \(1.07\times10^{-15}\) |
| 5 | \(3.58\times10^{-15}\) | \(2.49\times10^{-15}\) |

阈值设为 \(2\times10^{-10}\)，全部通过。

此前还完成了 N=4 坐标通道与独立 Fock 算符实现的交叉检查，最大相对
残差为 \(5.83\times10^{-13}\)。因此此次优化只改变计算路径，没有
改变 ansatz。

### 4.2 对称性

- \(\Phi_{\rm L}\) 保证费米反对称性；
- scalar CG 头严格给出 \(L=0\)，故 \(L^2=0\)；
- rank-2, \(M=2\) CG 头严格给出 \(L=2\)，故 \(L^2=L(L+1)=6\)；
- 不需要用带噪 Monte Carlo estimator 再判断 \(L^2\) 是否接近整数。

### 4.3 白化阈值稳定性

扫描了 \(10^{-8}\) 到 \(10^{-4}\) 的 overlap 白化阈值。N=20、
\(\ell_{\max}=5\) 的保留秩稳定为 ground 5、excited 10，验证能量不随
阈值改变。excited overlap 中另外 5 个方向是解析通道关系导致的数值零
模，而不是训练采样不足。

## 5. N=20 正式结果

每个普通正式运行使用 128 条链，训练集和验证集各
\(128\times48=6144\) 个构型；高统计运行使用 256 条链，每个集合各
\(256\times64=16384\) 个构型。

| \(\ell_{\max}\) | seed | \(E_0\) | \(E_2\) | gap | ground ESS | excited ESS |
|---:|---:|---:|---:|---:|---:|---:|
| 4 | 20260730 | 29.047917(273) | 29.191704(444) | 0.143787(521) | 0.969 | 0.905 |
| 4 | 20260831 | 29.046991(342) | 29.196176(426) | 0.149185(547) | 0.969 | 0.919 |
| 5 | 20260730 | 29.046285(278) | 29.185781(512) | 0.139496(582) | 0.948 | 0.648 |
| 5 | 20260831 | 29.043784(329) | 29.188765(487) | 0.144981(588) | 0.940 | 0.772 |
| 5 high-stat | 20261002 | 29.041503(195) | 29.187848(269) | 0.146346(332) | 0.960 | 0.754 |
| 6 | 20260730 | 29.045101(294) | 29.184966(532) | 0.139865(608) | 0.920 | 0.454 |

括号内为最后若干位的统计误差；ESS 列为独立验证集的 ESS fraction。

\(\ell_{\max}=6\) 相对 \(\ell_{\max}=5\) 明显降低训练激发能，但独立
验证激发能只改善约 \(8.1\times10^{-4}\)，同时 ESS 从 0.648 降到
0.454。这是收益饱和并开始加重重加权噪声的信号。因此
\(\ell_{\max}=5\) 是当前样本预算下更稳健的工作点。

三组 \(\ell_{\max}=5\) gap 的逆方差加权结果：

\[
\Delta=0.1447243\pm0.0025912,\qquad
\chi^2/{\rm dof}=1.046/2.
\]

## 6. 与固定 SMA 的区别

此前 N=20 固定 SMA 的高统计结果为

\[
E_0^{\rm Laughlin}=29.04892099,\qquad
E_2^{\rm SMA}=29.19442359,\qquad
\Delta_{\rm SMA}=0.14550260(26).
\]

本轮高统计训练结果相对它的变化是

\[
\delta E_0=-0.0074184,\qquad
\delta E_2=-0.0065751.
\]

基态和激发态都被独立训练显著降能。这直接说明当前输出不是“对
Laughlin 只作用一次固定算符后采样”的 SMA 结果。gap 仍与 SMA 接近，
是因为两个 sector 的变分修正发生了较强抵消：

\[
\Delta_{\rm trained}-\Delta_{\rm SMA}=0.0008433
\]

（单次高统计值），在当前误差内不显著。

## 7. 尺寸趋势与 benchmark

同一 \(\ell_{\max}=5\) 协议的补充结果：

| N | 训练 NQS gap | 固定 SMA gap |
|---:|---:|---:|
| 12 | 0.130401(667) | 0.143877(223) |
| 16 | 0.141196(576) | 0.145417(246) |
| 20 | 0.144724(259)，三 seed 合并 | 0.145503(264) |

N=12 的 excited importance ESS 约 0.20，N=16 约 0.30，因此这两个
单 seed 点的误差较大；N=20 的 ESS 反而改善到 0.65--0.75。尺寸趋势
与 gap 向约 0.145 附近靠近相容，但仅凭三个点不进行热力学外推。

小尺寸与严格二次量子化 tensor NQS 的既有 benchmark：

| N | 一次量子化训练 NQS | 严格二次量子化 tensor NQS |
|---:|---:|---:|
| 8 | 0.128448(367) | 0.128787201 |
| 9 | 0.139480(548) | 0.130509085 |
| 10 | 0.130366(431) | 0.129253599 |

N=8、10 在误差内一致；N=9 相差约 \(1.64\sigma\)，仍需要更多通道或
统计量确认。严格二次量子化结果在 \(N\le10\) 的数值精度更高，但其
Hilbert 空间扩展使 N=20 不可行：未约化 Fock 维数为

\[
{58\choose20}=1\,847\,253\,511\,032\,930.
\]

此前 autoregressive 二次量子化 NQS 在 N=10、12 已出现非常大的
\(L^2\) 污染（N=10 约 615--619，N=12 约 863--1085），其 gap
0.0625、0.0415 不能作为目标角动量 sector 的可靠 benchmark。本轮一次
量子化结果没有该问题。

## 8. 统计判据与当前可信边界

本轮“训练效果比较好”的判据为：

1. 训练集和验证集完全独立；
2. 两个随机种子 gap 相容；
3. excited validation ESS 不低于约 0.5（推荐点实际 0.65--0.75）；
4. 训练/验证能差不呈系统性恶化；
5. 白化阈值扫描稳定；
6. 对称性解析严格；
7. 增大 \(\ell_{\max}\) 后独立验证收益饱和，而非只看训练能量。

N=20 满足这些判据，因此当前可信训练边界至少已经达到 N=20。此次没有
继续测试 N>20，所以不能把 N=20 说成硬上限，也不能据此声称深度一次
量子化 NQS 已经可训练到 N=40 或 N=100；此前那些尺寸是固定 SMA，
不是多通道训练 NQS。

## 9. 代码、数据与复现

主要代码：

- `strict_first_quantized_streaming.py`：严格流式 SU(2) 坐标特征核；
- `strict_first_quantized_nqs_streaming_driver.py`：独立训练/验证、
  tolerance scan 和结果输出；
- `test_strict_first_quantized_streaming.py`：新旧核等价性测试；
- `summarize_strict_first_quantized_runs.py`：多 seed 汇总。

关键结果：

- `runs/strict_fq_streaming_N20_l5_highstat_seed20261002/results.json`
- `runs/strict_fq_streaming_N20_l5_seed20260730/results.json`
- `runs/strict_fq_streaming_N20_l5_seed20260831/results.json`
- `runs/strict_fq_streaming_N20_l6_seed20260730/results.json`
- `runs/strict_fq_streaming_N12_N16_l5_seed20260730/results.json`
- `runs/strict_fq_streaming_benchmark_20260730.csv`

高统计复现命令：

```bash
XLA_PYTHON_CLIENT_PREALLOCATE=false \
/home/zyz/miniconda3/envs/nk_env/bin/python \
strict_first_quantized_nqs_streaming_driver.py \
  --sizes 20 \
  --lmax 5 \
  --chains 256 \
  --burn-sweeps 750 \
  --training-records 64 \
  --validation-records 64 \
  --thin-sweeps 8 \
  --feature-batch 24 \
  --tolerances 1e-4,1e-5,1e-6,1e-7,1e-8 \
  --seed 20261002 \
  --output-dir runs/strict_fq_streaming_N20_l5_highstat_seed20261002
```

## 10. 后续改进建议

下一步若要把“至少 N=20”推进到 N=24--30，优先级应为：

1. 将 dense monomial tensor matrix 进一步改成带状/稀疏算符核，降低
   当前剩余的 \(D^2\) 算术；
2. 对 excited importance distribution 使用当前训练态做第二阶段
   direct Metropolis，而不继续依赖 SMA 重加权；
3. 加入三密度 SU(2) coupled channels，或在严格标量 backbone 上加入
   非线性等变层；
4. 保持多 seed、独立验证和精确 \(L^2\) 约束，不用训练能量单独决定
   是否扩大 ansatz。

其中第 2 项最可能改善 \(\ell_{\max}\ge6\) 时的 ESS；第 1 项最直接
决定更大 N 的计算吞吐。
