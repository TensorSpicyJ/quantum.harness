# \(\nu=1/3\) 手性引力子能隙：Haldane、当前 NQS 与杜玲杰实验的对比

## 一页结论

这次对比中，最合适的 Haldane 原始数值图是：

> F. D. M. Haldane and E. H. Rezayi, “Finite-Size Studies of the
> Incompressible State of the Fractionally Quantized Hall Effect and its
> Excitations,” *Physical Review Letters* **54**, 237 (1985), Fig. 5.
> [DOI](https://doi.org/10.1103/PhysRevLett.54.237)

原因是该图与当前代码使用同一个物理问题：球面几何、\(\nu=1/3\)、
\(2Q=3(N-1)\)、最低 Landau level、零厚度纯 Coulomb 相互作用，并把中性
集体激发画成 \(k\ell_B=L/\sqrt{Q}\) 的函数。当前 NQS 计算的 \(L=2\)
态正是这条磁旋子分支的长波端。

Haldane 2011 年的
[几何描述论文](https://doi.org/10.1103/PhysRevLett.107.116801)
是“内禀度规”与引力子图像的概念来源，但它没有给出一张可以直接与当前
能量数据逐点叠加的 \(\nu=1/3\) Coulomb 色散图。把长波 \(L=2\) 模明确
称为手性引力子，则应同时参考
[Liou, Haldane, Yang and Rezayi, PRL 123, 146801 (2019)](https://doi.org/10.1103/PhysRevLett.123.146801)。

当前大尺寸 scalable NQS/SMA 的 \(1/N\) 拟合为

\[
\Delta_\infty=0.14783\pm0.00297\;E_C,\qquad
E_C=\frac{e^2}{\epsilon\ell_B}.
\]

它与 Haldane-Rezayi Fig. 5 的理想二维长波能标相容。不过，这个误差只含
Monte Carlo/拟合统计误差；仓库已有小尺寸对照显示单一 rank-2 head 会把
gap 平均抬高约 \(0.0088E_C\)。

杜玲杰团队在 \(\nu=1/3\)、\(q\ell_B\simeq0.02\) 测得

\[
\Delta_{\mathrm{exp}}=0.66\ {\rm meV}=0.048E_C
\]

并确定其手性为 \(S=-2\)。见
[Liang et al., Nature 628, 78-83 (2024)](https://doi.org/10.1038/s41586-024-07201-w)。
实验使用 58.5 nm GaAs quantum well；论文用 \(0.305\) 缩放理想零厚度
色散来描述有限厚度软化。对当前 NQS 使用同一因子：

\[
0.305\,\Delta_\infty
=0.04509\pm0.00091E_C
=0.620\pm0.012\ {\rm meV}.
\]

这比实验中心值低约 \(6.1\%\)，绝对差约 \(0.040\) meV。相反，如果直接把
零厚度 NQS 与实验比较，会高出约 \(3.08\) 倍。因此，有限厚度不是可忽略
的小修正，而是理论-实验 benchmark 的主导换算。

![Haldane-NQS-Du comparison](output/haldane_nqs_du_comparison.png)

## 1. 三类能量必须分开

| 量 | 物理定义 | 当前值 |
|---|---|---:|
| Haldane Fig. 5 长波分支 | 理想二维、LLL、纯 Coulomb 中性激发 | 图示约 \(0.13-0.15E_C\) |
| Haldane Fig. 5 roton minimum | 同一分支的有限波矢最低点 | \(0.075E_C\) at \(k\ell_B=1.4\) |
| Haldane 分离准粒子-准空穴极限 | 大波矢中性激发 | \(0.105\pm0.005E_C\) |
| explicit Fock-space NQS V2 | \(N=5-9\) 的训练后 \(L=2\) gap | \(0.126-0.132E_C\) |
| scalable NQS/SMA | \(N=40-300\) 的单 density-head ansatz | \(\Delta_\infty=0.1478(30)E_C\) |
| 杜玲杰实验 | 58.5 nm GaAs well，\(q\ell_B\simeq0.02\) | \(0.048E_C=0.66\) meV |
| NQS 乘实验论文的有限厚度因子 | \(0.305\times\Delta_\infty\) | \(0.0451(9)E_C=0.620(12)\) meV |

Haldane 1985 文中的 \(0.075E_C\) 是 roton minimum，不是本项目计算的
\(L=2\) 长波 gap；文中的 \(0.105E_C\) 是大波矢分离准粒子-准空穴能量，
也不是 \(L=2\) gap。若把其中任一个数直接当作“文献中的 graviton gap”，
会得到错误 benchmark。

## 2. 与 Haldane Fig. 5 的对应

球面半径为 \(R=\sqrt{Q}\ell_B\)，所以

\[
k\ell_B=\frac{L}{\sqrt{Q}}.
\]

当前计算固定 \(L=2\)，于是

\[
k\ell_B=\frac{2}{\sqrt{3(N-1)/2}}.
\]

这解释了图 A 中的有限尺寸流动：\(N=5-9\) 的点仍在
\(k\ell_B\approx0.58-0.82\)，而 \(N=40-300\) 已进入
\(k\ell_B\approx0.09-0.26\) 的真正长波区。热力学极限同时对应
\(N\to\infty\) 和 \(k\ell_B\to0\)。

图 A 的灰色曲线只用于重现 Haldane Fig. 5 的整体视觉结构；它没有被当作
原始数据。图中只有两个灰色数值锚点来自作者正文的明确报价：
\(0.075E_C\) at \(k\ell_B=1.4\)，以及大波矢
\(0.105\pm0.005E_C\)。1985 论文没有以表格给出所有点，也没有给出严格
\(k=0\) 外推及误差，所以报告不应为它制造伪精度。

## 3. 与杜玲杰实验的对应

实验论文报告：

- \(\nu=1/3\) 的长波峰位在 \(0.66\) meV；
- \(q\ell_B\simeq0.02\)，足够接近 \(q=0\)；
- 归一化能量为 \(0.048E_C\)；
- 圆偏振选择定则给出 \(S=-2\)；
- \(\theta=10^\circ\) 数据的峰宽约 \(29\,\mu{\rm eV}\)；
- 58.5 nm GaAs well 中，理想二维色散需乘 \(0.305\) 才能与实验色散比较。

这里的 \(29\,\mu{\rm eV}\) 是谱峰 FWHM，不是峰位的统计误差。对比图用一条
短横线表示这个谱宽，避免把它错误解释成误差棒。

用实验给出的 \(0.66\ {\rm meV}=0.048E_C\) 可得该实验条件下
\(E_C=13.75\) meV。因此：

| 比较 | 归一化 gap | meV | 相对实验 |
|---|---:|---:|---:|
| ideal 2D scalable NQS/SMA | \(0.14783(30)\) | \(2.033(41)\) | \(3.08\times\) |
| NQS \(\times0.305\) | \(0.04509(91)\) | \(0.620(12)\) | \(-6.1\%\) |
| experiment | \(0.048\) | \(0.66\) | reference |

这个 \(6.1\%\) 一致性是有条件的：\(0.305\) 是实验论文用于色散的经验缩放，
并非我们显式把 58.5 nm transverse wavefunction、Landau-level mixing 和
无序写入 Hamiltonian 后重新训练得到的结果。因此应把它表述为
“有限厚度尺度 benchmark”，不能表述为无参数预测。

## 4. 当前 NQS 结果的可信边界

1. \(N=5-9\) 的 explicit Fock-space NQS V2 与 ED 基本重合，说明小尺寸
   \(L=2\) sector、SU(2) 多重态和能量计算本身是可靠的。
2. \(N=40-300\) 使用 Laughlin seed 加单一 rank-2 density head。它能够
   稳定进入长波极限，但表达能力弱于 explicit NQS V2。
3. 仓库总结已测得 scalable curve 相对小尺寸高精度结果平均偏高约
   \(0.0088E_C\)。若只做灵敏度估算，把它从热力学值扣除，会得到约
   \(0.139E_C\)；再乘 \(0.305\) 为约 \(0.583\) meV。这个数可作为系统误差
   方向的提示，但不能当作经过严格校准的新结果。
4. 最值得做的下一步不是继续减小 Monte Carlo error bar，而是把多个
   rank-2 heads、scalar dressing 和有限厚度 form factor 一起放进可扩展
   Hamiltonian/ansatz 后重新训练。

## 5. 文献定位与阅读顺序

1. [Haldane and Rezayi, PRL 54, 237 (1985)](https://doi.org/10.1103/PhysRevLett.54.237)：
   与当前 Hamiltonian 和球面色散直接对应的 Fig. 5。
2. [Haldane, PRL 107, 116801 (2011)](https://doi.org/10.1103/PhysRevLett.107.116801)：
   内禀 guiding-center metric 的概念来源。
3. [Yang, Hu, Papić and Haldane, PRL 108, 256807 (2012)](https://doi.org/10.1103/PhysRevLett.108.256807)：
   长波 collective mode 的显式模型波函数及其与 magnetoroton 的连接。
4. [Liou, Haldane, Yang and Rezayi, PRL 123, 146801 (2019)](https://doi.org/10.1103/PhysRevLett.123.146801)：
   将长波中性模明确识别为手性 \(-2\) graviton。
5. [Liang et al., Nature 628, 78-83 (2024)](https://doi.org/10.1038/s41586-024-07201-w)：
   杜玲杰团队的 circularly polarized RILS 实验。
6. [Scarola, Park and Jain, PRB 61, 13064 (2000)](https://doi.org/10.1103/PhysRevB.61.13064)：
   杜玲杰论文用于理想零厚度 magnetoroton 色散的理论来源。

## 6. 复现文件

- `make_haldane_nqs_du_comparison.py`：读取仓库现有 NQS 结果并生成图和 CSV。
- `output/haldane_nqs_du_comparison.svg`：可编辑矢量图。
- `output/haldane_nqs_du_comparison.png`：高分辨率位图。
- `output/haldane_nqs_du_comparison.csv`：所有用于作图的数值、来源和注释。

