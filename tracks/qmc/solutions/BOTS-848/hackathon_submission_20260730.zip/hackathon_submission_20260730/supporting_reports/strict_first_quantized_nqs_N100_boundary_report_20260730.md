# 严格一次量子化 NQS 的 N=100 边界测试

日期：2026-07-30  
设备：NVIDIA GeForce RTX 4090 Laptop GPU，16376 MiB  
能量单位：\(e^2/(\epsilon\ell_B)\)

## 1. 最终结论

本轮按 \(N=60,80,100\) 每次增加 20 个粒子，实际提交了本地 GPU
训练。三个尺寸都完成了从采样、坐标特征评估、VMC 线性方法训练到独立
验证的完整程序路径，没有 GPU OOM。

但“程序能够运行”和“训练结果可信”必须分开：

| 尺寸 | 计算可行性 | 统计可靠性 | 结论 |
|---:|---|---|---|
| N=40 | 可行 | 双种子、ESS 0.87--0.97 | 当前最后一个正式可信尺寸 |
| N=60 | 可行 | 稳定化后 ESS 0.35/0.79 | 仅低精度探索点 |
| N=80 | 可行 | 最佳测试 excited ESS 0.036；完整头约 0.002 | 训练失效 |
| N=100 | 可行 | 高统计 excited ESS 0.008；种子严重不一致 | 训练失效 |

因此：

\[
\boxed{\text{计算/显存边界至少达到 }N=100}
\]

但

\[
\boxed{\text{当前离线重加权 NQS 的可信物理边界是 }N=40}
\]

N=60 可以给出非常粗略的探索值

\[
\Delta_{60}=0.165(21),
\]

与固定 SMA 的约 0.149 在误差内一致；由于 ground ESS 只有 0.35，
不将它列为和 N=20--40 同等级的正式结果。

N=80 和 N=100 没有可信 gap。报告任何一个训练输出的中心值都会被少数
极端权重样本主导，物理上不可接受。

## 2. 方法保持不变的部分

所有计算仍使用连续球面 spinor 坐标和严格 LLL/SU(2) tensor-feature
NQS：

\[
\Phi_{\rm L}=\prod_{i<j}(u_i v_j-v_i u_j)^3,
\qquad 2Q=3(N-1).
\]

基态由严格 scalar 通道训练，激发态由严格 rank-2、\(M=2\) 通道训练。
因此无论统计是否可靠：

- ground 解析严格 \(L^2=0\)；
- excited 解析严格 \(L^2=6\)；
- 费米反对称性严格；
- 不构造 Fock 基底或二次量子化 Hamiltonian 矩阵。

失效的是 Monte Carlo importance reweighting 的统计覆盖，而不是角动量
对称性。

## 3. 大 N 数值稳定化

原始流式核在每个 exclusion polynomial 中连续卷积三次 Jastrow 因子。
到 N=60 后，单项式系数出现很大的共同尺度和动态范围。为此新增
`strict_first_quantized_nqs_stabilized_driver.py`，在每次 cubic
convolution 后除以最大系数：

\[
p^{(k+1)}
\longrightarrow
\frac{p^{(k)}*f_{k+1}}
{\max_r |(p^{(k)}*f_{k+1})_r|}.
\]

该共同尺度在所有 single/pair polynomial numerator 和 denominator
中严格消去，不改变波函数比值。

N=5 全通道新旧核检查：

| 通道 | 最大相对残差 |
|---|---:|
| scalar | \(5.12\times10^{-12}\) |
| rank-2 tensor | \(2.65\times10^{-11}\) |

均通过 \(2\times10^{-10}\) 阈值。

稳定化对 N=60 很重要：

| 核 | samples/split | ground ESS | excited ESS | gap |
|---|---:|---:|---:|---:|
| 原始 | 3072 | 0.161 | 0.132 | \(-0.015(25)\)，不可用 |
| 稳定化 | 1024 | 0.351 | 0.792 | \(0.165(21)\)，低精度 |

这说明一部分 N=60 问题来自多项式尺度，但稳定化后 ground 重加权仍然
较弱，剩余问题是重要性采样分布失配。

## 4. N=60

稳定化 \(\ell_{\max}=5\)：

\[
E_0=166.547714(155),
\]

\[
E_2=166.713205(147),
\]

\[
\Delta=0.165491(214).
\]

诊断：

- 1024 个独立训练构型；
- 1024 个独立验证构型；
- ground retained rank 5，validation ESS fraction 0.351；
- excited retained rank 10，validation ESS fraction 0.792；
- runtime 364.4 s；
- 与固定 SMA gap \(0.14912(86)\) 相差约 \(0.76\sigma\)。

excited sector 已恢复良好，但 ground 只有约 359 个等效样本且误差较大。
因此 N=60 是可用的探索点，不是高精度正式 benchmark。

## 5. N=80

### 5.1 完整 \(\ell_{\max}=5\) 头

每个训练/验证集合 512 个构型：

- ground ESS fraction 0.00203；
- excited ESS fraction 0.00198；
- 每个 sector 实际约只有 1 个有效样本；
- 输出 gap \(-0.036(55)\)，不可使用；
- runtime 503.9 s。

### 5.2 缩减为 \(\ell_{\max}=3\)

每个集合 256 个构型：

- ground rank 3，ESS fraction 0.226；
- excited rank 4，ESS fraction 0.0357；
- excited 约 9 个有效样本；
- 输出 gap \(0.097(62)\)，不可使用；
- runtime 152.5 s。

### 5.3 最小非平凡 \(\ell_{\max}=2\)

ground/excited 都只有 2 个训练通道：

- ground ESS fraction 0.125；
- excited ESS fraction 0.00489；
- 输出 gap 1.393，明显被极端权重样本控制；
- runtime 115.2 s。

减少通道没有解决 excited importance distribution 的尾部问题。因此
N=80 是当前统计方法的明确失败点。

## 6. N=100

N=100 已实际完成两次最小非平凡 \(\ell_{\max}=2\) 训练。

### 6.1 128/128 构型

\[
E_0=369.1683(492),\qquad
E_2=369.2709(507),\qquad
\Delta=0.1026(706).
\]

- ground ESS fraction 0.994；
- excited ESS fraction 0.188，约 24 个有效样本；
- runtime 149.5 s。

这个结果误差很大，但单独看仍与固定 SMA 的约 0.148 相容。

### 6.2 512/512 高统计复核

\[
E_0=369.1041(212),\qquad
E_2=369.6270(384),\qquad
\Delta=0.5229(439).
\]

- ground ESS fraction 0.306；
- excited ESS fraction 0.00827，仅约 4 个有效样本；
- runtime 576.8 s。

增加 4 倍样本后，ESS 估计反而暴露出更严重的 heavy tail，gap 与第一
次结果完全不一致。两次结果的形式加权给出

\[
\chi^2/{\rm dof}=25.54/1,
\]

明确拒绝“二者测量同一个稳定值”的假设。因此 N=100 不报告物理 gap。

## 7. 汇总

| N | ansatz | samples/split | ground ESS | excited ESS | raw gap | 物理状态 |
|---:|---:|---:|---:|---:|---:|---|
| 20 | \(\ell_{\max}=5\) | 16384 | 0.960 | 0.754 | 0.14635(33) | 可信 |
| 30 | \(\ell_{\max}=5\) | 6144 | 0.95--0.96 | 0.76--0.80 | 0.15476(47) | 可信 |
| 40 | \(\ell_{\max}=5\) | 6144 | 0.95--0.97 | 0.87--0.89 | 0.14989(48) | 可信 |
| 60 | \(\ell_{\max}=5\)，稳定化 | 1024 | 0.351 | 0.792 | 0.165(21) | 低精度探索 |
| 80 | \(\ell_{\max}=5\)，稳定化 | 512 | 0.002 | 0.002 | 不可用 | 失败 |
| 80 | \(\ell_{\max}=3\)，稳定化 | 256 | 0.226 | 0.036 | 不可用 | 失败 |
| 100 | \(\ell_{\max}=2\)，稳定化 | 128 | 0.994 | 0.188 | 0.103(71) | 不稳定 |
| 100 | \(\ell_{\max}=2\)，稳定化 | 512 | 0.306 | 0.008 | 0.523(44) | 失败 |

表中的 N=80、100 raw gap 只用于展示失效，不应作为物理数据引用。

## 8. 为什么边界出现在重加权而不是 GPU

当前训练先从 Laughlin 或 SMA reference 分布采样，再用

\[
w(\Omega)=
\frac{|\Psi_{\rm trained}(\Omega)|^2}
{|\Psi_{\rm reference}(\Omega)|^2}
\]

重加权独立验证。随 N 增大，\(\log w\) 的方差迅速增长。极少数构型控制
权重总和，使

\[
{\rm ESS}=
\frac{(\sum_iw_i)^2}{\sum_iw_i^2}
\]

从 N=40 的数千个有效样本下降到 N=80--100 的约 1--4 个有效样本。

这是典型 overlap catastrophe。增加普通 reference 样本的收益可能呈
指数恶化；单纯增加 GPU 时间或减少通道不能从根本上解决。

计算方面：

- N=100 特征和训练完整跑通；
- 16GB GPU 没有 OOM；
- 最小头 512/512 高统计完整运行约 9.6 分钟；
- 当前计算核的墙钟复杂度较高，但不是 N=100 失败的首要原因。

## 9. 要把可信边界推进到 N=100，需要什么

必须改变采样，而不只是继续增加 reference 样本：

1. 使用当前训练态本身做 direct Metropolis，而不是离线 SMA 重加权；
2. 使用 sequential/bridged distributions
   \(\Psi_\lambda=(1-\lambda)\Psi_{\rm ref}+\lambda\Psi_{\rm trained}\)；
3. 每次线性方法更新后小步更新采样分布，形成真正迭代 SR；
4. 为 excited state 实现局部增量 feature ratio，避免每个粒子 proposal
   重新计算完整 \(O(N^3\!-\!N^4)\) 特征；
5. 再使用带状单粒子张量和共享 pair exclusion products 降低 direct
   sampling 成本。

在完成 direct trained-state sampler 前，把 N=80/100 输出称为可靠
NQS gap 是不严谨的。

## 10. 文件

代码：

- `strict_first_quantized_nqs_stabilized_driver.py`
- `test_strict_first_quantized_stabilized.py`
- `strict_first_quantized_streaming.py`
- `strict_first_quantized_nqs_streaming_driver.py`

结果：

- `runs/strict_fq_stabilized_N60_l5_seed20261406/results.json`
- `runs/strict_fq_stabilized_N80_l5_seed20261507/results.json`
- `runs/strict_fq_stabilized_N80_l3_seed20261608/results.json`
- `runs/strict_fq_stabilized_N80_l2_seed20261709/results.json`
- `runs/strict_fq_stabilized_N100_l2_seed20261810/results.json`
- `runs/strict_fq_stabilized_N100_l2_highstat_seed20261911/results.json`
- `runs/strict_fq_N100_boundary_summary_20260730.csv`

N=60 未稳定化的失败结果保留在
`runs/strict_fq_streaming_N60_l5_seed20261305/results.json`，用于数值稳定
诊断，不应作为物理结果。
