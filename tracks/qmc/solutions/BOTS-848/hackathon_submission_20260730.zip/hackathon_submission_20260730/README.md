# 黑客松提交包：严格一次量子化 NQS 与 FQH 几何模

这是本目录的总入口。提交包把原工作区中分散的代码、原始结果、图表和阶段报告整理为一条可审计的证据链；没有改写科学计算代码，也没有补造数值结果。

建议评审顺序：

1. 阅读 [`REPORT.md`](REPORT.md)：完整问题、ansatz、约束、结果和局限。
2. 阅读 [`REPRODUCE.md`](REPRODUCE.md)：从快速测试到正式 GPU 复算的命令。
3. 用 [`MANIFEST.md`](MANIFEST.md) 从每条结论追到脚本与原始 CSV/JSON。
4. 若只想核查最重要的新结论，直接查看
   [`data/laughlin_comparison/laughlin_vmc_comparison_formal_20260730/first_quantized_paired.csv`](data/laughlin_comparison/laughlin_vmc_comparison_formal_20260730/first_quantized_paired.csv)。

## 一句话结果

在 Haldane 球面、费米 Laughlin \(\nu=1/3\)、\(2Q=3(N-1)\)、严格最低 Landau level 和电子-电子 Coulomb Hamiltonian 下，我们构造了

\[
\Psi_{\mathrm{NQS}}=\Phi_{\mathrm{Laughlin}}
\times\text{严格 SU(2) 不可约张量特征的可训练复线性组合}.
\]

它从结构上保持费米反对称、固定磁通、严格 LLL、基态 \(L=0\) 和激发态 \(L=2\)，并在 16 GB RTX 4090 Laptop GPU 上得到可信到 \(N=40\) 的 VMC 结果。

最关键的直接变分证据是：在同一批全新 Laughlin 样本上做配对重加权时，训练后的一次量子化 NQS 基态能量低于纯 Laughlin 波函数。\(N=16,20,30\) 的降能达到 \(3.39\) 到 \(7.32\sigma\)；\(N=40\) 两个训练种子方向一致，其中一个达到 \(3.45\sigma\)。

## 核心数值

所有无量纲能量都以

\[
E_C=\frac{e^2}{4\pi\epsilon_0\epsilon_r\ell_B}
\]

为单位。代码和部分凝聚态记号将其写成 \(e^2/(\epsilon\ell_B)\)。下表中的误差是绝对误差，不采用可能引起歧义的括号简写。

| 结果 | 数值 |
|---|---:|
| \(N=20\) 的 \(L=2\) 中性长波 gap | \(0.1447\pm0.0026_{\rm stat}\pm0.005_{\rm ansatz}\ E_C\) |
| \(N=30\) 的 \(L=2\) 中性长波 gap | \(0.1548\pm0.0047_{\rm stat}\pm0.006_{\rm ansatz}\ E_C\) |
| \(N=40\) 的 \(L=2\) 中性长波 gap | \(0.1499\pm0.0048_{\rm stat}\pm0.006_{\rm ansatz}\ E_C\) |
| \(N=20\) 的 NQS-Laughlin 基态能量差 | \(-0.004922\pm0.000673\ E_C\), \(7.32\sigma\) |
| \(N=30\) 的两个 NQS-Laughlin 差值 | \(-0.003090\pm0.000762\ E_C\)；\(-0.003131\pm0.000923\ E_C\) |
| \(N=40\) 的两个 NQS-Laughlin 差值 | \(-0.001415\pm0.001185\ E_C\)；\(-0.002958\pm0.000858\ E_C\) |
| Coulomb 最低 \(L=2\) 极点权重，\(N=6,8,9,10\) | \(82.0\%\) 到 \(96.0\%\) |
| \(N=8\) 的 QGT 对称扇区 crossing | \(\lambda_c=0.7684404954\) |

这里的 gap 是

\[
\Delta_2=E_{L=2}^{\min}-E_{L=0}^{\min},
\]

不是 transport gap、roton minimum，也不是 NQS 相对 Laughlin 的基态降能。

## 目录结构

```text
hackathon_submission_20260730/
├── README.md                   # 本文件：提交包入口
├── REPORT.md                  # 面向评审的完整报告
├── REPORT.pdf                 # REPORT.md 的固定版式版本
├── REPRODUCE.md               # 分层复现命令与预期输出
├── MANIFEST.md                # 结论-代码-数据对应表
├── requirements.txt           # 已验证环境的核心版本
├── code/                      # 从原工作区复制的科学计算代码
├── data/
│   ├── main_nqs_runs/         # N=12--40 正式一次量子化结果
│   ├── laughlin_comparison/   # 最关键的配对 Laughlin/NQS 比较
│   ├── exact_tensor_benchmark/# 小系统严格 tensor/ED 基准
│   └── failure_and_boundary/  # AR-NQS 失效与 N=60--100 边界
├── experiments/
│   ├── geometry_chirality_study_20260729/
│   ├── case_questions_20260730/
│   ├── case_questions_20260730_followup/
│   └── deephall_l2_minimal_20260730/
├── figures/                   # 报告中引用的现有图
└── supporting_reports/        # 原阶段报告，供追溯口径演进
```

## 复现的三个层级

- **快速审计（秒到分钟）**：运行单元测试、读取现成 CSV/JSON、重建汇总表。无需 GPU。
- **小系统物理复核（分钟）**：运行 \(N=4\) 到 \(8\) 的 ED/严格 SU(2) tensor 路线，检查 gap、能量方差和 \(L^2=0/6\)。
- **正式主结果复算（约数分钟至十几分钟/seed，依硬件而定）**：在 CUDA JAX 环境中重新运行 \(N=20,30,40\) 训练与独立验证，再在全新 Laughlin 链上做配对比较。

完整命令、运行时间和预期诊断见 [`REPRODUCE.md`](REPRODUCE.md)。

## 环境与硬件

正式一次量子化运行使用：

- Python 3.11.14；
- JAX/JAXLIB 0.9.0；
- NumPy 2.3.5；
- SciPy 1.17.0；
- NVIDIA GeForce RTX 4090 Laptop GPU，16376 MiB。

`requirements.txt` 记录了版本；CUDA 对应的 JAX wheel 仍需按复现机器平台安装。运行前必须确认 `jax.devices()` 返回 CUDA 设备，不能把 CPU fallback 标成 GPU 结果。

## 结果边界

可以声称：

- 一次量子化 NQS 在多个尺寸上以配对统计显著低于纯 Laughlin 基态能量；
- 严格 \(L=0/2\) 的可训练多通道 NQS 已可信推进到 \(N=40\)；
- \(N=100\) 的特征计算和完整训练路径可运行，但当前离线 importance reweighting 已统计失效；
- Coulomb Laughlin 液体的有限尺寸几何响应由强相干低能 \(L=2\) 主峰主导；
- 一些看似正面的解释被数值排除：球面 \(M=\pm2\) 不是圆偏振 helicity，有限 ED 的 Lorentzian FWHM 不是内禀寿命。

不能声称：

- 已得到高精度热力学极限 gap；
- \(N=80,100\) 的 raw gap 是可信物理结果；
- 当前已直接测量圆偏振 bright/dark 比或内禀衰减寿命；
- Moore-Read 小体系高 fidelity 已证明大尺寸 emergent supersymmetry。

