# 严格一次量子化 NQS 求解 \(\nu=1/3\) 分数量子霍尔几何模

## 黑客松最终报告：问题本源、ansatz、约束、结果、正确性与复现

整理日期：2026-07-30  
主工作区：`Hardness_NQS`  
主要硬件：NVIDIA GeForce RTX 4090 Laptop GPU，16376 MiB  
主要体系：Haldane 球面，费米 Laughlin \(\nu=1/3\)，严格最低 Landau level（LLL）  
能量单位：\(E_C=e^2/(4\pi\epsilon_0\epsilon_r\ell_B)\)

---

## 摘要

本工作研究 \(\nu=1/3\) 分数量子霍尔液体的长波 \(L=2\) 中性几何模。困难不只是 Hilbert 空间指数增长，还在于波函数必须同时保持费米反对称、固定磁通、严格 LLL 和确定的总角动量。普通 Fock-space autoregressive NQS 虽可扩展，却在本题中出现严重的总角动量污染；显式二次量化 SU(2) tensor NQS 在小系统极精确，却受 Fock 基数爆炸限制。

我们的主方案是在连续球面坐标中使用 Laughlin 反对称核，并乘以由 LLL 投影密度算符经 Clebsch-Gordan 耦合得到的严格 SU(2) scalar/rank-2 特征，再优化其复线性系数。这个 shallow first-quantized LLL-SU(2) tensor-feature NQS 从结构上给出基态 \(L=0\) 和激发态 \(L=2\)，不靠软 penalty 猜测角动量。

最重要的直接结果有四组：

1. **NQS 的确改进了 Laughlin 波函数。** 在同一批全新 Laughlin VMC 样本上做配对重加权时，一次量子化 NQS 基态能量在 \(N=16,20,30\) 低于纯 Laughlin，显著性为 \(3.39\) 到 \(7.32\sigma\)。\(N=40\) 两个训练种子都给出负差值，其中一个为 \(3.45\sigma\)。这不是比较不同采样器得到的两个大数，而是保留协方差的同样本配对检验。
2. **严格一次量子化 NQS 已可信推进到 \(N=40\)。** 推荐结果为
   \[
   \Delta_{20}=0.1447\pm0.0026_{\rm stat}\pm0.005_{\rm ansatz}\ E_C,
   \]
   \[
   \Delta_{30}=0.1548\pm0.0047_{\rm stat}\pm0.006_{\rm ansatz}\ E_C,
   \]
   \[
   \Delta_{40}=0.1499\pm0.0048_{\rm stat}\pm0.006_{\rm ansatz}\ E_C.
   \]
3. **算法的计算路径可运行到 \(N=100\)，但可信物理边界仍是 \(N=40\)。** \(N=80,100\) 失败的主因不是 16 GB 显存，而是 reference-to-trained importance reweighting 的 overlap catastrophe；ESS 降到约 1 到 4 个有效样本。
4. **物理故事不止一个 gap。** 在 \(N=8\) 的 \(V_1\to\) Coulomb 路径上，基态 Laughlin fidelity 最低仍为 0.9908，但最低 \(L=2\) 极点权重从 2.665% 增至 82.025%。即拓扑基态连续，而几何动力学谱在同一相中发生显著权重重组。

报告同时保留负结果：球面 \(M=\pm2\) 等权不能解释为 circular bright/dark helicity；有限闭合 ED 谱的 Lorentzian FWHM 主要是人工展宽，不能直接转成寿命；DeepHall-style 两层 pilot 没有达到目标 \(L^2=0/6\)；Moore-Read 小体系机器精度不等于大尺寸 emergent supersymmetry 证据。

---

## 1. 如何阅读本报告与证据分级

本报告把原工作区中按时间累积的探索压缩为“问题 - 方法 - 约束 - 数值 - 验证 - 边界”的顺序。每个主张都可通过 [`MANIFEST.md`](MANIFEST.md) 追到脚本与原始 CSV/JSON。

结论分为四级：

- **[A 已确认]**：有 ED/解析恒等式、多随机种子、独立 validation、零方差、sum rule 或配对统计支撑。
- **[B 条件性]**：数值可信，但仍依赖有限尺寸、通道截断或经验现实修正。
- **[C 否定/失败]**：某条方法或解释已被明确排除，是有价值的负结果。
- **[D 待完成]**：目前只有实现建议或物理预期。

报告中的统计误差一律写成显式绝对误差。原因是若中心值保留过多小数，传统括号写法容易被误读一位。例如原始 CSV 的 \(N=40\) weighted gap error 是 \(0.0048E_C\)，因此写成

\[
0.1499\pm0.0048_{\rm stat}\ E_C,
\]

---

## 2. 问题的本源

### 2.1 为什么是分数量子霍尔液体的“几何模”

强磁场把二维电子的回旋运动量子化为 Landau levels。投影到 LLL 后，普通动能冻结，低能物理来自导引中心自由度及其相互作用。对 \(\nu=1/3\) 的自旋极化电子，Laughlin 波函数给出不可压缩拓扑液体的经典模型态。

拓扑数据回答分数电荷、统计和边界理论；但同一拓扑相内部仍存在“相关空穴如何形变”的几何自由度。Haldane 导引中心几何把面积保持剪切视为内禀度规涨落，其最低长波中性集体模具有自旋 2。球面上的有限尺寸代表是最低 \(L=2\) 态，常被称作 graviton/geometric mode。

我认为本题不是“用神经网络拟合一个能量”，而是：

> 能否构造一个严格尊重 LLL 与 SU(2) 角动量结构的可扩展变分波函数，求出 \(L=0\) 基态和 \(L=2\) 几何激发，并说明这个激发在谱中是否真实、相干且具有可解释的几何意义？

### 2.2 为什么传统方法很快遇到尺寸墙

在 Haldane 球面上，

\[
2Q=N_\phi=3(N-1),\qquad N_{\rm orb}=2Q+1=3N-2.
\]

未约化 Fock 空间维数为

\[
\binom{3N-2}{N}.
\]

两个例子：

\[
\binom{88}{30}\approx2.97\times10^{23},\qquad
\binom{118}{40}\approx5.07\times10^{34}.
\]

ED 可以给小系统近乎精确的真值，却不能直接进入 \(N=30,40\)。这正是一次量化连续坐标表示的优势：采样 \(N\) 个电子坐标，而不是枚举所有占据构型。

### 2.3 本题最危险的概念错误

固定 \(L_z=M\) 不等于固定总角动量 \(L\)。例如 \(M=2\) 波函数可以混入所有 \(L\ge2\) 的分量。能量即使看起来合理，也可能来自错误角动量扇区。

这在实际计算中也印证了这点：可扩展 Fock autoregressive NQS 在 \(N=10\) 给出基态/激发态 \(\langle L^2\rangle\approx619/615\)，而目标应为 \(0/6\)。因此本题必须把不可约表示写进 ansatz，而不是只加软 penalty。

---

## 3. 物理模型、约束和单位

### 3.1 几何与磁通

- 几何：半径 \(R=\sqrt Q\,\ell_B\) 的 Haldane sphere；
- 粒子：完全自旋极化费米电子；
- 填充：\(\nu=1/3\) Laughlin sequence；
- 磁通：\(2Q=3(N-1)\)；
- 单粒子轨道数：\(2Q+1=3N-2\)；
- Landau-level 条件：严格投影到 LLL；
- 边界：球面无边界。

电子位置写成归一化 spinor

\[
\Omega_i=(u_i,v_i),\qquad |u_i|^2+|v_i|^2=1.
\]

两点 chord distance 为

\[
r_{ij}=2R|u_iv_j-v_iu_j|.
\]

### 3.2 Hamiltonian

主计算使用球面上的电子-电子 Coulomb 相互作用：

\[
H_C=\sum_{i<j}\frac{e^2}{4\pi\epsilon_0\epsilon_r r_{ij}}.
\]

以

\[
E_C=\frac{e^2}{4\pi\epsilon_0\epsilon_r\ell_B}
\]

为单位后，单个 pair 的无量纲势能为

\[
\frac{\ell_B}{r_{ij}}
=\frac{1}{2\sqrt Q\,|u_iv_j-v_iu_j|}.
\]

主 NQS-Laughlin 比较没有加中和背景常数。由于两种波函数在同一 \(N,Q\) 和同一 Hamiltonian 下比较，任何共同常数都不会改变
\(E_{\rm NQS}-E_{\rm Laughlin}\) 或 \(L=2-L=0\) 的 gap。

\(V_1\) pseudopotential parent Hamiltonian 只用于构造精确 Laughlin 参考或研究 \(V_1\to\) Coulomb 路径，不是主 Coulomb benchmark 的最终 Hamiltonian。

### 3.3 目标态与 gap

- 基态：给定磁通下的最低 \(L=0\) 态；
- 几何激发：最低 \(L=2\) 态；
- 报告 gap：

\[
\Delta_2=E_{L=2}^{\min}-E_{L=0}^{\min}.
\]

它是固定 \(L=2\)、随 \(N\to\infty\) 进入长波极限的中性几何模隙。它不是：

- transport gap；
- roton minimum；
- 分离准粒子-准空穴能；
- NQS 相对 Laughlin 的基态降能。

### 3.4 条件、约束与结果的对应

| 条件/约束 | 如何实现 | 防止什么错误 | 最终可观察量 |
|---|---|---|---|
| 固定 \(N\)、\(2Q=3(N-1)\) | Laughlin 核与单粒子多项式次数 | 错 filling/shift | 同一 \(\nu=1/3\) 序列 |
| 费米反对称 | \(\prod_{i<j}(u_iv_j-v_iu_j)^3\) | 交换对称性错误 | 合法电子波函数 |
| 严格 LLL | 全纯 spinor 多项式与 LLL 投影密度 | LL 污染 | LLL Coulomb 能量 |
| 基态 \(L=0\) | scalar CG 通道 | 高 \(L\) 泄漏 | \(E_0\) |
| 激发态 \(L=2\) | rank-2 CG 通道 | 把 \(M=2\) 误当 \(L=2\) | \(E_2\) 与 \(\Delta_2\) |
| 独立泛化检查 | 不同 Markov 链的 validation | training overfit | 正式能量与 ESS |
| 通道数值条件 | overlap SVD whitening | 线性依赖/伪低能 | retained rank 稳定 |
| 统计覆盖 | ESS 与多种子 | heavy-tail 假精度 | 可信尺寸边界 |

---

## 4. 到底使用了什么 ansatz

### 4.1 Laughlin 反对称核

费米 \(\nu=1/3\) Laughlin 波函数为

\[
\Phi_L(\Omega)=\prod_{i<j}(u_iv_j-v_iu_j)^3.
\]

它一次性提供：

- 奇次 Jastrow 零点带来的费米反对称；
- 正确磁通 \(2Q=3(N-1)\)；
- 严格 LLL 全纯性；
- \(L=0\) 的旋转标量基态种子；
- 正确的短程 correlation hole。

### 4.2 LLL 投影密度不可约张量

用 LLL 投影密度球张量 \(\bar\rho_{\ell m}\) 作为特征。不同 \(\ell,m\) 在旋转下按确定的 SU(2) 不可约表示变换。通过 Clebsch-Gordan 耦合构造：

\[
[\bar\rho_{\ell_1}\times\bar\rho_{\ell_2}]_{LM}
=\sum_{m_1,m_2}
\langle \ell_1m_1,\ell_2m_2|LM\rangle
\bar\rho_{\ell_1m_1}\bar\rho_{\ell_2m_2}.
\]

选择 \(L=0\) 得 scalar，选择 \(L=2,M=2\) 得 rank-2 tensor head。

### 4.3 正式基态与激发态

基态：

\[
\Psi_0(\Omega)=\Phi_L(\Omega)
\left[
a_0+\sum_{\ell=2}^{\ell_{\max}}
a_\ell[\bar\rho_\ell\times\bar\rho_\ell]_{00}(\Omega)
\right].
\]

激发态：

\[
\Psi_{22}(\Omega)=\Phi_L(\Omega)
\left[
c_0\bar\rho_{22}(\Omega)
+\sum_{\ell_1,\ell_2=2}^{\ell_{\max}}
c_{\ell_1\ell_2}
[\bar\rho_{\ell_1}\times\bar\rho_{\ell_2}]_{22}(\Omega)
\right].
\]

正式推荐点为 \(\ell_{\max}=5\)：

- ground：5 个原始复通道，保留秩 5；
- excited：15 个原始复通道，解析线性依赖后保留秩 10。

因此该 ansatz 应准确描述为：

> 固定的严格 LLL-SU(2) tensor feature extractor，加一个可训练复线性头的浅层一次量化 NQS。

它不是固定 SMA，因为最终 10 个 excited 通道共同优化；也不是深层 FermiNet/Psiformer/attention 网络。

### 4.4 训练和验证

在 reference 分布上采样后，计算小型 overlap 与 Hamiltonian 矩阵：

\[
S_{ab}=\langle F_a^\ast F_b\rangle,\qquad
H_{ab}=\langle F_a^\ast H F_b\rangle.
\]

SVD whitening 去除零模后解广义本征问题

\[
Hc=ESc.
\]

ground 以 Laughlin 分布作 reference，excited 以 SMA 分布降低采样方差。SMA 只是 importance distribution，不是最终波函数。

每个正式 run 都重新生成独立 validation 链。报告能量来自 validation，而不是 training energy。

### 4.5 为什么这套 ansatz 适合本题

1. **硬对称性**：\(L=0/2\) 由表示论保证，不靠噪声 penalty。
2. **物理先验明确**：Laughlin 核保留正确拓扑相与 clustering。
3. **严格 LLL**：不会因一般实空间网络引入反全纯分量。
4. **可系统改进**：提高 \(\ell_{\max}\)、加入三密度耦合或非线性 scalar backbone。
5. **不枚举 Fock 空间**：能进入 \(N=30,40\)。

---

## 5. 最重要的证据：NQS 能量比 Laughlin 波函数低

### 5.1 为什么这项比较重要

Laughlin 波函数本身已经是极强的 \(\nu=1/3\) 变分态。若一个所谓 NQS 只是在采样噪声内复制 Laughlin，或者使用不一致的 Hamiltonian/背景常数，就不能证明神经/可训练修正确实增加了变分能力。

这里采用更强的配对协议：

1. 从全新的 Laughlin Markov 链采样；
2. 在同一批构型上同时计算纯 Laughlin 势能与
   \[
   \Psi_{\rm NQS}=\Phi_L\sum_a c_aF_a
   \]
   的重加权能量；
3. 按 128 条独立链做 delete-one-chain jackknife；
4. 对差值保留两种估计的协方差；
5. 检查 importance ESS，排除少数极端权重主导。

这直接检验

\[
\delta E_0=E_0^{\rm NQS}-E_0^{\rm Laughlin}.
\]

### 5.2 一次量子化正式结果

每个尺寸有 128 条链、每链 64 个记录，共 8192 个全新构型。所有能量及误差单位均为 \(E_C\)。

| \(N\) | NQS run/seed | \(E_{\rm Laughlin}\) | \(E_{\rm NQS}\) | \(\delta E_0\) | 配对误差 | NQS 更低显著性 | ESS fraction |
|---:|---|---:|---:|---:|---:|---:|---:|
| 12 | 20260730 | 12.585819 | 12.584175 | -0.001644 | 0.000981 | \(1.68\sigma\) | 0.952 |
| 16 | 20260730 | 20.208862 | 20.204968 | -0.003894 | 0.001004 | \(3.88\sigma\) | 0.921 |
| 20 | 20261002 | 29.049103 | 29.044182 | -0.004922 | 0.000673 | \(7.32\sigma\) | 0.962 |
| 30 | 20261103 | 55.722700 | 55.719610 | -0.003090 | 0.000762 | \(4.05\sigma\) | 0.963 |
| 30 | 20261204 | 55.722700 | 55.719569 | -0.003131 | 0.000923 | \(3.39\sigma\) | 0.953 |
| 40 | 20261103 | 87.995965 | 87.994550 | -0.001415 | 0.001185 | \(1.19\sigma\) | 0.949 |
| 40 | 20261204 | 87.995965 | 87.993007 | -0.002958 | 0.000858 | \(3.45\sigma\) | 0.965 |

**[A] 结论：**

- \(N=16,20,30\) 已有超过 \(3\sigma\) 的直接变分降能；
- \(N=12\) 方向相同但单次仅 \(1.68\sigma\)；
- \(N=40\) 两个种子方向相同，一个显著、一个不显著，说明有限通道/种子敏感性仍存在；
- ESS 全部在 0.921 到 0.965，降能不是少数极端 weight 造成。

这项结果正是“用 Laughlin 做 VMC，拿一次量子化 NQS 去比，NQS 的结果比 Laughlin 波函数低”的定量实现。

原始数据：

```text
data/laughlin_comparison/laughlin_vmc_comparison_formal_20260730/
  first_quantized_paired.csv
  laughlin.csv
  results.json
```

复现代码：

```text
code/laughlin_vmc_comparison.py
code/test_laughlin_vmc_comparison.py
```

### 5.3 小尺寸二次量化严格 tensor 交叉检查

高统计 Laughlin VMC 每点 131072 个样本；严格二次量化 tensor/SU(2) 能量来自近零方差收缩。

| \(N\) | \(E_{\rm Laughlin}\) | 严格 tensor \(E_0\) | \(E_0-E_L\) | 显著性 |
|---:|---:|---:|---:|---:|
| 8 | \(6.364545\pm0.000368\) | 6.362650 | -0.001895 | \(5.15\sigma\) |
| 9 | \(7.773216\pm0.000403\) | 7.771022 | -0.002195 | \(5.45\sigma\) |
| 10 | \(9.283003\pm0.000445\) | 9.279895 | -0.003108 | \(6.99\sigma\) |

**[A] 结论：** 小系统独立路线也显示严格 SU(2) 可训练修正低于 Laughlin，支持一次量化大尺寸比较的物理方向。

### 5.4 不能混淆的两种“更低”

基态能量的变分降能 \(\delta E_0<0\) 是单 sector 的强证据。gap

\[
\Delta=E_2-E_0
\]

却不是变分上界：ground 与 excited 都降能后，差值可以向上或向下移动。因此某个 NQS gap 高于固定 SMA gap，不否定 NQS 的基态变分改进。

---

## 6. 主 gap 结果：在什么条件下得到什么数

### 6.1 \(N=20\)

推荐 \(\ell_{\max}=5\) 的三个 seed 直接对 gap 做逆方差加权：

\[
\Delta_{20}=0.1447243\pm0.0025912_{\rm stat}\ E_C.
\]

结合 \(\ell_{\max}=4,5,6\) 的 validation 变化，保守写为

\[
\boxed{\Delta_{20}=0.1447\pm0.0026_{\rm stat}\pm0.005_{\rm ansatz}\ E_C.}
\]

高统计单次 seed 20261002：

\[
E_0=29.04150\pm0.00195\ E_C,
\]

\[
E_2=29.18785\pm0.00269\ E_C,
\]

\[
\Delta=0.14635\pm0.00332\ E_C.
\]

### 6.2 \(N=30\)

| seed | \(E_0^{valid}\) | \(E_2^{valid}\) | gap | ESS ground/excited | runtime |
|---:|---:|---:|---:|---:|---:|
| 20261103 | \(55.711690\pm0.004234\) | \(55.866517\pm0.004901\) | \(0.154828\pm0.006477\) | 0.962 / 0.756 | 148.0 s |
| 20261204 | \(55.717207\pm0.003599\) | \(55.871891\pm0.005793\) | \(0.154684\pm0.006820\) | 0.950 / 0.796 | 149.9 s |

加权：

\[
\boxed{\Delta_{30}=0.1548\pm0.0047_{\rm stat}\pm0.006_{\rm ansatz}\ E_C.}
\]

### 6.3 \(N=40\)

| seed | \(E_0^{valid}\) | \(E_2^{valid}\) | gap | ESS ground/excited | runtime |
|---:|---:|---:|---:|---:|---:|
| 20261103 | \(87.994624\pm0.003996\) | \(88.141286\pm0.005301\) | \(0.146662\pm0.006639\) | 0.954 / 0.893 | 368.7 s |
| 20261204 | \(87.993364\pm0.004480\) | \(88.146787\pm0.005297\) | \(0.153423\pm0.006938\) | 0.966 / 0.866 | 373.5 s |

加权：

\[
\boxed{\Delta_{40}=0.1499\pm0.0048_{\rm stat}\pm0.006_{\rm ansatz}\ E_C.}
\]

两个 seed 相差约 \(0.70\sigma\)，统计相容。

### 6.4 截断选择

\(N=30,\ell_{\max}=6\) 虽降低 training excited energy，却给出：

- gap \(0.16072\pm0.00730E_C\)；
- excited validation ESS 从 0.756 降至 0.409；
- validation energy 没有相应改善。

因此正式结果保留 \(\ell_{\max}=5\)。选择依据是独立 validation 与 ESS，而不是更低的 training energy。

### 6.5 尺寸趋势的严谨说法

| \(N\) | trained gap \((E_C)\) | 证据等级 |
|---:|---:|---|
| 12 | \(0.1304\pm0.0067\) | 单 seed，excited ESS 0.20 |
| 16 | \(0.1412\pm0.0058\) | 单 seed，excited ESS 0.30 |
| 20 | \(0.1447\pm0.0026\) | 三 seed |
| 30 | \(0.1548\pm0.0047\) | 两 seed |
| 40 | \(0.1499\pm0.0048\) | 两 seed |

**[B] 结论：** \(N=20\) 到 \(40\) 与大约 \(0.145\) 到 \(0.150E_C\) 的长波理想二维能标相容。当前数据不足以做高精度热力学外推，也不足以确认 \(N=30\) 的中心值偏高代表真实非单调性。

---

## 7. 正确性证据链

### 7.1 ED 基准

在 \(N=6,2Q=15\)：

| 量 | ED |
|---|---:|
| \(E_0\) | 3.871634914021 \(E_C\) |
| \(E_2\) | 4.003323325986 \(E_C\) |
| \(\Delta_2\) | 0.131688411965 \(E_C\) |
| \([H,L^2]\) 最大残差 | \(2.02\times10^{-12}\) |
| 本征态能量方差 | \(2.35\times10^{-32}E_C^2\) |

严格二次量化 tensor NQS 在 \(N=4\) 到 7 与 ED 达机器精度；\(N=8\) gap 偏差约 \(1.91\times10^{-6}E_C\)。

### 7.2 连续坐标与 Fock 路线交叉检查

- \(N=4\) 连续坐标通道与独立 Fock operator 最大相对残差 \(5.83\times10^{-13}\)；
- 新 streaming 核与旧显式 pair-polynomial 核：
  - \(N=4\) rank-2 最大残差 \(6.98\times10^{-14}\)；
  - \(N=5\) rank-2 最大残差 \(3.58\times10^{-15}\)；
- 大 \(N\) 稳定化核在 \(N=5\) 的 scalar/rank-2 残差为 \(5.12\times10^{-12}\) / \(2.65\times10^{-11}\)。

这些检查说明优化改变了 contraction 路径，没有改变 ansatz。

### 7.3 对称性

- Laughlin 核保证费米反对称与正确磁通；
- scalar head 解析严格 \(L=0\)，即 \(L^2=0\)；
- rank-2 head 解析严格 \(L=2\)，即 \(L^2=6\)；
- 不同不可约表示自动正交，不需要 ground/excited overlap penalty。

### 7.4 独立 validation 与 ESS

正式 \(N=30,40\) 每个 run 使用：

- 128 条独立 GPU Markov 链；
- training \(128\times48=6144\) 个构型；
- validation 另取 \(6144\) 个构型；
- 不同随机数流；
- overlap tolerance 从 \(10^{-8}\) 到 \(10^{-4}\) 扫描；
- retained ranks 固定为 5/10。

### 7.5 多种子

- \(N=20\)：3 seed 加权；
- \(N=30,40\)：各 2 seed；
- Laughlin 配对比较在 \(N=30,40\) 保留两个不同 NQS 训练 seed；
- Moore-Read：每分支 5 seed；
- 一次/二次量化 \(N=6\) 公平比较：各 3 seed。

![一次/二次量化 NQS 多种子比较](figures/nqs_multiseed.png)

---

## 8. 可扩展性优势与真实边界

### 8.1 为什么一次量化能到 \(N=40\)

旧实现对每个电子对显式保存 \(D\times D\) 双变量多项式块，存储约 \(O(N^2D^2)\)。streaming 实现利用三次 Jastrow 因子的低秩分解，把 pair contraction 化为四项 shifted outer-product 收缩，中间存储降为约 \(O(N^2D)\)。

实测完整 run，包括 ground/excited、training/validation、首次 JAX 编译和广义本征求解：

| \(N\) | feature batch | 16 GB GPU 单 run |
|---:|---:|---:|
| 20 | 24--32 | 约 57--147 s |
| 30 | 16 | 约 148--150 s |
| 40 | 8 | 约 369--374 s |

因此“可以算到 \(N=40\)”是实际完成的训练与独立验证，不是维数估计。

### 8.2 \(N=60,80,100\) 边界实验

| \(N\) | ansatz | ground ESS | excited ESS | raw gap \((E_C)\) | 结论 |
|---:|---:|---:|---:|---:|---|
| 60 | \(\ell_{\max}=5\) 稳定化 | 0.351 | 0.792 | \(0.165\pm0.021\) | 低精度探索 |
| 80 | \(\ell_{\max}=5\) | 0.002 | 0.002 | \(-0.036\pm0.055\) | 不可用 |
| 80 | \(\ell_{\max}=3\) | 0.226 | 0.036 | \(0.097\pm0.062\) | 不可用 |
| 100 | \(\ell_{\max}=2\), 128 samples | 0.994 | 0.188 | \(0.103\pm0.071\) | 不稳定 |
| 100 | \(\ell_{\max}=2\), 512 samples | 0.306 | 0.008 | \(0.523\pm0.044\) | 失败 |

\(N=100\) 两次结果给出 \(\chi^2/{\rm dof}=25.54\)，明确不相容。增加样本反而发现更重的尾部。

**[A/C] 结论：**

- 特征、训练、验证和 16 GB GPU 路径至少可跑到 \(N=100\)；
- 当前可信物理结果边界是 \(N=40\)；
- \(N=80,100\) 失败是 importance overlap catastrophe，不是对称性失败或 OOM；
- 下一步必须用 trained-state direct Metropolis、bridge distributions 或迭代小步 SR，而不是继续堆 reference 样本。

---

## 9. 物理主线：同一 Laughlin 相中的几何谱重组

### 9.1 Coulomb 最低 \(L=2\) 模是否是真实主峰

| \(N\) | Coulomb 最低极点 \((E_C)\) | 最低极点权重 | \(V_1\) 最低极点权重 |
|---:|---:|---:|---:|
| 6 | 0.131688 | 95.95% | 80.70% |
| 8 | 0.128785 | 82.02% | 2.665% |
| 9 | 0.130509 | 89.21% | 0.850% |
| 10 | 0.129238 | 82.72% | 0.622% |

Krylov 截断检查：

- 谱矩 sum-rule 最大相对残差 \(6.79\times10^{-14}\)；
- \(N=9\) 从 180 到 220 步，主峰最大变化 \(1.31\times10^{-12}\)；
- \(N=10\) 从 140 到 180 步，主峰最大变化 \(7.23\times10^{-12}\)。

**[A] 结论：** 在可达有限尺寸中，Coulomb 最低 \(L=2\) 态是稳定相干主峰；而 \(V_1\) 端的最低 \(L=2\) 态可能很暗，最强几何权重位于更高极点。

### 9.2 \(V_1\to\) Coulomb 的加密谱流

考虑

\[
H(\alpha)=(1-\alpha)H_{V_1}+\alpha H_C.
\]

\(N=8\)：

- 基态 Laughlin fidelity 最低为 0.9908166；
- 静态 \(S_2\) 只变化约 -2.48%；
- 最低极点权重从 2.665% 增到 82.025%；
- 最低极点成为最强极点的交换约在 \(\alpha=0.79591\)；
- 最低极点权重越过 50% 约在 \(\alpha=0.83461\)。

这不是基态相变，而是同一拓扑相中的动力学几何谱权重连续重排。

![有限尺寸几何谱碎片化](figures/spectral_fragmentation.png)

---

## 10. 细分问题的来龙去脉与最终结论

### 10.1 \(S_4\)、Haldane bound 与反手性上界

采用

\[
S_L=\frac{2Q+1}{N(2L+1)}
\sum_M\langle\rho_{LM}^\dagger\rho_{LM}\rangle,\qquad
x=(q\ell_B)^2=\frac{L(L+1)}Q.
\]

用同尺寸 Coulomb/\(V_1\) 的 \(L=2\) 比值并以 Laughlin \(S_4=1/4\) 标定，得到

\[
S_4^C=0.26057\pm0.02092.
\]

它与 \(1/4\) 只差约 \(0.51\sigma\)。

**[B] 结论：** 数据与 Haldane bound 饱和相容，但不能声称证明精确饱和。基于积分 sum-rule 的反/主手性中心比约 2.07%，95% 保守上界约 9.35%；这不是频率分辨 circular spectrum。

### 10.2 Bright/Dark 手性为什么是一个 null result

最初问题希望比较 \(\rho_{2,+2}\) 和 \(\rho_{2,-2}\) 的谱权重。数值在 \(N=6,8,10\) 的 \(V_1\) 与 Coulomb 中都得到

\[
\frac{W_{-2}}{W_{+2}}=1
\]

到约 \(10^{-15}\) 到 \(10^{-11}\)。

这不是“没有手性”，而是球面 SO(3) 协变要求同一 \(L=2\) multiplet 的不同 \(M\) 分量等价。\(M\) 是角动量投影，不是平面局部标架中的 circular helicity。

**[C] 结论：** 不应报告数百倍的 bright/dark 比。真正圆偏振探针需要

\[
T_{xx}-T_{yy}\pm2iT_{xy}
\]

或带定向 bond-angle phase 的局部四极算符，最好在 torus/cylinder/平面局部标架中实现。

### 10.3 峰宽与寿命

有限闭合 Hilbert 空间的 ED 谱本质上是离散 \(\delta\) 峰。绘图时用 Lorentzian 展宽 \(\eta\)：

| \(N\) | Coulomb 主峰 \(\omega/E_C\) | 主峰权重 | 碎片化 \(\sigma/E_C\) | FWHM at \(\eta=0.005E_C\) |
|---:|---:|---:|---:|---:|
| 6 | 0.131688 | 95.95% | 0.015622 | 0.010031 |
| 8 | 0.128785 | 82.02% | 0.018822 | 0.010074 |
| 10 | 0.129238 | 82.72% | 0.019941 | 0.010075 |

多-\(\eta\) 拟合的 FWHM 斜率约 2.00 到 2.04，零截距只在 \(10^{-5}E_C\) 数值尺度上下摆动。

**[A/C] 结论：**

- 可以报告 \(\eta\)-无关的谱碎片化、主峰权重和谱矩；
- 当前数据与 \(\Gamma_{\rm physical}=0\) 相容；
- 不能把绘图 FWHM 转成内禀寿命；
- 真正非零衰减需热力学准连续谱、开放通道或实时演化。

### 10.4 QGT 与相变

第一版连续 ARPACK 扫描会继承上一点本征矢，可能被锁在同一 \(L\) 扇区，从而把上边界粗略放在 0.80 到 0.85。follow-up 对 \(L=0\) 和 \(L=2\) 分支独立求解，并跨扇区重启 unrestricted ground solve。

\(N=8\)：

\[
\lambda_c=0.7684404954,
\]

bracket 为 \([0.765,0.770]\)，求根残差 \(1.29\times10^{-12}\)，两分支完整性误差 \(4.05\times10^{-13}\)。

**[A] 结论：**

- 稳健量是 \(E_{L=0}=E_{L=2}\) 的 crossing 位置；
- 真实基态在正交扇区精确 crossing，网格上的 \(\chi_{\rm true}\) 峰高按步长发散，不是普适有限峰；
- 原始神经参数空间的 \({\rm Tr}\,Q\) 依赖重参数化；
- Chern 数仍未计算，需要 torus twist \((\theta_x,\theta_y)\) 的二维 Berry-curvature 积分。

![QGT 对称性分辨扫描](figures/qgt_symmetry_resolved.png)

### 10.5 Moore-Read graviton 与 neutral-fermion candidate

固定 \(2Q=2N-3\) 时：

- 偶 \(N=6\) 具有整数 \(L\)，测试 \(L=0,2\)；
- 奇 \(N=7\) 具有半整数 \(L\)，测试 \(L=3/2\)；
- 三个分支不属于同一个固定 \(N\) Hilbert 空间。

follow-up 用三体 parent Hamiltonian Rayleigh quotient 与 \(L^2\) 约束训练，teacher 只在训练后盲测。5 个随机种子：

| 分支 | 系统 | 最大能量误差 | 最低 fidelity |
|---|---|---:|---:|
| ground | \(N=6,L=0\) | \(1.25\times10^{-16}\) | 0.9999999999999998 |
| graviton | \(N=6,L=2\) | \(1.11\times10^{-15}\) | 1.0000000000000000 |
| neutral-fermion candidate | \(N=7,L=3/2\) | \(6.66\times10^{-16}\) | 0.9999999999999996 |

**[A/B] 结论：** 三个小体系分支都可从随机初始化变分回到精确本征态，证明小空间可表示性和优化正确性；没有大尺寸 VMC、超荷矩阵元和动力学简并前，不能声称 emergent SUSY/gravitino。

![Moore-Read 变分收敛](figures/mr_variational_convergence.png)

### 10.6 各向异性、quench 与粒子-空穴

- \(N=4\) rank-2 各向异性把第一隙从 \(0.093533E_C\) 软化到 \(0.005987E_C\)（\(|\lambda|=0.08\)），支持 nematic softening 方向；
- metric/quadrupole quench 主频 \(0.088813E_C\)，与各向同性第一隙差约 5.05%；
- 粒子-空穴共轭 gap 在机器精度内相同；
- PH 两侧 \(\rho_{2,+2}\) 与 \(\rho_{2,-2}\) 仍等权，再次说明 \(M=\pm2\) 不是 helicity。

这些是机制探针，不是完整 finite-thickness 或 generalized-pseudopotential 模型。

### 10.7 HMC 是否优于局部 Metropolis

实现了 \((S^2)^N\) 上 geodesic HMC：

- 动量投影到球面切空间；
- 位置按精确大圆更新；
- leapfrog 与 Metropolis 校正；
- warm start 修复近碰撞奇点；
- 修复 masked inverse 在自动微分中的 NaN。

\(N=12,20,40\) 上 HMC 与 Metropolis 势能相容，说明分布正确；但当前 energy ESS/s 约为局部 Metropolis 的 0.47 到 0.87。\(N=40,\ell_{\max}=4\) 得

\[
\Delta_{40}^{\rm HMC}=0.1415\pm0.0214E_C,
\]

与正式结果相容但误差更大。

**[A/B] 结论：** HMC 正确接入，但当前不替代高度批量化的默认 Metropolis。

### 10.8 DeepHall-style 两层 ansatz 的最小交叉检查

为了判断严格 tensor 路线是否过于复杂，另实现两层 Psiformer、单 determinant、LLL monopole-harmonic envelope 和 Coulomb-cusp Jastrow 的最小 DeepHall-style \(N=4\) pilot。

保存的最好 pilot：

- ground：\(\langle L^2\rangle=5.376\)，目标 0；
- excited：\(\langle L^2\rangle=14.996\)，目标 6。

因此两条能量不能组成可信 \(L=2-L=0\) gap。当前环境缺少原论文使用的 KFAC，pilot 使用 Adam 且 head dimension 更小。

**[C] 结论：** 这是优化/对称性失败诊断，不是正式物理结果。它反过来支持本题必须硬编码 SU(2) irrep。

同目录的 ED toy softened interaction

\[
V_w(r)=\frac{1}{\sqrt{r^2+w^2}}
\]

显示 \(N=4\) raw gap 从 \(w=0\) 的 \(0.131857E_C\) 降到 \(w=1.0\ell_B\) 的 \(0.080568E_C\)。这只说明软化相互作用会降低 gap 的方向，不是实际 GaAs transverse form factor 的无参数预测。

### 10.9 普通 Fock autoregressive NQS 为什么失败

| \(N\) | raw gap \((E_C)\) | \(L^2(M=0)\) | \(L^2(M=2)\) | ratio clip ground/excited |
|---:|---:|---:|---:|---:|
| 10 | \(0.0625\pm0.0168\) | 618.69 | 615.28 | 0.001% / 0.000% |
| 12 | \(0.0415\pm0.0190\) | 1085.30 | 863.11 | 2.53% / 0.80% |
| 14 | \(0.0807\pm0.0148\) | 1499.39 | 1275.63 | 19.55% / 11.45% |
| 16 | \(-0.0122\pm0.0231\) | 1840.97 | 1578.56 | 42.16% / 30.47% |
| 18 | \(0.0162\pm0.0176\) | 2382.03 | 2006.50 | 56.23% / 44.33% |
| 20 | \(0.0748\pm0.0212\) | 2771.34 | 2457.23 | 63.56% / 54.29% |

目标值应为 \(0/6\)。

**[C] 结论：** 它证明网络和 GPU 可以扩尺寸，却没有保持目标物理扇区；raw gap 不可解释为 graviton gap，也不能用于外推。

---

## 11. 方法演进：成功与失败为什么都重要

| 阶段 | 结果 | 最终判断 |
|---|---|---|
| ED 基线 | \(N\le7\) 精确，\(N=8\) 高精度 | 提供真值，不能扩大 |
| 早期 rank-1 tensor NQS | 对称性正确但激发态有 \(10^{-4}E_C\) bias | 误差来自表达力，不是 MC |
| full-multiplicity + whitening | \(N=4\) 到 7 机器精度，\(N=8\) 微小偏差 | 小系统主基准 |
| 显式 Fock sparse | \(N=9\) 强内部验证，\(N=10\) 内存峰值 | 必须转一次量化 |
| Fock autoregressive | 能到 \(N=20+\)，但 \(L^2\) 爆炸 | 可扩展性成功、物理扇区失败 |
| Fock-compiled 一次量化 | 连续坐标与 ED 一致 | 验证桥，仍指数复杂 |
| matrix-free 单张量头 | 严格 \(L\)，可跑到 \(N=100+\) | 固定 SMA baseline，不是训练 NQS |
| 多通道一次量化 | 真正训练到 \(N=12\) | 主方法建立 |
| streaming contraction | 正式推进到 \(N=20,30,40\) | 当前主结果 |
| stabilization \(N=60\) 到 100 | 无 OOM，但 ESS 崩溃 | 找到统计边界 |
| 几何/QGT/峰宽/MR follow-up | 多个解释被修正 | 把“一个 gap”变成完整物理故事 |

---

## 12. 与实验、有限厚度和 LL mixing

### 12.1 不同能量不能混用

| 量 | 典型能标 | 含义 |
|---|---:|---|
| 本项目 \(L=2\) 长波理想二维 gap | 约 \(0.13\) 到 \(0.15E_C\) | 固定 \(L=2\) |
| roton minimum | 约 \(0.075E_C\) | 有限 \(k\ell_B\sim1.4\) |
| 分离准粒子-准空穴 | 约 \(0.105E_C\) | 大波矢极限 |
| 引用实验长波峰 | \(0.048E_C=0.66\) meV | 58.5 nm GaAs well |

球面上 \(k\ell_B=L/\sqrt Q\)。固定 \(L=2\) 且 \(N\to\infty\) 才进入真正长波极限。

### 12.2 经验厚度 benchmark

早期固定单头/SMA 大尺寸曲线给出

\[
\Delta_\infty^{\rm SMA}=0.14783\pm0.00297E_C.
\]

乘实验论文使用的 0.305 厚度因子：

\[
0.305\Delta_\infty
=0.04509\pm0.00091E_C
=0.620\pm0.012\ {\rm meV}.
\]

与 0.66 meV 相差约 6.1%。

![Haldane、固定 SMA benchmark 与实验能标](figures/haldane_nqs_du_comparison.png)

（上面这张图看起来排版还有点问题但来不及修改了）

**[B] 口径：** 这说明有限厚度是主导修正的合理候选，但图中的大尺寸曲线是早期固定 SMA benchmark，不是当前多通道 NQS 的高精度热力学外推。真正的现实预测必须把 transverse form factor 写入 Hamiltonian 后重新训练。

### 12.3 LL mixing

主代码等价于

\[
\kappa=\frac{E_C}{\hbar\omega_c}=0.
\]

GaAs 近似

\[
\kappa\simeq\frac{2.52}{\sqrt{B[{\rm T}]}}
\]

，在 5、10、15 T 时约为 1.13、0.80、0.65。

最可行的下一步不是立刻显式加入多个 Landau levels，而是在 LLL 内使用

\[
H_{\rm eff}=H_C+\kappa\,\delta H^{(2)}
+\kappa H^{(3)}+O(\kappa^2),
\]

加入修正二体和诱导三体 pseudopotentials。这样可以复用现有一次量化 SU(2) NQS。

---

## 13. 两类 NQS 的公平多种子比较

在 \(N=6\) Coulomb、相近架构预算下：

| 指标 | 一次量化严格 SU(2) | 二次量化 Fock AR |
|---|---:|---:|
| gap 均值 \((E_C)\) | 0.132841854 | 0.129685322 |
| 跨 seed SD \((E_C)\) | 0.000272331 | 0.001855888 |
| 平均相对 ED 误差 | 0.876% | 1.521% |
| ground overlap | 99.9418% | 99.4093% |
| excited overlap | 99.3075% | 99.2547% |
| 平均 runtime | 54.4 s | 21.9 s |

**[A] 结论：** 一次量化严格 SU(2) 路线的 gap 跨种子散布小约 6.8 倍；Fock AR 单次更快，可用于架构探索，但不能用幸运单 seed 代表典型精度。

---

## 14. 结论

| 主题 | 可以声称 | 不能声称 |
|---|---|---|
| Laughlin 对比 | 多个尺寸上 NQS 基态能量显著更低 | 每个尺寸、每个 seed 都同样显著 |
| gap | 可信到 \(N=40\)，明确统计与 ansatz 误差 | 已有高精度热力学极限 |
| 可扩展性 | 16 GB GPU 完成 \(N=40\) 正式训练；程序到 \(N=100\) | \(N=80,100\) raw gap 可信 |
| 对称性 | 主 ansatz 解析严格 \(L=0/2\) | 固定 \(M\) 或软 penalty 足够 |
| 几何谱 | Coulomb 主峰权重 82%-96%；\(V_1\to C\) 权重重组 | \(V_1\) 最低态总是最强几何模 |
| \(S_4\) | \(0.26057\pm0.02092\)，与 1/4 相容 | 已证明精确饱和 |
| 手性 | \(M=\pm2\) 等权是 SO(3) null test | 已测 circular bright/dark 比 |
| 峰宽 | 可报告碎片化、主峰权重、谱矩 | FWHM 给出内禀寿命 |
| QGT | \(\lambda_c=0.7684404954\) 的扇区 crossing | 峰高是普适量；已算 Chern number |
| Moore-Read | 小体系三分支五 seed 机器精度 | 已证明大尺寸 SUSY/gravitino |
| 实验 | 经验厚度缩放后接近实验 | 已完成无参数样品预测 |

---

## 15. 报告与代码的直接对应

| 报告内容 | 首要脚本 | 首要结构化证据 |
|---|---|---|
| Hamiltonian、ED、\(L^2\) | `code/chiral_graviton_ed.py` | `data/exact_tensor_benchmark/summary.csv` |
| 一次量化 ansatz | `code/strict_first_quantized_tensor_nqs.py` | `data/main_nqs_runs/*/results.json` |
| streaming \(N=20\) 到 40 | `code/strict_first_quantized_streaming.py`; `strict_first_quantized_nqs_streaming_driver.py` | `data/main_nqs_runs/strict_fq_streaming_N20_N40_benchmark_20260730.csv` |
| NQS 低于 Laughlin | `code/laughlin_vmc_comparison.py` | `data/laughlin_comparison/.../first_quantized_paired.csv` |
| \(N=60\) 到 100 边界 | `code/strict_first_quantized_nqs_stabilized_driver.py` | `data/failure_and_boundary/strict_fq_N100_boundary_summary_20260730.csv` |
| AR-NQS 失败 | `code/chiral_graviton_fock_ar_nqs_symmetry_v5.py` | `data/failure_and_boundary/summary.csv` |
| 几何谱重组 | `experiments/geometry_chirality_study_20260729/*.py` | 同目录 `results/*.csv/json` |
| 峰宽、手性 | `experiments/case_questions_20260730/*.py` | 同目录 `results/` |
| QGT、MR、多 seed | `experiments/case_questions_20260730_followup/*.py` | 同目录 `results/` |
| DeepHall/有限厚度 toy | `experiments/deephall_l2_minimal_20260730/*.py` | 同目录 `results/` |

逐命令复现见 [`REPRODUCE.md`](REPRODUCE.md)，更细文件索引见 [`MANIFEST.md`](MANIFEST.md)。

---

## 16. 局限与下一步

### 16.1 当前局限

1. ansatz 是浅层 tensor-feature NQS，通道数仍有限；
2. \(N>40\) 的主要瓶颈是离线重加权覆盖，不是显存；
3. 还没有真实 finite-thickness form factor、LL-mixing 有效项或无序；
4. 球面 \(M=\pm2\) 不能直接测 circular helicity；
5. gap 数据尚不足以精确外推 \(N\to\infty\)；
6. Moore-Read 只完成小 Hilbert-space benchmark；
7. 当前 lifetime 分析只得到“不能从人工 FWHM 取寿命”的边界。

### 16.2 优先级

1. **direct trained-state sampling**：解决 \(N>40\) overlap catastrophe；
2. **真正 circular stress operator**：在局部标架区分 helicity；
3. **finite-thickness form factor 与 LL-mixing pseudopotentials**；
4. **更深但仍严格等变的 ansatz**：三密度 CG、非线性 scalar backbone、CF-exciton head；
5. **torus twist 与 Chern/Dehn twist**；
6. **metric quench/TDVP**：直接研究实时衰减；
7. **Moore-Read 大尺寸 parity-staggered gap 与候选超荷矩阵元**。

---

## 17. 最终结论

本项目的核心贡献不是单独给出一个 gap，而是把可扩展性、严格对称性和物理解释连成一条可验证的链：

1. 小系统 ED 与严格二次量化 tensor NQS 建立真值；
2. 失败的 autoregressive 路线证明“能训练”不等于“在正确 \(L\) 扇区”；
3. 一次量化 Laughlin 核加 SU(2) density-tensor 特征同时解决严格 LLL、费米反对称、角动量和 Fock 维数爆炸；
4. streaming contraction 使本地 16 GB GPU 实际完成 \(N=40\) 正式训练和独立验证；
5. 同样本配对 VMC 直接证明训练后 NQS 在多个尺寸上比纯 Laughlin 波函数具有更低的基态能量；
6. 几何谱显示 Coulomb Laughlin 液体的低能 \(L=2\) 响应是强相干主峰，并在 \(V_1\to\) Coulomb 的同一拓扑相内发生明显权重重组；
7. 手性、寿命、QGT、Moore-Read、有限厚度和 \(N=100\) 边界均给出了清楚的“已知什么、尚不能说什么”。

最稳妥的最终表述是：

> **[A] 严格一次量化 LLL-SU(2) tensor-feature NQS 已在 16 GB 本地 GPU 上可信训练到 \(N=40\)，同时解析保持基态 \(L=0\) 与激发态 \(L=2\)。**
>
> **[A] 在全新 Laughlin VMC 样本的配对检验中，训练后 NQS 在 \(N=16,20,30\) 显著降低基态 Coulomb 能量；\(N=40\) 两个种子方向一致，其中一个达到 \(3.45\sigma\)。**
>
> **[A] Coulomb Laughlin 液体在 \(N=6,8,9,10\) 的最低 \(L=2\) 极点承载约 82%-96% 的几何谱权重；从 \(V_1\) 到 Coulomb，基态保持拓扑连续而动力学几何谱显著重组。**
>
> **[C/D] \(N=80,100\) gap、圆偏振手性、内禀寿命和大尺寸 Moore-Read SUSY 尚不能声称；其失效原因和下一步已被明确定位。**

## 额外尝试：



简化的NQS ansatz：

纯两层 DeepHall/Psiformer 基础版失败，原因是没有学到正确的总角动量
sector；在它上面加入严格 \(L=0/L=2\) seed，并只让两层小网络学习旋转
不变的 scalar dressing 后，训练成功。

## 1. 失败的基础版

配置：

- \(N=4,\ 2Q=9,\ \kappa=1\)；
- 2 层、4 heads、head dimension 8、单 determinant；
- 15,633 个参数；
- Adam + \(L_z/L^2\) penalty。

结果：

| state   |            energy | \(\langle L_z\rangle\) | \(\langle L^2\rangle\) |          target |
| ------- | ----------------: | ---------------------: | ---------------------: | --------------: |
| ground  | 4.42923 ± 0.00933 |                  0.043 |                  5.376 |       \(L^2=0\) |
| excited | 4.28858 ± 0.00708 |                  1.914 |                 14.996 | \(L_z=2,L^2=6\) |

两态都发生 sector contamination，直接相减得到的负 gap 没有物理意义。

## 2. 成功的最小增强版

ansatz：

$$
\Psi_0=\Psi_{\rm Laughlin}\exp F_{\theta,0}(\{r_{ij}\}),
$$

$$
\Psi_{2,2}=\rho_{2,2}\Psi_{\rm Laughlin}
\exp F_{\theta,2}(\{r_{ij}\}).
$$

其中 \(F_\theta\) 只读取六个全局 pair-distance invariants，再经过两层
MLP。因此 neural dressing 是总角动量标量，不会改变 seed 的 irrep。

- 每个 sector 只有 401 个参数；
- 不使用 \(L_z/L^2\) penalty；
- ground 始终满足 \(\langle L^2\rangle\simeq0\)；
- excited 始终满足
  \(\langle L_z\rangle=2,\ \langle L^2\rangle=6\)；
- checkpoint 检查确认 neural dressing 非零，不是固定 SMA。

## 3. 可信 gap

能量单位为 \(E_C=e^2/(\epsilon\ell_B)\)。

| interaction                               |             \(E_0\) |             \(E_2\) |                 raw gap |   density-corrected gap |
| ----------------------------------------- | ------------------: | ------------------: | ----------------------: | ----------------------: |
| Coulomb                                   | 3.871987 ± 0.000964 | 4.002677 ± 0.002214 | **0.130689 ± 0.002415** |     0.113180 ± 0.002091 |
| \(V_w=1/\sqrt{r^2+w^2}\), \(w=1.5\ell_B\) | 3.676757 ± 0.000633 | 3.733102 ± 0.001023 | **0.056344 ± 0.001203** | **0.048796 ± 0.001042** |

严格 LLL-ED 的 Coulomb gap 是 \(0.1318568E_C\)，与增强版 NQS 一致。
软势经过

$$
\sqrt{\frac{2Q\nu}{N}}=0.8660254
$$

修正后得到 \(0.04880\pm0.00104E_C\)，与实验约 \(0.048E_C\) 一致。

## 4. 物理解读

1. 原 ansatz 的复杂部分并非全是多余的；精确 \(SU(2)\) sector 约束很重要。
2. 只减少网络层数或宽度不能解决问题，普通 Adam 很难通过 penalty 学出
   精确 \(L\)。
3. 有效的最小方案是“简单 invariant backbone + 严格 \(L=0/L=2\)
   symmetry head”。
4. \(w=1.5\ell_B\) 是等效 soft-Coulomb toy 参数，不是从真实 58.5 nm
   GaAs 横向波函数无参数推导的结果。

## 5. 主要文件

- `symmetry_anchored_nqs.py`：成功的 401 参数增强版；
- `results/symmetry_coulomb_gap_400.json`：Coulomb gap；
- `results/symmetry_w1p5_gap_200.json`：软势 gap；
- `RESULTS.md`：完整过程与失败诊断。
