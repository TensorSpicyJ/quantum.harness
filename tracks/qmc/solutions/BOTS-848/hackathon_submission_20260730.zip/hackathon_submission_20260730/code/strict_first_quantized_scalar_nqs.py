#!/usr/bin/env python3
"""Strict L=0 first-quantized scalar NQS trained by the VMC linear method."""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np

from chiral_graviton_ed import clebsch_gordan2
from strict_first_quantized_tensor_nqs import (
    collect_laughlin_samples,
    estimate_matrices,
    parse_sizes,
    solve_linear_method,
    weighted_statistics,
)
from strict_first_quantized_tensor_nqs_v2 import (
    monomial_tensor_matrices,
    monomial_values,
    pair_polynomial,
    safe_complex,
    single_polynomial,
)


def make_scalar_feature_function(particles: int, lmax: int):
    degree = 3 * (particles - 1)
    tensor_host = monomial_tensor_matrices(degree, lmax)
    tensors = {
        key: jnp.asarray(value, dtype=jnp.complex128)
        for key, value in tensor_host.items()
    }
    labels = ["identity"] + [f"[rho_{ell}xr_{ell}]_0" for ell in range(2, lmax + 1)]

    def one(spinors):
        basis = [
            monomial_values(spinors[index], degree)
            for index in range(particles)
        ]
        singles = [
            single_polynomial(spinors, index)
            for index in range(particles)
        ]
        single_denominators = [
            safe_complex(basis[index] @ singles[index])
            for index in range(particles)
        ]
        pairs = {}
        pair_denominators = {}
        for first in range(particles):
            for second in range(first + 1, particles):
                coefficients = pair_polynomial(spinors, first, second)
                pairs[(first, second)] = coefficients
                pair_denominators[(first, second)] = safe_complex(
                    basis[first] @ coefficients @ basis[second]
                )

        features = [jnp.asarray(1.0 + 0.0j, dtype=spinors.dtype)]
        for ell in range(2, lmax + 1):
            scalar = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
            for m in range(-ell, ell + 1):
                cg = clebsch_gordan2(
                    2 * ell, 2 * m, 2 * ell, -2 * m, 0, 0
                )
                if abs(cg) < 1.0e-14:
                    continue
                left_matrix = tensors[(ell, m)]
                right_matrix = tensors[(ell, -m)]
                same = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
                different = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
                for first in range(particles):
                    same = same + (
                        basis[first]
                        @ left_matrix
                        @ right_matrix
                        @ singles[first]
                    ) / single_denominators[first]
                    for second in range(particles):
                        if first == second:
                            continue
                        low, high = sorted((first, second))
                        coefficients = pairs[(low, high)]
                        denominator = pair_denominators[(low, high)]
                        if first < second:
                            numerator = (
                                basis[first]
                                @ left_matrix
                                @ coefficients
                                @ right_matrix.T
                                @ basis[second]
                            )
                        else:
                            numerator = (
                                basis[second]
                                @ right_matrix
                                @ coefficients
                                @ left_matrix.T
                                @ basis[first]
                            )
                        different = different + numerator / denominator
                scalar = scalar + cg * (same + different)
            features.append(scalar)
        return jnp.stack(features)

    return jax.jit(jax.vmap(one)), labels


def estimate_one_size(arguments, particles):
    start_time = time.perf_counter()
    feature_function, labels = make_scalar_feature_function(
        particles, arguments.lmax
    )
    coordinates, potential, acceptance = collect_laughlin_samples(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        arguments.seed,
    )
    split = arguments.training_records * arguments.chains

    def evaluate(coordinates_host):
        output = []
        for start in range(0, len(coordinates_host), arguments.feature_batch):
            output.append(
                np.asarray(
                    jax.device_get(
                        feature_function(
                            jnp.asarray(
                                coordinates_host[
                                    start : start + arguments.feature_batch
                                ]
                            )
                        )
                    )
                )
            )
        return np.concatenate(output, axis=0)

    training_features = evaluate(coordinates[:split])
    validation_features = evaluate(coordinates[split:])
    training_potential = potential[:split]
    validation_potential = potential[split:]
    scales = np.sqrt(
        np.maximum(
            np.mean(np.square(np.abs(training_features)), axis=0), 1.0e-30
        )
    )
    training_features /= scales[None, :]
    validation_features /= scales[None, :]
    overlap, hamiltonian = estimate_matrices(
        training_features, training_potential
    )
    _, coefficients, retained_rank = solve_linear_method(
        overlap, hamiltonian, arguments.whitening_tolerance
    )
    training_energy, _, training_ess, training_fraction = weighted_statistics(
        training_features,
        training_potential,
        coefficients,
        arguments.chains,
        arguments.training_records,
    )
    energy, stderr, validation_ess, validation_fraction = weighted_statistics(
        validation_features,
        validation_potential,
        coefficients,
        arguments.chains,
        arguments.records - arguments.training_records,
    )
    result = {
        "particles": particles,
        "two_q": 3 * (particles - 1),
        "lmax": arguments.lmax,
        "raw_channels": len(labels),
        "retained_rank": retained_rank,
        "training_energy": training_energy,
        "validation_energy": energy,
        "validation_stderr": stderr,
        "training_ess": training_ess,
        "training_ess_fraction": training_fraction,
        "validation_ess": validation_ess,
        "validation_ess_fraction": validation_fraction,
        "acceptance": acceptance,
        "channel_labels": labels,
        "coefficients_real": np.real(coefficients / scales).tolist(),
        "coefficients_imag": np.imag(coefficients / scales).tolist(),
        "runtime_seconds": time.perf_counter() - start_time,
    }
    print(
        f"N={particles} rank={retained_rank}/{len(labels)} "
        f"E0(train)={training_energy:.9f} "
        f"E0(valid)={energy:.9f}+/-{stderr:.2e} "
        f"ESS(valid)={validation_fraction:.3f} "
        f"time={result['runtime_seconds']:.1f}s",
        flush=True,
    )
    return result


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="8")
    parser.add_argument("--lmax", type=int, choices=(2, 3, 4), default=4)
    parser.add_argument("--chains", type=int, default=256)
    parser.add_argument("--burn-sweeps", type=int, default=500)
    parser.add_argument("--records", type=int, default=64)
    parser.add_argument("--training-records", type=int, default=32)
    parser.add_argument("--thin-sweeps", type=int, default=5)
    parser.add_argument("--feature-batch", type=int, default=64)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-7)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/strict_first_quantized_scalar_nqs"),
    )
    return parser.parse_args()


def main():
    arguments = parse_args()
    if not 0 < arguments.training_records < arguments.records:
        raise ValueError("training-records must be between 0 and records")
    sizes = parse_sizes(arguments.sizes)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        f"strict coordinate scalar-NQS VMC/SR: "
        f"sizes={sizes}, lmax={arguments.lmax}",
        flush=True,
    )
    results = [estimate_one_size(arguments, particles) for particles in sizes]
    payload = {
        "method": (
            "strict first-quantized LLL-SU(2) scalar NQS; "
            "VMC linear method/SR"
        ),
        "symmetry": {
            "L2": 0.0,
            "status": "exact by CG scalar construction",
        },
        "devices": [str(device) for device in jax.devices()],
        "arguments": {
            **vars(arguments),
            "output_dir": str(arguments.output_dir),
        },
        "results": results,
    }
    (arguments.output_dir / "results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(f"wrote {arguments.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
