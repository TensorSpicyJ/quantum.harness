#!/usr/bin/env python3
"""Independent Laughlin VMC baseline and paired first-quantized NQS comparison.

The Hamiltonian and geometry are intentionally imported from the existing
strict first-quantized implementation:

    * Haldane sphere at 2Q = 3(N - 1);
    * fermionic nu=1/3 Laughlin probability density;
    * electron-electron Coulomb energy in e^2/(epsilon l_B);
    * no neutralizing-background constant.

For a strict first-quantized result, the trained state is

    Psi_NQS = Psi_Laughlin * sum_a c_a F_a.

Consequently, both energies can be evaluated on the same fresh Laughlin
samples.  A delete-one-chain jackknife then estimates the uncertainty of the
paired difference E_NQS - E_Laughlin, retaining their covariance.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from strict_first_quantized_hmc import collect_hmc_samples
from strict_first_quantized_streaming import (
    make_streaming_scalar_feature_function,
)
from strict_first_quantized_tensor_nqs import (
    collect_laughlin_samples,
    parse_sizes,
)


def delete_one_chain_ratio(
    numerator_by_chain: np.ndarray,
    denominator_by_chain: np.ndarray,
) -> tuple[float, float, np.ndarray]:
    """Return full ratio, delete-one-chain standard error, and replicates."""

    numerator_by_chain = np.asarray(numerator_by_chain, dtype=np.float64)
    denominator_by_chain = np.asarray(denominator_by_chain, dtype=np.float64)
    if numerator_by_chain.ndim != 1:
        raise ValueError("numerator_by_chain must be one-dimensional")
    if numerator_by_chain.shape != denominator_by_chain.shape:
        raise ValueError("numerator and denominator shapes differ")
    chains = numerator_by_chain.size
    if chains < 2:
        raise ValueError("at least two independent chains are required")
    numerator = float(np.sum(numerator_by_chain))
    denominator = float(np.sum(denominator_by_chain))
    if not denominator > 0.0:
        raise ValueError("non-positive total denominator")
    leave_numerator = numerator - numerator_by_chain
    leave_denominator = denominator - denominator_by_chain
    if np.any(leave_denominator <= 0.0):
        raise ValueError("non-positive leave-one-chain denominator")
    replicates = leave_numerator / leave_denominator
    center = float(np.mean(replicates))
    stderr = math.sqrt(
        (chains - 1.0)
        / chains
        * float(np.sum(np.square(replicates - center)))
    )
    return numerator / denominator, stderr, replicates


def paired_statistics(
    potential: np.ndarray,
    weight: np.ndarray,
    records: int,
    chains: int,
) -> dict[str, float]:
    """Estimate Laughlin, NQS, and their paired difference."""

    potential = np.asarray(potential, dtype=np.float64).reshape(records, chains)
    weight = np.asarray(weight, dtype=np.float64).reshape(records, chains)
    if np.any(~np.isfinite(potential)) or np.any(~np.isfinite(weight)):
        raise ValueError("non-finite potential or weight")
    if np.any(weight < 0.0):
        raise ValueError("negative importance weight")

    laughlin_num = np.sum(potential, axis=0)
    laughlin_den = np.full(chains, records, dtype=np.float64)
    nqs_num = np.sum(weight * potential, axis=0)
    nqs_den = np.sum(weight, axis=0)

    laughlin, laughlin_stderr, laughlin_loo = delete_one_chain_ratio(
        laughlin_num, laughlin_den
    )
    nqs, nqs_stderr, nqs_loo = delete_one_chain_ratio(nqs_num, nqs_den)
    difference = nqs - laughlin
    difference_loo = nqs_loo - laughlin_loo
    difference_center = float(np.mean(difference_loo))
    difference_stderr = math.sqrt(
        (chains - 1.0)
        / chains
        * float(
            np.sum(np.square(difference_loo - difference_center))
        )
    )
    total_weight = float(np.sum(weight))
    ess = total_weight**2 / float(np.sum(np.square(weight)))
    z_lower = (
        -difference / difference_stderr
        if difference_stderr > 0.0
        else math.inf
    )
    return {
        "laughlin_energy": laughlin,
        "laughlin_stderr": laughlin_stderr,
        "nqs_energy": nqs,
        "nqs_stderr": nqs_stderr,
        "difference_nqs_minus_laughlin": difference,
        "difference_stderr_paired": difference_stderr,
        "z_score_nqs_lower": z_lower,
        "nqs_lower_at_2sigma": bool(
            difference + 2.0 * difference_stderr < 0.0
        ),
        "importance_ess": ess,
        "importance_ess_fraction": ess / weight.size,
    }


def evaluate_features(
    function: Any,
    coordinates: np.ndarray,
    batch_size: int,
) -> np.ndarray:
    output: list[np.ndarray] = []
    for start in range(0, len(coordinates), batch_size):
        batch = jnp.asarray(coordinates[start : start + batch_size])
        output.append(np.asarray(jax.device_get(function(batch))))
    return np.concatenate(output, axis=0)


def load_first_quantized_results(
    paths: list[Path],
    selected_sizes: set[int],
) -> list[dict[str, Any]]:
    loaded: list[dict[str, Any]] = []
    for path in paths:
        payload = json.loads(path.read_text(encoding="utf-8"))
        lmax = int(payload["arguments"]["lmax"])
        for result in payload["results"]:
            particles = int(result["particles"])
            if particles not in selected_sizes:
                continue
            ground = result["ground"]
            coefficients = np.asarray(
                ground["coefficients_real"], dtype=np.float64
            ) + 1.0j * np.asarray(
                ground["coefficients_imag"], dtype=np.float64
            )
            loaded.append(
                {
                    "source": str(path),
                    "run": path.parent.name,
                    "particles": particles,
                    "lmax": lmax,
                    "coefficients": coefficients,
                    "reported_energy": float(ground["validation_energy"]),
                    "reported_stderr": float(ground["validation_stderr"]),
                    "reported_l2": float(ground["L2"]),
                    "retained_rank": int(ground["retained_rank"]),
                }
            )
    return loaded


def collect_reference(
    arguments: argparse.Namespace,
    particles: int,
) -> tuple[np.ndarray, np.ndarray, float, dict[str, Any]]:
    if arguments.sampler == "hmc":
        coordinates, potential, acceptance, diagnostics = collect_hmc_samples(
            particles,
            arguments.chains,
            arguments.hmc_burn,
            arguments.records,
            arguments.hmc_thin,
            arguments.hmc_step_size,
            arguments.hmc_leapfrog_steps,
            arguments.seed + particles,
            "laughlin",
            arguments.hmc_target_acceptance,
        )
        return coordinates, potential, acceptance, diagnostics
    coordinates, potential, acceptance = collect_laughlin_samples(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        arguments.seed + particles,
    )
    return coordinates, potential, acceptance, {
        "sampler": "local_random_walk_metropolis"
    }


def pure_laughlin_statistics(
    potential: np.ndarray,
    records: int,
    chains: int,
) -> dict[str, float]:
    unit_weight = np.ones_like(potential, dtype=np.float64)
    result = paired_statistics(potential, unit_weight, records, chains)
    return {
        "energy": result["laughlin_energy"],
        "stderr": result["laughlin_stderr"],
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    scalar_rows: list[dict[str, Any]] = []
    for row in rows:
        scalar_rows.append(
            {
                key: value
                for key, value in row.items()
                if not isinstance(value, (dict, list, tuple))
            }
        )
    fieldnames: list[str] = []
    for row in scalar_rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(scalar_rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="8,9,10,20,30,40")
    parser.add_argument(
        "--first-nqs-results",
        type=Path,
        nargs="*",
        default=[],
        help="strict first-quantized results.json files",
    )
    parser.add_argument(
        "--sampler", choices=("metropolis", "hmc"), default="metropolis"
    )
    parser.add_argument("--chains", type=int, default=128)
    parser.add_argument("--records", type=int, default=64)
    parser.add_argument("--burn-sweeps", type=int, default=750)
    parser.add_argument("--thin-sweeps", type=int, default=8)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument("--hmc-burn", type=int, default=120)
    parser.add_argument("--hmc-thin", type=int, default=2)
    parser.add_argument("--hmc-step-size", type=float, default=0.01)
    parser.add_argument("--hmc-leapfrog-steps", type=int, default=12)
    parser.add_argument("--hmc-target-acceptance", type=float, default=0.65)
    parser.add_argument("--feature-batch", type=int, default=16)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/laughlin_vmc_comparison"),
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    sizes = parse_sizes(arguments.sizes)
    selected_sizes = set(sizes)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    first_results = load_first_quantized_results(
        arguments.first_nqs_results, selected_sizes
    )
    by_size: dict[int, list[dict[str, Any]]] = {size: [] for size in sizes}
    for result in first_results:
        by_size[result["particles"]].append(result)

    pure_rows: list[dict[str, Any]] = []
    paired_rows: list[dict[str, Any]] = []
    started_all = time.perf_counter()
    for particles in sizes:
        started = time.perf_counter()
        print(f"N={particles}: collecting fresh Laughlin samples", flush=True)
        coordinates, potential, acceptance, diagnostics = collect_reference(
            arguments, particles
        )
        pure = pure_laughlin_statistics(
            potential, arguments.records, arguments.chains
        )
        pure_row = {
            "particles": particles,
            "two_q": 3 * (particles - 1),
            "energy": pure["energy"],
            "stderr": pure["stderr"],
            "energy_per_particle": pure["energy"] / particles,
            "stderr_per_particle": pure["stderr"] / particles,
            "samples": int(len(potential)),
            "chains": arguments.chains,
            "records": arguments.records,
            "acceptance": float(acceptance),
            "sampler": arguments.sampler,
            "runtime_seconds": time.perf_counter() - started,
            "sampler_diagnostics": diagnostics,
        }
        pure_rows.append(pure_row)
        print(
            f"N={particles}: E_L={pure['energy']:.9f}"
            f" +/- {pure['stderr']:.2e}",
            flush=True,
        )

        feature_cache: dict[int, np.ndarray] = {}
        for result in by_size[particles]:
            lmax = result["lmax"]
            if lmax not in feature_cache:
                function, labels = make_streaming_scalar_feature_function(
                    particles, lmax
                )
                features = evaluate_features(
                    function,
                    coordinates,
                    arguments.feature_batch,
                )
                feature_cache[lmax] = features
                if features.shape[1] != len(labels):
                    raise RuntimeError("feature label/count mismatch")
            features = feature_cache[lmax]
            coefficients = result["coefficients"]
            if features.shape[1] != coefficients.size:
                raise ValueError(
                    f"{result['run']}: {features.shape[1]} features but "
                    f"{coefficients.size} coefficients"
                )
            amplitude_ratio = features @ coefficients
            weight = np.square(np.abs(amplitude_ratio))
            statistics = paired_statistics(
                potential, weight, arguments.records, arguments.chains
            )
            row = {
                "run": result["run"],
                "source": result["source"],
                "particles": particles,
                "two_q": 3 * (particles - 1),
                "lmax": lmax,
                "retained_rank": result["retained_rank"],
                "reported_nqs_energy": result["reported_energy"],
                "reported_nqs_stderr": result["reported_stderr"],
                "reported_l2": result["reported_l2"],
                **statistics,
                "difference_per_particle": (
                    statistics["difference_nqs_minus_laughlin"] / particles
                ),
                "difference_stderr_per_particle": (
                    statistics["difference_stderr_paired"] / particles
                ),
                "fresh_minus_reported_nqs": (
                    statistics["nqs_energy"] - result["reported_energy"]
                ),
            }
            paired_rows.append(row)
            print(
                f"N={particles} {result['run']}: "
                f"E_NQS-E_L={row['difference_nqs_minus_laughlin']:.9f}"
                f" +/- {row['difference_stderr_paired']:.2e}, "
                f"z_lower={row['z_score_nqs_lower']:.2f}, "
                f"ESS={row['importance_ess_fraction']:.3f}",
                flush=True,
            )

    payload = {
        "method": (
            "fresh Laughlin VMC plus paired importance reweighting for strict "
            "first-quantized NQS"
        ),
        "geometry": "Haldane sphere",
        "flux": "2Q=3(N-1)",
        "hamiltonian": (
            "electron-electron Coulomb only; no neutralizing-background "
            "constant"
        ),
        "energy_units": "e^2/(epsilon l_B)",
        "devices": [str(device) for device in jax.devices()],
        "arguments": {
            **vars(arguments),
            "first_nqs_results": [
                str(path) for path in arguments.first_nqs_results
            ],
            "output_dir": str(arguments.output_dir),
        },
        "laughlin": pure_rows,
        "first_quantized_paired": paired_rows,
        "runtime_seconds": time.perf_counter() - started_all,
    }
    (arguments.output_dir / "results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    write_csv(arguments.output_dir / "laughlin.csv", pure_rows)
    write_csv(arguments.output_dir / "first_quantized_paired.csv", paired_rows)
    print(f"wrote {arguments.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
