#!/usr/bin/env python3
"""Tests for the geodesic spherical HMC sampler."""

from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np

from strict_first_quantized_hmc import (
    _geodesic_step,
    random_unit_vectors,
    vectors_to_spinors,
)


def test_spinor_chord_identity() -> None:
    vectors = random_unit_vectors(jax.random.PRNGKey(1), 4, 7)
    spinors = vectors_to_spinors(vectors)
    u = spinors[..., 0]
    v = spinors[..., 1]
    determinant = (
        u[:, :, None] * v[:, None, :]
        - v[:, :, None] * u[:, None, :]
    )
    spinor_chord = np.square(np.abs(np.asarray(determinant)))
    vector_chord = np.asarray(
        0.5
        * (
            1.0
            - jnp.einsum("cik,cjk->cij", vectors, vectors)
        )
    )
    mask = np.broadcast_to(
        ~np.eye(vectors.shape[1], dtype=bool)[None, :, :],
        spinor_chord.shape,
    )
    assert np.max(np.abs(spinor_chord[mask] - vector_chord[mask])) < 1e-12


def test_geodesic_preserves_constraints_and_is_reversible() -> None:
    vectors = random_unit_vectors(jax.random.PRNGKey(2), 3, 5)
    raw = jax.random.normal(jax.random.PRNGKey(3), vectors.shape)
    momenta = raw - jnp.sum(raw * vectors, axis=-1, keepdims=True) * vectors
    moved_vectors, moved_momenta = _geodesic_step(
        vectors, momenta, jnp.asarray(0.07)
    )
    assert np.max(
        np.abs(np.asarray(jnp.linalg.norm(moved_vectors, axis=-1)) - 1.0)
    ) < 1e-12
    assert np.max(
        np.abs(np.asarray(jnp.sum(moved_vectors * moved_momenta, axis=-1)))
    ) < 1e-12
    restored_vectors, restored_momenta = _geodesic_step(
        moved_vectors, -moved_momenta, jnp.asarray(0.07)
    )
    assert np.max(np.abs(np.asarray(restored_vectors - vectors))) < 1e-12
    assert np.max(np.abs(np.asarray(restored_momenta + momenta))) < 1e-12


if __name__ == "__main__":
    test_spinor_chord_identity()
    test_geodesic_preserves_constraints_and_is_reversible()
    print("strict first-quantized HMC tests passed")
