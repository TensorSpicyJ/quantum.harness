#!/usr/bin/env python3
"""First-quantized coordinate VMC for the nu=1/3 Haldane-sphere graviton.

This is a strict-LLL, exact-SU(2) benchmark implementation of the ansatz

    Psi_0       = sum_a A_a B_a^(0) Psi_Laughlin
    Psi_2,M     = sum_(t,a) C_(t,a) T_(t,M)^(2) B_a^(0) Psi_Laughlin
    C_(t,a)     = sum_(r=1)^R X_(t,r) Y_(r,a).

The scalar and rank-2 operator channels are compiled once in the normalized
monopole-harmonic Slater basis.  The variational calculation itself is first
quantized: walkers are continuous electron coordinates on S^2, amplitudes are
evaluated as holomorphic monopole-harmonic polynomials, and the Coulomb energy
is sampled directly from |Psi(Omega_1,...,Omega_N)|^2.

The offline Fock compilation makes exact ED and second-quantized NQS
comparisons unambiguous for N <= 7.  It is intentionally a validation bridge,
not yet the final scalable spinor-differential implementation.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path
from typing import Callable, NamedTuple

import numpy as np

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import optax

from chiral_graviton_ed import (
    angular_momentum_squared,
    antisymmetric_pair_matrix,
    interaction_pseudopotentials,
    many_body_hamiltonian,
    raising_operator,
)
from chiral_graviton_nqs_vmc import (
    SectorCache,
    TensorHeadTerm,
    exact_observables,
    lowest_labeled_state,
    overlap,
    rank2_operator,
)
from chiral_graviton_nqs_vmc_v2 import (
    build_scalar_backbone,
    projected_ground_state,
    raw_tensor_features,
    tensor_head_terms,
    whiten_features,
)


jax.config.update("jax_enable_x64", True)


Array = np.ndarray
JaxArray = jax.Array


class CompiledSystem(NamedTuple):
    particles: int
    two_q: int
    cache: SectorCache
    occupations0: Array
    occupations2: Array
    scalar_features: Array
    tensor_features2: Array
    tensor_scales: Array
    tensor_terms: list[TensorHeadTerm]
    laughlin: Array
    sma: Array
    H0: Array
    H2: Array
    L20: Array
    L22: Array
    exact_E0: float
    exact_E2: float
    exact_ground: Array
    exact_excited: Array
    projected_E0: float
    projected_E2: float
    scalar_diagnostics: dict[str, object]
    tensor_diagnostics: dict[str, object]


def occupations_from_basis(basis: list[int], norbitals: int, particles: int) -> Array:
    occupations = np.empty((len(basis), particles), dtype=np.int32)
    for row, state in enumerate(basis):
        occupied = [index for index in range(norbitals) if (state >> index) & 1]
        if len(occupied) != particles:
            raise RuntimeError("basis state has the wrong particle number")
        occupations[row] = occupied
    return occupations


def compile_system(
    particles: int,
    lmax: int,
    scalar_depth: int,
    whitening_tolerance: float,
) -> CompiledSystem:
    """Compile exact LLL scalar/tensor channels and ED references."""

    two_q = 3 * (particles - 1)
    cache = SectorCache(particles, two_q)
    basis0 = cache.basis(0)
    basis2 = cache.basis(2)
    norbitals = two_q + 1

    coulomb_pp = interaction_pseudopotentials(two_q, "coulomb")
    pairs, coulomb_pair_matrix = antisymmetric_pair_matrix(two_q, coulomb_pp)
    H0 = many_body_hamiltonian(basis0, pairs, coulomb_pair_matrix, two_q)
    H2 = many_body_hamiltonian(basis2, pairs, coulomb_pair_matrix, two_q)

    v1_pp = interaction_pseudopotentials(two_q, "v1")
    _, v1_pair_matrix = antisymmetric_pair_matrix(two_q, v1_pp)
    H_v1 = many_body_hamiltonian(basis0, pairs, v1_pair_matrix, two_q)
    v1_energies, v1_vectors = np.linalg.eigh(H_v1)
    if abs(v1_energies[0]) > 1.0e-9:
        raise RuntimeError(f"V1 Laughlin seed is not a zero mode: {v1_energies[0]}")
    laughlin = v1_vectors[:, 0]
    laughlin *= np.sign(laughlin[np.argmax(np.abs(laughlin))])

    L20 = angular_momentum_squared(basis0, particles, two_q, 0)
    L22 = angular_momentum_squared(basis2, particles, two_q, 2)
    exact_E0, exact_ground = lowest_labeled_state(H0, L20, 0)
    exact_E2, exact_excited = lowest_labeled_state(H2, L22, 2)

    scalar_features, _, scalar_diagnostics = build_scalar_backbone(
        cache, laughlin, lmax, scalar_depth
    )
    terms = tensor_head_terms(lmax)
    raw_tensor2 = raw_tensor_features(cache, scalar_features, terms, 2)
    n_scalar = scalar_features.shape[1]
    tensor_features2 = raw_tensor2.reshape(
        len(basis2), len(terms), n_scalar
    )
    tensor_scales = np.linalg.norm(tensor_features2, axis=0)
    nonzero = tensor_scales > max(float(tensor_scales.max(initial=0.0)), 1.0) * 1.0e-13
    safe_scales = np.where(nonzero, tensor_scales, 1.0)
    tensor_features2 = tensor_features2 / safe_scales[None, :, :]
    tensor_features2[:, ~nonzero] = 0.0

    flat_tensor = tensor_features2.reshape(len(basis2), -1)
    whitened_tensor, _, tensor_diagnostics = whiten_features(
        flat_tensor, relative_tolerance=whitening_tolerance
    )
    projected_E0, _, _ = projected_ground_state(H0, scalar_features)
    projected_E2, _, _ = projected_ground_state(H2, whitened_tensor)

    sma = rank2_operator(
        cache, TensorHeadTerm("rho_2", 2, 0, linear=True), 2
    ) @ laughlin

    return CompiledSystem(
        particles=particles,
        two_q=two_q,
        cache=cache,
        occupations0=occupations_from_basis(basis0, norbitals, particles),
        occupations2=occupations_from_basis(basis2, norbitals, particles),
        scalar_features=scalar_features,
        tensor_features2=tensor_features2,
        tensor_scales=safe_scales,
        tensor_terms=terms,
        laughlin=laughlin,
        sma=sma,
        H0=H0,
        H2=H2,
        L20=L20,
        L22=L22,
        exact_E0=exact_E0,
        exact_E2=exact_E2,
        exact_ground=exact_ground,
        exact_excited=exact_excited,
        projected_E0=projected_E0,
        projected_E2=projected_E2,
        scalar_diagnostics=scalar_diagnostics,
        tensor_diagnostics=tensor_diagnostics,
    )


def orbital_normalizations(two_q: int) -> Array:
    return np.asarray(
        [
            math.sqrt(
                (two_q + 1)
                / (4.0 * math.pi)
                * math.comb(two_q, power_u)
            )
            for power_u in range(two_q + 1)
        ],
        dtype=np.float64,
    )


def spinors_from_cartesian(xyz: JaxArray) -> tuple[JaxArray, JaxArray]:
    """Return the north-gauge spinors used by the ED orbital convention."""

    z = jnp.clip(xyz[..., 2], -1.0, 1.0)
    phi = jnp.arctan2(xyz[..., 1], xyz[..., 0])
    u = jnp.sqrt(jnp.maximum((1.0 + z) * 0.5, 0.0)) * jnp.exp(0.5j * phi)
    v = jnp.sqrt(jnp.maximum((1.0 - z) * 0.5, 0.0)) * jnp.exp(-0.5j * phi)
    return u, v


def monopole_orbitals(
    xyz: JaxArray,
    two_q: int,
    normalizations: JaxArray,
) -> JaxArray:
    u, v = spinors_from_cartesian(xyz)
    powers_u = jnp.arange(two_q + 1)
    powers_v = two_q - powers_u
    return (
        normalizations[None, None, :]
        * u[..., None] ** powers_u[None, None, :]
        * v[..., None] ** powers_v[None, None, :]
    )


def determinant_expansion(
    orbitals: JaxArray,
    occupations: JaxArray,
    coefficients: JaxArray,
    determinant_chunk: int,
) -> JaxArray:
    """Evaluate a CI expansion while bounding the peak determinant tensor."""

    walkers, particles, _ = orbitals.shape
    determinant_count = occupations.shape[0]
    chunks = (determinant_count + determinant_chunk - 1) // determinant_chunk
    padded_count = chunks * determinant_chunk
    occupation_padding = padded_count - determinant_count
    occupations_padded = jnp.pad(
        occupations,
        ((0, occupation_padding), (0, 0)),
        mode="constant",
    )
    coefficients_padded = jnp.pad(
        coefficients,
        ((0, occupation_padding),),
        mode="constant",
    )

    def body(chunk_index: int, total: JaxArray) -> JaxArray:
        start = chunk_index * determinant_chunk
        occupied = jax.lax.dynamic_slice(
            occupations_padded,
            (start, 0),
            (determinant_chunk, particles),
        )
        chunk_coefficients = jax.lax.dynamic_slice(
            coefficients_padded,
            (start,),
            (determinant_chunk,),
        )
        matrices = jnp.take(orbitals, occupied, axis=2)
        matrices = jnp.transpose(matrices, (0, 2, 1, 3))
        determinants = jnp.linalg.det(matrices)
        return total + determinants @ chunk_coefficients.astype(determinants.dtype)

    initial = jnp.zeros((walkers,), dtype=orbitals.dtype)
    return jax.lax.fori_loop(0, chunks, body, initial)


def normalized_state_coefficients(
    parameters: dict[str, JaxArray],
    scalar_features: JaxArray,
    tensor_features2: JaxArray,
) -> tuple[JaxArray, JaxArray]:
    ground = scalar_features @ parameters["ground"]
    ground = ground / jnp.maximum(jnp.linalg.norm(ground), 1.0e-300)
    channel_matrix = parameters["tensor_left"] @ parameters["tensor_right"]
    excited = jnp.einsum("dta,ta->d", tensor_features2, channel_matrix)
    excited = excited / jnp.maximum(jnp.linalg.norm(excited), 1.0e-300)
    return ground, excited


def coulomb_potential(xyz: JaxArray, two_q: int) -> JaxArray:
    """Chord-distance Coulomb energy in e^2/(epsilon l_B)."""

    q = 0.5 * two_q
    dot = jnp.einsum("wia,wja->wij", xyz, xyz)
    particles = xyz.shape[1]
    i, j = jnp.triu_indices(particles, k=1)
    chord = jnp.sqrt(q) * jnp.sqrt(jnp.maximum(2.0 - 2.0 * dot[:, i, j], 1.0e-24))
    return jnp.sum(1.0 / chord, axis=1)


def random_sphere(key: JaxArray, walkers: int, particles: int) -> JaxArray:
    xyz = jax.random.normal(key, (walkers, particles, 3), dtype=jnp.float64)
    return xyz / jnp.linalg.norm(xyz, axis=-1, keepdims=True)


def propose_particle(
    key: JaxArray,
    xyz: JaxArray,
    particle: JaxArray,
    proposal_scale: float,
) -> JaxArray:
    """Symmetric isotropic geodesic proposal for one electron per walker."""

    key_tangent, key_angle = jax.random.split(key)
    current = xyz[:, particle, :]
    noise = jax.random.normal(key_tangent, current.shape, dtype=jnp.float64)
    tangent = noise - jnp.sum(noise * current, axis=1, keepdims=True) * current
    tangent_norm = jnp.maximum(jnp.linalg.norm(tangent, axis=1, keepdims=True), 1.0e-14)
    direction = tangent / tangent_norm
    angle = proposal_scale * jax.random.normal(
        key_angle, (xyz.shape[0], 1), dtype=jnp.float64
    )
    proposed = jnp.cos(angle) * current + jnp.sin(angle) * direction
    return xyz.at[:, particle, :].set(proposed)


def make_coordinate_functions(
    compiled: CompiledSystem,
    determinant_chunk: int,
) -> tuple[
    Callable[[dict[str, JaxArray], JaxArray], JaxArray],
    Callable[[dict[str, JaxArray], JaxArray], JaxArray],
]:
    normalizations = jax.device_put(jnp.asarray(orbital_normalizations(compiled.two_q)))
    occupations0 = jax.device_put(jnp.asarray(compiled.occupations0))
    occupations2 = jax.device_put(jnp.asarray(compiled.occupations2))
    scalar_features = jax.device_put(jnp.asarray(compiled.scalar_features))
    tensor_features2 = jax.device_put(jnp.asarray(compiled.tensor_features2))

    def coefficients(
        parameters: dict[str, JaxArray],
    ) -> tuple[JaxArray, JaxArray]:
        return normalized_state_coefficients(
            parameters, scalar_features, tensor_features2
        )

    def ground_logabs(
        parameters: dict[str, JaxArray], xyz: JaxArray
    ) -> JaxArray:
        ground, _ = coefficients(parameters)
        orbitals = monopole_orbitals(xyz, compiled.two_q, normalizations)
        amplitude = determinant_expansion(
            orbitals, occupations0, ground, determinant_chunk
        )
        return jnp.log(jnp.maximum(jnp.abs(amplitude), 1.0e-300))

    def excited_logabs(
        parameters: dict[str, JaxArray], xyz: JaxArray
    ) -> JaxArray:
        _, excited = coefficients(parameters)
        orbitals = monopole_orbitals(xyz, compiled.two_q, normalizations)
        amplitude = determinant_expansion(
            orbitals, occupations2, excited, determinant_chunk
        )
        return jnp.log(jnp.maximum(jnp.abs(amplitude), 1.0e-300))

    return ground_logabs, excited_logabs


def initialize_parameters(
    compiled: CompiledSystem,
    channel_rank: int,
    seed: int,
) -> dict[str, Array]:
    rng = np.random.default_rng(seed)
    ground = compiled.scalar_features.T @ compiled.laughlin
    ground /= np.linalg.norm(ground)
    n_terms = len(compiled.tensor_terms)
    n_scalar = compiled.scalar_features.shape[1]
    left = 1.0e-3 * rng.normal(size=(n_terms, channel_rank))
    right = 1.0e-3 * rng.normal(size=(channel_rank, n_scalar))
    left[0, 0] = 1.0
    right[0] = ground * compiled.tensor_scales[0]
    return {
        "ground": ground,
        "tensor_left": left,
        "tensor_right": right,
    }


def normalize_parameter_gauges(
    parameters: dict[str, JaxArray],
) -> dict[str, JaxArray]:
    return {
        "ground": parameters["ground"]
        / jnp.maximum(jnp.linalg.norm(parameters["ground"]), 1.0e-300),
        "tensor_left": parameters["tensor_left"]
        / jnp.maximum(jnp.linalg.norm(parameters["tensor_left"]), 1.0e-300),
        "tensor_right": parameters["tensor_right"]
        / jnp.maximum(jnp.linalg.norm(parameters["tensor_right"]), 1.0e-300),
    }


def host_coefficients(
    parameters: dict[str, Array],
    compiled: CompiledSystem,
) -> tuple[Array, Array]:
    ground = compiled.scalar_features @ parameters["ground"]
    ground /= np.linalg.norm(ground)
    channel_matrix = parameters["tensor_left"] @ parameters["tensor_right"]
    excited = np.einsum("dta,ta->d", compiled.tensor_features2, channel_matrix)
    excited /= np.linalg.norm(excited)
    return ground, excited


def parameter_payload(parameters: dict[str, JaxArray]) -> dict[str, Array]:
    return {
        name: np.asarray(jax.device_get(value))
        for name, value in parameters.items()
    }


def coordinate_exchange_residual(
    logabs_function: Callable[[dict[str, JaxArray], JaxArray], JaxArray],
    parameters: dict[str, JaxArray],
    xyz: JaxArray,
) -> float:
    original = logabs_function(parameters, xyz[:16])
    swapped_xyz = xyz[:16].at[:, 0, :].set(xyz[:16, 1, :])
    swapped_xyz = swapped_xyz.at[:, 1, :].set(xyz[:16, 0, :])
    swapped = logabs_function(parameters, swapped_xyz)
    # log|Psi| is exchange invariant; the determinant supplies the minus sign.
    return float(jnp.max(jnp.abs(original - swapped)))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-N", "--particles", type=int, default=6)
    parser.add_argument("--lmax", type=int, default=4)
    parser.add_argument("--scalar-depth", type=int, choices=(1, 2, 3), default=2)
    parser.add_argument("--channel-rank", type=int, default=3)
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--walkers", type=int, default=256)
    parser.add_argument("--burn-in", type=int, default=200)
    parser.add_argument("--moves-per-step", type=int, default=2)
    parser.add_argument("--eval-burn-in", type=int, default=100)
    parser.add_argument("--eval-steps", type=int, default=200)
    parser.add_argument("--learning-rate", type=float, default=2.0e-3)
    parser.add_argument("--proposal-scale", type=float, default=0.35)
    parser.add_argument("--determinant-chunk", type=int, default=128)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-11)
    parser.add_argument("--seed", type=int, default=20260729)
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/first_quantized_nqs_N6"),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not 2 <= args.particles <= 7:
        raise ValueError("this dense validation bridge supports 2 <= N <= 7")
    if args.channel_rank < 1:
        raise ValueError("channel rank must be positive")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()

    print(f"JAX devices: {jax.devices()}", flush=True)
    compiled = compile_system(
        args.particles,
        args.lmax,
        args.scalar_depth,
        args.whitening_tolerance,
    )
    print(
        f"N={args.particles}, 2Q={compiled.two_q}, "
        f"dim(M=0)={len(compiled.occupations0)}, "
        f"dim(M=2)={len(compiled.occupations2)}, "
        f"scalar rank={compiled.scalar_features.shape[1]}, "
        f"tensor terms={len(compiled.tensor_terms)}",
        flush=True,
    )
    print(
        f"full-channel subspace: E0={compiled.projected_E0:.12f}, "
        f"E2={compiled.projected_E2:.12f}, "
        f"gap={compiled.projected_E2-compiled.projected_E0:.12f}",
        flush=True,
    )

    initial_host = initialize_parameters(compiled, args.channel_rank, args.seed)
    parameters = {
        name: jax.device_put(jnp.asarray(value))
        for name, value in initial_host.items()
    }
    ground_logabs_raw, excited_logabs_raw = make_coordinate_functions(
        compiled, args.determinant_chunk
    )
    ground_logabs = jax.jit(ground_logabs_raw)
    excited_logabs = jax.jit(excited_logabs_raw)

    @jax.jit
    def move_ground(
        parameters: dict[str, JaxArray],
        xyz: JaxArray,
        logabs: JaxArray,
        key: JaxArray,
        particle: JaxArray,
    ) -> tuple[JaxArray, JaxArray, JaxArray]:
        proposal_key, accept_key = jax.random.split(key)
        proposed = propose_particle(
            proposal_key, xyz, particle, args.proposal_scale
        )
        proposed_logabs = ground_logabs_raw(parameters, proposed)
        accept = jnp.log(jax.random.uniform(accept_key, (xyz.shape[0],))) < (
            2.0 * (proposed_logabs - logabs)
        )
        xyz = jnp.where(accept[:, None, None], proposed, xyz)
        logabs = jnp.where(accept, proposed_logabs, logabs)
        return xyz, logabs, jnp.mean(accept)

    @jax.jit
    def move_excited(
        parameters: dict[str, JaxArray],
        xyz: JaxArray,
        logabs: JaxArray,
        key: JaxArray,
        particle: JaxArray,
    ) -> tuple[JaxArray, JaxArray, JaxArray]:
        proposal_key, accept_key = jax.random.split(key)
        proposed = propose_particle(
            proposal_key, xyz, particle, args.proposal_scale
        )
        proposed_logabs = excited_logabs_raw(parameters, proposed)
        accept = jnp.log(jax.random.uniform(accept_key, (xyz.shape[0],))) < (
            2.0 * (proposed_logabs - logabs)
        )
        xyz = jnp.where(accept[:, None, None], proposed, xyz)
        logabs = jnp.where(accept, proposed_logabs, logabs)
        return xyz, logabs, jnp.mean(accept)

    def loss(
        values: dict[str, JaxArray],
        xyz0: JaxArray,
        xyz2: JaxArray,
    ) -> tuple[JaxArray, tuple[JaxArray, JaxArray, JaxArray, JaxArray]]:
        log0 = ground_logabs_raw(values, xyz0)
        log2 = excited_logabs_raw(values, xyz2)
        potential0 = coulomb_potential(xyz0, compiled.two_q)
        potential2 = coulomb_potential(xyz2, compiled.two_q)
        energy0 = jnp.mean(potential0)
        energy2 = jnp.mean(potential2)
        centered0 = jax.lax.stop_gradient(potential0 - energy0)
        centered2 = jax.lax.stop_gradient(potential2 - energy2)
        surrogate0 = jnp.mean(2.0 * centered0 * log0)
        surrogate2 = jnp.mean(2.0 * centered2 * log2)
        surrogate = 0.5 * (surrogate0 + surrogate2)
        return surrogate, (
            energy0,
            energy2,
            jnp.var(potential0),
            jnp.var(potential2),
        )

    schedule = optax.cosine_decay_schedule(
        args.learning_rate, max(args.steps, 1), alpha=0.1
    )
    optimizer = optax.chain(
        optax.clip_by_global_norm(10.0),
        optax.adam(schedule),
    )
    optimizer_state = optimizer.init(parameters)

    @jax.jit
    def update(
        values: dict[str, JaxArray],
        state: optax.OptState,
        xyz0: JaxArray,
        xyz2: JaxArray,
    ):
        (_, diagnostics), gradient = jax.value_and_grad(
            loss, has_aux=True
        )(values, xyz0, xyz2)
        updates, state = optimizer.update(gradient, state, values)
        values = optax.apply_updates(values, updates)
        values = normalize_parameter_gauges(values)
        return values, state, diagnostics

    key = jax.random.PRNGKey(args.seed)
    key, key0, key2 = jax.random.split(key, 3)
    xyz0 = random_sphere(key0, args.walkers, args.particles)
    xyz2 = random_sphere(key2, args.walkers, args.particles)
    logabs0 = ground_logabs(parameters, xyz0)
    logabs2 = excited_logabs(parameters, xyz2)
    jax.block_until_ready(logabs2)

    burn_accept0 = []
    burn_accept2 = []
    for move in range(args.burn_in):
        key, move_key0, move_key2 = jax.random.split(key, 3)
        particle = jnp.asarray(move % args.particles, dtype=jnp.int32)
        xyz0, logabs0, acceptance0 = move_ground(
            parameters, xyz0, logabs0, move_key0, particle
        )
        xyz2, logabs2, acceptance2 = move_excited(
            parameters, xyz2, logabs2, move_key2, particle
        )
        burn_accept0.append(float(acceptance0))
        burn_accept2.append(float(acceptance2))
    print(
        f"burn-in acceptance=({np.mean(burn_accept0):.3f},"
        f"{np.mean(burn_accept2):.3f})",
        flush=True,
    )

    history: list[dict[str, float | int]] = []
    best_score = math.inf
    best_parameters = parameter_payload(parameters)
    for step in range(args.steps):
        accept0 = []
        accept2 = []
        for local_move in range(args.moves_per_step):
            key, move_key0, move_key2 = jax.random.split(key, 3)
            particle = jnp.asarray(
                (step * args.moves_per_step + local_move) % args.particles,
                dtype=jnp.int32,
            )
            xyz0, logabs0, acceptance0 = move_ground(
                parameters, xyz0, logabs0, move_key0, particle
            )
            xyz2, logabs2, acceptance2 = move_excited(
                parameters, xyz2, logabs2, move_key2, particle
            )
            accept0.append(float(acceptance0))
            accept2.append(float(acceptance2))
        parameters, optimizer_state, diagnostics = update(
            parameters, optimizer_state, xyz0, xyz2
        )
        # Parameters changed, so cached amplitudes must be refreshed.
        logabs0 = ground_logabs(parameters, xyz0)
        logabs2 = excited_logabs(parameters, xyz2)

        if step == 0:
            jax.block_until_ready(diagnostics)
        if step % args.log_every == 0 or step == args.steps - 1:
            energy0 = float(diagnostics[0])
            energy2 = float(diagnostics[1])
            row = {
                "step": step,
                "coordinate_E0": energy0,
                "coordinate_E2": energy2,
                "coordinate_gap": energy2 - energy0,
                "potential_variance0": float(diagnostics[2]),
                "potential_variance2": float(diagnostics[3]),
                "acceptance0": float(np.mean(accept0)),
                "acceptance2": float(np.mean(accept2)),
            }
            history.append(row)
            score = 0.5 * (energy0 + energy2)
            if score < best_score:
                best_score = score
                best_parameters = parameter_payload(parameters)
                np.savez_compressed(
                    args.output_dir / "best_checkpoint.npz",
                    **best_parameters,
                    step=step,
                    coordinate_score=score,
                )
            print(
                f"step={step:4d} E0={energy0:.8f} E2={energy2:.8f} "
                f"gap={energy2-energy0:.8f} "
                f"acc=({row['acceptance0']:.3f},{row['acceptance2']:.3f})",
                flush=True,
            )
            (args.output_dir / "history.json").write_text(
                json.dumps(history, indent=2), encoding="utf-8"
            )

    # Use the lowest sampled state-averaged checkpoint, selected without ED.
    parameters = {
        name: jax.device_put(jnp.asarray(value))
        for name, value in best_parameters.items()
    }
    logabs0 = ground_logabs(parameters, xyz0)
    logabs2 = excited_logabs(parameters, xyz2)

    eval_accept0 = []
    eval_accept2 = []
    chain_sum0 = jnp.zeros((args.walkers,), dtype=jnp.float64)
    chain_sum2 = jnp.zeros((args.walkers,), dtype=jnp.float64)
    retained = 0
    total_eval_moves = args.eval_burn_in + args.eval_steps
    for move in range(total_eval_moves):
        key, move_key0, move_key2 = jax.random.split(key, 3)
        particle = jnp.asarray(move % args.particles, dtype=jnp.int32)
        xyz0, logabs0, acceptance0 = move_ground(
            parameters, xyz0, logabs0, move_key0, particle
        )
        xyz2, logabs2, acceptance2 = move_excited(
            parameters, xyz2, logabs2, move_key2, particle
        )
        eval_accept0.append(float(acceptance0))
        eval_accept2.append(float(acceptance2))
        if move >= args.eval_burn_in:
            chain_sum0 = chain_sum0 + coulomb_potential(xyz0, compiled.two_q)
            chain_sum2 = chain_sum2 + coulomb_potential(xyz2, compiled.two_q)
            retained += 1
    chain_means0 = np.asarray(jax.device_get(chain_sum0 / retained))
    chain_means2 = np.asarray(jax.device_get(chain_sum2 / retained))
    mc_E0 = float(chain_means0.mean())
    mc_E2 = float(chain_means2.mean())
    mc_stderr0 = float(chain_means0.std(ddof=1) / math.sqrt(args.walkers))
    mc_stderr2 = float(chain_means2.std(ddof=1) / math.sqrt(args.walkers))

    final_host = parameter_payload(parameters)
    psi0, psi2 = host_coefficients(final_host, compiled)
    observables0 = exact_observables(psi0, compiled.H0, compiled.L20)
    observables2 = exact_observables(psi2, compiled.H2, compiled.L22)

    # Exact SU(2) tower check using the same learned reduced coefficients.
    channel_matrix = (
        final_host["tensor_left"] @ final_host["tensor_right"]
    )
    components: dict[int, Array] = {}
    multiplet: dict[str, dict[str, float]] = {}
    pairs, coulomb_pair_matrix = antisymmetric_pair_matrix(
        compiled.two_q,
        interaction_pseudopotentials(compiled.two_q, "coulomb"),
    )
    for M in range(-2, 3):
        raw_M = raw_tensor_features(
            compiled.cache,
            compiled.scalar_features,
            compiled.tensor_terms,
            M,
        ).reshape(
            len(compiled.cache.basis(M)),
            len(compiled.tensor_terms),
            compiled.scalar_features.shape[1],
        )
        scaled_M = raw_M / compiled.tensor_scales[None, :, :]
        psi_M = np.einsum("dta,ta->d", scaled_M, channel_matrix)
        components[M] = psi_M
        H_M = many_body_hamiltonian(
            compiled.cache.basis(M),
            pairs,
            coulomb_pair_matrix,
            compiled.two_q,
        )
        L2_M = angular_momentum_squared(
            compiled.cache.basis(M),
            compiled.particles,
            compiled.two_q,
            M,
        )
        multiplet[f"M={M:+d}"] = exact_observables(psi_M, H_M, L2_M)

    lowering_residuals = {}
    for M in range(-1, 3):
        lower = raising_operator(
            compiled.cache.basis(M - 1),
            compiled.cache.basis(M),
            compiled.two_q,
        ).T
        lhs = lower @ components[M]
        rhs = math.sqrt((2 + M) * (2 - M + 1)) * components[M - 1]
        denominator = max(np.linalg.norm(lhs), np.linalg.norm(rhs), 1.0e-15)
        lowering_residuals[f"M={M:+d}_to_{M-1:+d}"] = float(
            np.linalg.norm(lhs - rhs) / denominator
        )

    multiplet_energies = [value["energy"] for value in multiplet.values()]
    exchange0 = coordinate_exchange_residual(
        ground_logabs, parameters, xyz0
    )
    exchange2 = coordinate_exchange_residual(
        excited_logabs, parameters, xyz2
    )

    result = {
        "ansatz": {
            "name": "first-quantized strict-LLL SU(2) tensor-polynomial NQS",
            "lmax": args.lmax,
            "scalar_depth": args.scalar_depth,
            "channel_rank": args.channel_rank,
            "coordinate_representation": (
                "normalized monopole-harmonic Slater polynomial expansion"
            ),
            "offline_compilation": "LLL projected-density CG channels",
        },
        "method": "continuous-coordinate Haldane-sphere GPU VMC",
        "jax_devices": [str(device) for device in jax.devices()],
        "particles": args.particles,
        "two_q": compiled.two_q,
        "basis_dim_M0": len(compiled.occupations0),
        "basis_dim_M2": len(compiled.occupations2),
        "walkers": args.walkers,
        "steps": args.steps,
        "best_coordinate_score": best_score,
        "acceptance": {
            "burn_ground": float(np.mean(burn_accept0)),
            "burn_excited": float(np.mean(burn_accept2)),
            "eval_ground": float(np.mean(eval_accept0)),
            "eval_excited": float(np.mean(eval_accept2)),
        },
        "feature_ranks": {
            "ground": compiled.scalar_features.shape[1],
            "full_tensor": compiled.tensor_diagnostics["rank"],
            "learned_channel_rank": args.channel_rank,
        },
        "coordinate_monte_carlo": {
            "ground_energy": mc_E0,
            "ground_stderr": mc_stderr0,
            "excited_energy": mc_E2,
            "excited_stderr": mc_stderr2,
            "gap": mc_E2 - mc_E0,
            "gap_stderr": math.hypot(mc_stderr0, mc_stderr2),
            "estimator": "independent-walker chain means",
        },
        "same_state_exact_contraction": {
            "ground": observables0,
            "excited": observables2,
            "gap": observables2["energy"] - observables0["energy"],
            "ground_overlap_ED": overlap(psi0, compiled.exact_ground),
            "excited_overlap_ED": overlap(psi2, compiled.exact_excited),
        },
        "full_channel_subspace_optimum": {
            "E0": compiled.projected_E0,
            "E2": compiled.projected_E2,
            "gap": compiled.projected_E2 - compiled.projected_E0,
        },
        "ed_benchmark": {
            "E0": compiled.exact_E0,
            "E2": compiled.exact_E2,
            "gap": compiled.exact_E2 - compiled.exact_E0,
        },
        "symmetry": {
            "ground_exchange_logabs_residual": exchange0,
            "excited_exchange_logabs_residual": exchange2,
            "multiplet": multiplet,
            "multiplet_energy_spread": max(multiplet_energies)
            - min(multiplet_energies),
            "lowering_equivariance_residuals": lowering_residuals,
        },
        "runtime_seconds": time.perf_counter() - start,
        "cli": vars(args) | {"output_dir": str(args.output_dir)},
    }
    (args.output_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        args.output_dir / "final_checkpoint.npz",
        **final_host,
        psi_ground=psi0,
        psi_excited_M2=psi2,
    )
    print(json.dumps(result, indent=2), flush=True)
    print(f"completed; output={args.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
