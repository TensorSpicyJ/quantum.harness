#!/usr/bin/env python3
"""Improved symmetry-exact NQS/VMC for the nu=1/3 chiral graviton.

V2 removes the rank-1 coefficient bottleneck of ``chiral_graviton_nqs_vmc.py``.
It keeps the same exact LLL/SU(2) construction but:

* uses a two-layer scalar CG backbone;
* allows full multiplicity-channel mixing in the rank-2 head;
* whitens the non-orthogonal operator features with an SVD;
* trains independent coordinates in the resulting L=0 and L=2 subspaces.

Every whitened excited feature remains a parameter-shared rank-2 tensor across
M=-2,...,2, because the same channel transformation is applied to all five
components.  The implementation is still a small-system dense benchmark; a
sparse extension is required beyond the dense-ED regime.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path
from typing import Callable

import numpy as np

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import optax

from chiral_graviton_ed import (
    angular_momentum_squared,
    antisymmetric_pair_matrix,
    interaction_pseudopotentials,
    many_body_hamiltonian,
    raising_operator,
)
from chiral_graviton_nqs_vmc import (
    Array,
    JaxArray,
    SectorCache,
    TensorHeadTerm,
    exact_observables,
    lowest_labeled_state,
    mc_energy,
    overlap,
    rank2_operator,
    scalar_operator,
)


jax.config.update("jax_enable_x64", True)


def whiten_features(
    matrix: Array, relative_tolerance: float = 1.0e-11
) -> tuple[Array, Array, dict[str, object]]:
    """Return an orthonormal basis and a reusable raw-to-white transform."""

    norms = np.linalg.norm(matrix, axis=0)
    keep = norms > max(norms.max(initial=0.0), 1.0) * 1.0e-13
    if not np.any(keep):
        raise RuntimeError("all feature columns are zero")
    kept = matrix[:, keep]
    column_scale = 1.0 / np.linalg.norm(kept, axis=0)
    scaled = kept * column_scale[None, :]
    u, singular_values, vh = np.linalg.svd(scaled, full_matrices=False)
    rank = int(np.sum(singular_values > singular_values[0] * relative_tolerance))
    if rank == 0:
        raise RuntimeError("feature matrix has zero numerical rank")
    kept_transform = (
        column_scale[:, None]
        * vh[:rank].T
        / singular_values[:rank][None, :]
    )
    transform = np.zeros((matrix.shape[1], rank))
    transform[keep] = kept_transform
    basis = matrix @ transform
    orthogonality_error = float(
        np.max(np.abs(basis.T @ basis - np.eye(rank)))
    )
    return basis, transform, {
        "raw_columns": int(matrix.shape[1]),
        "nonzero_columns": int(np.count_nonzero(keep)),
        "rank": rank,
        "singular_values": singular_values.tolist(),
        "orthogonality_error": orthogonality_error,
    }


def projected_ground_state(H: Array, features: Array) -> tuple[float, Array, Array]:
    """Lowest Rayleigh-Ritz state in an orthonormal feature basis."""

    projected = 0.5 * (features.T @ H @ features)
    projected = projected + projected.T
    energies, vectors = np.linalg.eigh(projected)
    coefficients = vectors[:, 0]
    return float(energies[0]), coefficients, features @ coefficients


def build_scalar_backbone(
    cache: SectorCache,
    laughlin: Array,
    lmax: int,
    depth: int,
) -> tuple[Array, list[str], dict[str, object]]:
    """Build and whiten scalar density-product features."""

    operators = {
        ell: scalar_operator(cache, ell) for ell in range(2, lmax + 1)
    }
    columns = [laughlin]
    labels = ["identity"]
    for ell, operator in operators.items():
        columns.append(operator @ laughlin)
        labels.append(f"S{ell}")
    if depth >= 2:
        for left_ell, left in operators.items():
            for right_ell, right in operators.items():
                columns.append(left @ (right @ laughlin))
                labels.append(f"S{left_ell}S{right_ell}")
    if depth >= 3:
        for first_ell, first in operators.items():
            for second_ell, second in operators.items():
                for third_ell, third in operators.items():
                    columns.append(first @ (second @ (third @ laughlin)))
                    labels.append(f"S{first_ell}S{second_ell}S{third_ell}")
    raw = np.column_stack(columns)
    features, _, diagnostics = whiten_features(raw)
    diagnostics["labels"] = labels
    return features, labels, diagnostics


def tensor_head_terms(lmax: int) -> list[TensorHeadTerm]:
    terms = [TensorHeadTerm("rho_2", 2, 0, linear=True)]
    for l1 in range(2, lmax + 1):
        for l2 in range(2, lmax + 1):
            if abs(l1 - l2) <= 2 <= l1 + l2:
                terms.append(TensorHeadTerm(f"[rho_{l1}xr_{l2}]_2", l1, l2))
    return terms


def raw_tensor_features(
    cache: SectorCache,
    scalar_features: Array,
    terms: list[TensorHeadTerm],
    M: int,
) -> Array:
    """Return columns O_(j,M) G_i, ordered with j outer and i inner."""

    columns = []
    for term in terms:
        operator = rank2_operator(cache, term, M)
        for index in range(scalar_features.shape[1]):
            columns.append(operator @ scalar_features[:, index])
    return np.column_stack(columns)


def make_linear_vmc_step(
    ground_features: JaxArray,
    excited_features: JaxArray,
    H0: JaxArray,
    H2: JaxArray,
    samples: int,
    weight_ground: float,
    weight_excited: float,
    optimizer: optax.GradientTransformation,
) -> Callable:
    """JIT-compiled independent-sample VMC update in whitened coordinates."""

    def sample_surrogate(
        psi: JaxArray, H: JaxArray, key: JaxArray
    ) -> tuple[JaxArray, tuple[JaxArray, JaxArray]]:
        probability = jnp.square(jnp.abs(psi))
        probability /= jnp.sum(probability)
        indices = jax.random.categorical(
            key,
            jnp.log(jnp.maximum(probability, 1.0e-300)),
            shape=(samples,),
        )
        local_energy = (H @ psi)[indices] / psi[indices]
        mean_energy = jnp.mean(local_energy)
        centered = jax.lax.stop_gradient(local_energy - mean_energy)
        log_amplitude = jnp.log(
            jnp.maximum(jnp.abs(psi[indices]), 1.0e-300)
        )
        surrogate = 2.0 * jnp.real(jnp.mean(centered * log_amplitude))
        variance = jnp.real(
            jnp.mean(jnp.square(local_energy - mean_energy))
        )
        return surrogate, (jnp.real(mean_energy), variance)

    def loss(
        parameters: dict[str, JaxArray], key: JaxArray
    ) -> tuple[JaxArray, tuple[JaxArray, JaxArray, JaxArray, JaxArray]]:
        psi0 = ground_features @ parameters["ground"]
        psi2 = excited_features @ parameters["excited"]
        key0, key2 = jax.random.split(key)
        loss0, (energy0, variance0) = sample_surrogate(psi0, H0, key0)
        loss2, (energy2, variance2) = sample_surrogate(psi2, H2, key2)
        total = weight_ground * loss0 + weight_excited * loss2
        return total, (energy0, energy2, variance0, variance2)

    @jax.jit
    def step(
        parameters: dict[str, JaxArray],
        optimizer_state: optax.OptState,
        key: JaxArray,
    ):
        (_, diagnostics), gradient = jax.value_and_grad(
            loss, has_aux=True
        )(parameters, key)
        updates, optimizer_state = optimizer.update(
            gradient, optimizer_state, parameters
        )
        parameters = optax.apply_updates(parameters, updates)
        parameters = {
            name: value / jnp.linalg.norm(value)
            for name, value in parameters.items()
        }
        return parameters, optimizer_state, diagnostics

    return step


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-N", "--particles", type=int, default=6)
    parser.add_argument("--lmax", type=int, default=4)
    parser.add_argument("--scalar-depth", type=int, choices=(1, 2, 3), default=2)
    parser.add_argument("--steps", type=int, default=1500)
    parser.add_argument("--samples", type=int, default=8192)
    parser.add_argument("--eval-samples", type=int, default=1048576)
    parser.add_argument("--learning-rate", type=float, default=1.0e-3)
    parser.add_argument("--weight-ground", type=float, default=0.5)
    parser.add_argument("--weight-excited", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=20260728)
    parser.add_argument("--log-every", type=int, default=25)
    parser.add_argument(
        "--initialization", choices=("sma", "projected"), default="sma"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path("runs/nqs_vmc_v2_N6")
    )
    parser.add_argument("--setup-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.lmax < 2:
        raise ValueError("lmax must be at least 2")
    if args.steps < 0 or args.samples <= 0:
        raise ValueError("steps must be non-negative and samples positive")
    if not math.isclose(args.weight_ground + args.weight_excited, 1.0):
        raise ValueError("state weights must sum to one")

    start = time.perf_counter()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    two_q = 3 * (args.particles - 1)
    cache = SectorCache(args.particles, two_q)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        f"N={args.particles}, 2Q={two_q}, "
        f"dim(M=0)={len(cache.basis(0))}, dim(M=2)={len(cache.basis(2))}",
        flush=True,
    )

    coulomb_pp = interaction_pseudopotentials(two_q, "coulomb")
    pairs, coulomb_pair_matrix = antisymmetric_pair_matrix(
        two_q, coulomb_pp
    )
    H0 = many_body_hamiltonian(
        cache.basis(0), pairs, coulomb_pair_matrix, two_q
    )
    H2 = many_body_hamiltonian(
        cache.basis(2), pairs, coulomb_pair_matrix, two_q
    )
    v1_pp = interaction_pseudopotentials(two_q, "v1")
    _, v1_pair_matrix = antisymmetric_pair_matrix(two_q, v1_pp)
    H_v1 = many_body_hamiltonian(
        cache.basis(0), pairs, v1_pair_matrix, two_q
    )
    v1_energies, v1_vectors = np.linalg.eigh(H_v1)
    if abs(v1_energies[0]) > 1.0e-9:
        raise RuntimeError(f"V1 seed is not a zero mode: {v1_energies[0]}")
    laughlin = v1_vectors[:, 0]
    laughlin *= np.sign(laughlin[np.argmax(np.abs(laughlin))])

    L20 = angular_momentum_squared(
        cache.basis(0), args.particles, two_q, 0
    )
    L22 = angular_momentum_squared(
        cache.basis(2), args.particles, two_q, 2
    )
    exact_E0, exact_ground = lowest_labeled_state(H0, L20, 0)
    exact_E2, exact_excited = lowest_labeled_state(H2, L22, 2)

    ground_features, scalar_labels, scalar_diagnostics = (
        build_scalar_backbone(
            cache,
            laughlin,
            args.lmax,
            args.scalar_depth,
        )
    )
    terms = tensor_head_terms(args.lmax)
    raw_excited_M2 = raw_tensor_features(
        cache, ground_features, terms, 2
    )
    excited_features, tensor_transform, tensor_diagnostics = (
        whiten_features(raw_excited_M2)
    )

    subspace_E0, projected_ground_coefficients, projected_ground = (
        projected_ground_state(H0, ground_features)
    )
    subspace_E2, projected_excited_coefficients, projected_excited = (
        projected_ground_state(H2, excited_features)
    )

    sma = rank2_operator(
        cache, TensorHeadTerm("rho_2", 2, 0, linear=True), 2
    ) @ laughlin
    if args.initialization == "projected":
        initial_parameters = {
            "ground": projected_ground_coefficients,
            "excited": projected_excited_coefficients,
        }
    else:
        initial_parameters = {
            "ground": ground_features.T @ laughlin,
            "excited": excited_features.T @ sma,
        }
    initial_parameters = {
        name: value / np.linalg.norm(value)
        for name, value in initial_parameters.items()
    }

    # Verify the shared channel transformation on the complete L=2 tower.
    initial_components: dict[int, Array] = {}
    for M in range(-2, 3):
        raw_M = raw_tensor_features(cache, ground_features, terms, M)
        features_M = raw_M @ tensor_transform
        initial_components[M] = (
            features_M @ initial_parameters["excited"]
        )
    initial_lowering_residuals = {}
    for M in range(-1, 3):
        lower = raising_operator(
            cache.basis(M - 1), cache.basis(M), two_q
        ).T
        lhs = lower @ initial_components[M]
        rhs = (
            math.sqrt((2 + M) * (2 - M + 1))
            * initial_components[M - 1]
        )
        denominator = max(
            np.linalg.norm(lhs), np.linalg.norm(rhs), 1.0e-15
        )
        initial_lowering_residuals[f"M={M:+d}"] = float(
            np.linalg.norm(lhs - rhs) / denominator
        )
    maximum_initial_residual = max(initial_lowering_residuals.values())
    if maximum_initial_residual > 2.0e-9:
        raise RuntimeError(
            f"whitened tensor covariance failed: {maximum_initial_residual:.3e}"
        )

    print(
        f"scalar raw/rank={scalar_diagnostics['raw_columns']}/"
        f"{scalar_diagnostics['rank']}, tensor raw/rank="
        f"{tensor_diagnostics['raw_columns']}/{tensor_diagnostics['rank']}",
        flush=True,
    )
    print(
        f"subspace optima: E0={subspace_E0:.12f}, "
        f"E2={subspace_E2:.12f}, gap={subspace_E2-subspace_E0:.12f}",
        flush=True,
    )
    print(
        f"ED benchmark:   E0={exact_E0:.12f}, E2={exact_E2:.12f}, "
        f"gap={exact_E2-exact_E0:.12f}",
        flush=True,
    )
    print(
        f"initial tensor residual={maximum_initial_residual:.3e}",
        flush=True,
    )

    metadata = {
        "particles": args.particles,
        "two_q": two_q,
        "scalar_labels": scalar_labels,
        "tensor_terms": [term.name for term in terms],
        "scalar_diagnostics": scalar_diagnostics,
        "tensor_diagnostics": tensor_diagnostics,
        "initial_lowering_residuals": initial_lowering_residuals,
        "subspace_optimum": {
            "E0": subspace_E0,
            "E2": subspace_E2,
            "gap": subspace_E2 - subspace_E0,
            "ground_overlap_ED": overlap(projected_ground, exact_ground),
            "excited_overlap_ED": overlap(projected_excited, exact_excited),
        },
        "ed_benchmark": {
            "E0": exact_E0,
            "E2": exact_E2,
            "gap": exact_E2 - exact_E0,
        },
        "jax_devices": [str(device) for device in jax.devices()],
        "cli": vars(args) | {"output_dir": str(args.output_dir)},
    }
    (args.output_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    if args.setup_only:
        print("setup-only checks passed", flush=True)
        return

    ground_jax = jax.device_put(jnp.asarray(ground_features))
    excited_jax = jax.device_put(jnp.asarray(excited_features))
    H0_jax = jax.device_put(jnp.asarray(H0))
    H2_jax = jax.device_put(jnp.asarray(H2))
    parameters = {
        name: jax.device_put(jnp.asarray(value))
        for name, value in initial_parameters.items()
    }
    schedule = optax.cosine_decay_schedule(
        args.learning_rate, max(args.steps, 1), alpha=0.05
    )
    optimizer = optax.chain(
        optax.clip_by_global_norm(10.0), optax.adam(schedule)
    )
    optimizer_state = optimizer.init(parameters)
    vmc_step = make_linear_vmc_step(
        ground_jax,
        excited_jax,
        H0_jax,
        H2_jax,
        args.samples,
        args.weight_ground,
        args.weight_excited,
        optimizer,
    )
    key = jax.random.PRNGKey(args.seed)

    def parameters_to_states(
        values: dict[str, Array],
    ) -> tuple[Array, Array]:
        return (
            ground_features @ values["ground"],
            excited_features @ values["excited"],
        )

    best_parameters = {
        name: value.copy() for name, value in initial_parameters.items()
    }
    best_psi0, best_psi2 = parameters_to_states(best_parameters)
    best_observables0 = exact_observables(best_psi0, H0, L20)
    best_observables2 = exact_observables(best_psi2, H2, L22)
    best_loss = (
        args.weight_ground * best_observables0["energy"]
        + args.weight_excited * best_observables2["energy"]
    )
    history = []
    for iteration in range(args.steps):
        key, step_key = jax.random.split(key)
        parameters, optimizer_state, diagnostics = vmc_step(
            parameters, optimizer_state, step_key
        )
        if iteration == 0:
            jax.block_until_ready(diagnostics)
        if iteration % args.log_every == 0 or iteration == args.steps - 1:
            host_parameters = {
                name: np.asarray(jax.device_get(value))
                for name, value in parameters.items()
            }
            psi0, psi2 = parameters_to_states(host_parameters)
            observables0 = exact_observables(psi0, H0, L20)
            observables2 = exact_observables(psi2, H2, L22)
            weighted = (
                args.weight_ground * observables0["energy"]
                + args.weight_excited * observables2["energy"]
            )
            row = {
                "step": iteration,
                "vmc_E0": float(diagnostics[0]),
                "vmc_E2": float(diagnostics[1]),
                "exact_E0": observables0["energy"],
                "exact_E2": observables2["energy"],
                "gap": observables2["energy"] - observables0["energy"],
                "variance0": observables0["energy_variance"],
                "variance2": observables2["energy_variance"],
            }
            history.append(row)
            print(
                f"step={iteration:5d} E0={row['exact_E0']:.12f} "
                f"E2={row['exact_E2']:.12f} gap={row['gap']:.12f} "
                f"var=({row['variance0']:.2e},{row['variance2']:.2e})",
                flush=True,
            )
            if weighted < best_loss:
                best_loss = weighted
                best_parameters = {
                    name: value.copy()
                    for name, value in host_parameters.items()
                }
                np.savez_compressed(
                    args.output_dir / "best_checkpoint.npz",
                    ground=best_parameters["ground"],
                    excited=best_parameters["excited"],
                    step=iteration,
                    weighted_energy=weighted,
                )
            (args.output_dir / "history.json").write_text(
                json.dumps(history, indent=2), encoding="utf-8"
            )

    psi0, psi2 = parameters_to_states(best_parameters)
    final_components = {}
    multiplet = {}
    lowering_residuals = {}
    for M in range(-2, 3):
        raw_M = raw_tensor_features(cache, ground_features, terms, M)
        features_M = raw_M @ tensor_transform
        psi_M = features_M @ best_parameters["excited"]
        final_components[M] = psi_M
        H_M = many_body_hamiltonian(
            cache.basis(M), pairs, coulomb_pair_matrix, two_q
        )
        L2_M = angular_momentum_squared(
            cache.basis(M), args.particles, two_q, M
        )
        multiplet[f"M={M:+d}"] = exact_observables(
            psi_M, H_M, L2_M
        )
    for M in range(-1, 3):
        lower = raising_operator(
            cache.basis(M - 1), cache.basis(M), two_q
        ).T
        lhs = lower @ final_components[M]
        rhs = (
            math.sqrt((2 + M) * (2 - M + 1))
            * final_components[M - 1]
        )
        denominator = max(
            np.linalg.norm(lhs), np.linalg.norm(rhs), 1.0e-15
        )
        lowering_residuals[f"M={M:+d}_to_{M-1:+d}"] = float(
            np.linalg.norm(lhs - rhs) / denominator
        )

    observables0 = exact_observables(psi0, H0, L20)
    observables2 = multiplet["M=+2"]
    rng = np.random.default_rng(args.seed + 1)
    mc0 = mc_energy(psi0, H0, args.eval_samples, rng)
    mc2 = mc_energy(psi2, H2, args.eval_samples, rng)
    multiplet_energies = [
        entry["energy"] for entry in multiplet.values()
    ]
    result = {
        "ansatz": (
            "LLL-SU(2) tensor NQS V2: depth-"
            f"{args.scalar_depth} scalar backbone + full channel mixing"
        ),
        "method": "state-averaged independent-sample GPU VMC",
        "particles": args.particles,
        "two_q": two_q,
        "steps": args.steps,
        "samples_per_step_per_state": args.samples,
        "feature_ranks": {
            "ground": scalar_diagnostics["rank"],
            "excited": tensor_diagnostics["rank"],
        },
        "exact_ansatz": {
            "ground": observables0,
            "excited_M2": observables2,
            "gap": observables2["energy"] - observables0["energy"],
            "ground_overlap_ED": overlap(psi0, exact_ground),
            "excited_overlap_ED": overlap(psi2, exact_excited),
        },
        "monte_carlo": {
            "ground": mc0,
            "excited_M2": mc2,
            "gap": mc2["energy"] - mc0["energy"],
            "gap_stderr": math.hypot(mc0["stderr"], mc2["stderr"]),
        },
        "subspace_optimum": metadata["subspace_optimum"],
        "ed_benchmark": metadata["ed_benchmark"],
        "multiplet": multiplet,
        "multiplet_energy_spread": (
            max(multiplet_energies) - min(multiplet_energies)
        ),
        "lowering_equivariance_residuals": lowering_residuals,
        "runtime_seconds": time.perf_counter() - start,
    }
    (args.output_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        args.output_dir / "final_states.npz",
        basis_M0=np.asarray(cache.basis(0), dtype=np.uint64),
        psi_ground=psi0,
        **{
            f"basis_M{M:+d}": np.asarray(
                cache.basis(M), dtype=np.uint64
            )
            for M in range(-2, 3)
        },
        **{
            f"psi_M{M:+d}": final_components[M]
            for M in range(-2, 3)
        },
    )
    print(json.dumps(result, indent=2), flush=True)
    print(f"completed; output={args.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
