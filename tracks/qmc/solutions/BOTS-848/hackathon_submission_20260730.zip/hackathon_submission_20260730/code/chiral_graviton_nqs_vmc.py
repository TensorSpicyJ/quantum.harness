#!/usr/bin/env python3
"""Symmetry-exact NQS/VMC for the nu=1/3 chiral graviton on a sphere.

This implements the minimal LLL--SU(2) irreducible-tensor ansatz proposed in
section 8.4 of ``nqs_ansatz_symmetry_focused_report.md``.  In second
quantization,

    |psi_0>   = C^(0)(a) |Laughlin>
    |psi_2M>  = O^(2)_M(b) C^(0)(a) |Laughlin>,

where C is made from CG-coupled scalar density products and O is made from a
linear density tensor plus CG-coupled rank-2 density products.  The scalar
parameters are shared by the L=0 and L=2 states, and the same tensor-head
parameters generate all five M components.

The loss is optimized with independent-sample variational Monte Carlo.  Since
the small-system benchmark sectors fit in memory, samples are drawn exactly
from |psi|^2; the energy gradient is nevertheless the standard stochastic VMC
log-derivative estimator.  Exact contractions are used only for diagnostics
and comparison with ``chiral_graviton_ed.py``.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import optax

from chiral_graviton_ed import (
    _annihilate,
    _create,
    angular_momentum_squared,
    antisymmetric_pair_matrix,
    clebsch_gordan2,
    fock_basis,
    interaction_pseudopotentials,
    many_body_hamiltonian,
    raising_operator,
)


jax.config.update("jax_enable_x64", True)

Array = np.ndarray
JaxArray = jax.Array


@dataclass(frozen=True)
class TensorHeadTerm:
    name: str
    l1: int
    l2: int
    linear: bool = False


def density_matrix(
    source_basis: tuple[int, ...],
    target_basis: tuple[int, ...],
    two_q: int,
    ell: int,
    m: int,
) -> Array:
    """Matrix of the LLL projected density tensor rho_(ell,m)."""

    if abs(m) > ell:
        return np.zeros((len(target_basis), len(source_basis)))
    target_index = {state: i for i, state in enumerate(target_basis)}
    result = np.zeros((len(target_basis), len(source_basis)))
    for ket_index, state in enumerate(source_basis):
        for orbital1 in range(two_q + 1):
            if not ((state >> orbital1) & 1):
                continue
            tm1 = -two_q + 2 * orbital1
            tm2 = tm1 + 2 * m
            if tm2 < -two_q or tm2 > two_q:
                continue
            orbital2 = (tm2 + two_q) // 2
            cg = clebsch_gordan2(two_q, tm2, two_q, -tm1, 2 * ell, 2 * m)
            if abs(cg) < 1.0e-15:
                continue
            first = _annihilate(state, orbital1)
            assert first is not None
            intermediate, sign1 = first
            second = _create(intermediate, orbital2)
            if second is None:
                continue
            final_state, sign2 = second
            bra_index = target_index.get(final_state)
            if bra_index is None:
                continue
            phase = -1.0 if ((two_q - tm1) // 2) % 2 else 1.0
            result[bra_index, ket_index] += phase * cg * sign1 * sign2
    return result


class SectorCache:
    """Cache Fock bases and projected-density matrices for one (N, 2Q)."""

    def __init__(self, particles: int, two_q: int):
        self.particles = particles
        self.two_q = two_q
        self._bases: dict[int, tuple[int, ...]] = {}
        self._rho: dict[tuple[int, int, int], Array] = {}

    def basis(self, M: int) -> tuple[int, ...]:
        if M not in self._bases:
            self._bases[M] = fock_basis(self.particles, self.two_q, M)
        return self._bases[M]

    def rho(self, source_M: int, ell: int, m: int) -> Array:
        key = (source_M, ell, m)
        if key not in self._rho:
            self._rho[key] = density_matrix(
                self.basis(source_M),
                self.basis(source_M + m),
                self.two_q,
                ell,
                m,
            )
        return self._rho[key]


def scalar_operator(cache: SectorCache, ell: int) -> Array:
    """Return [rho_ell tensor rho_ell]_(0,0) in the M=0 sector."""

    dimension = len(cache.basis(0))
    result = np.zeros((dimension, dimension))
    for m in range(-ell, ell + 1):
        cg = clebsch_gordan2(2 * ell, 2 * m, 2 * ell, -2 * m, 0, 0)
        result += cg * cache.rho(-m, ell, m) @ cache.rho(0, ell, -m)
    return result


def rank2_operator(cache: SectorCache, term: TensorHeadTerm, M: int) -> Array:
    """Return one O^(2)_M channel mapping the M=0 sector to sector M."""

    if term.linear:
        return cache.rho(0, 2, M)
    result = np.zeros((len(cache.basis(M)), len(cache.basis(0))))
    for m1 in range(-term.l1, term.l1 + 1):
        m2 = M - m1
        if abs(m2) > term.l2:
            continue
        cg = clebsch_gordan2(
            2 * term.l1, 2 * m1, 2 * term.l2, 2 * m2, 4, 2 * M
        )
        if abs(cg) < 1.0e-15:
            continue
        result += cg * cache.rho(m2, term.l1, m1) @ cache.rho(0, term.l2, m2)
    return result


def lowest_labeled_state(H: Array, L2: Array, target_L: int) -> tuple[float, Array]:
    energies, vectors = np.linalg.eigh(H)
    l2_values = np.einsum("ij,ij->j", vectors, L2 @ vectors)
    target = target_L * (target_L + 1)
    candidates = np.flatnonzero(np.abs(l2_values - target) < 1.0e-7)
    if not len(candidates):
        raise RuntimeError(f"no L={target_L} eigenstate found")
    index = int(candidates[0])
    return float(energies[index]), vectors[:, index]


def normalized_columns(columns: list[Array], labels: list[str]) -> tuple[Array, Array]:
    matrix = np.column_stack(columns)
    norms = np.linalg.norm(matrix, axis=0)
    if np.any(norms < 1.0e-12):
        bad = [labels[i] for i in np.flatnonzero(norms < 1.0e-12)]
        raise RuntimeError(f"zero/redundant ansatz channels: {bad}")
    return matrix / norms, 1.0 / norms


def exact_observables(psi: Array, H: Array, L2: Array) -> dict[str, float]:
    norm = float(np.vdot(psi, psi).real)
    energy = float(np.vdot(psi, H @ psi).real / norm)
    h2 = float(np.vdot(H @ psi, H @ psi).real / norm)
    l2 = float(np.vdot(psi, L2 @ psi).real / norm)
    l22 = float(np.vdot(L2 @ psi, L2 @ psi).real / norm)
    return {
        "energy": energy,
        "energy_variance": max(0.0, h2 - energy**2),
        "L2": l2,
        "L2_variance": max(0.0, l22 - l2**2),
    }


def make_vmc_step(
    ground_features: JaxArray,
    excited_features: JaxArray,
    H0: JaxArray,
    H2: JaxArray,
    samples: int,
    weight_ground: float,
    weight_excited: float,
    optimizer: optax.GradientTransformation,
) -> Callable:
    """Create a JIT-compiled state-averaged VMC update."""

    def wavefunctions(params: dict[str, JaxArray]) -> tuple[JaxArray, JaxArray]:
        psi0 = ground_features @ params["a"]
        psi2 = jnp.einsum("sji,j,i->s", excited_features, params["b"], params["a"])
        return psi0, psi2

    def sample_surrogate(
        psi: JaxArray, H: JaxArray, key: JaxArray
    ) -> tuple[JaxArray, tuple[JaxArray, JaxArray]]:
        probability = jnp.square(jnp.abs(psi))
        probability = probability / jnp.sum(probability)
        indices = jax.random.categorical(
            key, jnp.log(jnp.maximum(probability, 1.0e-300)), shape=(samples,)
        )
        hpsi = H @ psi
        selected = psi[indices]
        local_energy = hpsi[indices] / selected
        mean_energy = jnp.mean(local_energy)
        centered = jax.lax.stop_gradient(local_energy - mean_energy)
        log_amplitude = jnp.log(jnp.maximum(jnp.abs(selected), 1.0e-300))
        surrogate = 2.0 * jnp.real(jnp.mean(centered * log_amplitude))
        variance = jnp.real(jnp.mean(jnp.square(local_energy - mean_energy)))
        return surrogate, (jnp.real(mean_energy), variance)

    def loss(
        params: dict[str, JaxArray], key: JaxArray
    ) -> tuple[JaxArray, tuple[JaxArray, JaxArray, JaxArray, JaxArray]]:
        psi0, psi2 = wavefunctions(params)
        key0, key2 = jax.random.split(key)
        loss0, (energy0, variance0) = sample_surrogate(psi0, H0, key0)
        loss2, (energy2, variance2) = sample_surrogate(psi2, H2, key2)
        total = weight_ground * loss0 + weight_excited * loss2
        return total, (energy0, energy2, variance0, variance2)

    @jax.jit
    def step(
        params: dict[str, JaxArray],
        opt_state: optax.OptState,
        key: JaxArray,
    ):
        (_, diagnostics), gradient = jax.value_and_grad(loss, has_aux=True)(params, key)
        updates, opt_state = optimizer.update(gradient, opt_state, params)
        params = optax.apply_updates(params, updates)
        params = {
            "a": params["a"] / jnp.linalg.norm(params["a"]),
            "b": params["b"] / jnp.linalg.norm(params["b"]),
        }
        return params, opt_state, diagnostics

    return step


def mc_energy(
    psi: Array, H: Array, samples: int, rng: np.random.Generator
) -> dict[str, float]:
    probability = np.square(np.abs(psi))
    probability /= probability.sum()
    indices = rng.choice(len(psi), size=samples, replace=True, p=probability)
    local = (H @ psi)[indices] / psi[indices]
    energy = float(np.mean(local).real)
    variance = float(np.var(local).real)
    return {
        "energy": energy,
        "stderr": math.sqrt(variance / samples),
        "variance": variance,
        "samples": samples,
    }


def overlap(psi: Array, reference: Array) -> float:
    return float(
        abs(np.vdot(reference, psi)) ** 2
        / (np.vdot(reference, reference).real * np.vdot(psi, psi).real)
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-N", "--particles", type=int, default=6)
    parser.add_argument("--lmax", type=int, default=4)
    parser.add_argument("--steps", type=int, default=2500)
    parser.add_argument("--samples", type=int, default=4096)
    parser.add_argument("--eval-samples", type=int, default=262144)
    parser.add_argument("--learning-rate", type=float, default=2.0e-3)
    parser.add_argument("--weight-ground", type=float, default=0.5)
    parser.add_argument("--weight-excited", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=20260727)
    parser.add_argument("--log-every", type=int, default=25)
    parser.add_argument("--output-dir", type=Path, default=Path("runs/nqs_vmc_N6"))
    parser.add_argument("--setup-only", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.particles < 3:
        raise ValueError("particles must be at least 3")
    if args.lmax < 2:
        raise ValueError("lmax must be at least 2")
    if args.steps < 0 or args.samples <= 0:
        raise ValueError("steps must be non-negative and samples positive")
    if not math.isclose(args.weight_ground + args.weight_excited, 1.0):
        raise ValueError("state weights must sum to one")

    start = time.perf_counter()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    two_q = 3 * (args.particles - 1)
    cache = SectorCache(args.particles, two_q)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        f"N={args.particles}, 2Q={two_q}, Norb={two_q + 1}, "
        f"dim(M=0)={len(cache.basis(0))}, dim(M=2)={len(cache.basis(2))}",
        flush=True,
    )

    coulomb_pp = interaction_pseudopotentials(two_q, "coulomb")
    pairs, coulomb_pair_matrix = antisymmetric_pair_matrix(two_q, coulomb_pp)
    H0 = many_body_hamiltonian(cache.basis(0), pairs, coulomb_pair_matrix, two_q)
    H2 = many_body_hamiltonian(cache.basis(2), pairs, coulomb_pair_matrix, two_q)
    v1_pp = interaction_pseudopotentials(two_q, "v1")
    _, v1_pair_matrix = antisymmetric_pair_matrix(two_q, v1_pp)
    H_v1 = many_body_hamiltonian(cache.basis(0), pairs, v1_pair_matrix, two_q)
    laughlin_energy, laughlin_vectors = np.linalg.eigh(H_v1)
    if abs(laughlin_energy[0]) > 1.0e-9:
        raise RuntimeError(f"V1 Laughlin energy is not zero: {laughlin_energy[0]}")
    laughlin = laughlin_vectors[:, 0]
    laughlin *= np.sign(laughlin[np.argmax(np.abs(laughlin))])

    L20 = angular_momentum_squared(cache.basis(0), args.particles, two_q, 0)
    L22 = angular_momentum_squared(cache.basis(2), args.particles, two_q, 2)
    exact_E0, exact_ground = lowest_labeled_state(H0, L20, 0)
    exact_E2, exact_excited = lowest_labeled_state(H2, L22, 2)

    scalar_labels = ["identity"] + [
        f"[rho_{ell}xr_{ell}]_00" for ell in range(2, args.lmax + 1)
    ]
    scalar_columns = [laughlin]
    for ell in range(2, args.lmax + 1):
        scalar_columns.append(scalar_operator(cache, ell) @ laughlin)
    ground_features, scalar_scales = normalized_columns(scalar_columns, scalar_labels)

    head_terms = [TensorHeadTerm("rho_2", 2, 0, linear=True)]
    for l1 in range(2, args.lmax + 1):
        for l2 in range(2, args.lmax + 1):
            if abs(l1 - l2) <= 2 <= l1 + l2:
                head_terms.append(TensorHeadTerm(f"[rho_{l1}xr_{l2}]_2", l1, l2))

    head_raw_M2 = [rank2_operator(cache, term, 2) for term in head_terms]
    head_seed_norms = np.array([np.linalg.norm(op @ laughlin) for op in head_raw_M2])
    if np.any(head_seed_norms < 1.0e-12):
        bad = [head_terms[i].name for i in np.flatnonzero(head_seed_norms < 1.0e-12)]
        raise RuntimeError(f"zero rank-2 channels: {bad}")
    head_scales = 1.0 / head_seed_norms
    head_M2 = [scale * op for scale, op in zip(head_scales, head_raw_M2)]
    excited_features = np.stack(
        [
            np.stack(
                [op @ ground_features[:, i] for i in range(ground_features.shape[1])],
                axis=1,
            )
            for op in head_M2
        ],
        axis=1,
    )

    parameters_np = {
        "a": np.eye(1, ground_features.shape[1], 0, dtype=np.float64).ravel(),
        "b": np.eye(1, len(head_terms), 0, dtype=np.float64).ravel(),
    }
    psi0_initial = ground_features @ parameters_np["a"]
    psi2_initial = np.einsum(
        "sji,j,i->s", excited_features, parameters_np["b"], parameters_np["a"]
    )

    component_initial: dict[int, Array] = {}
    for M in range(-2, 3):
        operators = [
            head_scales[j] * rank2_operator(cache, term, M)
            for j, term in enumerate(head_terms)
        ]
        features_M = np.stack(
            [
                np.stack(
                    [op @ ground_features[:, i] for i in range(ground_features.shape[1])],
                    axis=1,
                )
                for op in operators
            ],
            axis=1,
        )
        component_initial[M] = np.einsum(
            "sji,j,i->s", features_M, parameters_np["b"], parameters_np["a"]
        )
    tensor_residuals: dict[str, float] = {}
    for M in range(-1, 3):
        lower = raising_operator(cache.basis(M - 1), cache.basis(M), two_q).T
        lhs = lower @ component_initial[M]
        rhs = math.sqrt((2 + M) * (2 - M + 1)) * component_initial[M - 1]
        denominator = max(np.linalg.norm(lhs), np.linalg.norm(rhs), 1.0e-15)
        tensor_residuals[f"Lminus_M{M:+d}"] = float(
            np.linalg.norm(lhs - rhs) / denominator
        )
    maximum_tensor_residual = max(tensor_residuals.values())
    if maximum_tensor_residual > 2.0e-10:
        raise RuntimeError(
            f"rank-2 covariance test failed: residual={maximum_tensor_residual:.3e}"
        )
    print(
        f"ansatz channels: scalar={ground_features.shape[1]}, "
        f"rank2={len(head_terms)}, tensor residual={maximum_tensor_residual:.3e}",
        flush=True,
    )
    print(
        f"initial SMA: E0={exact_observables(psi0_initial, H0, L20)['energy']:.10f}, "
        f"E2={exact_observables(psi2_initial, H2, L22)['energy']:.10f}",
        flush=True,
    )

    metadata = {
        "particles": args.particles,
        "two_q": two_q,
        "lmax": args.lmax,
        "scalar_channels": scalar_labels,
        "rank2_channels": [term.name for term in head_terms],
        "scalar_scales": scalar_scales.tolist(),
        "head_scales": head_scales.tolist(),
        "tensor_residuals_initial": tensor_residuals,
        "jax_devices": [str(device) for device in jax.devices()],
        "exact_benchmark": {"E0": exact_E0, "E2": exact_E2, "gap": exact_E2 - exact_E0},
        "cli": vars(args) | {"output_dir": str(args.output_dir)},
    }
    (args.output_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    if args.setup_only:
        print(f"setup-only checks passed; output={args.output_dir.resolve()}", flush=True)
        return

    ground_jax = jax.device_put(jnp.asarray(ground_features))
    excited_jax = jax.device_put(jnp.asarray(excited_features))
    H0_jax = jax.device_put(jnp.asarray(H0))
    H2_jax = jax.device_put(jnp.asarray(H2))
    params = {
        name: jax.device_put(jnp.asarray(value)) for name, value in parameters_np.items()
    }
    schedule = optax.cosine_decay_schedule(
        args.learning_rate, max(args.steps, 1), alpha=0.05
    )
    optimizer = optax.chain(optax.clip_by_global_norm(10.0), optax.adam(schedule))
    opt_state = optimizer.init(params)
    vmc_step = make_vmc_step(
        ground_jax,
        excited_jax,
        H0_jax,
        H2_jax,
        args.samples,
        args.weight_ground,
        args.weight_excited,
        optimizer,
    )
    key = jax.random.PRNGKey(args.seed)
    history: list[dict[str, float | int]] = []
    best_loss = math.inf
    best_params = parameters_np
    for iteration in range(args.steps):
        key, step_key = jax.random.split(key)
        params, opt_state, diagnostics = vmc_step(params, opt_state, step_key)
        if iteration == 0:
            jax.block_until_ready(diagnostics)
        if iteration % args.log_every == 0 or iteration == args.steps - 1:
            a_np = np.asarray(jax.device_get(params["a"]))
            b_np = np.asarray(jax.device_get(params["b"]))
            psi0 = ground_features @ a_np
            psi2 = np.einsum("sji,j,i->s", excited_features, b_np, a_np)
            obs0 = exact_observables(psi0, H0, L20)
            obs2 = exact_observables(psi2, H2, L22)
            weighted = (
                args.weight_ground * obs0["energy"]
                + args.weight_excited * obs2["energy"]
            )
            row = {
                "step": iteration,
                "vmc_E0": float(diagnostics[0]),
                "vmc_E2": float(diagnostics[1]),
                "exact_E0": obs0["energy"],
                "exact_E2": obs2["energy"],
                "gap": obs2["energy"] - obs0["energy"],
                "variance0": obs0["energy_variance"],
                "variance2": obs2["energy_variance"],
            }
            history.append(row)
            print(
                f"step={iteration:5d} E0={obs0['energy']:.10f} "
                f"E2={obs2['energy']:.10f} gap={row['gap']:.10f} "
                f"var=({obs0['energy_variance']:.2e},{obs2['energy_variance']:.2e})",
                flush=True,
            )
            if weighted < best_loss:
                best_loss = weighted
                best_params = {"a": a_np.copy(), "b": b_np.copy()}
                np.savez_compressed(
                    args.output_dir / "best_checkpoint.npz",
                    a=best_params["a"],
                    b=best_params["b"],
                    step=iteration,
                    weighted_energy=weighted,
                )
            (args.output_dir / "history.json").write_text(
                json.dumps(history, indent=2), encoding="utf-8"
            )

    a_best, b_best = best_params["a"], best_params["b"]
    psi0 = ground_features @ a_best
    final_components: dict[int, Array] = {}
    multiplet: dict[str, dict[str, float]] = {}
    lowering_residuals: dict[str, float] = {}
    for M in range(-2, 3):
        operators_M = [
            head_scales[j] * rank2_operator(cache, term, M)
            for j, term in enumerate(head_terms)
        ]
        features_M = np.stack(
            [
                np.stack(
                    [op @ ground_features[:, i] for i in range(ground_features.shape[1])],
                    axis=1,
                )
                for op in operators_M
            ],
            axis=1,
        )
        psi_M = np.einsum("sji,j,i->s", features_M, b_best, a_best)
        final_components[M] = psi_M
        H_M = many_body_hamiltonian(
            cache.basis(M), pairs, coulomb_pair_matrix, two_q
        )
        L2_M = angular_momentum_squared(cache.basis(M), args.particles, two_q, M)
        multiplet[f"M={M:+d}"] = exact_observables(psi_M, H_M, L2_M)
    for M in range(-1, 3):
        lower = raising_operator(cache.basis(M - 1), cache.basis(M), two_q).T
        lhs = lower @ final_components[M]
        rhs = math.sqrt((2 + M) * (2 - M + 1)) * final_components[M - 1]
        denominator = max(np.linalg.norm(lhs), np.linalg.norm(rhs), 1.0e-15)
        lowering_residuals[f"M={M:+d}_to_{M-1:+d}"] = float(
            np.linalg.norm(lhs - rhs) / denominator
        )

    obs0 = exact_observables(psi0, H0, L20)
    obs2 = multiplet["M=+2"]
    rng = np.random.default_rng(args.seed + 1)
    mc0 = mc_energy(psi0, H0, args.eval_samples, rng)
    mc2 = mc_energy(final_components[2], H2, args.eval_samples, rng)
    energies_M = [entry["energy"] for entry in multiplet.values()]
    result = {
        "ansatz": "LLL-SU(2) irreducible-tensor NQS, minimal two-density layer",
        "method": "state-averaged independent-sample VMC",
        "particles": args.particles,
        "two_q": two_q,
        "steps": args.steps,
        "samples_per_step_per_state": args.samples,
        "exact_ansatz": {
            "ground": obs0,
            "excited_M2": obs2,
            "gap": obs2["energy"] - obs0["energy"],
            "ground_overlap_ED": overlap(psi0, exact_ground),
            "excited_overlap_ED": overlap(final_components[2], exact_excited),
        },
        "monte_carlo": {
            "ground": mc0,
            "excited_M2": mc2,
            "gap": mc2["energy"] - mc0["energy"],
            "gap_stderr": math.hypot(mc0["stderr"], mc2["stderr"]),
        },
        "ed_benchmark": {"E0": exact_E0, "E2": exact_E2, "gap": exact_E2 - exact_E0},
        "multiplet": multiplet,
        "multiplet_energy_spread": max(energies_M) - min(energies_M),
        "lowering_equivariance_residuals": lowering_residuals,
        "runtime_seconds": time.perf_counter() - start,
    }
    (args.output_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        args.output_dir / "final_states.npz",
        basis_M0=np.asarray(cache.basis(0), dtype=np.uint64),
        psi_ground=psi0,
        **{
            f"basis_M{M:+d}": np.asarray(cache.basis(M), dtype=np.uint64)
            for M in range(-2, 3)
        },
        **{f"psi_M{M:+d}": final_components[M] for M in range(-2, 3)},
    )
    print(json.dumps(result, indent=2), flush=True)
    print(f"completed; output={args.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
