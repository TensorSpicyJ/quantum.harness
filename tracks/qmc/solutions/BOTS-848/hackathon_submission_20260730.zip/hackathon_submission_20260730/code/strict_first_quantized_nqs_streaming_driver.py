#!/usr/bin/env python3
"""Train strict first-quantized ground and L=2 NQS at large N.

The feature extractor is the exact LLL/SU(2) streaming implementation from
``strict_first_quantized_streaming``.  Both the scalar ground-state head and
the rank-2 excited-state head are variationally optimized with VMC linear
method / stochastic reconfiguration.  Training and validation use separate
Markov chains and random seeds.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np

from strict_first_quantized_hmc import collect_hmc_samples
from strict_first_quantized_streaming import (
    make_streaming_scalar_feature_function,
    make_streaming_tensor_feature_function,
)
from strict_first_quantized_tensor_nqs import (
    collect_laughlin_samples,
    estimate_matrices,
    parse_sizes,
    solve_linear_method,
    weighted_statistics,
)
from strict_first_quantized_tensor_nqs_v3 import (
    collect_sma_samples,
    estimate_weighted_matrices,
    reference_weighted_statistics,
)


def evaluate_features(
    function,
    coordinates: np.ndarray,
    feature_batch: int,
) -> np.ndarray:
    output = []
    started = time.perf_counter()
    for start in range(0, len(coordinates), feature_batch):
        batch = jnp.asarray(coordinates[start : start + feature_batch])
        output.append(np.asarray(jax.device_get(function(batch))))
        completed = min(start + feature_batch, len(coordinates))
        if completed == feature_batch or completed % (16 * feature_batch) == 0:
            print(
                f"  features {completed}/{len(coordinates)} "
                f"elapsed={time.perf_counter() - started:.1f}s",
                flush=True,
            )
    return np.concatenate(output, axis=0)


def overlap_diagnostics(overlap: np.ndarray) -> dict:
    eigenvalues = np.linalg.eigvalsh(overlap)
    positive = eigenvalues[eigenvalues > 0.0]
    return {
        "eigenvalues": eigenvalues.tolist(),
        "condition_number_positive": (
            float(positive[-1] / positive[0]) if len(positive) else math.inf
        ),
    }


def tolerance_scan(
    overlap: np.ndarray,
    hamiltonian: np.ndarray,
    validation_features: np.ndarray,
    validation_potential: np.ndarray,
    scales: np.ndarray,
    chains: int,
    records: int,
    tolerances: list[float],
    reference_weighted: bool,
) -> list[dict]:
    rows = []
    for tolerance in tolerances:
        _, coefficients, rank = solve_linear_method(
            overlap, hamiltonian, tolerance
        )
        statistic = (
            reference_weighted_statistics
            if reference_weighted
            else weighted_statistics
        )
        energy, stderr, ess, ess_fraction = statistic(
            validation_features,
            validation_potential,
            coefficients,
            chains,
            records,
        )
        rows.append(
            {
                "tolerance": tolerance,
                "rank": rank,
                "validation_energy": energy,
                "validation_stderr": stderr,
                "validation_ess": ess,
                "validation_ess_fraction": ess_fraction,
                "coefficients_real": np.real(
                    coefficients / scales
                ).tolist(),
                "coefficients_imag": np.imag(
                    coefficients / scales
                ).tolist(),
            }
        )
    return rows


def sample_reference(arguments, particles: int, records: int, seed: int, target: str):
    if arguments.sampler == 'hmc':
        step_size = (
            arguments.hmc_step_size_ground
            if target == 'laughlin'
            else arguments.hmc_step_size_excited
        )
        coordinates, potential, acceptance, diagnostics = collect_hmc_samples(
            particles,
            arguments.chains,
            arguments.hmc_burn_trajectories,
            records,
            arguments.hmc_thin_trajectories,
            step_size,
            arguments.hmc_leapfrog_steps,
            seed,
            target,
            arguments.hmc_target_acceptance,
        )
        return coordinates, potential, acceptance, diagnostics
    collector = (
        collect_laughlin_samples if target == 'laughlin' else collect_sma_samples
    )
    coordinates, potential, acceptance = collector(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        seed,
    )
    return coordinates, potential, acceptance, {
        'sampler': 'local_random_walk_metropolis'
    }


def train_ground(arguments, particles: int) -> dict:
    print(f"N={particles} ground: sampling independent train set", flush=True)
    (
        train_coordinates,
        train_potential,
        train_acceptance,
        train_sampler_diagnostics,
    ) = sample_reference(
        arguments,
        particles,
        arguments.training_records,
        arguments.seed + 101,
        'laughlin',
    )
    print(f'N={particles} ground: sampling independent validation set', flush=True)
    (
        validation_coordinates,
        validation_potential,
        validation_acceptance,
        validation_sampler_diagnostics,
    ) = sample_reference(
        arguments,
        particles,
        arguments.validation_records,
        arguments.seed + 100_101,
        'laughlin',
    )
    feature_function, labels = make_streaming_scalar_feature_function(
        particles, arguments.lmax
    )
    print(f"N={particles} ground: evaluating train features", flush=True)
    train_features = evaluate_features(
        feature_function, train_coordinates, arguments.feature_batch
    )
    print(f"N={particles} ground: evaluating validation features", flush=True)
    validation_features = evaluate_features(
        feature_function, validation_coordinates, arguments.feature_batch
    )
    scales = np.sqrt(
        np.maximum(
            np.mean(np.square(np.abs(train_features)), axis=0), 1.0e-30
        )
    )
    train_features /= scales[None, :]
    validation_features /= scales[None, :]
    overlap, hamiltonian = estimate_matrices(train_features, train_potential)
    scan = tolerance_scan(
        overlap,
        hamiltonian,
        validation_features,
        validation_potential,
        scales,
        arguments.chains,
        arguments.validation_records,
        arguments.tolerances,
        False,
    )
    selected = min(
        scan,
        key=lambda row: abs(row["tolerance"] - arguments.whitening_tolerance),
    )
    _, selected_coefficients, _ = solve_linear_method(
        overlap, hamiltonian, selected["tolerance"]
    )
    training_energy, training_stderr, training_ess, training_fraction = (
        weighted_statistics(
            train_features,
            train_potential,
            selected_coefficients,
            arguments.chains,
            arguments.training_records,
        )
    )
    return {
        "sector": "ground",
        "L2": 0.0,
        "channel_labels": labels,
        "raw_channels": len(labels),
        "selected_tolerance": selected["tolerance"],
        "retained_rank": selected["rank"],
        "training_energy": training_energy,
        "training_stderr": training_stderr,
        "validation_energy": selected["validation_energy"],
        "validation_stderr": selected["validation_stderr"],
        "training_ess": training_ess,
        "training_ess_fraction": training_fraction,
        "validation_ess": selected["validation_ess"],
        "validation_ess_fraction": selected["validation_ess_fraction"],
        'sampler': arguments.sampler,
        "training_acceptance": train_acceptance,
        "validation_acceptance": validation_acceptance,
        'training_sampler_diagnostics': train_sampler_diagnostics,
        'validation_sampler_diagnostics': validation_sampler_diagnostics,
        "overlap": overlap_diagnostics(overlap),
        "tolerance_scan": scan,
        "coefficients_real": selected["coefficients_real"],
        "coefficients_imag": selected["coefficients_imag"],
    }


def train_excited(arguments, particles: int) -> dict:
    print(f"N={particles} excited: sampling independent train set", flush=True)
    (
        train_coordinates,
        train_potential,
        train_acceptance,
        train_sampler_diagnostics,
    ) = sample_reference(
        arguments,
        particles,
        arguments.training_records,
        arguments.seed + 307,
        'sma',
    )
    print(
        f'N={particles} excited: sampling independent validation set',
        flush=True,
    )
    (
        validation_coordinates,
        validation_potential,
        validation_acceptance,
        validation_sampler_diagnostics,
    ) = sample_reference(
        arguments,
        particles,
        arguments.validation_records,
        arguments.seed + 100_307,
        'sma',
    )
    feature_function, labels = make_streaming_tensor_feature_function(
        particles, arguments.lmax
    )
    print(f"N={particles} excited: evaluating train features", flush=True)
    train_features = evaluate_features(
        feature_function, train_coordinates, arguments.feature_batch
    )
    print(f"N={particles} excited: evaluating validation features", flush=True)
    validation_features = evaluate_features(
        feature_function, validation_coordinates, arguments.feature_batch
    )
    scales = np.sqrt(
        np.maximum(
            np.mean(np.square(np.abs(train_features)), axis=0), 1.0e-30
        )
    )
    train_features /= scales[None, :]
    validation_features /= scales[None, :]
    overlap, hamiltonian = estimate_weighted_matrices(
        train_features, train_potential
    )
    scan = tolerance_scan(
        overlap,
        hamiltonian,
        validation_features,
        validation_potential,
        scales,
        arguments.chains,
        arguments.validation_records,
        arguments.tolerances,
        True,
    )
    selected = min(
        scan,
        key=lambda row: abs(row["tolerance"] - arguments.whitening_tolerance),
    )
    _, selected_coefficients, _ = solve_linear_method(
        overlap, hamiltonian, selected["tolerance"]
    )
    training_energy, training_stderr, training_ess, training_fraction = (
        reference_weighted_statistics(
            train_features,
            train_potential,
            selected_coefficients,
            arguments.chains,
            arguments.training_records,
        )
    )
    return {
        "sector": "excited",
        "L2": 6.0,
        "sampling_reference": (
            "SMA only as importance distribution; not the final state"
        ),
        "channel_labels": labels,
        "raw_channels": len(labels),
        "selected_tolerance": selected["tolerance"],
        "retained_rank": selected["rank"],
        "training_energy": training_energy,
        "training_stderr": training_stderr,
        "validation_energy": selected["validation_energy"],
        "validation_stderr": selected["validation_stderr"],
        "training_ess": training_ess,
        "training_ess_fraction": training_fraction,
        "validation_ess": selected["validation_ess"],
        "validation_ess_fraction": selected["validation_ess_fraction"],
        'sampler': arguments.sampler,
        "training_acceptance": train_acceptance,
        "validation_acceptance": validation_acceptance,
        'training_sampler_diagnostics': train_sampler_diagnostics,
        'validation_sampler_diagnostics': validation_sampler_diagnostics,
        "overlap": overlap_diagnostics(overlap),
        "tolerance_scan": scan,
        "coefficients_real": selected["coefficients_real"],
        "coefficients_imag": selected["coefficients_imag"],
    }


def parse_tolerances(specification: str) -> list[float]:
    values = sorted({float(value) for value in specification.split(",")})
    if not values or values[0] <= 0.0:
        raise ValueError("all tolerances must be positive")
    return values


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="20")
    parser.add_argument("--lmax", type=int, default=4)
    parser.add_argument("--chains", type=int, default=128)
    parser.add_argument("--burn-sweeps", type=int, default=500)
    parser.add_argument("--training-records", type=int, default=32)
    parser.add_argument("--validation-records", type=int, default=32)
    parser.add_argument("--thin-sweeps", type=int, default=5)
    parser.add_argument("--feature-batch", type=int, default=4)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument('--sampler', choices=('metropolis', 'hmc'), default='metropolis')
    parser.add_argument('--hmc-burn-trajectories', type=int, default=100)
    parser.add_argument('--hmc-thin-trajectories', type=int, default=2)
    parser.add_argument('--hmc-step-size-ground', type=float, default=0.01)
    parser.add_argument('--hmc-step-size-excited', type=float, default=0.005)
    parser.add_argument('--hmc-leapfrog-steps', type=int, default=12)
    parser.add_argument('--hmc-target-acceptance', type=float, default=0.65)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-7)
    parser.add_argument(
        "--tolerances", default="1e-5,1e-6,1e-7,1e-8"
    )
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/strict_fq_streaming"),
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    arguments.tolerances = parse_tolerances(arguments.tolerances)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        "strict first-quantized streaming NQS; "
        f"sizes={parse_sizes(arguments.sizes)}, lmax={arguments.lmax}",
        flush=True,
    )
    all_results = []
    for particles in parse_sizes(arguments.sizes):
        started = time.perf_counter()
        ground = train_ground(arguments, particles)
        excited = train_excited(arguments, particles)
        gap = excited["validation_energy"] - ground["validation_energy"]
        gap_stderr = math.hypot(
            excited["validation_stderr"], ground["validation_stderr"]
        )
        result = {
            "particles": particles,
            "two_q": 3 * (particles - 1),
            "ground": ground,
            "excited": excited,
            "gap": gap,
            "gap_stderr": gap_stderr,
            "symmetry": {
                "ground_L2": 0.0,
                "excited_L2": 6.0,
                "status": "exact by SU(2) tensor construction",
            },
            "runtime_seconds": time.perf_counter() - started,
        }
        all_results.append(result)
        print(
            f"N={particles} E0={ground['validation_energy']:.9f}"
            f"+/-{ground['validation_stderr']:.2e} "
            f"E2={excited['validation_energy']:.9f}"
            f"+/-{excited['validation_stderr']:.2e} "
            f"gap={gap:.9f}+/-{gap_stderr:.2e}",
            flush=True,
        )
        payload = {
            "method": (
                "strict first-quantized LLL-SU(2) streaming tensor-feature "
                "NQS; VMC linear method/SR"
            ),
            "important_distinction": (
                "both ground and excited coefficients are trained; SMA is "
                "only the excited-sector importance distribution"
            ),
            "devices": [str(device) for device in jax.devices()],
            "arguments": {
                **vars(arguments),
                "output_dir": str(arguments.output_dir),
            },
            "results": all_results,
        }
        (arguments.output_dir / "results.json").write_text(
            json.dumps(payload, indent=2), encoding="utf-8"
        )
    print(f"wrote {arguments.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
