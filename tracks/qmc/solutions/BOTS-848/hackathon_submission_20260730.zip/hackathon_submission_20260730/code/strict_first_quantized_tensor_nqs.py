#!/usr/bin/env python3
"""Strict first-quantized LLL--SU(2) tensor NQS trained by VMC.

The variational excited state is a trainable linear tensor network

    Psi_22(z) = Psi_L(z) sum_a c_a F_a(z),

where F_a are exact rank-2 irreducible tensors assembled from one-body LLL
density multipoles rho_(ell,m), ell <= lmax.  The density multipoles are
evaluated directly in continuous spinor coordinates as holomorphic
differential operators.  No Fock basis, CI vector, or Hamiltonian matrix is
constructed during training or evaluation.

The coefficients are trained with the VMC linear method (the exact
stochastic-reconfiguration update for a linear ansatz): Laughlin-distributed
GPU samples estimate the overlap and Hamiltonian matrices, followed by a
small generalized eigenproblem.  This is a genuine variational optimization;
the fixed GMP/SMA state is only the first feature channel.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np
import scipy.linalg

from chiral_graviton_ed import clebsch_gordan2
from chiral_graviton_nqs_scaling_gpu import (
    potential_energy,
    random_spinors,
    run_sweeps,
)


Array = jax.Array
RatioFunction = Callable[[Array], Array]
LocalOperator = Callable[[RatioFunction, Array, int], Array]


@dataclass
class Result:
    particles: int
    two_q: int
    lmax: int
    raw_channels: int
    retained_rank: int
    ground_energy: float
    excited_energy: float
    gap: float
    ground_stderr: float
    excited_stderr: float
    gap_stderr: float
    training_ess: float
    training_ess_fraction: float
    validation_ess: float
    validation_ess_fraction: float
    acceptance: float
    coefficients_real: list[float]
    coefficients_imag: list[float]
    channel_labels: list[str]
    runtime_seconds: float


def parse_sizes(specification: str) -> list[int]:
    result: list[int] = []
    for token in specification.split(","):
        fields = token.strip().split(":")
        if len(fields) == 1:
            result.append(int(fields[0]))
        elif len(fields) in (2, 3):
            start, stop = int(fields[0]), int(fields[1])
            step = int(fields[2]) if len(fields) == 3 else 1
            result.extend(range(start, stop + 1, step))
        else:
            raise ValueError(f"invalid size token: {token}")
    result = sorted(set(result))
    if not result or result[0] < 2:
        raise ValueError("at least one N >= 2 is required")
    return result


def laughlin_connections(spinors: Array) -> tuple[Array, Array]:
    """Return partial_u log(Psi_L) and partial_v log(Psi_L)."""

    u = spinors[:, 0]
    v = spinors[:, 1]
    determinant = u[:, None] * v[None, :] - v[:, None] * u[None, :]
    particles = spinors.shape[0]
    inverse = jnp.where(
        jnp.eye(particles, dtype=bool),
        0.0 + 0.0j,
        1.0 / determinant,
    )
    connection_u = 3.0 * jnp.sum(v[None, :] * inverse, axis=1)
    connection_v = -3.0 * jnp.sum(u[None, :] * inverse, axis=1)
    return connection_u, connection_v


def directional_derivative(
    function: RatioFunction,
    spinors: Array,
    particle: int,
    component: int,
) -> Array:
    tangent = jnp.zeros_like(spinors).at[particle, component].set(1.0 + 0.0j)
    return jax.jvp(function, (spinors,), (tangent,))[1]


def angular_operators() -> tuple[LocalOperator, LocalOperator]:
    """Return conjugated single-particle L+ and L- ratio operators."""

    def plus(function: RatioFunction, spinors: Array, particle: int) -> Array:
        _, connection_v = laughlin_connections(spinors)
        value = function(spinors)
        derivative = directional_derivative(function, spinors, particle, 1)
        return spinors[particle, 0] * (
            derivative + connection_v[particle] * value
        )

    def minus(function: RatioFunction, spinors: Array, particle: int) -> Array:
        connection_u, _ = laughlin_connections(spinors)
        value = function(spinors)
        derivative = directional_derivative(function, spinors, particle, 0)
        return spinors[particle, 1] * (
            derivative + connection_u[particle] * value
        )

    return plus, minus


def compose_local(left: LocalOperator, right: LocalOperator) -> LocalOperator:
    def composed(
        function: RatioFunction, spinors: Array, particle: int
    ) -> Array:
        return left(
            lambda coordinates: right(function, coordinates, particle),
            spinors,
            particle,
        )

    return composed


def subtract_local(
    left: LocalOperator, right: LocalOperator, scale: float
) -> LocalOperator:
    def difference(
        function: RatioFunction, spinors: Array, particle: int
    ) -> Array:
        return scale * (
            left(function, spinors, particle)
            - right(function, spinors, particle)
        )

    return difference


def multipole_operators(lmax: int) -> dict[tuple[int, int], LocalOperator]:
    """Build one-particle irreducible tensors from L+^ell and commutators."""

    plus, minus = angular_operators()
    operators: dict[tuple[int, int], LocalOperator] = {}
    for ell in range(2, lmax + 1):
        highest = plus
        for _ in range(ell - 1):
            highest = compose_local(plus, highest)
        operators[(ell, ell)] = highest
        for m in range(ell, -ell, -1):
            current = operators[(ell, m)]
            commutator = subtract_local(
                compose_local(minus, current),
                compose_local(current, minus),
                1.0 / math.sqrt((ell + m) * (ell - m + 1)),
            )
            operators[(ell, m - 1)] = commutator
    return operators


def global_operator(
    local: LocalOperator, function: RatioFunction, spinors: Array
) -> Array:
    total = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
    for particle in range(spinors.shape[0]):
        total = total + local(function, spinors, particle)
    return total


def channel_specifications(lmax: int) -> list[tuple[int, int] | None]:
    specifications: list[tuple[int, int] | None] = [None]
    for left in range(2, lmax + 1):
        for right in range(2, lmax + 1):
            if abs(left - right) <= 2 <= left + right:
                specifications.append((left, right))
    return specifications


def make_feature_function(
    particles: int, lmax: int
) -> tuple[Callable[[Array], Array], list[str]]:
    operators = multipole_operators(lmax)
    specifications = channel_specifications(lmax)
    labels = ["rho_2"]
    labels.extend(f"[rho_{a}xr_{b}]_2" for a, b in specifications[1:])

    def one(spinors: Array) -> Array:
        constant: RatioFunction = lambda coordinates: jnp.asarray(
            1.0 + 0.0j, dtype=coordinates.dtype
        )
        linear = global_operator(operators[(2, 2)], constant, spinors)
        values = [linear]
        for specification in specifications[1:]:
            assert specification is not None
            left, right = specification
            coupled = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
            for m_left in range(-left, left + 1):
                m_right = 2 - m_left
                if abs(m_right) > right:
                    continue
                cg = clebsch_gordan2(
                    2 * left,
                    2 * m_left,
                    2 * right,
                    2 * m_right,
                    4,
                    4,
                )
                if abs(cg) < 1.0e-14:
                    continue
                inner: RatioFunction = (
                    lambda coordinates, op=operators[(right, m_right)]:
                    global_operator(op, constant, coordinates)
                )
                coupled = coupled + cg * global_operator(
                    operators[(left, m_left)], inner, spinors
                )
            values.append(coupled)
        return jnp.stack(values)

    return jax.jit(jax.vmap(one)), labels


def collect_laughlin_samples(
    particles: int,
    chains: int,
    burn_sweeps: int,
    records: int,
    thin_sweeps: int,
    initial_scale: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, float]:
    key = jax.random.PRNGKey(seed + 1009 * particles)
    key, initial_key = jax.random.split(key)
    spinors = random_spinors(initial_key, chains, particles)
    scale = initial_scale / math.sqrt(particles)
    remaining = burn_sweeps
    while remaining:
        block = min(25, remaining)
        spinors, key, acceptance = run_sweeps(
            spinors, key, jnp.asarray(scale), count=block
        )
        acceptance_value = float(jax.device_get(acceptance))
        scale *= math.exp(0.6 * (acceptance_value - 0.45))
        scale = float(np.clip(scale, 0.005, 0.8))
        remaining -= block

    coordinate_records = []
    potential_records = []
    acceptances = []
    two_q = 3 * (particles - 1)
    for _ in range(records):
        spinors, key, acceptance = run_sweeps(
            spinors, key, jnp.asarray(scale), count=thin_sweeps
        )
        coordinate_records.append(np.asarray(jax.device_get(spinors)))
        potential_records.append(
            np.asarray(jax.device_get(potential_energy(spinors, two_q)))
        )
        acceptances.append(float(jax.device_get(acceptance)))
    return (
        np.concatenate(coordinate_records, axis=0),
        np.concatenate(potential_records, axis=0),
        float(np.mean(acceptances)),
    )


def estimate_matrices(
    features: np.ndarray, potential: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    count = features.shape[0]
    overlap = features.conj().T @ features / count
    hamiltonian = features.conj().T @ (potential[:, None] * features) / count
    return 0.5 * (overlap + overlap.conj().T), 0.5 * (
        hamiltonian + hamiltonian.conj().T
    )


def solve_linear_method(
    overlap: np.ndarray,
    hamiltonian: np.ndarray,
    tolerance: float,
) -> tuple[float, np.ndarray, int]:
    eigenvalues, eigenvectors = np.linalg.eigh(overlap)
    keep = eigenvalues > tolerance * max(float(eigenvalues[-1]), 1.0)
    whitening = eigenvectors[:, keep] / np.sqrt(eigenvalues[keep])[None, :]
    projected = whitening.conj().T @ hamiltonian @ whitening
    energies, vectors = np.linalg.eigh(projected)
    coefficients = whitening @ vectors[:, 0]
    coefficients /= np.sqrt(
        np.real(coefficients.conj() @ overlap @ coefficients)
    )
    return float(energies[0]), coefficients, int(np.count_nonzero(keep))


def weighted_statistics(
    features: np.ndarray,
    potential: np.ndarray,
    coefficients: np.ndarray,
    chains: int,
    records: int,
) -> tuple[float, float, float, float]:
    amplitude = features @ coefficients
    weight = np.square(np.abs(amplitude))
    total = float(np.sum(weight))
    energy = float(np.sum(weight * potential) / total)
    ess = total**2 / float(np.sum(np.square(weight)))
    reshaped_weight = weight.reshape(records, chains)
    reshaped_energy = potential.reshape(records, chains)
    chain_weight = np.sum(reshaped_weight, axis=0)
    chain_energy = np.sum(
        reshaped_weight * reshaped_energy, axis=0
    ) / np.maximum(chain_weight, 1.0e-300)
    stderr = float(np.std(chain_energy, ddof=1) / math.sqrt(chains))
    return energy, stderr, ess, ess / len(weight)


def estimate_one_size(arguments: argparse.Namespace, particles: int) -> Result:
    start = time.perf_counter()
    feature_function, labels = make_feature_function(particles, arguments.lmax)
    coordinates, potential, acceptance = collect_laughlin_samples(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        arguments.seed,
    )
    split = arguments.training_records * arguments.chains
    training_coordinates = coordinates[:split]
    validation_coordinates = coordinates[split:]
    training_potential = potential[:split]
    validation_potential = potential[split:]

    def evaluate(coordinates_host: np.ndarray) -> np.ndarray:
        output = []
        for start_index in range(0, len(coordinates_host), arguments.feature_batch):
            batch = jnp.asarray(
                coordinates_host[
                    start_index : start_index + arguments.feature_batch
                ]
            )
            output.append(np.asarray(jax.device_get(feature_function(batch))))
        return np.concatenate(output, axis=0)

    training_features = evaluate(training_coordinates)
    validation_features = evaluate(validation_coordinates)
    overlap, hamiltonian = estimate_matrices(
        training_features, training_potential
    )
    _, coefficients, retained_rank = solve_linear_method(
        overlap, hamiltonian, arguments.whitening_tolerance
    )
    excited_energy, excited_stderr, training_ess, training_fraction = (
        weighted_statistics(
            training_features,
            training_potential,
            coefficients,
            arguments.chains,
            arguments.training_records,
        )
    )
    (
        validation_energy,
        validation_stderr,
        validation_ess,
        validation_fraction,
    ) = weighted_statistics(
        validation_features,
        validation_potential,
        coefficients,
        arguments.chains,
        arguments.records - arguments.training_records,
    )
    ground_matrix = potential.reshape(arguments.records, arguments.chains)
    ground_chain = np.mean(ground_matrix, axis=0)
    ground_energy = float(np.mean(ground_chain))
    ground_stderr = float(np.std(ground_chain, ddof=1) / math.sqrt(arguments.chains))
    gap = validation_energy - ground_energy
    gap_stderr = math.hypot(validation_stderr, ground_stderr)
    result = Result(
        particles=particles,
        two_q=3 * (particles - 1),
        lmax=arguments.lmax,
        raw_channels=len(labels),
        retained_rank=retained_rank,
        ground_energy=ground_energy,
        excited_energy=validation_energy,
        gap=gap,
        ground_stderr=ground_stderr,
        excited_stderr=validation_stderr,
        gap_stderr=gap_stderr,
        training_ess=training_ess,
        training_ess_fraction=training_fraction,
        validation_ess=validation_ess,
        validation_ess_fraction=validation_fraction,
        acceptance=acceptance,
        coefficients_real=np.real(coefficients).tolist(),
        coefficients_imag=np.imag(coefficients).tolist(),
        channel_labels=labels,
        runtime_seconds=time.perf_counter() - start,
    )
    print(
        f"N={particles} rank={retained_rank}/{len(labels)} "
        f"E2(train)={excited_energy:.9f} "
        f"E2(valid)={validation_energy:.9f} "
        f"gap={gap:.9f}+/-{gap_stderr:.2e} "
        f"ESS(valid)={validation_fraction:.3f} "
        f"time={result.runtime_seconds:.1f}s",
        flush=True,
    )
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="4,5,6")
    parser.add_argument("--lmax", type=int, choices=(2, 3, 4), default=2)
    parser.add_argument("--chains", type=int, default=64)
    parser.add_argument("--burn-sweeps", type=int, default=300)
    parser.add_argument("--records", type=int, default=64)
    parser.add_argument("--training-records", type=int, default=32)
    parser.add_argument("--thin-sweeps", type=int, default=4)
    parser.add_argument("--feature-batch", type=int, default=64)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-9)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/strict_first_quantized_tensor_nqs"),
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    if not 0 < arguments.training_records < arguments.records:
        raise ValueError("training-records must be between 0 and records")
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        "strict first-quantized VMC linear-method training; "
        f"sizes={parse_sizes(arguments.sizes)}, lmax={arguments.lmax}",
        flush=True,
    )
    results = [
        estimate_one_size(arguments, particles)
        for particles in parse_sizes(arguments.sizes)
    ]
    payload = {
        "method": (
            "strict first-quantized LLL-SU(2) multi-channel tensor NQS; "
            "VMC linear-method training"
        ),
        "ansatz": (
            "trainable CG-coupled projected-density tensors acting on "
            "the Laughlin seed"
        ),
        "symmetry": {
            "ground_L2": 0.0,
            "excited_L2": 6.0,
            "status": "exact by irreducible-tensor construction",
        },
        "devices": [str(device) for device in jax.devices()],
        "arguments": {
            **vars(arguments),
            "output_dir": str(arguments.output_dir),
        },
        "results": [asdict(result) for result in results],
    }
    (arguments.output_dir / "results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    with (arguments.output_dir / "results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                key
                for key in asdict(results[0])
                if key
                not in (
                    "coefficients_real",
                    "coefficients_imag",
                    "channel_labels",
                )
            ],
        )
        writer.writeheader()
        for result in results:
            row = asdict(result)
            for key in (
                "coefficients_real",
                "coefficients_imag",
                "channel_labels",
            ):
                row.pop(key)
            writer.writerow(row)
    print(f"wrote {arguments.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
