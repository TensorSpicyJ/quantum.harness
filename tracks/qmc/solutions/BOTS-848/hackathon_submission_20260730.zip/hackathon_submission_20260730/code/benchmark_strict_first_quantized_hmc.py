#!/usr/bin/env python3
# Compare local Metropolis and global spherical HMC reference sampling.

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import jax
import numpy as np

from strict_first_quantized_hmc import collect_hmc_samples
from strict_first_quantized_tensor_nqs import collect_laughlin_samples, parse_sizes
from strict_first_quantized_tensor_nqs_v3 import collect_sma_samples


def autocorrelation_diagnostics(values: np.ndarray, records: int, chains: int) -> dict:
    series = values.reshape(records, chains)
    centered = series - np.mean(series, axis=0, keepdims=True)
    variance = float(np.mean(np.square(centered)))
    if variance <= 0.0:
        return {'tau_int': 1.0, 'ess': float(records * chains)}
    correlations = []
    for lag in range(1, records):
        value = float(np.mean(centered[:-lag] * centered[lag:]) / variance)
        correlations.append(value)
        if value <= 0.0:
            break
    positive = [value for value in correlations if value > 0.0]
    tau = max(1.0, 1.0 + 2.0 * float(np.sum(positive)))
    return {
        'tau_int': tau,
        'ess': float(records * chains / tau),
        'positive_lags': len(positive),
    }


def run_one(arguments, particles: int, target: str, sampler: str) -> dict:
    started = time.perf_counter()
    if sampler == 'hmc':
        step = arguments.hmc_step_ground if target == 'laughlin' else arguments.hmc_step_excited
        _, potential, acceptance, diagnostics = collect_hmc_samples(
            particles,
            arguments.chains,
            arguments.hmc_burn,
            arguments.records,
            arguments.hmc_thin,
            step,
            arguments.hmc_leapfrog,
            arguments.seed + particles + (0 if target == 'laughlin' else 10000),
            target,
        )
    else:
        collector = collect_laughlin_samples if target == 'laughlin' else collect_sma_samples
        _, potential, acceptance = collector(
            particles,
            arguments.chains,
            arguments.metropolis_burn,
            arguments.records,
            arguments.metropolis_thin,
            arguments.initial_scale,
            arguments.seed + particles + (0 if target == 'laughlin' else 10000),
        )
        diagnostics = {'sampler': 'local_random_walk_metropolis'}
    elapsed = time.perf_counter() - started
    correlation = autocorrelation_diagnostics(
        np.asarray(potential), arguments.records, arguments.chains
    )
    return {
        'particles': particles,
        'target': target,
        'sampler': sampler,
        'mean_potential': float(np.mean(potential)),
        'potential_stderr_naive': float(np.std(potential, ddof=1) / np.sqrt(len(potential))),
        'acceptance': float(acceptance),
        'seconds': elapsed,
        'tau_int_potential': correlation['tau_int'],
        'ess_potential': correlation['ess'],
        'ess_per_second': correlation['ess'] / elapsed,
        'positive_lags': correlation['positive_lags'],
        'sampler_diagnostics': diagnostics,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--sizes', default='12,20,40')
    parser.add_argument('--targets', default='laughlin,sma')
    parser.add_argument('--chains', type=int, default=64)
    parser.add_argument('--records', type=int, default=64)
    parser.add_argument('--metropolis-burn', type=int, default=300)
    parser.add_argument('--metropolis-thin', type=int, default=5)
    parser.add_argument('--initial-scale', type=float, default=0.9)
    parser.add_argument('--hmc-burn', type=int, default=100)
    parser.add_argument('--hmc-thin', type=int, default=1)
    parser.add_argument('--hmc-step-ground', type=float, default=0.01)
    parser.add_argument('--hmc-step-excited', type=float, default=0.005)
    parser.add_argument('--hmc-leapfrog', type=int, default=12)
    parser.add_argument('--seed', type=int, default=20260730)
    parser.add_argument('--output-dir', type=Path, default=Path('runs/hmc_benchmark'))
    arguments = parser.parse_args()
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for particles in parse_sizes(arguments.sizes):
        for target in arguments.targets.split(','):
            for sampler in ('metropolis', 'hmc'):
                row = run_one(arguments, particles, target.strip(), sampler)
                rows.append(row)
                print(row, flush=True)
    payload = {
        'devices': [str(device) for device in jax.devices()],
        'arguments': {**vars(arguments), 'output_dir': str(arguments.output_dir)},
        'rows': rows,
    }
    (arguments.output_dir / 'results.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    flat_rows = [{key: value for key, value in row.items() if key != 'sampler_diagnostics'} for row in rows]
    with (arguments.output_dir / 'results.csv').open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(flat_rows[0]))
        writer.writeheader()
        writer.writerows(flat_rows)
    print(f'wrote {arguments.output_dir.resolve()}', flush=True)


if __name__ == '__main__':
    main()
