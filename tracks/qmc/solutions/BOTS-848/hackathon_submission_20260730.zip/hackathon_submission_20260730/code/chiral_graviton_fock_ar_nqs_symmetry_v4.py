#!/usr/bin/env python3
"""V4 symmetry-focused Fock NQS with importance-sampled L_-L_+."""

from __future__ import annotations

from typing import Any

import chiral_graviton_fock_ar_nqs_symmetry_v3 as v3


jax = v3.jax
jnp = v3.jnp
PyTree = v3.PyTree


def make_lplus_norm_importance(
    particles: int,
    log_psi: Any,
    hops: int,
    ratio_clip: float,
) -> Any:
    """Unbiased allowed-move importance sampler for L_-L_+.

    The diagonal undo term is exact. Cross terms sample a valid raising move
    and then a valid non-undo lowering move, both proportional to their ladder
    coefficients. Inverse proposal probabilities recover the complete sum.
    """

    two_q = 3 * (particles - 1)
    norbitals = two_q + 1
    orbital_axis = jnp.arange(norbitals, dtype=jnp.int32)
    raising_coefficients = jnp.sqrt(
        jnp.asarray(
            [
                0.5 * (two_q - (-two_q + 2 * i))
                * (0.5 * (two_q + (-two_q + 2 * i)) + 1.0)
                for i in range(norbitals - 1)
            ],
            dtype=jnp.float32,
        )
    )

    def local(
        params: PyTree,
        occupations: jax.Array,
        log_values: jax.Array,
        sector_M: int,
        key: jax.Array,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        batch = occupations.shape[0]
        occupied = jnp.sort(
            jnp.where(occupations > 0, orbital_axis[None, :], norbitals),
            axis=1,
        )[:, :particles]
        safe_occupied = jnp.minimum(occupied, norbitals - 2)
        valid_all_raise = (
            (occupied < norbitals - 1)
            & (
                occupations[
                    jnp.arange(batch)[:, None],
                    jnp.minimum(occupied + 1, norbitals - 1),
                ]
                == 0
            )
        )
        raise_coeff_all = raising_coefficients[safe_occupied]
        diagonal = jnp.sum(
            valid_all_raise * raise_coeff_all**2, axis=1
        )

        raise_key, lower_key = jax.random.split(key)
        raise_weights = jnp.where(
            valid_all_raise, raise_coeff_all, 0.0
        )
        raise_total = jnp.sum(raise_weights, axis=1)
        raise_logits = jnp.where(
            raise_weights > 0.0,
            jnp.log(raise_weights + 1.0e-30),
            -1.0e30,
        )
        raise_position = jnp.argmax(
            raise_logits[:, None, :]
            + jax.random.gumbel(
                raise_key, (batch, hops, particles)
            ),
            axis=2,
        ).astype(jnp.int32)
        row = jnp.arange(batch, dtype=jnp.int32)[:, None]
        hop = jnp.arange(hops, dtype=jnp.int32)[None, :]
        raised_from = occupied[row, raise_position]
        raised_to = jnp.minimum(raised_from + 1, norbitals - 1)
        selected_raise_weight = jnp.take_along_axis(
            raise_weights, raise_position, axis=1
        )
        raise_probability = selected_raise_weight / jnp.maximum(
            raise_total[:, None], 1.0e-30
        )
        valid_raise = raise_total[:, None] > 0.0

        intermediate = jnp.broadcast_to(
            occupations[:, None, :], (batch, hops, norbitals)
        )
        intermediate = intermediate.at[row, hop, raised_from].set(0)
        intermediate = intermediate.at[row, hop, raised_to].set(1)
        intermediate = jnp.where(
            valid_raise[:, :, None],
            intermediate,
            occupations[:, None, :],
        )
        intermediate_occupied = jnp.sort(
            jnp.where(
                intermediate > 0,
                orbital_axis[None, None, :],
                norbitals,
            ),
            axis=2,
        )[:, :, :particles]
        lower_from_all = intermediate_occupied
        lower_to_all = jnp.maximum(lower_from_all - 1, 0)
        row3 = jnp.arange(batch, dtype=jnp.int32)[:, None, None]
        hop3 = jnp.arange(hops, dtype=jnp.int32)[None, :, None]
        valid_lower_all = (
            (lower_from_all > 0)
            & (intermediate[row3, hop3, lower_to_all] == 0)
            & (lower_from_all != raised_to[:, :, None])
            & valid_raise[:, :, None]
        )
        lower_coeff_all = raising_coefficients[
            jnp.minimum(lower_to_all, norbitals - 2)
        ]
        lower_weights = jnp.where(
            valid_lower_all, lower_coeff_all, 0.0
        )
        lower_total = jnp.sum(lower_weights, axis=2)
        lower_logits = jnp.where(
            lower_weights > 0.0,
            jnp.log(lower_weights + 1.0e-30),
            -1.0e30,
        )
        lower_position = jnp.argmax(
            lower_logits
            + jax.random.gumbel(
                lower_key, (batch, hops, particles)
            ),
            axis=2,
        ).astype(jnp.int32)
        lowered_from = jnp.take_along_axis(
            lower_from_all, lower_position[:, :, None], axis=2
        )[:, :, 0]
        lowered_to = jnp.maximum(lowered_from - 1, 0)
        selected_lower_weight = jnp.take_along_axis(
            lower_weights, lower_position[:, :, None], axis=2
        )[:, :, 0]
        lower_probability = selected_lower_weight / jnp.maximum(
            lower_total, 1.0e-30
        )
        has_cross = valid_raise & (lower_total > 0.0)

        moved = intermediate.at[row, hop, lowered_from].set(0)
        moved = moved.at[row, hop, lowered_to].set(1)
        moved = jnp.where(
            has_cross[:, :, None], moved, occupations[:, None, :]
        )
        candidate_logs = log_psi(
            params, moved.reshape(batch * hops, norbitals), sector_M
        ).reshape(batch, hops)
        delta = candidate_logs - log_values[:, None]
        clipped_real = jnp.clip(jnp.real(delta), -ratio_clip, ratio_clip)
        ratio = jnp.exp(clipped_real + 1j * jnp.imag(delta))
        raise_coefficient = raising_coefficients[
            jnp.minimum(raised_from, norbitals - 2)
        ]
        lower_coefficient = raising_coefficients[
            jnp.minimum(lowered_to, norbitals - 2)
        ]
        cross_samples = (
            raise_coefficient
            * lower_coefficient
            * ratio
            / jnp.maximum(
                raise_probability * lower_probability, 1.0e-30
            )
            * has_cross
        )
        value = diagonal + jnp.mean(cross_samples, axis=1)
        clip_event = (
            (jnp.real(delta) < -ratio_clip)
            | (jnp.real(delta) > ratio_clip)
        ) & has_cross
        valid_count = jnp.maximum(jnp.sum(has_cross), 1)
        return value, {
            "lplus_valid_fraction": jnp.mean(has_cross),
            "lplus_clip_fraction": jnp.sum(clip_event) / valid_count,
        }

    return local


def main() -> None:
    v3.parse_v3_options()
    v3.v2.make_local_energy = v3.make_local_energy_importance
    v3.v2.make_lplus_norm_local = make_lplus_norm_importance
    v3.v2.make_train_step = v3.make_train_step_symmetry_v3
    v3.v2.train_one = v3.train_one_v3
    v3.v2.main()


if __name__ == "__main__":
    main()
