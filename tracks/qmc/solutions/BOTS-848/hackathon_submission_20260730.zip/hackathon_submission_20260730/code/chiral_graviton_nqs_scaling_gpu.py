#!/usr/bin/env python3
"""Matrix-free GPU VMC scaling for the spherical chiral-graviton gap.

This is the scalable one-tensor-head limit of the symmetry-focused NQS:

    ground:  Psi_L = prod_{i<j} (u_i v_j - v_i u_j)^3
    excited: Psi_22 = [sum_i (L_{i,+})^2] Psi_L

The ratio Psi_22/Psi_L is evaluated analytically, so neither the Fock basis
nor a many-body Hamiltonian matrix is constructed.  Coulomb energies are
sampled in first quantization on the Haldane sphere.  Ground and excited
distributions are sampled independently by direct GPU Metropolis VMC; no
importance reweighting is used.

The scalable SMA result is deliberately kept separate from the more
expressive explicit Fock-space NQS V2 benchmarks at N <= 10.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass
from functools import partial
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np


Array = jax.Array


@dataclass
class ScalingResult:
    particles: int
    two_q: int
    ground_energy: float
    excited_energy: float
    gap: float
    ground_energy_variance: float
    excited_energy_variance: float
    gap_block_variance: float
    gap_stderr: float
    reweight_ess: float
    reweight_ess_fraction: float
    acceptance: float
    excited_acceptance: float
    sampling_mode: str
    proposal_scale: float
    chains: int
    records_per_chain: int
    runtime_seconds: float


def parse_sizes(specification: str) -> list[int]:
    """Parse comma-separated integers and inclusive ranges a:b[:step]."""

    sizes: list[int] = []
    for token in specification.split(","):
        token = token.strip()
        if not token:
            continue
        fields = token.split(":")
        if len(fields) == 1:
            sizes.append(int(fields[0]))
            continue
        if len(fields) not in (2, 3):
            raise ValueError(f"invalid size token: {token}")
        start, stop = int(fields[0]), int(fields[1])
        step = int(fields[2]) if len(fields) == 3 else 1
        if step <= 0 or stop < start:
            raise ValueError(f"invalid size range: {token}")
        sizes.extend(range(start, stop + 1, step))
    result = sorted(set(sizes))
    if not result or result[0] < 2:
        raise ValueError("at least one N >= 2 is required")
    return result


def random_spinors(key: Array, chains: int, particles: int) -> Array:
    """Uniform random normalized complex spinors."""

    real, imag = jax.random.normal(
        key, (2, chains, particles, 2), dtype=jnp.float64
    )
    spinors = real + 1.0j * imag
    return spinors / jnp.linalg.norm(spinors, axis=-1, keepdims=True)


@jax.jit
def _metropolis_sweep(
    spinors: Array, key: Array, proposal_scale: Array
) -> tuple[Array, Array, Array]:
    """One sweep: update every particle once in every independent chain."""

    particles = spinors.shape[1]

    def update_particle(index, state):
        coordinates, update_key, accepted_total = state
        update_key, noise_key, uniform_key = jax.random.split(update_key, 3)
        real, imag = jax.random.normal(
            noise_key,
            (2, coordinates.shape[0], 2),
            dtype=jnp.float64,
        )
        proposal = coordinates[:, index, :] + proposal_scale * (
            real + 1.0j * imag
        )
        proposal /= jnp.linalg.norm(proposal, axis=-1, keepdims=True)

        old = coordinates[:, index, :]
        old_det = (
            old[:, None, 0] * coordinates[:, :, 1]
            - old[:, None, 1] * coordinates[:, :, 0]
        )
        new_det = (
            proposal[:, None, 0] * coordinates[:, :, 1]
            - proposal[:, None, 1] * coordinates[:, :, 0]
        )
        old_abs = jnp.abs(old_det).at[:, index].set(1.0)
        new_abs = jnp.abs(new_det).at[:, index].set(1.0)
        delta_log_probability = 6.0 * jnp.sum(
            jnp.log(jnp.maximum(new_abs, 1.0e-300))
            - jnp.log(jnp.maximum(old_abs, 1.0e-300)),
            axis=1,
        )
        accept = (
            jnp.log(jax.random.uniform(uniform_key, (coordinates.shape[0],)))
            < delta_log_probability
        )
        updated = jnp.where(accept[:, None], proposal, old)
        coordinates = coordinates.at[:, index, :].set(updated)
        return coordinates, update_key, accepted_total + jnp.mean(accept)

    spinors, key, accepted = jax.lax.fori_loop(
        0,
        particles,
        update_particle,
        (spinors, key, jnp.asarray(0.0, dtype=jnp.float64)),
    )
    return spinors, key, accepted / particles


@partial(jax.jit, static_argnames=("count",))
def run_sweeps(
    spinors: Array, key: Array, proposal_scale: Array, count: int
) -> tuple[Array, Array, Array]:
    """Run a static number of Metropolis sweeps."""

    def body(_, state):
        coordinates, sweep_key, acceptance_sum = state
        coordinates, sweep_key, acceptance = _metropolis_sweep(
            coordinates, sweep_key, proposal_scale
        )
        return coordinates, sweep_key, acceptance_sum + acceptance

    spinors, key, acceptance = jax.lax.fori_loop(
        0,
        count,
        body,
        (spinors, key, jnp.asarray(0.0, dtype=jnp.float64)),
    )
    return spinors, key, acceptance / count


@jax.jit
def tensor_components(spinors: Array) -> tuple[Array, Array, Array]:
    """Return derivative arrays A, B and the tensor ratio."""

    u = spinors[:, :, 0]
    v = spinors[:, :, 1]
    determinant = (
        u[:, :, None] * v[:, None, :]
        - v[:, :, None] * u[:, None, :]
    )
    particles = spinors.shape[1]
    inverse = jnp.where(
        jnp.eye(particles, dtype=bool)[None, :, :],
        0.0 + 0.0j,
        1.0 / determinant,
    )
    u_j = u[:, None, :]
    first_derivative = -3.0 * jnp.sum(u_j * inverse, axis=2)
    second_term = -3.0 * jnp.sum(
        jnp.square(u_j) * jnp.square(inverse), axis=2
    )
    ratio = jnp.sum(
        jnp.square(u)
        * (jnp.square(first_derivative) + second_term),
        axis=1,
    )
    return first_derivative, second_term, ratio


@jax.jit
def _excited_metropolis_sweep(
    spinors: Array,
    key: Array,
    proposal_scale: Array,
    first_derivative: Array,
    second_term: Array,
    current_ratio: Array,
) -> tuple[Array, Array, Array, Array, Array, Array]:
    """One O(N^2) sweep targeting the direct excited density."""

    particles = spinors.shape[1]

    def update_particle(index, state):
        (
            coordinates,
            update_key,
            current_first,
            current_second,
            ratio,
            accepted_total,
        ) = state
        update_key, noise_key, uniform_key = jax.random.split(update_key, 3)
        real, imag = jax.random.normal(
            noise_key,
            (2, coordinates.shape[0], 2),
            dtype=jnp.float64,
        )
        proposal = coordinates[:, index, :] + proposal_scale * (
            real + 1.0j * imag
        )
        proposal /= jnp.linalg.norm(proposal, axis=-1, keepdims=True)
        old = coordinates[:, index, :]
        old_det = (
            old[:, None, 0] * coordinates[:, :, 1]
            - old[:, None, 1] * coordinates[:, :, 0]
        )
        new_det = (
            proposal[:, None, 0] * coordinates[:, :, 1]
            - proposal[:, None, 1] * coordinates[:, :, 0]
        )
        old_abs = jnp.abs(old_det).at[:, index].set(1.0)
        new_abs = jnp.abs(new_det).at[:, index].set(1.0)
        ground_delta = 6.0 * jnp.sum(
            jnp.log(jnp.maximum(new_abs, 1.0e-300))
            - jnp.log(jnp.maximum(old_abs, 1.0e-300)),
            axis=1,
        )

        old_inverse = (1.0 / old_det.at[:, index].set(1.0)).at[
            :, index
        ].set(0.0)
        new_inverse = (1.0 / new_det.at[:, index].set(1.0)).at[
            :, index
        ].set(0.0)
        all_u = coordinates[:, :, 0]
        old_u = old[:, 0]
        new_u = proposal[:, 0]
        first_delta = 3.0 * (
            new_u[:, None] * new_inverse
            - old_u[:, None] * old_inverse
        )
        second_delta = -3.0 * (
            jnp.square(new_u[:, None]) * jnp.square(new_inverse)
            - jnp.square(old_u[:, None]) * jnp.square(old_inverse)
        )
        first_delta = first_delta.at[:, index].set(0.0)
        second_delta = second_delta.at[:, index].set(0.0)
        proposed_first = current_first + first_delta
        proposed_second = current_second + second_delta
        proposed_first = proposed_first.at[:, index].set(
            -3.0 * jnp.sum(all_u * new_inverse, axis=1)
        )
        proposed_second = proposed_second.at[:, index].set(
            -3.0 * jnp.sum(
                jnp.square(all_u) * jnp.square(new_inverse), axis=1
            )
        )
        proposed_u = all_u.at[:, index].set(new_u)
        proposed_ratio = jnp.sum(
            jnp.square(proposed_u)
            * (jnp.square(proposed_first) + proposed_second),
            axis=1,
        )
        tensor_delta = 2.0 * (
            jnp.log(jnp.maximum(jnp.abs(proposed_ratio), 1.0e-300))
            - jnp.log(jnp.maximum(jnp.abs(ratio), 1.0e-300))
        )
        accept = (
            jnp.log(jax.random.uniform(uniform_key, (coordinates.shape[0],)))
            < ground_delta + tensor_delta
        )
        coordinates = coordinates.at[:, index, :].set(
            jnp.where(accept[:, None], proposal, old)
        )
        current_first = jnp.where(
            accept[:, None], proposed_first, current_first
        )
        current_second = jnp.where(
            accept[:, None], proposed_second, current_second
        )
        ratio = jnp.where(accept, proposed_ratio, ratio)
        return (
            coordinates,
            update_key,
            current_first,
            current_second,
            ratio,
            accepted_total + jnp.mean(accept),
        )

    (
        spinors,
        key,
        first_derivative,
        second_term,
        current_ratio,
        accepted,
    ) = jax.lax.fori_loop(
        0,
        particles,
        update_particle,
        (
            spinors,
            key,
            first_derivative,
            second_term,
            current_ratio,
            jnp.asarray(0.0, dtype=jnp.float64),
        ),
    )
    return (
        spinors,
        key,
        first_derivative,
        second_term,
        current_ratio,
        accepted / particles,
    )


@partial(jax.jit, static_argnames=("count",))
def run_excited_sweeps(
    spinors: Array,
    key: Array,
    proposal_scale: Array,
    first_derivative: Array,
    second_term: Array,
    current_ratio: Array,
    count: int,
) -> tuple[Array, Array, Array, Array, Array, Array]:
    """Run direct excited sweeps using incremental tensor derivatives."""

    def body(_, state):
        (
            coordinates,
            sweep_key,
            current_first,
            current_second,
            ratio,
            acceptance_sum,
        ) = state
        (
            coordinates,
            sweep_key,
            current_first,
            current_second,
            ratio,
            acceptance,
        ) = _excited_metropolis_sweep(
            coordinates,
            sweep_key,
            proposal_scale,
            current_first,
            current_second,
            ratio,
        )
        return (
            coordinates,
            sweep_key,
            current_first,
            current_second,
            ratio,
            acceptance_sum + acceptance,
        )

    (
        spinors,
        key,
        first_derivative,
        second_term,
        current_ratio,
        acceptance,
    ) = jax.lax.fori_loop(
        0,
        count,
        body,
        (
            spinors,
            key,
            first_derivative,
            second_term,
            current_ratio,
            jnp.asarray(0.0, dtype=jnp.float64),
        ),
    )
    return (
        spinors,
        key,
        first_derivative,
        second_term,
        current_ratio,
        acceptance / count,
    )

@jax.jit
def potential_energy(spinors: Array, two_q: int) -> Array:
    """Coulomb interaction in e^2/(epsilon l_B) for every chain."""

    u = spinors[:, :, 0]
    v = spinors[:, :, 1]
    determinant = (
        u[:, :, None] * v[:, None, :]
        - v[:, :, None] * u[:, None, :]
    )
    particles = spinors.shape[1]
    upper = jnp.triu(jnp.ones((particles, particles), dtype=bool), k=1)
    chord_factor = jnp.maximum(jnp.abs(determinant), 1.0e-300)
    radius = jnp.sqrt(0.5 * two_q)
    return jnp.sum(
        jnp.where(
            upper[None, :, :],
            1.0 / (2.0 * radius * chord_factor),
            0.0,
        ),
        axis=(1, 2),
    )


def estimate_one_size(
    particles: int,
    chains: int,
    burn_sweeps: int,
    records: int,
    thin_sweeps: int,
    initial_scale: float,
    seed: int,
) -> ScalingResult:
    """Sample ground and excited NQS distributions independently on GPU."""

    start = time.perf_counter()
    two_q = 3 * (particles - 1)
    master_key = jax.random.PRNGKey(seed + 1009 * particles)
    ground_key, excited_key, ground_init_key, excited_init_key = (
        jax.random.split(master_key, 4)
    )
    ground_spinors = random_spinors(ground_init_key, chains, particles)
    excited_spinors = random_spinors(excited_init_key, chains, particles)
    (
        excited_first,
        excited_second,
        excited_ratio,
    ) = tensor_components(excited_spinors)
    ground_scale = initial_scale / math.sqrt(particles)
    excited_scale = initial_scale / math.sqrt(particles)

    remaining = burn_sweeps
    while remaining:
        block = min(25, remaining)
        ground_spinors, ground_key, ground_acceptance = run_sweeps(
            ground_spinors,
            ground_key,
            jnp.asarray(ground_scale),
            count=block,
        )
        (
            excited_spinors,
            excited_key,
            excited_first,
            excited_second,
            excited_ratio,
            excited_acceptance,
        ) = run_excited_sweeps(
            excited_spinors,
            excited_key,
            jnp.asarray(excited_scale),
            excited_first,
            excited_second,
            excited_ratio,
            count=block,
        )
        ground_acceptance_value = float(jax.device_get(ground_acceptance))
        excited_acceptance_value = float(jax.device_get(excited_acceptance))
        ground_scale *= math.exp(0.6 * (ground_acceptance_value - 0.45))
        excited_scale *= math.exp(0.6 * (excited_acceptance_value - 0.40))
        ground_scale = float(np.clip(ground_scale, 0.005, 0.8))
        excited_scale = float(np.clip(excited_scale, 0.003, 0.8))
        remaining -= block

    ground_records: list[np.ndarray] = []
    excited_records: list[np.ndarray] = []
    ground_acceptances: list[float] = []
    excited_acceptances: list[float] = []
    for _ in range(records):
        ground_spinors, ground_key, ground_acceptance = run_sweeps(
            ground_spinors,
            ground_key,
            jnp.asarray(ground_scale),
            count=thin_sweeps,
        )
        (
            excited_spinors,
            excited_key,
            excited_first,
            excited_second,
            excited_ratio,
            excited_acceptance,
        ) = run_excited_sweeps(
            excited_spinors,
            excited_key,
            jnp.asarray(excited_scale),
            excited_first,
            excited_second,
            excited_ratio,
            count=thin_sweeps,
        )
        ground_records.append(
            np.asarray(jax.device_get(potential_energy(ground_spinors, two_q)))
        )
        excited_records.append(
            np.asarray(jax.device_get(potential_energy(excited_spinors, two_q)))
        )
        ground_acceptances.append(float(jax.device_get(ground_acceptance)))
        excited_acceptances.append(float(jax.device_get(excited_acceptance)))

    ground_potential = np.stack(ground_records)
    excited_potential = np.stack(excited_records)
    ground_energy = float(np.mean(ground_potential))
    excited_energy = float(np.mean(excited_potential))
    gap = excited_energy - ground_energy
    ground_variance = float(np.var(ground_potential, ddof=1))
    excited_variance = float(np.var(excited_potential, ddof=1))
    gap_by_chain = (
        np.mean(excited_potential, axis=0)
        - np.mean(ground_potential, axis=0)
    )
    gap_block_variance = float(np.var(gap_by_chain, ddof=1))
    gap_stderr = math.sqrt(gap_block_variance / chains)
    sample_count = float(ground_potential.size)

    result = ScalingResult(
        particles=particles,
        two_q=two_q,
        ground_energy=ground_energy,
        excited_energy=excited_energy,
        gap=gap,
        ground_energy_variance=ground_variance,
        excited_energy_variance=excited_variance,
        gap_block_variance=gap_block_variance,
        gap_stderr=gap_stderr,
        reweight_ess=sample_count,
        reweight_ess_fraction=1.0,
        acceptance=float(np.mean(ground_acceptances)),
        excited_acceptance=float(np.mean(excited_acceptances)),
        sampling_mode="direct_incremental_ground_and_excited",
        proposal_scale=ground_scale,
        chains=chains,
        records_per_chain=records,
        runtime_seconds=time.perf_counter() - start,
    )
    print(
        f"N={particles:2d} gap={result.gap:.9f} "
        f"+/-{result.gap_stderr:.2e} "
        f"var_gap={result.gap_block_variance:.2e} "
        f"var_E=({result.ground_energy_variance:.2e},"
        f"{result.excited_energy_variance:.2e}) "
        f"acc=({result.acceptance:.3f},"
        f"{result.excited_acceptance:.3f}) "
        f"time={result.runtime_seconds:.1f}s",
        flush=True,
    )
    return result

EXPLICIT_FOCK_NQS = {
    4: 0.13185675492702065,
    5: 0.126172063848,
    6: 0.131688411965,
    7: 0.129198097823,
    8: 0.128787201036470,
    9: 0.130509157061733,
    10: 0.129253598510125,
}


def write_csv(path: Path, results: list[ScalingResult]) -> None:
    fields = list(asdict(results[0]).keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(result) for result in results)


def write_report(
    path: Path, results: list[ScalingResult], arguments: argparse.Namespace
) -> None:
    """Write the data table and a weighted finite-size summary."""

    large = [result for result in results if result.particles >= 14]
    sizes = np.asarray([result.particles for result in large], dtype=float)
    gaps = np.asarray([result.gap for result in large])
    errors = np.asarray([result.gap_stderr for result in large])
    weights = 1.0 / np.square(errors)
    weighted_mean = float(np.sum(weights * gaps) / np.sum(weights))
    weighted_mean_error = float(1.0 / np.sqrt(np.sum(weights)))
    design = np.column_stack((np.ones_like(sizes), 1.0 / sizes))
    normal = design.T @ (weights[:, None] * design)
    covariance = np.linalg.inv(normal)
    fit = covariance @ (design.T @ (weights * gaps))
    residual = gaps - design @ fit
    chi_square = float(np.sum(np.square(residual / errors)))

    offsets = []
    for result in results:
        benchmark = EXPLICIT_FOCK_NQS.get(result.particles)
        if benchmark is not None:
            offsets.append(result.gap - benchmark)
    if offsets:
        offset_summary = (
            f"- mean scalable-minus-explicit offset for available N<=10: "
            f"`{np.mean(offsets):+.6f}` (range "
            f"`{np.min(offsets):+.6f}` to `{np.max(offsets):+.6f}`)"
        )
    else:
        offset_summary = (
            "- small-N ansatz offset: unavailable in this size-only run; "
            "use the N=4...40 benchmark report"
        )

    lines = [
        "# Matrix-free NQS/SMA GPU scaling results",
        "",
        "The scalable ansatz is the exact Laughlin seed plus the highest-"
        "weight rank-2 density head. Ground and excited distributions were "
        "sampled independently; no importance reweighting is used.",
        "",
        f"- GPU devices: `{jax.devices()}`",
        f"- chains: {arguments.chains}",
        f"- burn sweeps: {arguments.burn_sweeps}",
        f"- records per chain: {arguments.records}",
        f"- thin sweeps: {arguments.thin_sweeps}",
        "- energy unit: `e^2/(epsilon l_B)`",
        "",
        "## Finite-size summary inside this scalable ansatz",
        "",
        f"- weighted mean for N >= 14: `{weighted_mean:.9f} +/- "
        f"{weighted_mean_error:.2e}` (MC error only)",
        f"- weighted fit Delta(N)=Delta_inf+a/N: `Delta_inf="
        f"{fit[0]:.9f} +/- {math.sqrt(covariance[0,0]):.2e}`",
        f"- fit slope: `{fit[1]:.9f}`; chi2/dof: "
        f"`{chi_square:.2f}/{max(len(large)-2, 0)}`",
        offset_summary,

        "",
        "The fit error above is statistical only. The small-N offset shows "
        "that one tensor head has an O(1e-2) ansatz systematic error, so the "
        "extrapolated number must not be presented as explicit-NQS accuracy.",
        "",
        "## Per-size data",
        "",
        "| N | gap | stderr | gap block variance | var(E0) | var(E2) | "
        "acc(E0) | acc(E2) | runtime(s) |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for result in results:
        lines.append(
            f"| {result.particles} | {result.gap:.9f} | "
            f"{result.gap_stderr:.3e} | "
            f"{result.gap_block_variance:.3e} | "
            f"{result.ground_energy_variance:.3e} | "
            f"{result.excited_energy_variance:.3e} | "
            f"{result.acceptance:.3f} | "
            f"{result.excited_acceptance:.3f} | "
            f"{result.runtime_seconds:.1f} |"
        )
    lines.extend(
        [
            "",
            "## Reliability note",
            "",
            "`gap_block_variance` is the variance across independent-chain "
            "gap estimates and `stderr=sqrt(gap_block_variance/chains)`. "
            "This incorporates within-chain autocorrelation at the chosen "
            "record spacing more conservatively than treating all records "
            "as independent.",
            "",
            "For N <= 10, the explicit Fock-space NQS V2 remains the accuracy "
            "benchmark. The matrix-free branch is intended for scaling and "
            "boundary exploration through N=40.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--sizes",
        default="4:12,14:40:2",
        help="comma-separated N values or inclusive a:b[:step] ranges",
    )
    parser.add_argument("--chains", type=int, default=128)
    parser.add_argument("--burn-sweeps", type=int, default=300)
    parser.add_argument("--records", type=int, default=64)
    parser.add_argument("--thin-sweeps", type=int, default=4)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument("--seed", type=int, default=20260728)
    parser.add_argument(
        "--output-dir", type=Path, default=Path("runs/nqs_scaling_gpu")
    )
    parser.add_argument(
        "--report-only-from",
        type=Path,
        default=None,
        help="regenerate README from an existing scaling_results.json",
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    if arguments.report_only_from is not None:
        payload = json.loads(
            arguments.report_only_from.read_text(encoding="utf-8")
        )
        results = [ScalingResult(**row) for row in payload["results"]]
        arguments.output_dir.mkdir(parents=True, exist_ok=True)
        write_report(arguments.output_dir / "README.md", results, arguments)
        print(f"wrote {arguments.output_dir / 'README.md'}", flush=True)
        return
    if min(
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records,
        arguments.thin_sweeps,
    ) <= 0:
        raise ValueError("sampling counts must all be positive")
    sizes = parse_sizes(arguments.sizes)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(f"scaling sizes: {sizes}", flush=True)

    results: list[ScalingResult] = []
    partial_path = arguments.output_dir / "scaling_results.partial.json"
    for particles in sizes:
        result = estimate_one_size(
            particles=particles,
            chains=arguments.chains,
            burn_sweeps=arguments.burn_sweeps,
            records=arguments.records,
            thin_sweeps=arguments.thin_sweeps,
            initial_scale=arguments.initial_scale,
            seed=arguments.seed,
        )
        results.append(result)
        partial_path.write_text(
            json.dumps([asdict(item) for item in results], indent=2),
            encoding="utf-8",
        )

    json_path = arguments.output_dir / "scaling_results.json"
    csv_path = arguments.output_dir / "scaling_results.csv"
    report_path = arguments.output_dir / "README.md"

    payload = {
        "ansatz": "matrix-free Laughlin plus rank-2 density-head NQS/SMA",
        "energy_units": "e^2/(epsilon l_B)",
        "devices": [str(device) for device in jax.devices()],
        "arguments": {
            **vars(arguments),
            "output_dir": str(arguments.output_dir),
        },
        "results": [asdict(result) for result in results],
        "explicit_fock_nqs_benchmark": EXPLICIT_FOCK_NQS,
    }
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    write_csv(csv_path, results)
    write_report(report_path, results, arguments)
    if partial_path.exists():
        partial_path.unlink()
    print(f"wrote {json_path}", flush=True)
    print(f"wrote {csv_path}", flush=True)
    print(f"wrote {report_path}", flush=True)


if __name__ == "__main__":
    main()
