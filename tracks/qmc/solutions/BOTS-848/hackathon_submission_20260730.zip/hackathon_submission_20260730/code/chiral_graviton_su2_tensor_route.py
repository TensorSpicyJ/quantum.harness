#!/usr/bin/env python3
"""Staged benchmark driver for the strict SU(2) LLL tensor-NQS route.

The actual variational states are implemented in
``chiral_graviton_nqs_vmc_sparse.py``.  This driver launches every system size
in a fresh Python process (so GPU memory is released between sizes), selects
reusable sparse caches, enables ED where it is still useful, and writes a
single machine-readable and human-readable benchmark summary.

The variational family is

    |Psi_0>   = C_theta^(0) |Laughlin>
    |Psi_2,M> = O_theta,M^(2) C_theta^(0) |Laughlin>,

where C is assembled from scalar-coupled projected-density tensors and O is a
trainable rank-2 density-tensor head.  Angular momentum is therefore fixed by
construction instead of by an L^2 penalty.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / "chiral_graviton_nqs_vmc_sparse.py"


def parse_sizes(text: str) -> list[int]:
    sizes = sorted({int(x.strip()) for x in text.split(",") if x.strip()})
    if not sizes or min(sizes) < 2:
        raise argparse.ArgumentTypeError("sizes must be comma-separated integers >= 2")
    return sizes


def find_cache(n: int, output_root: Path) -> Path:
    """Pick a compatible pre-existing sparse cache, otherwise a new cache."""
    candidates = [
        ROOT / "runs" / f"sparse_cache_N{n}",
        ROOT / "runs" / f"sparse_setup_N{n}",
        ROOT / "runs" / f"setup_N{n}",
        output_root / f"cache_N{n}",
    ]
    required_groups = [
        ("coulomb_M0.npz", "H_M0.npz", "H0.npz"),
        ("coulomb_M2.npz", "H_M2.npz", "H2.npz"),
    ]
    for candidate in candidates:
        if not candidate.is_dir():
            continue
        names = {p.name for p in candidate.iterdir()}
        if all(any(name in names for name in group) for group in required_groups):
            return candidate
    return output_root / f"cache_N{n}"


def finite(value: Any) -> float | None:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def first(mapping: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in mapping:
            return mapping[key]
    return None


def nested(mapping: dict[str, Any], *path: str) -> dict[str, Any]:
    value: Any = mapping
    for key in path:
        if not isinstance(value, dict):
            return {}
        value = value.get(key, {})
    return value if isinstance(value, dict) else {}


def flatten_result(n: int, result: dict[str, Any], wall_s: float) -> dict[str, Any]:
    ansatz = nested(result, "ansatz")
    feature_ranks = nested(result, "feature_ranks")
    exact = nested(result, "exact_ansatz")
    if not exact:
        exact = nested(result, "variational")
    ground = nested(exact, "ground")
    excited = nested(exact, "excited")
    if not excited:
        excited = nested(exact, "excited_M2")
    mc = nested(result, "monte_carlo")
    ed = nested(result, "ed")
    if not ed:
        ed = nested(result, "ed_benchmark")
    tower = nested(result, "tower_check")
    if not tower:
        tower = nested(result, "lowering_equivariance_residuals")

    gap = finite(first(exact, "gap", "gap_energy"))
    if gap is None:
        e0 = finite(first(ground, "energy", "E"))
        e2 = finite(first(excited, "energy", "E"))
        gap = None if e0 is None or e2 is None else e2 - e0

    ed_gap = finite(first(ed, "gap", "gap_energy"))
    gap_error = None if gap is None or ed_gap is None else gap - ed_gap
    gap_rel = (
        None
        if gap_error is None or ed_gap in (None, 0.0)
        else abs(gap_error / ed_gap)
    )

    lowering_values: list[float] = []
    for value in tower.values():
        if isinstance(value, (int, float)):
            x = finite(value)
            if x is not None:
                lowering_values.append(abs(x))
        elif isinstance(value, dict):
            for subvalue in value.values():
                x = finite(subvalue)
                if x is not None:
                    lowering_values.append(abs(x))

    return {
        "N": n,
        "status": "ok",
        "wall_s": wall_s,
        "basis_dim_M0": first(result, "basis_dim_M0", "dim_M0"),
        "basis_dim_M2": first(result, "basis_dim_M2", "dim_M2"),
        "lmax": first(ansatz, "lmax", "ell_max"),
        "scalar_depth": first(ansatz, "scalar_depth", "depth"),
        "ground_feature_rank": first(feature_ranks, "ground_feature_rank", "ground_rank"),
        "excited_feature_rank": first(feature_ranks, "excited_feature_rank", "excited_rank"),
        "E0": finite(first(ground, "energy", "E")),
        "var_E0": finite(first(ground, "variance", "energy_variance")),
        "L2_0": finite(first(ground, "L2", "l2")),
        "E2": finite(first(excited, "energy", "E")),
        "var_E2": finite(first(excited, "variance", "energy_variance")),
        "L2_2": finite(first(excited, "L2", "l2")),
        "gap": gap,
        "mc_gap": finite(first(mc, "gap", "gap_mean")),
        "mc_gap_stderr": finite(first(mc, "gap_stderr", "stderr")),
        "ed_E0": finite(first(ed, "E0", "ground_energy")),
        "ed_E2": finite(first(ed, "E2", "excited_energy")),
        "ed_gap": ed_gap,
        "gap_error": gap_error,
        "gap_relative_error": gap_rel,
        "ground_overlap": finite(first(ed, "ground_overlap", "overlap_ground")),
        "excited_overlap": finite(first(ed, "excited_overlap", "overlap_excited")),
        "max_tower_residual": max(lowering_values) if lowering_values else None,
    }


def write_summary(rows: list[dict[str, Any]], output_root: Path, config: dict[str, Any]) -> None:
    output_root.mkdir(parents=True, exist_ok=True)
    payload = {"config": config, "results": rows}
    (output_root / "summary.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    columns = sorted({key for row in rows for key in row})
    with (output_root / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)

    def fmt(value: Any, digits: int = 9) -> str:
        if value is None:
            return "—"
        if isinstance(value, float):
            return f"{value:.{digits}g}"
        return str(value)

    lines = [
        "# Strict SU(2) density-tensor NQS benchmark",
        "",
        "The state uses trainable scalar projected-density channels for the ground",
        "state and a trainable rank-2 tensor head for the graviton.  Therefore",
        "$L=0$ and $L=2$ are representation-theoretic constraints, not penalties.",
        "",
        "| N | status | gap | ED gap | rel. gap error | var(E0) | var(E2) | "
        "$L_0^2$ | $L_2^2$ | MC gap stderr | wall time |",
        "|---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        for key in ("gap", "ed_gap", "gap_relative_error", "var_E0", "var_E2", "L2_0", "L2_2", "mc_gap_stderr"):
            row.setdefault(key, None)
        lines.append(
            "| {N} | {status} | {gap} | {ed_gap} | {gap_relative_error} | "
            "{var_E0} | {var_E2} | {L2_0} | {L2_2} | {mc_gap_stderr} | "
            "{wall_s} s |".format(
                **{key: fmt(value) for key, value in row.items()}
            )
        )
    lines += [
        "",
        "## Reliability criteria",
        "",
        "- ED overlap and gap error test wave-function accuracy where ED is enabled.",
        "- $L_0^2=0$, $L_2^2=6$, and the lowering-tower residual test exact SU(2).",
        "- Energy variance tests eigenstate quality independently of ED.",
        "- Monte Carlo standard error measures sampling noise, not ansatz bias.",
        "",
        "A larger size is accepted only if the symmetry residual remains near machine",
        "precision and the energy variances do not show systematic deterioration.",
    ]
    (output_root / "RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_command(args: argparse.Namespace, n: int, run_dir: Path, cache: Path) -> list[str]:
    # N=9 benefits substantially from the larger channel set; N=10 uses the
    # compact lmax=4 model to keep the explicit sparse Fock benchmark tractable.
    lmax = args.lmax_n9 if n == 9 else args.lmax
    command = [
        sys.executable,
        str(ENGINE),
        "-N",
        str(n),
        "--output-dir",
        str(run_dir),
        "--cache-dir",
        str(cache),
        "--lmax",
        str(lmax),
        "--scalar-depth",
        str(args.scalar_depth),
        "--steps",
        str(args.steps),
        "--samples",
        str(args.samples),
        "--eval-samples",
        str(args.eval_samples),
        "--seed",
        str(args.seed + n),
    ]
    if n <= args.ed_max:
        command.append("--ed-benchmark")
    if n > args.tower_max:
        command.append("--skip-tower-check")
    return command


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", type=parse_sizes, default=parse_sizes("4,5,6,7,8,9,10"))
    parser.add_argument("--output-root", type=Path, default=ROOT / "runs" / "su2_tensor_route")
    parser.add_argument("--lmax", type=int, default=4)
    parser.add_argument("--lmax-n9", type=int, default=6)
    parser.add_argument("--scalar-depth", type=int, default=2)
    parser.add_argument("--steps", type=int, default=30)
    parser.add_argument("--samples", type=int, default=4096)
    parser.add_argument("--eval-samples", type=int, default=131072)
    parser.add_argument("--ed-max", type=int, default=8)
    parser.add_argument("--tower-max", type=int, default=9)
    parser.add_argument("--seed", type=int, default=20260729)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--fail-fast", action="store_true")
    args = parser.parse_args()

    if not ENGINE.is_file():
        raise FileNotFoundError(f"missing tensor-NQS engine: {ENGINE}")
    output_root = args.output_root.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    config = vars(args).copy()
    config["sizes"] = args.sizes
    config["output_root"] = str(output_root)
    config["engine"] = str(ENGINE)

    for n in args.sizes:
        run_dir = output_root / f"N{n}"
        result_file = run_dir / "result.json"
        if result_file.is_file() and not args.overwrite:
            print(f"[N={n}] reusing completed result: {result_file}", flush=True)
            result = json.loads(result_file.read_text(encoding="utf-8"))
            rows.append(flatten_result(n, result, result.get("runtime_seconds", 0.0)))
            write_summary(rows, output_root, config)
            continue

        cache = find_cache(n, output_root)
        command = build_command(args, n, run_dir, cache)
        print(f"[N={n}] cache={cache}", flush=True)
        print("[command] " + " ".join(map(str, command)), flush=True)
        started = time.perf_counter()
        try:
            subprocess.run(command, cwd=ROOT, check=True)
            wall_s = time.perf_counter() - started
            result = json.loads(result_file.read_text(encoding="utf-8"))
            rows.append(flatten_result(n, result, wall_s))
        except Exception as exc:
            wall_s = time.perf_counter() - started
            rows.append({"N": n, "status": "failed", "wall_s": wall_s, "error": repr(exc)})
            write_summary(rows, output_root, config)
            if args.fail_fast:
                raise
        write_summary(rows, output_root, config)

    print(f"Summary: {output_root / 'RESULTS.md'}", flush=True)
    return 0 if all(row["status"] == "ok" for row in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
