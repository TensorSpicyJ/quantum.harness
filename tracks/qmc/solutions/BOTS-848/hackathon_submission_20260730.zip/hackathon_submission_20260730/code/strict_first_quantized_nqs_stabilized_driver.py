#!/usr/bin/env python3
"""Large-N driver with scale-stabilized exclusion polynomials.

Every cubic convolution is divided by its largest coefficient.  This common
scale cancels exactly from all single- and pair-polynomial ratios, while
preventing exponential coefficient growth at large particle number.
"""

from __future__ import annotations

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp

import strict_first_quantized_streaming as streaming


def normalized_convolve_fixed(coefficients, factor):
    result = jnp.zeros_like(coefficients)
    length = coefficients.shape[0]
    for shift in range(4):
        result = result.at[shift:].add(
            factor[shift] * coefficients[: length - shift]
        )
    scale = jnp.maximum(jnp.max(jnp.abs(result)), 1.0e-300)
    return result / scale


# The feature builders resolve this module global while JAX traces them.
streaming._convolve_fixed = normalized_convolve_fixed

from strict_first_quantized_nqs_streaming_driver import main


if __name__ == "__main__":
    main()
