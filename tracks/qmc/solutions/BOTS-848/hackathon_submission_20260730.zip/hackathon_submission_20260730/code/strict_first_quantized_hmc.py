#!/usr/bin/env python3
"""Geodesic HMC samplers for strict spherical first-quantized NQS.

The existing production drivers use local random-walk Metropolis updates for
the Laughlin and SMA reference distributions.  This module implements a
global Hybrid Monte Carlo update on the product manifold (S^2)^N.  Each
position update follows an exact great-circle geodesic, while the force is
the tangent projection of the ambient gradient of log probability.

The HMC sampler is used only as an importance sampler.  It does not alter the
strict LLL/SU(2) variational channels or their linear-method optimization.
"""

from __future__ import annotations

import math
from functools import partial

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np

from chiral_graviton_nqs_scaling_gpu import (
    potential_energy,
    random_spinors,
    run_excited_sweeps,
    run_sweeps,
    tensor_components,
)


Array = jax.Array


def random_unit_vectors(key: Array, chains: int, particles: int) -> Array:
    vectors = jax.random.normal(
        key, (chains, particles, 3), dtype=jnp.float64
    )
    return vectors / jnp.linalg.norm(vectors, axis=-1, keepdims=True)


@jax.jit
def vectors_to_spinors(vectors: Array) -> Array:
    """Choose a stable local spinor gauge for each unit vector.

    The two branches are related by a particle-local U(1) phase.  All sampled
    densities and wavefunction ratios used by the strict NQS are gauge
    covariant, so the branch choice does not affect observables.
    """

    x, y, z = vectors[..., 0], vectors[..., 1], vectors[..., 2]
    north = z >= 0.0

    north_u = jnp.sqrt(jnp.maximum(0.5 * (1.0 + z), 1.0e-300))
    north_v = (x + 1.0j * y) / jnp.maximum(2.0 * north_u, 1.0e-300)

    south_v = jnp.sqrt(jnp.maximum(0.5 * (1.0 - z), 1.0e-300))
    south_u = (x - 1.0j * y) / jnp.maximum(2.0 * south_v, 1.0e-300)

    u = jnp.where(north, north_u + 0.0j, south_u)
    v = jnp.where(north, north_v, south_v + 0.0j)
    spinors = jnp.stack((u, v), axis=-1)
    return spinors / jnp.linalg.norm(spinors, axis=-1, keepdims=True)


@jax.jit
def spinors_to_vectors(spinors: Array) -> Array:
    u = spinors[..., 0]
    v = spinors[..., 1]
    product = jnp.conj(u) * v
    return jnp.stack(
        (
            2.0 * jnp.real(product),
            2.0 * jnp.imag(product),
            jnp.square(jnp.abs(u)) - jnp.square(jnp.abs(v)),
        ),
        axis=-1,
    )


def _one_laughlin_log_probability(vectors: Array) -> Array:
    gram = vectors @ vectors.T
    particles = vectors.shape[0]
    chord = jnp.maximum(0.5 * (1.0 - gram), 1.0e-300)
    mask = jnp.triu(jnp.ones((particles, particles), dtype=bool), k=1)
    return 3.0 * jnp.sum(jnp.where(mask, jnp.log(chord), 0.0))


def _one_sma_log_probability(vectors: Array) -> Array:
    spinors = vectors_to_spinors(vectors)
    u = spinors[:, 0]
    v = spinors[:, 1]
    determinant = u[:, None] * v[None, :] - v[:, None] * u[None, :]
    particles = vectors.shape[0]
    diagonal = jnp.eye(particles, dtype=bool)
    safe_determinant = jnp.where(diagonal, 1.0 + 0.0j, determinant)
    inverse = jnp.where(diagonal, 0.0 + 0.0j, 1.0 / safe_determinant)
    first_derivative = -3.0 * jnp.sum(u[None, :] * inverse, axis=1)
    second_term = -3.0 * jnp.sum(
        jnp.square(u[None, :]) * jnp.square(inverse), axis=1
    )
    ratio = jnp.sum(
        jnp.square(u)
        * (jnp.square(first_derivative) + second_term)
    )
    return _one_laughlin_log_probability(vectors) + 2.0 * jnp.log(
        jnp.maximum(jnp.abs(ratio), 1.0e-300)
    )


_batched_laughlin_log_probability = jax.jit(
    jax.vmap(_one_laughlin_log_probability)
)
_batched_sma_log_probability = jax.jit(
    jax.vmap(_one_sma_log_probability)
)
_batched_laughlin_gradient = jax.jit(
    jax.vmap(jax.grad(_one_laughlin_log_probability))
)
_batched_sma_gradient = jax.jit(
    jax.vmap(jax.grad(_one_sma_log_probability))
)


def _tangent(values: Array, vectors: Array) -> Array:
    return values - jnp.sum(values * vectors, axis=-1, keepdims=True) * vectors


def _geodesic_step(vectors: Array, momenta: Array, step_size: Array):
    speed = jnp.linalg.norm(momenta, axis=-1, keepdims=True)
    angle = step_size * speed
    direction = momenta / jnp.maximum(speed, 1.0e-300)
    cosine = jnp.cos(angle)
    sine = jnp.sin(angle)
    new_vectors = cosine * vectors + sine * direction
    new_momenta = -speed * sine * vectors + cosine * momenta
    return new_vectors, new_momenta


@partial(jax.jit, static_argnames=("leapfrog_steps", "target"))
def hmc_trajectory(
    vectors: Array,
    key: Array,
    step_size: Array,
    leapfrog_steps: int,
    target: str,
) -> tuple[Array, Array, Array, Array]:
    """Run one Metropolis-corrected global geodesic HMC trajectory."""

    if target == "laughlin":
        log_probability = _batched_laughlin_log_probability
        gradient = _batched_laughlin_gradient
    elif target == "sma":
        log_probability = _batched_sma_log_probability
        gradient = _batched_sma_gradient
    else:
        raise ValueError(f"unknown HMC target: {target}")

    key, momentum_key, uniform_key = jax.random.split(key, 3)
    raw_momenta = jax.random.normal(momentum_key, vectors.shape)
    momenta = _tangent(raw_momenta, vectors)
    initial_momenta = momenta
    initial_log_probability = log_probability(vectors)

    force = _tangent(gradient(vectors), vectors)
    momenta = _tangent(momenta + 0.5 * step_size * force, vectors)

    def body(index: int, state: tuple[Array, Array]):
        current_vectors, current_momenta = state
        current_vectors, current_momenta = _geodesic_step(
            current_vectors, current_momenta, step_size
        )
        current_force = _tangent(
            gradient(current_vectors), current_vectors
        )
        force_scale = jnp.where(
            index + 1 == leapfrog_steps, 0.5, 1.0
        )
        current_momenta = _tangent(
            current_momenta + force_scale * step_size * current_force,
            current_vectors,
        )
        return current_vectors, current_momenta

    proposed_vectors, proposed_momenta = jax.lax.fori_loop(
        0, leapfrog_steps, body, (vectors, momenta)
    )
    proposed_log_probability = log_probability(proposed_vectors)
    initial_kinetic = 0.5 * jnp.sum(
        jnp.square(initial_momenta), axis=(1, 2)
    )
    proposed_kinetic = 0.5 * jnp.sum(
        jnp.square(proposed_momenta), axis=(1, 2)
    )
    log_acceptance = (
        proposed_log_probability
        - proposed_kinetic
        - initial_log_probability
        + initial_kinetic
    )
    accept = (
        jnp.log(jax.random.uniform(uniform_key, (vectors.shape[0],)))
        < log_acceptance
    )
    output = jnp.where(accept[:, None, None], proposed_vectors, vectors)
    return output, key, jnp.mean(accept), jnp.mean(
        jnp.minimum(0.0, log_acceptance)
    )


def collect_hmc_samples(
    particles: int,
    chains: int,
    burn_trajectories: int,
    records: int,
    thin_trajectories: int,
    step_size: float,
    leapfrog_steps: int,
    seed: int,
    target: str,
    target_acceptance: float = 0.65,
) -> tuple[np.ndarray, np.ndarray, float, dict[str, float]]:
    """Collect Laughlin or SMA-reference samples with adaptive-burn HMC."""

    key = jax.random.PRNGKey(seed + 3001 * particles)
    key, initial_key = jax.random.split(key)
    spinors = random_spinors(initial_key, chains, particles)
    warm_scale = 0.9 / math.sqrt(particles)
    warm_steps = max(50, burn_trajectories)
    if target == 'laughlin':
        spinors, key, _ = run_sweeps(
            spinors,
            key,
            jnp.asarray(warm_scale),
            count=warm_steps,
        )
    else:
        first, second, ratio = tensor_components(spinors)
        spinors, key, first, second, ratio, _ = run_excited_sweeps(
            spinors,
            key,
            jnp.asarray(warm_scale),
            first,
            second,
            ratio,
            count=warm_steps,
        )
    vectors = spinors_to_vectors(spinors)
    current_step = float(step_size)
    burn_acceptances: list[float] = []

    for trajectory in range(burn_trajectories):
        vectors, key, acceptance, _ = hmc_trajectory(
            vectors,
            key,
            jnp.asarray(current_step),
            leapfrog_steps,
            target,
        )
        value = float(jax.device_get(acceptance))
        burn_acceptances.append(value)
        adaptation = 0.08 / math.sqrt(1.0 + trajectory / 20.0)
        current_step *= math.exp(adaptation * (value - target_acceptance))
        current_step = float(np.clip(current_step, 1.0e-4, 0.5))

    coordinate_records: list[np.ndarray] = []
    potential_records: list[np.ndarray] = []
    production_acceptances: list[float] = []
    two_q = 3 * (particles - 1)
    for _ in range(records):
        for _ in range(thin_trajectories):
            vectors, key, acceptance, _ = hmc_trajectory(
                vectors,
                key,
                jnp.asarray(current_step),
                leapfrog_steps,
                target,
            )
            production_acceptances.append(
                float(jax.device_get(acceptance))
            )
        spinors = vectors_to_spinors(vectors)
        coordinate_records.append(np.asarray(jax.device_get(spinors)))
        potential_records.append(
            np.asarray(jax.device_get(potential_energy(spinors, two_q)))
        )

    diagnostics = {
        "adapted_step_size": current_step,
        "burn_acceptance": float(np.mean(burn_acceptances)),
        "production_acceptance": float(np.mean(production_acceptances)),
        "leapfrog_steps": float(leapfrog_steps),
        "trajectory_length": current_step * leapfrog_steps,
    }
    return (
        np.concatenate(coordinate_records, axis=0),
        np.concatenate(potential_records, axis=0),
        diagnostics["production_acceptance"],
        diagnostics,
    )

