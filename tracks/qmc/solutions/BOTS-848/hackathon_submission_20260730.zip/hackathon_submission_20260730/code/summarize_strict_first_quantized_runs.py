#!/usr/bin/env python3
"""Summarize streaming first-quantized NQS result JSON files."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", nargs="+", type=Path)
    parser.add_argument("--csv", type=Path)
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    rows = []
    for path in arguments.results:
        payload = json.loads(path.read_text(encoding="utf-8"))
        run_arguments = payload["arguments"]
        for result in payload["results"]:
            ground = result["ground"]
            excited = result["excited"]
            rows.append(
                {
                    "path": str(path),
                    "N": result["particles"],
                    "lmax": run_arguments["lmax"],
                    "seed": run_arguments["seed"],
                    "samples_per_split": (
                        run_arguments["chains"]
                        * run_arguments["training_records"]
                    ),
                    "E0_train": ground["training_energy"],
                    "E0_valid": ground["validation_energy"],
                    "E0_stderr": ground["validation_stderr"],
                    "E0_ESS_fraction": ground["validation_ess_fraction"],
                    "E0_rank": ground["retained_rank"],
                    "E2_train": excited["training_energy"],
                    "E2_valid": excited["validation_energy"],
                    "E2_stderr": excited["validation_stderr"],
                    "E2_ESS_fraction": excited["validation_ess_fraction"],
                    "E2_rank": excited["retained_rank"],
                    "gap": result["gap"],
                    "gap_stderr": result["gap_stderr"],
                    "runtime_seconds": result["runtime_seconds"],
                }
            )
    fields = list(rows[0])
    print(",".join(fields))
    for row in rows:
        print(",".join(str(row[field]) for field in fields))
    if arguments.csv:
        arguments.csv.parent.mkdir(parents=True, exist_ok=True)
        with arguments.csv.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)

    groups = {}
    for row in rows:
        key = (row["N"], row["lmax"])
        groups.setdefault(key, []).append(row)
    for key, group in sorted(groups.items()):
        if len(group) < 2:
            continue
        inverse_variances = [
            1.0 / row["gap_stderr"] ** 2 for row in group
        ]
        weighted_gap = sum(
            row["gap"] * weight
            for row, weight in zip(group, inverse_variances)
        ) / sum(inverse_variances)
        weighted_stderr = math.sqrt(1.0 / sum(inverse_variances))
        chi2 = sum(
            (row["gap"] - weighted_gap) ** 2 / row["gap_stderr"] ** 2
            for row in group
        )
        print(
            f"N={key[0]} lmax={key[1]} weighted_gap={weighted_gap:.9f} "
            f"stderr={weighted_stderr:.3e} chi2/dof="
            f"{chi2:.3f}/{len(group) - 1}"
        )


if __name__ == "__main__":
    main()
