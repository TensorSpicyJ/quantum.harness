#!/usr/bin/env python3
"""Scalable strict first-quantized LLL--SU(2) tensor NQS.

This implementation evaluates projected-density tensor channels directly in
continuous spinor coordinates.  For each electron, its degree-2Q Laughlin
polynomial is built in the monomial basis.  One-body irreducible tensors are
finite matrices in that polynomial space; coupled two-density channels use
one- and two-electron polynomial contractions.  No many-body Fock basis or
Hamiltonian matrix is constructed.

The trainable state is

    Psi_22 = Psi_L sum_a c_a F_a,

with F_0=rho_(2,2) and the remaining F_a equal to exact CG-coupled
[rho_l1 x rho_l2]_(2,2) channels.  Coefficients c_a are optimized from VMC
samples by the linear method, i.e. stochastic reconfiguration solved exactly
inside the sampled feature subspace.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict
from pathlib import Path
from typing import Callable

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np

from chiral_graviton_ed import clebsch_gordan2
from strict_first_quantized_tensor_nqs import (
    Result,
    collect_laughlin_samples,
    estimate_matrices,
    parse_sizes,
    solve_linear_method,
    weighted_statistics,
)


Array = jax.Array


def monomial_tensor_matrices(
    degree: int, lmax: int
) -> dict[tuple[int, int], np.ndarray]:
    """Irreducible one-body tensors in u^(d-r) v^r coefficients."""

    dimension = degree + 1
    plus = np.zeros((dimension, dimension), dtype=np.float64)
    minus = np.zeros_like(plus)
    for r in range(dimension):
        if r > 0:
            plus[r - 1, r] = r
        if r < degree:
            minus[r + 1, r] = degree - r
    tensors: dict[tuple[int, int], np.ndarray] = {}
    for ell in range(2, lmax + 1):
        highest = np.linalg.matrix_power(plus, ell)
        highest /= np.linalg.norm(highest)
        tensors[(ell, ell)] = highest
        for m in range(ell, -ell, -1):
            current = tensors[(ell, m)]
            lowered = (minus @ current - current @ minus) / math.sqrt(
                (ell + m) * (ell - m + 1)
            )
            tensors[(ell, m - 1)] = lowered
    return tensors


def channel_specifications(lmax: int) -> list[tuple[int, int] | None]:
    specifications: list[tuple[int, int] | None] = [None]
    for left in range(2, lmax + 1):
        for right in range(2, lmax + 1):
            if abs(left - right) <= 2 <= left + right:
                specifications.append((left, right))
    return specifications


def convolve_cubic(coefficients: Array, factor: Array) -> Array:
    result = jnp.zeros_like(coefficients)
    dimension = coefficients.shape[0]
    for shift in range(4):
        result = result.at[shift:].add(
            factor[shift] * coefficients[: dimension - shift]
        )
    return result


def cubic_factor(other_spinor: Array) -> Array:
    u, v = other_spinor
    return jnp.stack(
        (
            v**3,
            -3.0 * v**2 * u,
            3.0 * v * u**2,
            -(u**3),
        )
    )


def polynomial_excluding(
    spinors: Array, particle: int, excluded: int
) -> Array:
    degree = 3 * (spinors.shape[0] - 1)
    coefficients = jnp.zeros((degree + 1,), dtype=spinors.dtype)
    coefficients = coefficients.at[0].set(1.0 + 0.0j)
    for other in range(spinors.shape[0]):
        if other != particle and other != excluded:
            coefficients = convolve_cubic(
                coefficients, cubic_factor(spinors[other])
            )
    return coefficients


def single_polynomial(spinors: Array, particle: int) -> Array:
    return polynomial_excluding(spinors, particle, particle)


def pair_polynomial(spinors: Array, first: int, second: int) -> Array:
    """Bivariate coefficients containing every factor touching i or j."""

    degree = 3 * (spinors.shape[0] - 1)
    first_coefficients = polynomial_excluding(spinors, first, second)
    second_coefficients = polynomial_excluding(spinors, second, first)
    outer = first_coefficients[:, None] * second_coefficients[None, :]
    result = jnp.zeros((degree + 1, degree + 1), dtype=spinors.dtype)
    for first_shift in range(4):
        second_shift = 3 - first_shift
        coefficient = math.comb(3, first_shift) * (-1.0) ** first_shift
        result = result.at[
            first_shift:, second_shift:
        ].add(
            coefficient
            * outer[
                : degree + 1 - first_shift,
                : degree + 1 - second_shift,
            ]
        )
    return result


def monomial_values(spinor: Array, degree: int) -> Array:
    r = jnp.arange(degree + 1)
    return spinor[0] ** (degree - r) * spinor[1] ** r


def safe_complex(value: Array) -> Array:
    magnitude = jnp.abs(value)
    return jnp.where(
        magnitude > 1.0e-280,
        value,
        jnp.asarray(1.0e-280 + 0.0j, dtype=value.dtype),
    )


def make_feature_function(
    particles: int, lmax: int
) -> tuple[Callable[[Array], Array], list[str]]:
    degree = 3 * (particles - 1)
    tensor_host = monomial_tensor_matrices(degree, lmax)
    tensors = {
        key: jnp.asarray(value, dtype=jnp.complex128)
        for key, value in tensor_host.items()
    }
    specifications = channel_specifications(lmax)
    labels = ["rho_2"]
    labels.extend(
        f"[rho_{left}xr_{right}]_2"
        for left, right in specifications[1:]
    )

    def one(spinors: Array) -> Array:
        basis = [
            monomial_values(spinors[index], degree)
            for index in range(particles)
        ]
        singles = [
            single_polynomial(spinors, index)
            for index in range(particles)
        ]
        single_denominators = [
            safe_complex(basis[index] @ singles[index])
            for index in range(particles)
        ]
        pairs: dict[tuple[int, int], Array] = {}
        pair_denominators: dict[tuple[int, int], Array] = {}
        for first in range(particles):
            for second in range(first + 1, particles):
                coefficients = pair_polynomial(spinors, first, second)
                pairs[(first, second)] = coefficients
                pair_denominators[(first, second)] = safe_complex(
                    basis[first] @ coefficients @ basis[second]
                )

        linear = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
        rho22 = tensors[(2, 2)]
        for particle in range(particles):
            linear = linear + (
                basis[particle] @ rho22 @ singles[particle]
            ) / single_denominators[particle]
        features = [linear]

        for specification in specifications[1:]:
            assert specification is not None
            left, right = specification
            coupled = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
            for m_left in range(-left, left + 1):
                m_right = 2 - m_left
                if abs(m_right) > right:
                    continue
                cg = clebsch_gordan2(
                    2 * left,
                    2 * m_left,
                    2 * right,
                    2 * m_right,
                    4,
                    4,
                )
                if abs(cg) < 1.0e-14:
                    continue
                left_matrix = tensors[(left, m_left)]
                right_matrix = tensors[(right, m_right)]
                same_particle = jnp.asarray(
                    0.0 + 0.0j, dtype=spinors.dtype
                )
                different_particle = jnp.asarray(
                    0.0 + 0.0j, dtype=spinors.dtype
                )
                for first in range(particles):
                    same_particle = same_particle + (
                        basis[first]
                        @ left_matrix
                        @ right_matrix
                        @ singles[first]
                    ) / single_denominators[first]
                    for second in range(particles):
                        if first == second:
                            continue
                        low, high = sorted((first, second))
                        coefficients = pairs[(low, high)]
                        denominator = pair_denominators[(low, high)]
                        if first < second:
                            numerator = (
                                basis[first]
                                @ left_matrix
                                @ coefficients
                                @ right_matrix.T
                                @ basis[second]
                            )
                        else:
                            numerator = (
                                basis[second]
                                @ right_matrix
                                @ coefficients
                                @ left_matrix.T
                                @ basis[first]
                            )
                        different_particle = (
                            different_particle + numerator / denominator
                        )
                coupled = coupled + cg * (
                    same_particle + different_particle
                )
            features.append(coupled)
        return jnp.stack(features)

    return jax.jit(jax.vmap(one)), labels


def estimate_one_size(arguments: argparse.Namespace, particles: int) -> Result:
    start_time = time.perf_counter()
    feature_function, labels = make_feature_function(particles, arguments.lmax)
    coordinates, potential, acceptance = collect_laughlin_samples(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        arguments.seed,
    )
    split = arguments.training_records * arguments.chains
    training_coordinates = coordinates[:split]
    validation_coordinates = coordinates[split:]
    training_potential = potential[:split]
    validation_potential = potential[split:]

    def evaluate(coordinates_host: np.ndarray) -> np.ndarray:
        batches = []
        for start in range(0, len(coordinates_host), arguments.feature_batch):
            batch = jnp.asarray(
                coordinates_host[start : start + arguments.feature_batch]
            )
            batches.append(
                np.asarray(jax.device_get(feature_function(batch)))
            )
        return np.concatenate(batches, axis=0)

    training_features = evaluate(training_coordinates)
    validation_features = evaluate(validation_coordinates)
    scales = np.sqrt(
        np.maximum(np.mean(np.square(np.abs(training_features)), axis=0), 1.0e-30)
    )
    training_features /= scales[None, :]
    validation_features /= scales[None, :]
    overlap, hamiltonian = estimate_matrices(
        training_features, training_potential
    )
    _, coefficients, retained_rank = solve_linear_method(
        overlap, hamiltonian, arguments.whitening_tolerance
    )
    (
        training_energy,
        _,
        training_ess,
        training_ess_fraction,
    ) = weighted_statistics(
        training_features,
        training_potential,
        coefficients,
        arguments.chains,
        arguments.training_records,
    )
    (
        excited_energy,
        excited_stderr,
        validation_ess,
        validation_ess_fraction,
    ) = weighted_statistics(
        validation_features,
        validation_potential,
        coefficients,
        arguments.chains,
        arguments.records - arguments.training_records,
    )
    validation_ground = validation_potential.reshape(
        arguments.records - arguments.training_records, arguments.chains
    )
    ground_by_chain = np.mean(validation_ground, axis=0)
    ground_energy = float(np.mean(ground_by_chain))
    ground_stderr = float(
        np.std(ground_by_chain, ddof=1) / math.sqrt(arguments.chains)
    )
    gap = excited_energy - ground_energy
    gap_stderr = math.hypot(excited_stderr, ground_stderr)
    result = Result(
        particles=particles,
        two_q=3 * (particles - 1),
        lmax=arguments.lmax,
        raw_channels=len(labels),
        retained_rank=retained_rank,
        ground_energy=ground_energy,
        excited_energy=excited_energy,
        gap=gap,
        ground_stderr=ground_stderr,
        excited_stderr=excited_stderr,
        gap_stderr=gap_stderr,
        training_ess=training_ess,
        training_ess_fraction=training_ess_fraction,
        validation_ess=validation_ess,
        validation_ess_fraction=validation_ess_fraction,
        acceptance=acceptance,
        coefficients_real=np.real(coefficients / scales).tolist(),
        coefficients_imag=np.imag(coefficients / scales).tolist(),
        channel_labels=labels,
        runtime_seconds=time.perf_counter() - start_time,
    )
    print(
        f"N={particles} channels={retained_rank}/{len(labels)} "
        f"E2(train)={training_energy:.9f} "
        f"E2(valid)={excited_energy:.9f} "
        f"gap={gap:.9f}+/-{gap_stderr:.2e} "
        f"ESS(valid)={validation_ess_fraction:.3f} "
        f"time={result.runtime_seconds:.1f}s",
        flush=True,
    )
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="4,5,6")
    parser.add_argument("--lmax", type=int, choices=(2, 3, 4), default=3)
    parser.add_argument("--chains", type=int, default=64)
    parser.add_argument("--burn-sweeps", type=int, default=300)
    parser.add_argument("--records", type=int, default=64)
    parser.add_argument("--training-records", type=int, default=32)
    parser.add_argument("--thin-sweeps", type=int, default=4)
    parser.add_argument("--feature-batch", type=int, default=16)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-9)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/strict_first_quantized_tensor_nqs_v2"),
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    if not 0 < arguments.training_records < arguments.records:
        raise ValueError("training-records must be between 0 and records")
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    sizes = parse_sizes(arguments.sizes)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        f"strict coordinate tensor-NQS VMC training: "
        f"sizes={sizes}, lmax={arguments.lmax}",
        flush=True,
    )
    results = [estimate_one_size(arguments, particles) for particles in sizes]
    payload = {
        "method": (
            "strict first-quantized LLL-SU(2) multi-channel tensor NQS; "
            "VMC linear-method/stochastic-reconfiguration training"
        ),
        "coordinate_evaluation": (
            "one- and two-electron homogeneous-polynomial contractions"
        ),
        "symmetry": {
            "ground_L2": 0.0,
            "excited_L2": 6.0,
            "status": "exact by CG irreducible-tensor construction",
        },
        "devices": [str(device) for device in jax.devices()],
        "arguments": {
            **vars(arguments),
            "output_dir": str(arguments.output_dir),
        },
        "results": [asdict(result) for result in results],
    }
    (arguments.output_dir / "results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    scalar_fields = [
        key
        for key in asdict(results[0])
        if key
        not in ("coefficients_real", "coefficients_imag", "channel_labels")
    ]
    with (arguments.output_dir / "results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=scalar_fields)
        writer.writeheader()
        for result in results:
            row = asdict(result)
            writer.writerow({key: row[key] for key in scalar_fields})
    print(f"wrote {arguments.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
