#!/usr/bin/env python3
"""Numerical equivalence checks for the streaming tensor contractions."""

import jax
import numpy as np

from chiral_graviton_nqs_scaling_gpu import random_spinors
from strict_first_quantized_scalar_nqs import make_scalar_feature_function
from strict_first_quantized_streaming import (
    make_streaming_scalar_feature_function,
    make_streaming_tensor_feature_function,
)
from strict_first_quantized_tensor_nqs_v2 import make_feature_function


def relative_residual(reference: np.ndarray, candidate: np.ndarray) -> float:
    return float(
        np.max(
            np.abs(reference - candidate)
            / np.maximum(np.abs(reference), 1.0e-12)
        )
    )


def main() -> None:
    for particles in (4, 5):
        coordinates = random_spinors(
            jax.random.PRNGKey(1701 + particles), 2, particles
        )
        dense_tensor, dense_labels = make_feature_function(particles, 4)
        stream_tensor, stream_labels = (
            make_streaming_tensor_feature_function(particles, 4)
        )
        dense_scalar, dense_scalar_labels = make_scalar_feature_function(
            particles, 4
        )
        stream_scalar, stream_scalar_labels = (
            make_streaming_scalar_feature_function(particles, 4)
        )
        tensor_reference = np.asarray(dense_tensor(coordinates))
        tensor_candidate = np.asarray(stream_tensor(coordinates))
        scalar_reference = np.asarray(dense_scalar(coordinates))
        scalar_candidate = np.asarray(stream_scalar(coordinates))
        assert dense_labels == stream_labels
        assert dense_scalar_labels == stream_scalar_labels
        tensor_error = relative_residual(
            tensor_reference, tensor_candidate
        )
        scalar_error = relative_residual(
            scalar_reference, scalar_candidate
        )
        print(
            f"N={particles} tensor_relative_residual={tensor_error:.3e} "
            f"scalar_relative_residual={scalar_error:.3e}"
        )
        assert tensor_error < 2.0e-10
        assert scalar_error < 2.0e-10
    print(f"devices={jax.devices()}")


if __name__ == "__main__":
    main()
