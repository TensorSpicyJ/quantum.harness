#!/usr/bin/env python3
"""Tempered symmetry-focused autoregressive Fock NQS.

V5 extends the allowed-move importance samplers in V4 with two continuation
tools for transferring a trained NQS to a much larger system:

* amplitude-logit tempering at initialization, which broadens an excessively
  sharp autoregressive distribution without altering its phase network;
* a positive entropy temperature during warmup, annealed exactly to zero as
  the normalized highest-weight penalty is ramped on.

The final objective is therefore still the zero-temperature variational
energy plus the highest-weight constraint. Entropy only stabilizes the
continuation path and is absent after warmup.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

import chiral_graviton_fock_ar_nqs_symmetry_v4 as v4


v3 = v4.v3
v2 = v3.v2
jax = v3.jax
jnp = v3.jnp
optax = v3.optax
PyTree = v3.PyTree

AMPLITUDE_INIT_SCALE = 0.35
ENTROPY_TEMPERATURE = 0.02


def make_train_step_tempered(
    sample: Any,
    log_psi: Any,
    local0: Any,
    local2: Any,
    lplus0: Any,
    lplus2: Any,
    highest_weight_penalty: float,
    optimizer: optax.GradientTransformation,
    batch: int,
) -> Any:
    """VMC score gradient with entropy-to-symmetry warmup continuation."""

    particles = v3.ACTIVE_PARTICLES
    if particles <= 0:
        raise RuntimeError("ACTIVE_PARTICLES was not set")
    q = 1.5 * (particles - 1)
    lplus_scale = max(1.0, particles * q * (q + 1.0))

    def sector_loss(
        params: PyTree,
        sample_key: jax.Array,
        hop_key: jax.Array,
        sector_M: int,
        local: Any,
        lplus_local: Any,
        continuation: jax.Array,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        occupations, _ = sample(params, sample_key, batch, sector_M)
        occupations = jax.lax.stop_gradient(occupations)
        logs = log_psi(params, occupations, sector_M)
        energies, diagnostics = local(
            params, occupations, logs, sector_M, hop_key
        )
        lplus_values, lplus_diagnostics = lplus_local(
            params,
            occupations,
            logs,
            sector_M,
            jax.random.fold_in(hop_key, 9173),
        )
        normalized_lplus = lplus_values / lplus_scale
        log_probability = 2.0 * jnp.real(logs)
        energy_centered = v3._robust_center(
            energies, v3.ROBUST_CENTER_CLIP
        )
        symmetry_centered = v3._robust_center(
            normalized_lplus, v3.ROBUST_CENTER_CLIP
        )
        entropy_centered = v3._robust_center(
            log_probability.astype(jnp.complex64),
            v3.ROBUST_CENTER_CLIP,
        )
        entropy_ramp = jnp.maximum(0.0, 1.0 - continuation)
        centered = jax.lax.stop_gradient(
            energy_centered
            + highest_weight_penalty
            * continuation
            * symmetry_centered
            + ENTROPY_TEMPERATURE
            * entropy_ramp
            * entropy_centered
        )
        surrogate = 2.0 * jnp.real(
            jnp.mean(centered * jnp.conj(logs))
        )
        diagnostics = {
            **diagnostics,
            "energy": jnp.mean(jnp.real(energies)),
            "variance": jnp.var(jnp.real(energies)),
            "lplus_norm": jnp.mean(jnp.real(lplus_values)),
            "lplus_variance": jnp.var(jnp.real(lplus_values)),
            "normalized_lplus": jnp.mean(jnp.real(normalized_lplus)),
            "mean_log_probability": jnp.mean(log_probability),
            **lplus_diagnostics,
        }
        return surrogate, diagnostics

    def step(
        params: PyTree,
        opt_state: PyTree,
        key: jax.Array,
        learning_scale: jax.Array,
    ) -> tuple[PyTree, PyTree, dict[str, jax.Array]]:
        keys = jax.random.split(key, 4)

        def loss_function(p: PyTree):
            loss0, diag0 = sector_loss(
                p,
                keys[0],
                keys[1],
                0,
                local0,
                lplus0,
                learning_scale,
            )
            loss2, diag2 = sector_loss(
                p,
                keys[2],
                keys[3],
                2,
                local2,
                lplus2,
                learning_scale,
            )
            return 0.5 * (loss0 + loss2), (diag0, diag2)

        (_, (diag0, diag2)), gradients = jax.value_and_grad(
            loss_function, has_aux=True
        )(params)
        updates, opt_state = optimizer.update(gradients, opt_state, params)
        updates = jax.tree_util.tree_map(
            lambda value: learning_scale * value, updates
        )
        params = optax.apply_updates(params, updates)
        return params, opt_state, {
            "E0": diag0["energy"],
            "E2": diag2["energy"],
            "gap": diag2["energy"] - diag0["energy"],
            "var0": diag0["variance"],
            "var2": diag2["variance"],
            "valid0": diag0["valid_fraction"],
            "valid2": diag2["valid_fraction"],
            "clip0": diag0["ratio_clip_fraction"],
            "clip2": diag2["ratio_clip_fraction"],
            "imag0": diag0["imaginary_mean"],
            "imag2": diag2["imaginary_mean"],
            "gradient_norm": optax.global_norm(gradients),
            "lplus0": diag0["lplus_norm"],
            "lplus2": diag2["lplus_norm"],
            "lplus_var0": diag0["lplus_variance"],
            "lplus_var2": diag2["lplus_variance"],
            "normalized_lplus0": diag0["normalized_lplus"],
            "normalized_lplus2": diag2["normalized_lplus"],
            "mean_logp0": diag0["mean_log_probability"],
            "mean_logp2": diag2["mean_log_probability"],
        }

    return jax.jit(step)


def _temper_initial_params(initial_params: PyTree | None) -> PyTree | None:
    if initial_params is None or AMPLITUDE_INIT_SCALE == 1.0:
        return initial_params
    tempered = {
        name: jnp.asarray(value)
        for name, value in initial_params.items()
    }
    tempered["amp"] = tempered["amp"] * AMPLITUDE_INIT_SCALE
    tempered["amp_bias"] = (
        tempered["amp_bias"] * AMPLITUDE_INIT_SCALE
    )
    return tempered


def train_one_v5(
    config: Any,
    output_dir: Path,
    cache_dir: Path,
    resume: bool,
    initial_params: PyTree | None = None,
):
    """Apply one-time tempering and record the complete V5 provenance."""

    v3.ACTIVE_PARTICLES = int(config.particles)
    initial_params = _temper_initial_params(initial_params)
    result, params = v3.ORIGINAL_TRAIN_ONE(
        config,
        output_dir,
        cache_dir,
        resume,
        initial_params,
    )
    result["method"] = (
        "sampled complex Fock-space autoregressive NQS; "
        "V5 tempered continuation + importance-sampled H and L_-L_+"
    )
    result["v5_improvements"] = {
        "amplitude_init_scale": AMPLITUDE_INIT_SCALE,
        "entropy_temperature_initial": ENTROPY_TEMPERATURE,
        "entropy_annealed_to_zero_at_warmup": True,
        "hamiltonian_allowed_move_importance_sampling": True,
        "highest_weight_allowed_move_importance_sampling": True,
        "highest_weight_scale": "N*Q*(Q+1)",
        "highest_weight_ramped_during_warmup": True,
        "robust_center_clip": v3.ROBUST_CENTER_CLIP,
    }
    run_dir = Path(output_dir) / f"N{config.particles}"
    (run_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    return result, params


def parse_v5_options() -> None:
    global AMPLITUDE_INIT_SCALE, ENTROPY_TEMPERATURE
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "--amplitude-init-scale", type=float, default=0.35
    )
    parser.add_argument(
        "--entropy-temperature", type=float, default=0.02
    )
    options, remaining = parser.parse_known_args()
    if not 0.0 < options.amplitude_init_scale <= 1.0:
        raise ValueError("--amplitude-init-scale must be in (0,1]")
    if options.entropy_temperature < 0.0:
        raise ValueError("--entropy-temperature must be non-negative")
    AMPLITUDE_INIT_SCALE = options.amplitude_init_scale
    ENTROPY_TEMPERATURE = options.entropy_temperature
    sys.argv = [sys.argv[0], *remaining]


def main() -> None:
    parse_v5_options()
    v3.parse_v3_options()
    v2.make_local_energy = v3.make_local_energy_importance
    v2.make_lplus_norm_local = v4.make_lplus_norm_importance
    v2.make_train_step = make_train_step_tempered
    v2.train_one = train_one_v5
    v2.main()


if __name__ == "__main__":
    main()
