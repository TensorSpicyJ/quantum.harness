#!/usr/bin/env python3
"""Variance-reduced, highest-weight Fock-space autoregressive NQS.

This is an executable V3 front-end for ``chiral_graviton_fock_ar_nqs.py``.
It keeps the same complex autoregressive wavefunction and exact fixed-(N,M)
sampler, but replaces two numerically problematic VMC components:

1. Off-diagonal two-body moves are sampled only from Pauli-allowed targets,
   with probability proportional to the absolute interaction matrix element.
   The inverse proposal probability keeps the local-energy estimator unbiased.
2. The L_-L_+ highest-weight penalty is divided by the extensive single-particle
   angular-momentum scale N Q(Q+1), ramped on during warmup, and robustly
   centered before it enters the score-function gradient.

All Hamiltonian construction, teacher pretraining, checkpoints, evaluation,
and command-line options from V2 remain available.  V3-only options are parsed
first and removed before dispatching to the V2 driver.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np

import chiral_graviton_fock_ar_nqs as v2


jax = v2.jax
jnp = v2.jnp
optax = v2.optax
PyTree = v2.PyTree
PairData = v2.PairData


ACTIVE_PARTICLES = 0
ROBUST_CENTER_CLIP = 10.0
SOURCE_STRATIFIED = True


def make_local_energy_importance(
    particles: int,
    pair_data: PairData,
    log_psi: Any,
    hops: int,
    ratio_clip: float,
) -> Any:
    """Unbiased importance-sampled two-body local energy.

    A source occupied pair is marginally uniform.  Conditional on that source,
    only Pauli-allowed target pairs are proposed, with q(t|s) proportional to
    |V_ts|.  Thus pair_count * V_ts / q(t|s) is an unbiased estimator of the
    complete off-diagonal sum.  Random offsets make the optional stratified
    source sequence marginally uniform while improving within-batch coverage.
    """

    norbitals = 3 * particles - 2
    pair_count = particles * (particles - 1) // 2
    max_slots = int(pair_data.pair_a.shape[1])
    orbital_axis = jnp.arange(norbitals, dtype=jnp.int32)
    target_axis = jnp.arange(max_slots, dtype=jnp.int32)

    def local_energy(
        params: PyTree,
        occupations: jax.Array,
        log_values: jax.Array,
        sector_M: int,
        key: jax.Array,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        batch = occupations.shape[0]
        occupied = jnp.sort(
            jnp.where(occupations > 0, orbital_axis[None, :], norbitals),
            axis=1,
        )[:, :particles]
        all_c = occupied[:, pair_data.occupied_pair_positions[:, 0]]
        all_d = occupied[:, pair_data.occupied_pair_positions[:, 1]]
        all_sum = all_c + all_d
        all_slot = pair_data.slots[all_c, all_d]
        diagonal = jnp.sum(
            pair_data.values[all_sum, all_slot, all_slot], axis=1
        )

        source_key, target_key = jax.random.split(key)
        if SOURCE_STRATIFIED:
            offset = jax.random.randint(
                source_key, (batch, 1), 0, pair_count
            )
            stride = max(1, pair_count // max(1, hops))
            sampled_source = (
                offset
                + stride * jnp.arange(hops, dtype=jnp.int32)[None, :]
            ) % pair_count
        else:
            sampled_source = jax.random.randint(
                source_key, (batch, hops), 0, pair_count
            )

        c = jnp.take_along_axis(all_c, sampled_source, axis=1)
        d = jnp.take_along_axis(all_d, sampled_source, axis=1)
        pair_sum = c + d
        source_slot = pair_data.slots[c, d]
        count = pair_data.counts[pair_sum]

        slots = target_axis[None, None, :]
        candidate_a = pair_data.pair_a[pair_sum[:, :, None], slots]
        candidate_b = pair_data.pair_b[pair_sum[:, :, None], slots]
        safe_a = jnp.clip(candidate_a, 0, norbitals - 1)
        safe_b = jnp.clip(candidate_b, 0, norbitals - 1)
        row3 = jnp.arange(batch, dtype=jnp.int32)[:, None, None]
        slot_allowed = (
            (slots < count[:, :, None])
            & (slots != source_slot[:, :, None])
            & (occupations[row3, safe_a] == 0)
            & (occupations[row3, safe_b] == 0)
        )
        candidate_elements = pair_data.values[
            pair_sum[:, :, None],
            slots,
            source_slot[:, :, None],
        ]
        candidate_weights = jnp.where(
            slot_allowed, jnp.abs(candidate_elements), 0.0
        )
        total_weight = jnp.sum(candidate_weights, axis=2)
        has_target = total_weight > 0.0
        logits = jnp.where(
            candidate_weights > 0.0,
            jnp.log(candidate_weights + 1.0e-30),
            -1.0e30,
        )
        target_slot = jax.random.categorical(
            target_key, logits, axis=2
        ).astype(jnp.int32)
        selected_weight = jnp.take_along_axis(
            candidate_weights, target_slot[:, :, None], axis=2
        )[:, :, 0]
        proposal_probability = selected_weight / jnp.maximum(
            total_weight, 1.0e-30
        )
        a = pair_data.pair_a[pair_sum, target_slot]
        b = pair_data.pair_b[pair_sum, target_slot]
        element = pair_data.values[pair_sum, target_slot, source_slot]

        row = jnp.arange(batch, dtype=jnp.int32)[:, None]
        hop = jnp.arange(hops, dtype=jnp.int32)[None, :]
        moved = jnp.broadcast_to(
            occupations[:, None, :], (batch, hops, norbitals)
        )
        moved = moved.at[row, hop, c].set(0)
        moved = moved.at[row, hop, d].set(0)
        moved = moved.at[row, hop, a].set(1)
        moved = moved.at[row, hop, b].set(1)
        moved = jnp.where(
            has_target[:, :, None], moved, occupations[:, None, :]
        )

        batch_index = jnp.arange(batch, dtype=jnp.int32)[:, None]
        prefix = jnp.cumsum(occupations, axis=1) - occupations

        def prefix_at(index: jax.Array) -> jax.Array:
            return prefix[batch_index, index]

        exponent = (
            prefix_at(c)
            + prefix_at(d)
            - 1
            + prefix_at(b)
            - (c < b)
            - (d < b)
            + prefix_at(a)
            - (c < a)
            - (d < a)
        )
        sign = jnp.where(exponent % 2 == 0, 1.0, -1.0)
        candidate_logs = log_psi(
            params, moved.reshape(batch * hops, norbitals), sector_M
        ).reshape(batch, hops)
        delta = candidate_logs - log_values[:, None]
        clipped_real = jnp.clip(jnp.real(delta), -ratio_clip, ratio_clip)
        ratio = jnp.exp(clipped_real + 1j * jnp.imag(delta))
        contribution = (
            pair_count
            * element
            * sign
            * ratio
            / jnp.maximum(proposal_probability, 1.0e-30)
            * has_target
        )
        off_diagonal = jnp.mean(contribution, axis=1)
        energy = diagonal + off_diagonal
        clip_event = (
            (jnp.real(delta) < -ratio_clip)
            | (jnp.real(delta) > ratio_clip)
        ) & has_target
        valid_count = jnp.maximum(jnp.sum(has_target), 1)
        return energy, {
            "diagonal": jnp.mean(diagonal),
            "valid_fraction": jnp.mean(has_target),
            "ratio_clip_fraction": jnp.sum(clip_event) / valid_count,
            "imaginary_mean": jnp.mean(jnp.imag(energy)),
        }

    return local_energy


def _robust_center(values: jax.Array, clip: float) -> jax.Array:
    centered = values - jnp.mean(values)
    if clip <= 0.0:
        return centered
    return jnp.clip(jnp.real(centered), -clip, clip) + 1j * jnp.clip(
        jnp.imag(centered), -clip, clip
    )


def make_train_step_symmetry_v3(
    sample: Any,
    log_psi: Any,
    local0: Any,
    local2: Any,
    lplus0: Any,
    lplus2: Any,
    highest_weight_penalty: float,
    optimizer: optax.GradientTransformation,
    batch: int,
) -> Any:
    """VMC step with an extensive-scale-normalized highest-weight penalty."""

    particles = ACTIVE_PARTICLES
    if particles <= 0:
        raise RuntimeError("ACTIVE_PARTICLES was not set before train-step build")
    q = 1.5 * (particles - 1)
    lplus_scale = max(1.0, particles * q * (q + 1.0))

    def sector_loss(
        params: PyTree,
        sample_key: jax.Array,
        hop_key: jax.Array,
        sector_M: int,
        local: Any,
        lplus_local: Any,
        penalty_ramp: jax.Array,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        occupations, _ = sample(params, sample_key, batch, sector_M)
        occupations = jax.lax.stop_gradient(occupations)
        logs = log_psi(params, occupations, sector_M)
        energies, diagnostics = local(
            params, occupations, logs, sector_M, hop_key
        )
        lplus_values, lplus_diagnostics = lplus_local(
            params,
            occupations,
            logs,
            sector_M,
            jax.random.fold_in(hop_key, 9173),
        )
        normalized_lplus = lplus_values / lplus_scale
        energy_centered = _robust_center(
            energies, ROBUST_CENTER_CLIP
        )
        symmetry_centered = _robust_center(
            normalized_lplus, ROBUST_CENTER_CLIP
        )
        centered = jax.lax.stop_gradient(
            energy_centered
            + highest_weight_penalty * penalty_ramp * symmetry_centered
        )
        surrogate = 2.0 * jnp.real(
            jnp.mean(centered * jnp.conj(logs))
        )
        diagnostics = {
            **diagnostics,
            "energy": jnp.mean(jnp.real(energies)),
            "variance": jnp.var(jnp.real(energies)),
            "lplus_norm": jnp.mean(jnp.real(lplus_values)),
            "lplus_variance": jnp.var(jnp.real(lplus_values)),
            "normalized_lplus": jnp.mean(jnp.real(normalized_lplus)),
            **lplus_diagnostics,
        }
        return surrogate, diagnostics

    def step(
        params: PyTree,
        opt_state: PyTree,
        key: jax.Array,
        learning_scale: jax.Array,
    ) -> tuple[PyTree, PyTree, dict[str, jax.Array]]:
        keys = jax.random.split(key, 4)

        def loss_function(p: PyTree):
            loss0, diag0 = sector_loss(
                p, keys[0], keys[1], 0, local0, lplus0, learning_scale
            )
            loss2, diag2 = sector_loss(
                p, keys[2], keys[3], 2, local2, lplus2, learning_scale
            )
            return 0.5 * (loss0 + loss2), (diag0, diag2)

        (_, (diag0, diag2)), gradients = jax.value_and_grad(
            loss_function, has_aux=True
        )(params)
        updates, opt_state = optimizer.update(gradients, opt_state, params)
        updates = jax.tree_util.tree_map(
            lambda value: learning_scale * value, updates
        )
        params = optax.apply_updates(params, updates)
        return params, opt_state, {
            "E0": diag0["energy"],
            "E2": diag2["energy"],
            "gap": diag2["energy"] - diag0["energy"],
            "var0": diag0["variance"],
            "var2": diag2["variance"],
            "valid0": diag0["valid_fraction"],
            "valid2": diag2["valid_fraction"],
            "clip0": diag0["ratio_clip_fraction"],
            "clip2": diag2["ratio_clip_fraction"],
            "imag0": diag0["imaginary_mean"],
            "imag2": diag2["imaginary_mean"],
            "gradient_norm": optax.global_norm(gradients),
            "lplus0": diag0["lplus_norm"],
            "lplus2": diag2["lplus_norm"],
            "lplus_var0": diag0["lplus_variance"],
            "lplus_var2": diag2["lplus_variance"],
            "normalized_lplus0": diag0["normalized_lplus"],
            "normalized_lplus2": diag2["normalized_lplus"],
        }

    return jax.jit(step)


ORIGINAL_TRAIN_ONE = v2.train_one


def train_one_v3(*args: Any, **kwargs: Any):
    global ACTIVE_PARTICLES
    config = args[0] if args else kwargs["config"]
    ACTIVE_PARTICLES = int(config.particles)
    result, params = ORIGINAL_TRAIN_ONE(*args, **kwargs)
    result["method"] = (
        "sampled complex Fock-space autoregressive NQS; "
        "V3 allowed-move importance sampling + normalized highest-weight VMC"
    )
    result["v3_improvements"] = {
        "allowed_target_importance_sampling": True,
        "target_proposal": "absolute interaction matrix element",
        "source_stratification": SOURCE_STRATIFIED,
        "highest_weight_scale": "N*Q*(Q+1)",
        "robust_center_clip": ROBUST_CENTER_CLIP,
        "highest_weight_warmup": True,
    }
    output_dir = args[1] if len(args) > 1 else kwargs["output_dir"]
    run_dir = Path(output_dir) / f"N{config.particles}"
    (run_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    return result, params


def parse_v3_options() -> None:
    global ROBUST_CENTER_CLIP, SOURCE_STRATIFIED
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--robust-center-clip", type=float, default=10.0)
    parser.add_argument("--random-source-pairs", action="store_true")
    options, remaining = parser.parse_known_args()
    ROBUST_CENTER_CLIP = options.robust_center_clip
    SOURCE_STRATIFIED = not options.random_source_pairs
    sys.argv = [sys.argv[0], *remaining]


def main() -> None:
    parse_v3_options()
    v2.make_local_energy = make_local_energy_importance
    v2.make_train_step = make_train_step_symmetry_v3
    v2.train_one = train_one_v3
    v2.main()


if __name__ == "__main__":
    main()
