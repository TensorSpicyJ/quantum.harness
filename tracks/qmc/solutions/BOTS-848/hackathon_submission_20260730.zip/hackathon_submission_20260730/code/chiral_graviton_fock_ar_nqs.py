#!/usr/bin/env python3
"""Sampled Fock-space autoregressive NQS for the spherical Coulomb gap.

This program is deliberately different from the explicit-vector V2 code:

* it never enumerates the fixed-(N,M) Hilbert space;
* a complex autoregressive recurrent network represents normalized Fock
  amplitudes and is genuinely optimized by VMC;
* particle number and total Lz are imposed exactly by a feasibility mask;
* diagonal two-body terms are summed exactly, while off-diagonal pair
  scatterings use an unbiased stochastic local-energy estimator.

The same conditional network is trained in M=0 and M=2.  The reported gap is
E(M=2)-E(M=0).  At the Laughlin flux 2Q=3(N-1), the lowest state in M=0 is the
L=0 ground state and the lowest state in M=2 is expected to be the L=2
graviton.  Small-system ED tests and L^2 diagnostics are provided because an
autoregressive ansatz does not enforce full SU(2) irreducibility by itself.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, NamedTuple

import numpy as np

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.88")

import jax
import jax.numpy as jnp
import optax

from chiral_graviton_ed import (
    _phase,
    antisymmetric_pair_matrix,
    fock_basis,
    interaction_pseudopotentials,
    many_body_hamiltonian,
    wigner_3j2,
)


Array = np.ndarray
PyTree = Any


class PairData(NamedTuple):
    pair_a: jax.Array
    pair_b: jax.Array
    counts: jax.Array
    slots: jax.Array
    values: jax.Array
    occupied_pair_positions: jax.Array


@dataclass
class TrainConfig:
    particles: int
    hidden: int
    batch: int
    hops: int
    steps: int
    learning_rate: float
    warmup: int
    seed: int
    log_every: int
    eval_batches: int
    eval_batch: int
    eval_hops: int
    grad_clip: float
    ratio_clip: float
    highest_weight_penalty: float
    lplus_hops: int
    eval_lplus_hops: int


def _triangle_delta(tj1: int, tj2: int, tj3: int) -> float:
    """Triangle coefficient Delta(j1,j2,j3), with doubled arguments."""

    a = (tj1 + tj2 - tj3) // 2
    b = (tj1 - tj2 + tj3) // 2
    c = (-tj1 + tj2 + tj3) // 2
    d = (tj1 + tj2 + tj3) // 2 + 1
    if min(a, b, c) < 0 or (tj1 + tj2 + tj3) % 2:
        return 0.0
    return math.exp(
        0.5
        * (
            math.lgamma(a + 1)
            + math.lgamma(b + 1)
            + math.lgamma(c + 1)
            - math.lgamma(d + 1)
        )
    )


def wigner_6j2(
    tj1: int,
    tj2: int,
    tj3: int,
    tj4: int,
    tj5: int,
    tj6: int,
) -> float:
    """Wigner 6-j symbol using doubled integer angular momenta."""

    prefactor = (
        _triangle_delta(tj1, tj2, tj3)
        * _triangle_delta(tj1, tj5, tj6)
        * _triangle_delta(tj4, tj2, tj6)
        * _triangle_delta(tj4, tj5, tj3)
    )
    if prefactor == 0.0:
        return 0.0
    lower = (
        (tj1 + tj2 + tj3) // 2,
        (tj1 + tj5 + tj6) // 2,
        (tj4 + tj2 + tj6) // 2,
        (tj4 + tj5 + tj3) // 2,
    )
    upper = (
        (tj1 + tj2 + tj4 + tj5) // 2,
        (tj2 + tj3 + tj5 + tj6) // 2,
        (tj1 + tj3 + tj4 + tj6) // 2,
    )
    z_min = max(lower)
    z_max = min(upper)
    if z_min > z_max:
        return 0.0
    terms = []
    for z in range(z_min, z_max + 1):
        log_denominator = sum(
            math.lgamma(z - value + 1) for value in lower
        ) + sum(math.lgamma(value - z + 1) for value in upper)
        terms.append(
            _phase(z) * math.exp(math.lgamma(z + 2) - log_denominator)
        )
    return prefactor * math.fsum(terms)


def fast_coulomb_pseudopotentials(two_q: int) -> dict[int, float]:
    """Spherical Coulomb pseudopotentials in e^2/(epsilon*l_B).

    This is the recoupled 6-j form of the product-basis expression used in
    ``chiral_graviton_ed.py``.  It changes the setup scaling from a nested
    product-basis contraction to O((2Q)^3), and agrees with that reference
    expression at machine precision for the ED sizes.
    """

    if two_q <= 0:
        raise ValueError("Coulomb interaction requires Q > 0")
    charge = np.asarray(
        [
            wigner_3j2(two_q, 2 * k, two_q, -two_q, 0, two_q)
            for k in range(two_q + 1)
        ],
        dtype=np.float64,
    )
    prefactor = (two_q + 1.0) ** 2 / math.sqrt(two_q / 2.0)
    result: dict[int, float] = {}
    for J in range(two_q + 1):
        terms = [
            wigner_6j2(two_q, two_q, 2 * J, two_q, two_q, 2 * k)
            * charge[k] ** 2
            for k in range(two_q + 1)
        ]
        result[J] = (
            prefactor * _phase(two_q + J) * math.fsum(terms)
        )
    return result


def _pair_lists(norbitals: int) -> tuple[list[list[tuple[int, int]]], int]:
    lists: list[list[tuple[int, int]]] = [
        [] for _ in range(2 * norbitals - 1)
    ]
    for a in range(norbitals):
        for b in range(a + 1, norbitals):
            lists[a + b].append((a, b))
    return lists, max(map(len, lists))


def _pair_lplus(
    source: list[tuple[int, int]],
    target: list[tuple[int, int]],
    two_q: int,
) -> Array:
    target_index = {pair: i for i, pair in enumerate(target)}
    matrix = np.zeros((len(target), len(source)), dtype=np.float64)
    for column, (a, b) in enumerate(source):
        for which in (0, 1):
            orbitals = [a, b]
            orbital = orbitals[which]
            if orbital >= two_q:
                continue
            raised = orbital + 1
            if raised in orbitals:
                continue
            two_m = -two_q + 2 * orbital
            coefficient = math.sqrt(
                0.5 * (two_q - two_m)
                * (0.5 * (two_q + two_m) + 1.0)
            )
            orbitals[which] = raised
            pair = tuple(sorted(orbitals))
            row = target_index.get(pair)
            if row is not None:
                matrix[row, column] += coefficient
    return matrix


def pair_blocks(
    two_q: int, pseudopotentials: dict[int, float]
) -> tuple[Array, Array, Array, Array, float]:
    """Build compact fixed-pair-M interaction blocks using pair L^2."""

    norbitals = two_q + 1
    lists, max_pairs = _pair_lists(norbitals)
    pair_a = np.zeros((2 * norbitals - 1, max_pairs), dtype=np.int32)
    pair_b = np.zeros_like(pair_a)
    counts = np.asarray([len(x) for x in lists], dtype=np.int32)
    slots = np.full((norbitals, norbitals), -1, dtype=np.int32)
    values = np.zeros(
        (2 * norbitals - 1, max_pairs, max_pairs), dtype=np.float64
    )
    worst_l2_residual = 0.0
    for pair_sum, pairs in enumerate(lists):
        if not pairs:
            continue
        for slot, (a, b) in enumerate(pairs):
            pair_a[pair_sum, slot] = a
            pair_b[pair_sum, slot] = b
            slots[a, b] = slot
            slots[b, a] = slot
        target = lists[pair_sum + 1] if pair_sum + 1 < len(lists) else []
        lplus = _pair_lplus(pairs, target, two_q)
        pair_M = pair_sum - two_q
        l2 = lplus.T @ lplus + pair_M * (pair_M + 1) * np.eye(len(pairs))
        eigenvalues, vectors = np.linalg.eigh(l2)
        inferred_J = np.rint(
            0.5 * (np.sqrt(np.maximum(0.0, 1.0 + 4.0 * eigenvalues)) - 1.0)
        ).astype(int)
        residual = np.max(np.abs(eigenvalues - inferred_J * (inferred_J + 1)))
        worst_l2_residual = max(worst_l2_residual, float(residual))
        if len(set(inferred_J.tolist())) != len(pairs):
            raise RuntimeError(f"pair L2 degeneracy in pair_sum={pair_sum}")
        diagonal = np.asarray(
            [pseudopotentials[int(J)] for J in inferred_J],
            dtype=np.float64,
        )
        values[pair_sum, : len(pairs), : len(pairs)] = (
            vectors * diagonal[None, :]
        ) @ vectors.T
    return pair_a, pair_b, counts, slots, values, worst_l2_residual


def load_or_build_interaction(
    particles: int, cache_dir: Path
) -> tuple[dict[str, Array], dict[str, float]]:
    two_q = 3 * (particles - 1)
    path = cache_dir / f"coulomb_pair_blocks_2Q{two_q}.npz"
    cache_dir.mkdir(parents=True, exist_ok=True)
    if path.exists():
        with np.load(path) as data:
            arrays = {key: data[key] for key in data.files}
        metadata = {
            "setup_seconds": 0.0,
            "pair_l2_residual": float(arrays.pop("pair_l2_residual")),
            "cache_hit": 1.0,
        }
        return arrays, metadata
    started = time.perf_counter()
    pseudopotentials = fast_coulomb_pseudopotentials(two_q)
    pa, pb, counts, slots, values, residual = pair_blocks(
        two_q, pseudopotentials
    )
    arrays = {
        "pair_a": pa,
        "pair_b": pb,
        "counts": counts,
        "slots": slots,
        "values": values,
        "pseudopotentials": np.asarray(
            [pseudopotentials[J] for J in range(two_q + 1)]
        ),
    }
    temporary = path.with_suffix(".tmp.npz")
    np.savez_compressed(
        temporary,
        **arrays,
        pair_l2_residual=np.asarray(residual),
    )
    temporary.replace(path)
    return arrays, {
        "setup_seconds": time.perf_counter() - started,
        "pair_l2_residual": residual,
        "cache_hit": 0.0,
    }


def init_params(key: jax.Array, hidden: int, feature_count: int = 5) -> PyTree:
    keys = iter(jax.random.split(key, 24))

    def normal(shape: tuple[int, ...], scale: float) -> jax.Array:
        return scale * jax.random.normal(next(keys), shape, dtype=jnp.float32)

    return {
        "embedding": normal((2, hidden), 0.08),
        "context": normal((feature_count, hidden), 1.0 / math.sqrt(feature_count)),
        "context_bias": jnp.zeros((hidden,), dtype=jnp.float32),
        "Wz": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "Uz": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "bz": jnp.zeros((hidden,), dtype=jnp.float32),
        "Wr": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "Ur": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "br": jnp.zeros((hidden,), dtype=jnp.float32),
        "Wh": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "Uh": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "bh": jnp.zeros((hidden,), dtype=jnp.float32),
        "amp": normal((hidden,), 0.05),
        "amp_bias": jnp.asarray(0.0, dtype=jnp.float32),
        "phase_embedding": normal((2, hidden), 0.08),
        "phase_context": normal((3, hidden), 1.0 / math.sqrt(3.0)),
        "phase_U_forward": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "phase_U_backward": normal((hidden, hidden), 1.0 / math.sqrt(hidden)),
        "phase_hidden_bias": jnp.zeros((hidden,), dtype=jnp.float32),
        "phase_output": normal((2 * hidden,), 0.08),
        "phase_bias": normal((), 0.03),
        "phase_step": normal((2, hidden), 0.12),
        "phase_step_bias": normal((2,), 0.03),
    }


def make_wavefunction_functions(
    particles: int, hidden: int
) -> tuple[Any, Any]:
    two_q = 3 * (particles - 1)
    norbitals = two_q + 1
    base_sum = particles * two_q // 2

    def features(
        i: jax.Array,
        n_used: jax.Array,
        sum_used: jax.Array,
        sector_M: int,
    ) -> jax.Array:
        batch = n_used.shape[0]
        target_sum = base_sum + sector_M
        return jnp.stack(
            [
                jnp.full((batch,), 2.0 * i / max(1, norbitals - 1) - 1.0),
                (particles - n_used) / float(particles),
                (target_sum - sum_used)
                / float(max(1, particles * (norbitals - 1))),
                jnp.full((batch,), sector_M / 2.0),
                jnp.full((batch,), particles / float(norbitals)),
            ],
            axis=1,
        ).astype(jnp.float32)

    def valid_choices(
        i: jax.Array,
        n_used: jax.Array,
        sum_used: jax.Array,
        sector_M: int,
    ) -> tuple[jax.Array, jax.Array]:
        target = base_sum + sector_M
        future = norbitals - i - 1

        def valid(choice: int) -> jax.Array:
            left_n = particles - n_used - choice
            left_sum = target - sum_used - choice * i
            minimum = left_n * (i + 1) + left_n * (left_n - 1) // 2
            maximum = left_n * (norbitals - 1) - left_n * (left_n - 1) // 2
            return (
                (left_n >= 0)
                & (left_n <= future)
                & (left_sum >= minimum)
                & (left_sum <= maximum)
            )

        return valid(0), valid(1)

    def update_hidden(
        params: PyTree,
        hidden_state: jax.Array,
        context: jax.Array,
        choice: jax.Array,
    ) -> jax.Array:
        x = params["embedding"][choice] + context @ params["context"]
        x = jnp.tanh(x + params["context_bias"])
        z = jax.nn.sigmoid(x @ params["Wz"] + hidden_state @ params["Uz"] + params["bz"])
        r = jax.nn.sigmoid(x @ params["Wr"] + hidden_state @ params["Ur"] + params["br"])
        proposal = jnp.tanh(
            x @ params["Wh"] + (r * hidden_state) @ params["Uh"] + params["bh"]
        )
        return (1.0 - z) * hidden_state + z * proposal

    def configuration_phase(
        params: PyTree, occupations: jax.Array, sector_M: int
    ) -> jax.Array:
        """Bidirectional recurrent sign/phase head."""

        batch = occupations.shape[0]
        positions = jnp.arange(norbitals, dtype=jnp.int32)

        def scan_direction(
            choices: jax.Array,
            indices: jax.Array,
            recurrent: jax.Array,
        ) -> jax.Array:
            initial = jnp.zeros((batch, hidden), dtype=jnp.float32)

            def phase_step(h: jax.Array, xs: tuple[jax.Array, jax.Array]):
                i, choice = xs
                context = jnp.stack(
                    [
                        jnp.full(
                            (batch,),
                            2.0 * i / max(1, norbitals - 1) - 1.0,
                        ),
                        jnp.full((batch,), sector_M / 2.0),
                        jnp.full((batch,), particles / float(norbitals)),
                    ],
                    axis=1,
                )
                x = (
                    params["phase_embedding"][choice]
                    + context @ params["phase_context"]
                )
                return jnp.tanh(
                    x + h @ recurrent + params["phase_hidden_bias"]
                ), None

            final, _ = jax.lax.scan(
                phase_step, initial, (indices, choices)
            )
            return final

        forward = scan_direction(
            occupations.T, positions, params["phase_U_forward"]
        )
        backward = scan_direction(
            occupations[:, ::-1].T,
            positions[::-1],
            params["phase_U_backward"],
        )
        return jnp.pi * jax.nn.sigmoid(
            jnp.concatenate([forward, backward], axis=1)
            @ params["phase_output"]
            + params["phase_bias"]
        )

    def log_psi(
        params: PyTree, occupations: jax.Array, sector_M: int
    ) -> jax.Array:
        batch = occupations.shape[0]
        initial = (
            jnp.zeros((batch, hidden), dtype=jnp.float32),
            jnp.zeros((batch,), dtype=jnp.int32),
            jnp.zeros((batch,), dtype=jnp.int32),
            jnp.zeros((batch,), dtype=jnp.float32),
            jnp.zeros((batch, hidden), dtype=jnp.float32),
            jnp.zeros((batch,), dtype=jnp.float32),
        )

        def step(carry: tuple[jax.Array, ...], xs: tuple[jax.Array, jax.Array]):
            hidden_state, n_used, sum_used, log_probability, phase_hidden, phase = carry
            i, choice = xs
            context = features(i, n_used, sum_used, sector_M)
            pre = jnp.tanh(hidden_state + context @ params["context"])
            raw_logit = pre @ params["amp"] + params["amp_bias"]
            phase_context = context[:, (0, 3, 4)]
            phase_pre = jnp.tanh(
                phase_hidden + phase_context @ params["phase_context"]
            )
            raw_phase = jnp.pi * jnp.tanh(
                phase_pre @ params["phase_step"][sector_M // 2]
                + params["phase_step_bias"][sector_M // 2]
            )
            valid0, valid1 = valid_choices(i, n_used, sum_used, sector_M)
            logit0 = jnp.where(valid0, 0.0, -1.0e30)
            logit1 = jnp.where(valid1, raw_logit, -1.0e30)
            normalization = jnp.logaddexp(logit0, logit1)
            selected = jnp.where(choice == 1, logit1, logit0) - normalization
            hidden_state = update_hidden(params, hidden_state, context, choice)
            phase_hidden = jnp.tanh(
                params["phase_embedding"][choice]
                + phase_context @ params["phase_context"]
                + phase_hidden @ params["phase_U_forward"]
                + params["phase_hidden_bias"]
            )
            return (
                hidden_state,
                n_used + choice,
                sum_used + choice * i,
                log_probability + selected,
                phase_hidden,
                phase + choice * raw_phase,
            ), None

        final, _ = jax.lax.scan(
            step,
            initial,
            (jnp.arange(norbitals, dtype=jnp.int32), occupations.T),
        )
        phase = configuration_phase(params, occupations, sector_M)
        return 0.5 * final[3] + 1j * phase

    def sample(
        params: PyTree, key: jax.Array, batch: int, sector_M: int
    ) -> tuple[jax.Array, jax.Array]:
        uniforms = jax.random.uniform(
            key, (norbitals, batch), dtype=jnp.float32
        )
        initial = (
            jnp.zeros((batch, hidden), dtype=jnp.float32),
            jnp.zeros((batch,), dtype=jnp.int32),
            jnp.zeros((batch,), dtype=jnp.int32),
            jnp.zeros((batch,), dtype=jnp.float32),
            jnp.zeros((batch, hidden), dtype=jnp.float32),
            jnp.zeros((batch,), dtype=jnp.float32),
        )

        def step(carry: tuple[jax.Array, ...], xs: tuple[jax.Array, jax.Array]):
            hidden_state, n_used, sum_used, log_probability, phase_hidden, phase = carry
            i, uniform = xs
            context = features(i, n_used, sum_used, sector_M)
            pre = jnp.tanh(hidden_state + context @ params["context"])
            raw_logit = pre @ params["amp"] + params["amp_bias"]
            phase_context = context[:, (0, 3, 4)]
            phase_pre = jnp.tanh(
                phase_hidden + phase_context @ params["phase_context"]
            )
            raw_phase = jnp.pi * jnp.tanh(
                phase_pre @ params["phase_step"][sector_M // 2]
                + params["phase_step_bias"][sector_M // 2]
            )
            valid0, valid1 = valid_choices(i, n_used, sum_used, sector_M)
            logit0 = jnp.where(valid0, 0.0, -1.0e30)
            logit1 = jnp.where(valid1, raw_logit, -1.0e30)
            normalization = jnp.logaddexp(logit0, logit1)
            probability1 = jnp.exp(logit1 - normalization)
            choice = (uniform < probability1).astype(jnp.int32)
            selected = jnp.where(choice == 1, logit1, logit0) - normalization
            hidden_state = update_hidden(params, hidden_state, context, choice)
            phase_hidden = jnp.tanh(
                params["phase_embedding"][choice]
                + phase_context @ params["phase_context"]
                + phase_hidden @ params["phase_U_forward"]
                + params["phase_hidden_bias"]
            )
            return (
                hidden_state,
                n_used + choice,
                sum_used + choice * i,
                log_probability + selected,
                phase_hidden,
                phase + choice * raw_phase,
            ), choice

        final, choices = jax.lax.scan(
            step,
            initial,
            (jnp.arange(norbitals, dtype=jnp.int32), uniforms),
        )
        phase = configuration_phase(params, choices.T, sector_M)
        return choices.T, 0.5 * final[3] + 1j * phase

    return log_psi, sample


def make_pair_data(arrays: dict[str, Array], particles: int) -> PairData:
    occupied_positions = np.asarray(
        [(i, j) for i in range(particles) for j in range(i + 1, particles)],
        dtype=np.int32,
    )
    return PairData(
        pair_a=jnp.asarray(arrays["pair_a"], dtype=jnp.int32),
        pair_b=jnp.asarray(arrays["pair_b"], dtype=jnp.int32),
        counts=jnp.asarray(arrays["counts"], dtype=jnp.int32),
        slots=jnp.asarray(arrays["slots"], dtype=jnp.int32),
        values=jnp.asarray(arrays["values"], dtype=jnp.float32),
        occupied_pair_positions=jnp.asarray(occupied_positions),
    )


def make_local_energy(
    particles: int,
    pair_data: PairData,
    log_psi: Any,
    hops: int,
    ratio_clip: float,
) -> Any:
    norbitals = 3 * particles - 2
    pair_count = particles * (particles - 1) // 2
    orbital_axis = jnp.arange(norbitals, dtype=jnp.int32)

    def local_energy(
        params: PyTree,
        occupations: jax.Array,
        log_values: jax.Array,
        sector_M: int,
        key: jax.Array,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        batch = occupations.shape[0]
        occupied = jnp.sort(
            jnp.where(occupations > 0, orbital_axis[None, :], norbitals),
            axis=1,
        )[:, :particles]
        all_c = occupied[:, pair_data.occupied_pair_positions[:, 0]]
        all_d = occupied[:, pair_data.occupied_pair_positions[:, 1]]
        all_sum = all_c + all_d
        all_slot = pair_data.slots[all_c, all_d]
        diagonal = jnp.sum(
            pair_data.values[all_sum, all_slot, all_slot], axis=1
        )

        source_key, target_key = jax.random.split(key)
        sampled_source = jax.random.randint(
            source_key, (batch, hops), 0, pair_count
        )
        c = jnp.take_along_axis(all_c, sampled_source, axis=1)
        d = jnp.take_along_axis(all_d, sampled_source, axis=1)
        pair_sum = c + d
        source_slot = pair_data.slots[c, d]
        count = pair_data.counts[pair_sum]
        # Draw uniformly from all target slots except the source slot.
        draw = jax.random.randint(
            target_key,
            (batch, hops),
            0,
            jnp.maximum(1, count - 1),
        )
        target_slot = draw + (draw >= source_slot)
        a = pair_data.pair_a[pair_sum, target_slot]
        b = pair_data.pair_b[pair_sum, target_slot]

        batch_index = jnp.arange(batch)[:, None]
        empty_a = occupations[batch_index, a] == 0
        empty_b = occupations[batch_index, b] == 0
        valid = empty_a & empty_b & (count > 1)

        moved = jnp.broadcast_to(
            occupations[:, None, :], (batch, hops, norbitals)
        )
        row = jnp.arange(batch)[:, None]
        hop = jnp.arange(hops)[None, :]
        moved = moved.at[row, hop, c].set(0)
        moved = moved.at[row, hop, d].set(0)
        moved = moved.at[row, hop, a].set(1)
        moved = moved.at[row, hop, b].set(1)
        moved = jnp.where(valid[:, :, None], moved, occupations[:, None, :])

        prefix = jnp.cumsum(occupations, axis=1) - occupations

        def prefix_at(index: jax.Array) -> jax.Array:
            return prefix[batch_index, index]

        exponent = (
            prefix_at(c)
            + prefix_at(d)
            - 1
            + prefix_at(b)
            - (c < b)
            - (d < b)
            + prefix_at(a)
            - (c < a)
            - (d < a)
        )
        sign = jnp.where(exponent % 2 == 0, 1.0, -1.0)
        element = pair_data.values[
            pair_sum, target_slot, source_slot
        ]
        candidate_logs = log_psi(
            params, moved.reshape(batch * hops, norbitals), sector_M
        ).reshape(batch, hops)
        delta = candidate_logs - log_values[:, None]
        clipped_real = jnp.clip(jnp.real(delta), -ratio_clip, ratio_clip)
        ratio = jnp.exp(clipped_real + 1j * jnp.imag(delta))
        contribution = (
            pair_count
            * (count - 1)
            * element
            * sign
            * ratio
            * valid
        )
        off_diagonal = jnp.mean(contribution, axis=1)
        energy = diagonal + off_diagonal
        return energy, {
            "diagonal": jnp.mean(diagonal),
            "valid_fraction": jnp.mean(valid),
            "ratio_clip_fraction": jnp.mean(
                (jnp.real(delta) < -ratio_clip)
                | (jnp.real(delta) > ratio_clip)
            ),
            "imaginary_mean": jnp.mean(jnp.imag(energy)),
        }

    return local_energy


def make_lplus_norm_local(
    particles: int,
    log_psi: Any,
    hops: int,
    ratio_clip: float,
) -> Any:
    """Stochastic local estimator of L_- L_+ in a fixed-M sector.

    The diagonal (raise and immediately undo) is exact. Cross terms sample
    an occupied orbital to raise and then an occupied orbital to lower.
    Adjacent one-body hops have positive fermionic sign in the ordered
    occupation convention.
    """

    two_q = 3 * (particles - 1)
    norbitals = two_q + 1
    orbital_axis = jnp.arange(norbitals, dtype=jnp.int32)
    raising_coefficients = jnp.sqrt(
        jnp.asarray(
            [
                0.5 * (two_q - (-two_q + 2 * i))
                * (0.5 * (two_q + (-two_q + 2 * i)) + 1.0)
                for i in range(norbitals - 1)
            ],
            dtype=jnp.float32,
        )
    )

    def local(
        params: PyTree,
        occupations: jax.Array,
        log_values: jax.Array,
        sector_M: int,
        key: jax.Array,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        batch = occupations.shape[0]
        occupied = jnp.sort(
            jnp.where(occupations > 0, orbital_axis[None, :], norbitals),
            axis=1,
        )[:, :particles]
        safe_occupied = jnp.minimum(occupied, norbitals - 2)
        valid_all_raise = (
            (occupied < norbitals - 1)
            & (
                occupations[
                    jnp.arange(batch)[:, None],
                    jnp.minimum(occupied + 1, norbitals - 1),
                ]
                == 0
            )
        )
        diagonal = jnp.sum(
            valid_all_raise
            * raising_coefficients[safe_occupied] ** 2,
            axis=1,
        )

        raise_key, lower_key = jax.random.split(key)
        raise_position = jax.random.randint(
            raise_key, (batch, hops), 0, particles
        )
        row = jnp.arange(batch)[:, None]
        hop = jnp.arange(hops)[None, :]
        raised_from = occupied[row, raise_position]
        raised_to = jnp.minimum(raised_from + 1, norbitals - 1)
        valid_raise = (
            (raised_from < norbitals - 1)
            & (occupations[row, raised_to] == 0)
        )
        intermediate = jnp.broadcast_to(
            occupations[:, None, :], (batch, hops, norbitals)
        )
        intermediate = intermediate.at[row, hop, raised_from].set(0)
        intermediate = intermediate.at[row, hop, raised_to].set(1)
        intermediate = jnp.where(
            valid_raise[:, :, None],
            intermediate,
            occupations[:, None, :],
        )
        intermediate_occupied = jnp.sort(
            jnp.where(
                intermediate > 0,
                orbital_axis[None, None, :],
                norbitals,
            ),
            axis=2,
        )[:, :, :particles]
        lower_position = jax.random.randint(
            lower_key, (batch, hops), 0, particles
        )
        lowered_from = jnp.take_along_axis(
            intermediate_occupied, lower_position[:, :, None], axis=2
        )[:, :, 0]
        lowered_to = jnp.maximum(lowered_from - 1, 0)
        valid_lower = (
            (lowered_from > 0)
            & (intermediate[row, hop, lowered_to] == 0)
        )
        valid_cross = (
            valid_raise
            & valid_lower
            & (lowered_from != raised_to)
        )
        moved = intermediate.at[row, hop, lowered_from].set(0)
        moved = moved.at[row, hop, lowered_to].set(1)
        moved = jnp.where(
            valid_cross[:, :, None],
            moved,
            occupations[:, None, :],
        )
        candidate_logs = log_psi(
            params, moved.reshape(batch * hops, norbitals), sector_M
        ).reshape(batch, hops)
        delta = candidate_logs - log_values[:, None]
        clipped_real = jnp.clip(jnp.real(delta), -ratio_clip, ratio_clip)
        ratio = jnp.exp(clipped_real + 1j * jnp.imag(delta))
        coefficient = (
            raising_coefficients[jnp.minimum(raised_from, norbitals - 2)]
            * raising_coefficients[jnp.minimum(lowered_to, norbitals - 2)]
        )
        cross = particles**2 * jnp.mean(
            coefficient * ratio * valid_cross, axis=1
        )
        value = diagonal + cross
        return value, {
            "lplus_valid_fraction": jnp.mean(valid_cross),
            "lplus_clip_fraction": jnp.mean(
                (jnp.real(delta) < -ratio_clip)
                | (jnp.real(delta) > ratio_clip)
            ),
        }

    return local


def parameter_count(params: PyTree) -> int:
    return sum(int(x.size) for x in jax.tree_util.tree_leaves(params))


def make_train_step(
    sample: Any,
    log_psi: Any,
    local0: Any,
    local2: Any,
    lplus0: Any,
    lplus2: Any,
    highest_weight_penalty: float,
    optimizer: optax.GradientTransformation,
    batch: int,
) -> Any:
    def sector_loss(
        params: PyTree,
        sample_key: jax.Array,
        hop_key: jax.Array,
        sector_M: int,
        local: Any,
        lplus_local: Any,
    ) -> tuple[jax.Array, dict[str, jax.Array]]:
        occupations, _ = sample(params, sample_key, batch, sector_M)
        occupations = jax.lax.stop_gradient(occupations)
        logs = log_psi(params, occupations, sector_M)
        energies, diagnostics = local(
            params, occupations, logs, sector_M, hop_key
        )
        lplus_values, lplus_diagnostics = lplus_local(
            params, occupations, logs, sector_M,
            jax.random.fold_in(hop_key, 9173),
        )
        objective = energies + highest_weight_penalty * lplus_values
        centered = jax.lax.stop_gradient(
            objective - jnp.mean(objective)
        )
        surrogate = 2.0 * jnp.real(
            jnp.mean(centered * jnp.conj(logs))
        )
        diagnostics = {
            **diagnostics,
            "energy": jnp.mean(jnp.real(energies)),
            "variance": jnp.var(jnp.real(energies)),
            "lplus_norm": jnp.mean(jnp.real(lplus_values)),
            "lplus_variance": jnp.var(jnp.real(lplus_values)),
            **lplus_diagnostics,
        }
        return surrogate, diagnostics

    def step(
        params: PyTree,
        opt_state: PyTree,
        key: jax.Array,
        learning_scale: jax.Array,
    ) -> tuple[PyTree, PyTree, dict[str, jax.Array]]:
        keys = jax.random.split(key, 4)

        def loss_function(p: PyTree):
            loss0, diag0 = sector_loss(
                p, keys[0], keys[1], 0, local0, lplus0
            )
            loss2, diag2 = sector_loss(
                p, keys[2], keys[3], 2, local2, lplus2
            )
            return 0.5 * (loss0 + loss2), (diag0, diag2)

        (_, (diag0, diag2)), gradients = jax.value_and_grad(
            loss_function, has_aux=True
        )(params)
        updates, opt_state = optimizer.update(gradients, opt_state, params)
        updates = jax.tree_util.tree_map(
            lambda value: learning_scale * value, updates
        )
        params = optax.apply_updates(params, updates)
        gradient_norm = optax.global_norm(gradients)
        return params, opt_state, {
            "E0": diag0["energy"],
            "E2": diag2["energy"],
            "gap": diag2["energy"] - diag0["energy"],
            "var0": diag0["variance"],
            "var2": diag2["variance"],
            "valid0": diag0["valid_fraction"],
            "valid2": diag2["valid_fraction"],
            "clip0": diag0["ratio_clip_fraction"],
            "clip2": diag2["ratio_clip_fraction"],
            "imag0": diag0["imaginary_mean"],
            "imag2": diag2["imaginary_mean"],
            "gradient_norm": gradient_norm,
            "lplus0": diag0["lplus_norm"],
            "lplus2": diag2["lplus_norm"],
            "lplus_var0": diag0["lplus_variance"],
            "lplus_var2": diag2["lplus_variance"],
        }

    return jax.jit(step)


def evaluate(
    params: PyTree,
    key: jax.Array,
    sample: Any,
    log_psi: Any,
    local: Any,
    lplus_local: Any,
    sector_M: int,
    batches: int,
    batch: int,
) -> dict[str, float]:
    @jax.jit
    def one_batch(k: jax.Array):
        sample_key, hop_key = jax.random.split(k)
        occupations, _ = sample(params, sample_key, batch, sector_M)
        logs = log_psi(params, occupations, sector_M)
        energies, diagnostics = local(
            params, occupations, logs, sector_M, hop_key
        )
        lplus_values, lplus_diagnostics = lplus_local(
            params, occupations, logs, sector_M,
            jax.random.fold_in(hop_key, 9173),
        )
        return energies, lplus_values, diagnostics, lplus_diagnostics

    real_energies = []
    imaginary = []
    valid = []
    clipped = []
    lplus_samples = []
    lplus_valid = []
    for _ in range(batches):
        key, subkey = jax.random.split(key)
        energies, lplus_values, diagnostics, lplus_diagnostics = one_batch(
            subkey
        )
        real_energies.append(np.asarray(jnp.real(energies)))
        lplus_samples.append(np.asarray(jnp.real(lplus_values)))
        imaginary.append(float(diagnostics["imaginary_mean"]))
        valid.append(float(diagnostics["valid_fraction"]))
        clipped.append(float(diagnostics["ratio_clip_fraction"]))
        lplus_valid.append(
            float(lplus_diagnostics["lplus_valid_fraction"])
        )
    values = np.concatenate(real_energies)
    batch_means = np.asarray([np.mean(x) for x in real_energies])
    lplus_values = np.concatenate(lplus_samples)
    lplus_batch_means = np.asarray([np.mean(x) for x in lplus_samples])
    return {
        "energy": float(np.mean(values)),
        "sample_variance": float(np.var(values, ddof=1)),
        "standard_error_batch": float(
            np.std(batch_means, ddof=1) / math.sqrt(max(1, batches))
        )
        if batches > 1
        else float("nan"),
        "imaginary_mean": float(np.mean(imaginary)),
        "valid_fraction": float(np.mean(valid)),
        "ratio_clip_fraction": float(np.mean(clipped)),
        "samples": int(values.size),
        "lplus_norm": float(np.mean(lplus_values)),
        "lplus_norm_standard_error": float(
            np.std(lplus_batch_means, ddof=1) / math.sqrt(max(1, batches))
        )
        if batches > 1
        else float("nan"),
        "L2": float(
            np.mean(lplus_values) + sector_M * (sector_M + 1)
        ),
        "lplus_valid_fraction": float(np.mean(lplus_valid)),
    }


def exact_small_system_test(cache_dir: Path, seed: int = 17) -> dict[str, float]:
    """Validate interaction setup and stochastic local energies at N=4."""

    particles = 4
    two_q = 9
    arrays, _ = load_or_build_interaction(particles, cache_dir)
    fast_pp = arrays["pseudopotentials"]
    reference_pp = interaction_pseudopotentials(two_q, "coulomb")
    pp_error = max(
        abs(fast_pp[J] - reference_pp[J]) for J in range(two_q + 1)
    )
    pairs, reference_pair_matrix = antisymmetric_pair_matrix(
        two_q, reference_pp
    )
    lists, _ = _pair_lists(two_q + 1)
    pair_error = 0.0
    pair_index = {pair: i for i, pair in enumerate(pairs)}
    for pair_sum, block_pairs in enumerate(lists):
        for i, pair_i in enumerate(block_pairs):
            for j, pair_j in enumerate(block_pairs):
                pair_error = max(
                    pair_error,
                    abs(
                        arrays["values"][pair_sum, i, j]
                        - reference_pair_matrix[
                            pair_index[pair_i], pair_index[pair_j]
                        ]
                    ),
                )
    basis = fock_basis(particles, two_q, 0)
    H = many_body_hamiltonian(
        basis, pairs, reference_pair_matrix, two_q
    )
    exact_energy = float(np.linalg.eigvalsh(H)[0])

    # Test unbiasedness of the pair-scattering estimator on a fixed random
    # complex vector.  This avoids conflating network training with algebra.
    rng = np.random.default_rng(seed)
    psi = rng.normal(size=len(basis)) + 1j * rng.normal(size=len(basis))
    psi /= np.linalg.norm(psi)
    index = {state: i for i, state in enumerate(basis)}
    state = basis[len(basis) // 2]
    exact_local = (H @ psi)[index[state]] / psi[index[state]]
    occupied = [i for i in range(two_q + 1) if (state >> i) & 1]
    estimates = []
    for _ in range(20000):
        diagonal = 0.0
        off = []
        for c_index in range(particles):
            for d_index in range(c_index + 1, particles):
                c, d = occupied[c_index], occupied[d_index]
                pair_sum = c + d
                source_slot = int(arrays["slots"][c, d])
                diagonal += arrays["values"][
                    pair_sum, source_slot, source_slot
                ]
        pair_choice = rng.integers(particles * (particles - 1) // 2)
        c_index, d_index = [
            (i, j)
            for i in range(particles)
            for j in range(i + 1, particles)
        ][pair_choice]
        c, d = occupied[c_index], occupied[d_index]
        pair_sum = c + d
        source_slot = int(arrays["slots"][c, d])
        count = int(arrays["counts"][pair_sum])
        draw = rng.integers(max(1, count - 1))
        target_slot = int(draw + (draw >= source_slot))
        a = int(arrays["pair_a"][pair_sum, target_slot])
        b = int(arrays["pair_b"][pair_sum, target_slot])
        value = 0.0j
        if not ((state >> a) & 1) and not ((state >> b) & 1):
            from chiral_graviton_ed import apply_pair_operator

            moved, sign = apply_pair_operator(state, a, b, c, d)
            value = (
                particles
                * (particles - 1)
                // 2
                * (count - 1)
                * arrays["values"][pair_sum, target_slot, source_slot]
                * sign
                * psi[index[moved]]
                / psi[index[state]]
            )
        estimates.append(diagonal + value)
    stochastic_mean = np.mean(estimates)
    stochastic_error = abs(stochastic_mean - exact_local)
    return {
        "pseudopotential_max_error": float(pp_error),
        "pair_block_max_error": float(pair_error),
        "exact_ground_energy_M0": exact_energy,
        "local_energy_exact_real": float(np.real(exact_local)),
        "local_energy_exact_imag": float(np.imag(exact_local)),
        "local_energy_mc_real": float(np.real(stochastic_mean)),
        "local_energy_mc_imag": float(np.imag(stochastic_mean)),
        "local_energy_mc_absolute_error": float(stochastic_error),
    }


def supervised_teacher_pretrain(
    teacher_path: Path,
    hidden: int,
    steps: int,
    batch: int,
    learning_rate: float,
    phase_weight: float,
    seed: int,
    output_dir: Path,
) -> tuple[PyTree, dict[str, float]]:
    """Pretrain on the explicit N=8 V2 states, then transfer the weights.

    Only this initialization stage enumerates a small Fock space. All target
    sizes continue with direct autoregressive sampling.
    """

    data = np.load(teacher_path)
    basis0 = np.asarray(data["basis_M0"], dtype=np.uint64)
    basis2 = np.asarray(data["basis_M2"], dtype=np.uint64)
    psi0 = np.asarray(data["psi_ground"], dtype=np.complex128)
    psi2 = np.asarray(data["psi_excited_M2"], dtype=np.complex128)
    particles = int(round((basis0[0].bit_count() if hasattr(basis0[0], "bit_count") else int(basis0[0]).bit_count())))
    if particles <= 0:
        particles = 8
    two_q = 3 * (particles - 1)
    norbitals = two_q + 1

    def occupations(states: Array) -> Array:
        return (
            (states[:, None] >> np.arange(norbitals, dtype=np.uint64))
            & np.uint64(1)
        ).astype(np.int32)

    occupations0 = occupations(basis0)
    occupations2 = occupations(basis2)
    psi0 /= np.linalg.norm(psi0)
    psi2 /= np.linalg.norm(psi2)
    probability0 = np.abs(psi0) ** 2
    probability2 = np.abs(psi2) ** 2
    phase0 = np.angle(psi0).astype(np.float32)
    phase2 = np.angle(psi2).astype(np.float32)

    log_psi, _ = make_wavefunction_functions(particles, hidden)
    key = jax.random.PRNGKey(seed + 881)
    key, init_key = jax.random.split(key)
    params = init_params(init_key, hidden)
    optimizer = optax.chain(
        optax.clip_by_global_norm(5.0), optax.adam(learning_rate)
    )
    opt_state = optimizer.init(params)

    @jax.jit
    def step(
        p: PyTree,
        state: PyTree,
        configurations0: jax.Array,
        phases0: jax.Array,
        configurations2: jax.Array,
        phases2: jax.Array,
    ):
        def loss_function(q: PyTree):
            logs0 = log_psi(q, configurations0, 0)
            logs2 = log_psi(q, configurations2, 2)
            nll0 = -2.0 * jnp.mean(jnp.real(logs0))
            nll2 = -2.0 * jnp.mean(jnp.real(logs2))

            def sign_cross_entropy(logs, target_phases):
                target_negative = (
                    jnp.abs(target_phases) > 0.5 * jnp.pi
                ).astype(jnp.float32)
                probability_negative = jnp.clip(
                    jnp.imag(logs) / jnp.pi,
                    1.0e-6,
                    1.0 - 1.0e-6,
                )
                return -jnp.mean(
                    target_negative * jnp.log(probability_negative)
                    + (1.0 - target_negative)
                    * jnp.log(1.0 - probability_negative)
                )

            phase0_loss = sign_cross_entropy(logs0, phases0)
            phase2_loss = sign_cross_entropy(logs2, phases2)
            loss = 0.5 * (nll0 + nll2) + phase_weight * 0.5 * (
                phase0_loss + phase2_loss
            )
            return loss, (nll0, nll2, phase0_loss, phase2_loss)

        (loss, diagnostics), gradients = jax.value_and_grad(
            loss_function, has_aux=True
        )(p)
        updates, state = optimizer.update(gradients, state, p)
        return optax.apply_updates(p, updates), state, loss, diagnostics

    rng = np.random.default_rng(seed + 1771)
    started = time.perf_counter()
    for iteration in range(1, steps + 1):
        indices0 = rng.choice(len(basis0), batch, p=probability0)
        indices2 = rng.choice(len(basis2), batch, p=probability2)
        params, opt_state, loss, diagnostics = step(
            params,
            opt_state,
            jnp.asarray(occupations0[indices0]),
            jnp.asarray(phase0[indices0]),
            jnp.asarray(occupations2[indices2]),
            jnp.asarray(phase2[indices2]),
        )
        if iteration == 1 or iteration % 250 == 0 or iteration == steps:
            host = [float(x) for x in diagnostics]
            print(
                f"teacher step={iteration:5d} loss={float(loss):.6f} "
                f"NLL=({host[0]:.4f},{host[1]:.4f}) "
                f"phase=({host[2]:.3e},{host[3]:.3e})",
                flush=True,
            )

    def overlap(configurations: Array, teacher: Array, sector_M: int) -> float:
        logs = np.asarray(
            jax.jit(log_psi)(params, jnp.asarray(configurations), sector_M)
        )
        model = np.exp(logs.astype(np.complex128))
        model /= np.linalg.norm(model)
        return float(abs(np.vdot(teacher, model)) ** 2)

    diagnostics = {
        "particles": particles,
        "steps": steps,
        "seconds": time.perf_counter() - started,
        "ground_overlap": overlap(occupations0, psi0, 0),
        "excited_overlap": overlap(occupations2, psi2, 2),
    }
    np.savez(
        output_dir / "teacher_pretrained_params.npz",
        **{name: np.asarray(value) for name, value in params.items()},
    )
    (output_dir / "teacher_pretrain.json").write_text(
        json.dumps(diagnostics, indent=2), encoding="utf-8"
    )
    print("teacher pretrain:", json.dumps(diagnostics), flush=True)
    return params, diagnostics


def train_one(
    config: TrainConfig,
    output_dir: Path,
    cache_dir: Path,
    resume: bool,
    initial_params: PyTree | None = None,
) -> tuple[dict[str, Any], PyTree]:
    particles = config.particles
    two_q = 3 * (particles - 1)
    norbitals = two_q + 1
    run_dir = output_dir / f"N{particles}"
    run_dir.mkdir(parents=True, exist_ok=True)
    arrays, setup = load_or_build_interaction(particles, cache_dir)
    pair_data = make_pair_data(arrays, particles)
    log_psi, sample = make_wavefunction_functions(particles, config.hidden)
    local_train = make_local_energy(
        particles, pair_data, log_psi, config.hops, config.ratio_clip
    )
    local_eval = make_local_energy(
        particles, pair_data, log_psi, config.eval_hops, config.ratio_clip
    )
    lplus_train = make_lplus_norm_local(
        particles, log_psi, config.lplus_hops, config.ratio_clip
    )
    lplus_eval = make_lplus_norm_local(
        particles, log_psi, config.eval_lplus_hops, config.ratio_clip
    )

    key = jax.random.PRNGKey(config.seed + 1009 * particles)
    key, init_key = jax.random.split(key)
    params = init_params(init_key, config.hidden) if initial_params is None else initial_params
    schedule = optax.chain(
        optax.clip_by_global_norm(config.grad_clip),
        optax.adam(config.learning_rate),
    )
    opt_state = schedule.init(params)
    start_step = 0
    checkpoint = run_dir / "checkpoint.npz"
    if resume and checkpoint.exists():
        restored = np.load(checkpoint, allow_pickle=True)
        params = {
            name.removeprefix("param__"): jnp.asarray(restored[name])
            for name in restored.files
            if name.startswith("param__")
        }
        start_step = int(restored["step"])
        key = jnp.asarray(restored["key"], dtype=jnp.uint32)
        opt_state = schedule.init(params)

    train_step = make_train_step(
        sample,
        log_psi,
        local_train,
        local_train,
        lplus_train,
        lplus_train,
        config.highest_weight_penalty,
        schedule,
        config.batch,
    )
    print(
        f"N={particles}, 2Q={two_q}, orbitals={norbitals}, "
        f"parameters={parameter_count(params)}, GPU={jax.devices()[0]}",
        flush=True,
    )
    print(
        f"interaction setup={setup['setup_seconds']:.2f}s, "
        f"pair-L2 residual={setup['pair_l2_residual']:.3e}",
        flush=True,
    )
    history: list[dict[str, float]] = []
    started = time.perf_counter()
    compile_finished: float | None = None
    for step in range(start_step + 1, config.steps + 1):
        key, step_key = jax.random.split(key)
        if config.warmup > 0:
            learning_scale = min(1.0, step / config.warmup)
        else:
            learning_scale = 1.0
        params, opt_state, diagnostics = train_step(
            params, opt_state, step_key, jnp.asarray(learning_scale)
        )
        if compile_finished is None:
            jax.block_until_ready(diagnostics["gap"])
            compile_finished = time.perf_counter()
            print(
                f"N={particles} JIT first step "
                f"{compile_finished-started:.1f}s",
                flush=True,
            )
        if step == 1 or step % config.log_every == 0 or step == config.steps:
            host = {key_: float(value) for key_, value in diagnostics.items()}
            host["step"] = step
            host["elapsed_seconds"] = time.perf_counter() - started
            history.append(host)
            print(
                f"N={particles} step={step:5d} "
                f"E0={host['E0']:.7f} E2={host['E2']:.7f} "
                f"gap={host['gap']:.7f} "
                f"var=({host['var0']:.3e},{host['var2']:.3e}) "
                f"|g|={host['gradient_norm']:.3e} "
                f"valid=({host['valid0']:.2f},{host['valid2']:.2f}) "
                f"clip=({host['clip0']:.3e},{host['clip2']:.3e}) "
                f"L+norm=({host['lplus0']:.3f},{host['lplus2']:.3f}) "
                f"t={host['elapsed_seconds']:.1f}s",
                flush=True,
            )
            np.savez(
                checkpoint,
                step=np.asarray(step),
                key=np.asarray(key),
                **{
                    f"param__{name}": np.asarray(value)
                    for name, value in params.items()
                },
            )
            (run_dir / "history.json").write_text(
                json.dumps(history, indent=2), encoding="utf-8"
            )

    train_seconds = time.perf_counter() - started
    key, eval0_key, eval2_key = jax.random.split(key, 3)
    eval0 = evaluate(
        params,
        eval0_key,
        sample,
        log_psi,
        local_eval,
        lplus_eval,
        0,
        config.eval_batches,
        config.eval_batch,
    )
    eval2 = evaluate(
        params,
        eval2_key,
        sample,
        log_psi,
        local_eval,
        lplus_eval,
        2,
        config.eval_batches,
        config.eval_batch,
    )
    gap = eval2["energy"] - eval0["energy"]
    gap_stderr = math.hypot(
        eval0["standard_error_batch"], eval2["standard_error_batch"]
    )
    result: dict[str, Any] = {
        "method": "sampled complex Fock-space autoregressive NQS",
        "particles": particles,
        "two_q": two_q,
        "orbitals": norbitals,
        "parameters": parameter_count(params),
        "config": asdict(config),
        "interaction_setup": setup,
        "training_seconds": train_seconds,
        "jit_seconds": (compile_finished - started)
        if compile_finished is not None
        else float("nan"),
        "evaluation_M0": eval0,
        "evaluation_M2": eval2,
        "gap": gap,
        "gap_standard_error": gap_stderr,
        "gap_variance_proxy": (
            eval0["sample_variance"] + eval2["sample_variance"]
        ),
    }
    (run_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    return result, params


def write_summary(results: list[dict[str, Any]], output_dir: Path) -> None:
    fields = [
        "N",
        "gap",
        "gap_standard_error",
        "E0",
        "E2",
        "variance_E0",
        "variance_E2",
        "gap_variance_proxy",
        "training_seconds",
        "setup_seconds",
        "parameters",
    ]
    rows = []
    for result in results:
        rows.append(
            {
                "N": result["particles"],
                "gap": result["gap"],
                "gap_standard_error": result["gap_standard_error"],
                "E0": result["evaluation_M0"]["energy"],
                "E2": result["evaluation_M2"]["energy"],
                "variance_E0": result["evaluation_M0"]["sample_variance"],
                "variance_E2": result["evaluation_M2"]["sample_variance"],
                "gap_variance_proxy": result["gap_variance_proxy"],
                "training_seconds": result["training_seconds"],
                "setup_seconds": result["interaction_setup"]["setup_seconds"],
                "parameters": result["parameters"],
            }
        )
    with (output_dir / "summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    (output_dir / "summary.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--sizes", type=int, nargs="+", default=[15, 20, 25, 30, 40]
    )
    parser.add_argument("--hidden", type=int, default=64)
    parser.add_argument("--batch", type=int, default=48)
    parser.add_argument("--hops", type=int, default=24)
    parser.add_argument("--steps", type=int, default=2000)
    parser.add_argument("--learning-rate", type=float, default=1.0e-3)
    parser.add_argument("--warmup", type=int, default=100)
    parser.add_argument("--seed", type=int, default=20260729)
    parser.add_argument("--log-every", type=int, default=25)
    parser.add_argument("--eval-batches", type=int, default=12)
    parser.add_argument("--eval-batch", type=int, default=96)
    parser.add_argument("--eval-hops", type=int, default=128)
    parser.add_argument("--grad-clip", type=float, default=5.0)
    parser.add_argument("--ratio-clip", type=float, default=15.0)
    parser.add_argument(
        "--highest-weight-penalty", type=float, default=0.05
    )
    parser.add_argument("--lplus-hops", type=int, default=24)
    parser.add_argument("--eval-lplus-hops", type=int, default=128)
    parser.add_argument(
        "--teacher-path",
        type=Path,
        default=Path("runs/nqs_sparse_N8/final_states.npz"),
    )
    parser.add_argument("--pretrain-steps", type=int, default=3000)
    parser.add_argument("--pretrain-batch", type=int, default=512)
    parser.add_argument("--pretrain-learning-rate", type=float, default=1.0e-3)
    parser.add_argument("--pretrain-phase-weight", type=float, default=2.0)
    parser.add_argument(
        "--load-pretrained-params",
        type=Path,
        default=None,
    )
    parser.add_argument(
        "--no-progressive-transfer",
        action="store_true",
        help="restart every target size from the N=8 teacher weights",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/fock_ar_nqs_N15_N40"),
    )
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=Path("runs/fock_ar_nqs_interaction_cache"),
    )
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--self-test-only", action="store_true")
    parser.add_argument("--skip-self-test", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    print(f"JAX devices: {jax.devices()}", flush=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.skip_self_test:
        test = exact_small_system_test(args.cache_dir, args.seed)
        print("small-system test:", json.dumps(test, indent=2), flush=True)
        (args.output_dir / "self_test.json").write_text(
            json.dumps(test, indent=2), encoding="utf-8"
        )
        if test["pseudopotential_max_error"] > 1.0e-10:
            raise AssertionError("fast Coulomb pseudopotentials failed")
        if test["pair_block_max_error"] > 1.0e-9:
            raise AssertionError("pair interaction blocks failed")
    if args.self_test_only:
        return

    teacher_params = None
    if args.load_pretrained_params is not None:
        loaded = np.load(args.load_pretrained_params)
        teacher_params = {
            name.removeprefix("param__"): jnp.asarray(loaded[name])
            for name in loaded.files
            if name.startswith("param__")
            or name not in {"step", "key"}
        }
    if args.pretrain_steps > 0:
        teacher_params, _ = supervised_teacher_pretrain(
            args.teacher_path,
            args.hidden,
            args.pretrain_steps,
            args.pretrain_batch,
            args.pretrain_learning_rate,
            args.pretrain_phase_weight,
            args.seed,
            args.output_dir,
        )

    results = []
    current_params = teacher_params
    for particles in args.sizes:
        config = TrainConfig(
            particles=particles,
            hidden=args.hidden,
            batch=args.batch,
            hops=args.hops,
            steps=args.steps,
            learning_rate=args.learning_rate,
            warmup=args.warmup,
            seed=args.seed,
            log_every=args.log_every,
            eval_batches=args.eval_batches,
            eval_batch=args.eval_batch,
            eval_hops=args.eval_hops,
            grad_clip=args.grad_clip,
            ratio_clip=args.ratio_clip,
            highest_weight_penalty=args.highest_weight_penalty,
            lplus_hops=args.lplus_hops,
            eval_lplus_hops=args.eval_lplus_hops,
        )
        initial = (
            teacher_params if args.no_progressive_transfer else current_params
        )
        result, current_params = train_one(
            config, args.output_dir, args.cache_dir, args.resume, initial
        )
        results.append(result)
        write_summary(results, args.output_dir)
        print(
            f"completed N={particles}: gap={result['gap']:.8f} "
            f"+/- {result['gap_standard_error']:.3e}",
            flush=True,
        )


if __name__ == "__main__":
    main()
