#!/usr/bin/env python3
"""Strict coordinate tensor NQS with SMA-reference VMC training.

The variational state and exact LLL/SU(2) channels are implemented in
``strict_first_quantized_tensor_nqs_v2``.  This production driver samples the
fixed SMA only as an importance distribution.  The final coefficients remain
free and are optimized by the VMC linear method from weighted overlap and
Hamiltonian matrices.  An independent SMA-reference validation set is used
for the reported energy.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict
from pathlib import Path

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np

from chiral_graviton_nqs_scaling_gpu import (
    potential_energy,
    random_spinors,
    run_excited_sweeps,
    tensor_components,
)
from strict_first_quantized_tensor_nqs import (
    Result,
    collect_laughlin_samples,
    parse_sizes,
    solve_linear_method,
)
from strict_first_quantized_tensor_nqs_v2 import make_feature_function


def collect_sma_samples(
    particles: int,
    chains: int,
    burn_sweeps: int,
    records: int,
    thin_sweeps: int,
    initial_scale: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, float]:
    key = jax.random.PRNGKey(seed + 2017 * particles)
    key, initial_key = jax.random.split(key)
    spinors = random_spinors(initial_key, chains, particles)
    first, second, ratio = tensor_components(spinors)
    scale = initial_scale / math.sqrt(particles)
    remaining = burn_sweeps
    while remaining:
        block = min(25, remaining)
        spinors, key, first, second, ratio, acceptance = (
            run_excited_sweeps(
                spinors,
                key,
                jnp.asarray(scale),
                first,
                second,
                ratio,
                count=block,
            )
        )
        acceptance_value = float(jax.device_get(acceptance))
        scale *= math.exp(0.6 * (acceptance_value - 0.40))
        scale = float(np.clip(scale, 0.003, 0.8))
        remaining -= block

    coordinates = []
    potentials = []
    acceptances = []
    two_q = 3 * (particles - 1)
    for _ in range(records):
        spinors, key, first, second, ratio, acceptance = (
            run_excited_sweeps(
                spinors,
                key,
                jnp.asarray(scale),
                first,
                second,
                ratio,
                count=thin_sweeps,
            )
        )
        coordinates.append(np.asarray(jax.device_get(spinors)))
        potentials.append(
            np.asarray(jax.device_get(potential_energy(spinors, two_q)))
        )
        acceptances.append(float(jax.device_get(acceptance)))
    return (
        np.concatenate(coordinates, axis=0),
        np.concatenate(potentials, axis=0),
        float(np.mean(acceptances)),
    )


def estimate_weighted_matrices(
    features: np.ndarray, potential: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    reference = np.maximum(np.square(np.abs(features[:, 0])), 1.0e-300)
    reduced = features / np.sqrt(reference)[:, None]
    overlap = reduced.conj().T @ reduced / len(features)
    hamiltonian = reduced.conj().T @ (
        potential[:, None] * reduced
    ) / len(features)
    return (
        0.5 * (overlap + overlap.conj().T),
        0.5 * (hamiltonian + hamiltonian.conj().T),
    )


def reference_weighted_statistics(
    features: np.ndarray,
    potential: np.ndarray,
    coefficients: np.ndarray,
    chains: int,
    records: int,
) -> tuple[float, float, float, float]:
    reference = np.maximum(np.square(np.abs(features[:, 0])), 1.0e-300)
    amplitude = features @ coefficients
    weight = np.square(np.abs(amplitude)) / reference
    total = float(np.sum(weight))
    energy = float(np.sum(weight * potential) / total)
    ess = total**2 / float(np.sum(np.square(weight)))
    weights_by_record = weight.reshape(records, chains)
    energy_by_record = potential.reshape(records, chains)
    chain_weight = np.sum(weights_by_record, axis=0)
    chain_energy = np.sum(
        weights_by_record * energy_by_record, axis=0
    ) / np.maximum(chain_weight, 1.0e-300)
    stderr = float(np.std(chain_energy, ddof=1) / math.sqrt(chains))
    return energy, stderr, ess, ess / len(weight)


def estimate_one_size(arguments: argparse.Namespace, particles: int) -> Result:
    start_time = time.perf_counter()
    feature_function, labels = make_feature_function(particles, arguments.lmax)
    coordinates, excited_potential, excited_acceptance = collect_sma_samples(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        arguments.seed,
    )
    _, ground_potential, ground_acceptance = collect_laughlin_samples(
        particles,
        arguments.chains,
        arguments.burn_sweeps,
        arguments.records - arguments.training_records,
        arguments.thin_sweeps,
        arguments.initial_scale,
        arguments.seed + 7919,
    )
    split = arguments.training_records * arguments.chains

    def evaluate(coordinates_host: np.ndarray) -> np.ndarray:
        batches = []
        for start in range(0, len(coordinates_host), arguments.feature_batch):
            batch = jnp.asarray(
                coordinates_host[start : start + arguments.feature_batch]
            )
            batches.append(
                np.asarray(jax.device_get(feature_function(batch)))
            )
        return np.concatenate(batches, axis=0)

    training_features = evaluate(coordinates[:split])
    validation_features = evaluate(coordinates[split:])
    training_potential = excited_potential[:split]
    validation_potential = excited_potential[split:]
    scales = np.sqrt(
        np.maximum(
            np.mean(np.square(np.abs(training_features)), axis=0), 1.0e-30
        )
    )
    training_features /= scales[None, :]
    validation_features /= scales[None, :]
    overlap, hamiltonian = estimate_weighted_matrices(
        training_features, training_potential
    )
    _, coefficients, retained_rank = solve_linear_method(
        overlap, hamiltonian, arguments.whitening_tolerance
    )
    training_energy, _, training_ess, training_fraction = (
        reference_weighted_statistics(
            training_features,
            training_potential,
            coefficients,
            arguments.chains,
            arguments.training_records,
        )
    )
    excited_energy, excited_stderr, validation_ess, validation_fraction = (
        reference_weighted_statistics(
            validation_features,
            validation_potential,
            coefficients,
            arguments.chains,
            arguments.records - arguments.training_records,
        )
    )
    validation_records = arguments.records - arguments.training_records
    ground_matrix = ground_potential.reshape(
        validation_records, arguments.chains
    )
    ground_by_chain = np.mean(ground_matrix, axis=0)
    ground_energy = float(np.mean(ground_by_chain))
    ground_stderr = float(
        np.std(ground_by_chain, ddof=1) / math.sqrt(arguments.chains)
    )
    result = Result(
        particles=particles,
        two_q=3 * (particles - 1),
        lmax=arguments.lmax,
        raw_channels=len(labels),
        retained_rank=retained_rank,
        ground_energy=ground_energy,
        excited_energy=excited_energy,
        gap=excited_energy - ground_energy,
        ground_stderr=ground_stderr,
        excited_stderr=excited_stderr,
        gap_stderr=math.hypot(ground_stderr, excited_stderr),
        training_ess=training_ess,
        training_ess_fraction=training_fraction,
        validation_ess=validation_ess,
        validation_ess_fraction=validation_fraction,
        acceptance=0.5 * (ground_acceptance + excited_acceptance),
        coefficients_real=np.real(coefficients / scales).tolist(),
        coefficients_imag=np.imag(coefficients / scales).tolist(),
        channel_labels=labels,
        runtime_seconds=time.perf_counter() - start_time,
    )
    print(
        f"N={particles} channels={retained_rank}/{len(labels)} "
        f"E2(train)={training_energy:.9f} "
        f"E2(valid)={excited_energy:.9f} "
        f"gap={result.gap:.9f}+/-{result.gap_stderr:.2e} "
        f"ESS(valid)={validation_fraction:.3f} "
        f"time={result.runtime_seconds:.1f}s",
        flush=True,
    )
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="8")
    parser.add_argument("--lmax", type=int, choices=(2, 3, 4), default=4)
    parser.add_argument("--chains", type=int, default=256)
    parser.add_argument("--burn-sweeps", type=int, default=500)
    parser.add_argument("--records", type=int, default=64)
    parser.add_argument("--training-records", type=int, default=32)
    parser.add_argument("--thin-sweeps", type=int, default=5)
    parser.add_argument("--feature-batch", type=int, default=64)
    parser.add_argument("--initial-scale", type=float, default=0.9)
    parser.add_argument("--whitening-tolerance", type=float, default=1.0e-7)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runs/strict_first_quantized_tensor_nqs_v3"),
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_args()
    if not 0 < arguments.training_records < arguments.records:
        raise ValueError("training-records must be between 0 and records")
    sizes = parse_sizes(arguments.sizes)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        f"strict coordinate tensor-NQS VMC/SR with SMA reference: "
        f"sizes={sizes}, lmax={arguments.lmax}",
        flush=True,
    )
    results = [estimate_one_size(arguments, particles) for particles in sizes]
    payload = {
        "method": (
            "strict first-quantized LLL-SU(2) multi-channel tensor NQS; "
            "SMA-reference VMC linear method/SR"
        ),
        "important_distinction": (
            "SMA is only the sampling reference; all retained channel "
            "coefficients are variationally optimized"
        ),
        "symmetry": {
            "ground_L2": 0.0,
            "excited_L2": 6.0,
            "status": "exact by CG irreducible-tensor construction",
        },
        "devices": [str(device) for device in jax.devices()],
        "arguments": {
            **vars(arguments),
            "output_dir": str(arguments.output_dir),
        },
        "results": [asdict(result) for result in results],
    }
    (arguments.output_dir / "results.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    scalar_fields = [
        key
        for key in asdict(results[0])
        if key
        not in ("coefficients_real", "coefficients_imag", "channel_labels")
    ]
    with (arguments.output_dir / "results.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=scalar_fields)
        writer.writeheader()
        for result in results:
            row = asdict(result)
            writer.writerow({key: row[key] for key in scalar_fields})
    print(f"wrote {arguments.output_dir.resolve()}", flush=True)


if __name__ == "__main__":
    main()
