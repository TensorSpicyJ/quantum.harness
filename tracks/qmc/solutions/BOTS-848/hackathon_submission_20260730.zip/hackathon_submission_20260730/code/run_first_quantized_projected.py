#!/usr/bin/env python3
"""Run coordinate VMC from a symmetry-subspace Rayleigh-Ritz pretraining."""

from __future__ import annotations

import numpy as np

import chiral_graviton_first_quantized_nqs as fq
from chiral_graviton_nqs_vmc_v2 import projected_ground_state, whiten_features


def projected_initialization(
    compiled: fq.CompiledSystem,
    channel_rank: int,
    seed: int,
) -> dict[str, np.ndarray]:
    """Factor the optimal full-channel state into a rank-R tensor head."""

    del seed
    _, ground_coordinates, _ = projected_ground_state(
        compiled.H0, compiled.scalar_features
    )
    flat = compiled.tensor_features2.reshape(
        compiled.tensor_features2.shape[0], -1
    )
    white, raw_to_white, _ = whiten_features(flat)
    _, white_coordinates, _ = projected_ground_state(compiled.H2, white)
    raw_coordinates = raw_to_white @ white_coordinates
    channel_matrix = raw_coordinates.reshape(
        len(compiled.tensor_terms), compiled.scalar_features.shape[1]
    )
    left_singular, singular_values, right_singular = np.linalg.svd(
        channel_matrix, full_matrices=False
    )
    retained = min(channel_rank, len(singular_values))
    root = np.sqrt(singular_values[:retained])
    left = left_singular[:, :retained] * root[None, :]
    right = root[:, None] * right_singular[:retained, :]
    if retained < channel_rank:
        left = np.pad(left, ((0, 0), (0, channel_rank - retained)))
        right = np.pad(right, ((0, channel_rank - retained), (0, 0)))
    return {
        "ground": ground_coordinates / np.linalg.norm(ground_coordinates),
        "tensor_left": left,
        "tensor_right": right,
    }


if __name__ == "__main__":
    fq.initialize_parameters = projected_initialization
    fq.main()
