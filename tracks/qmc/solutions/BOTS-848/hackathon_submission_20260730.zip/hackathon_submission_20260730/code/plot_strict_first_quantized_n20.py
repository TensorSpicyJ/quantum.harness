#!/usr/bin/env python3
"""Create the benchmark figure used by the N=20 streaming NQS report."""

from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    figure, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))

    sizes = np.asarray([8, 9, 10, 12, 16, 20])
    gaps = np.asarray(
        [
            0.1284480242,
            0.1394800090,
            0.1303662544,
            0.1304005589,
            0.1411956707,
            0.1447242520,
        ]
    )
    errors = np.asarray(
        [
            0.0036739829,
            0.0054771813,
            0.0043148782,
            0.0066714903,
            0.0057615430,
            0.002591,
        ]
    )
    axes[0].errorbar(
        sizes,
        gaps,
        yerr=errors,
        fmt="o-",
        capsize=3,
        color="#0068b5",
        label="trained strict first-quantized NQS",
    )
    axes[0].set_xlabel("particle number N")
    axes[0].set_ylabel(r"$\Delta_{L=2}=E_2-E_0$")
    axes[0].set_xticks(sizes)
    axes[0].grid(alpha=0.25)
    axes[0].legend(frameon=False, fontsize=8)

    lmax = np.asarray([4, 5, 6])
    lmax_gap = np.asarray([0.146359173, 0.144724252, 0.139864836])
    lmax_error = np.asarray([0.003773, 0.002591, 0.0060808])
    ess = np.asarray([0.912, 0.755, 0.454])
    axes[1].errorbar(
        lmax,
        lmax_gap,
        yerr=lmax_error,
        fmt="o-",
        capsize=3,
        color="#b14623",
        label="gap",
    )
    axes[1].set_xlabel(r"tensor cutoff $\ell_{\max}$ at N=20")
    axes[1].set_ylabel(r"$\Delta_{L=2}$", color="#b14623")
    axes[1].tick_params(axis="y", labelcolor="#b14623")
    axes[1].set_xticks(lmax)
    axes[1].grid(alpha=0.25)
    twin = axes[1].twinx()
    twin.plot(
        lmax,
        ess,
        "s--",
        color="#268238",
        label="excited validation ESS fraction",
    )
    twin.set_ylabel("ESS fraction", color="#268238")
    twin.tick_params(axis="y", labelcolor="#268238")
    twin.set_ylim(0.35, 1.0)

    figure.suptitle(
        "Strict first-quantized LLL/SU(2) NQS on local RTX 4090 Laptop GPU"
    )
    figure.tight_layout()
    figure.savefig(
        "runs/strict_fq_streaming_n20_benchmark.png",
        dpi=180,
        bbox_inches="tight",
    )


if __name__ == "__main__":
    main()
