#!/usr/bin/env python3
"""Memory-scalable strict first-quantized LLL--SU(2) tensor features.

This module is algebraically equivalent to the polynomial implementation in
``strict_first_quantized_tensor_nqs_v2``.  The important difference is that a
two-electron polynomial is never materialized as a dense ``(2Q+1)^2`` array.
For a pair ``i,j`` the Laughlin polynomial factorizes into four shifted outer
products.  Tensor contractions are therefore evaluated from four pairs of
one-dimensional contractions.  Exclusion polynomials are built with
``lax.fori_loop`` so XLA does not receive an O(N^3) Python-unrolled graph.
"""

from __future__ import annotations

import math
from typing import Callable

import jax

jax.config.update("jax_enable_x64", True)

import jax.numpy as jnp
import numpy as np

from chiral_graviton_ed import clebsch_gordan2
from strict_first_quantized_tensor_nqs_v2 import (
    channel_specifications,
    monomial_tensor_matrices,
    monomial_values,
    safe_complex,
)


Array = jax.Array


def _convolve_fixed(coefficients: Array, factor: Array) -> Array:
    """Convolve into a fixed-size buffer, discarding only known-zero tails."""

    result = jnp.zeros_like(coefficients)
    length = coefficients.shape[0]
    for shift in range(4):
        result = result.at[shift:].add(
            factor[shift] * coefficients[: length - shift]
        )
    return result


def _cubic_factor(spinor: Array) -> Array:
    u, v = spinor
    return jnp.stack(
        (
            v**3,
            -3.0 * v**2 * u,
            3.0 * v * u**2,
            -(u**3),
        )
    )


def _exclusion_polynomial(
    spinors: Array, first: Array, second: Array, length: int
) -> Array:
    """Product of all cubic factors except ``first`` and ``second``.

    Passing the same index twice excludes one particle.  The loop body is
    constant-size and remains compact when N grows.
    """

    initial = jnp.zeros((length,), dtype=spinors.dtype)
    initial = initial.at[0].set(1.0 + 0.0j)

    def body(index: int, coefficients: Array) -> Array:
        include = (index != first) & (index != second)
        return jax.lax.cond(
            include,
            lambda value: _convolve_fixed(
                value, _cubic_factor(spinors[index])
            ),
            lambda value: value,
            coefficients,
        )

    return jax.lax.fori_loop(0, spinors.shape[0], body, initial)


def _shifted_contractions(
    row: Array, pair_coefficients: Array
) -> Array:
    """Return row @ shift_s(pair_coefficients), s=0..3."""

    base_length = pair_coefficients.shape[-1]
    return jnp.stack(
        [
            jnp.sum(
                row[..., shift : shift + base_length]
                * pair_coefficients,
                axis=-1,
            )
            for shift in range(4)
        ],
        axis=-1,
    )


def _pair_contraction(
    left_matrix: Array,
    right_matrix: Array,
    basis: Array,
    pair_coefficients: Array,
    pair_first: Array,
    pair_second: Array,
    pair_denominator: Array,
) -> Array:
    """Sum ordered i<j contractions with left on i and right on j."""

    left_rows = basis[pair_first] @ left_matrix
    right_rows = basis[pair_second] @ right_matrix
    left_values = _shifted_contractions(left_rows, pair_coefficients)
    right_values = _shifted_contractions(right_rows, pair_coefficients)
    cubic_coefficients = jnp.asarray(
        [1.0, -3.0, 3.0, -1.0], dtype=basis.dtype
    )
    numerator = jnp.sum(
        cubic_coefficients[None, :]
        * left_values
        * right_values[:, ::-1],
        axis=1,
    )
    return jnp.sum(numerator / pair_denominator)


def _coordinate_workspace(
    spinors: Array, particles: int
) -> tuple[Array, Array, Array, Array, Array, Array]:
    degree = 3 * (particles - 1)
    pair_length = degree - 2
    basis = jax.vmap(lambda value: monomial_values(value, degree))(spinors)
    particle_indices = jnp.arange(particles, dtype=jnp.int32)
    singles = jax.vmap(
        lambda index: _exclusion_polynomial(
            spinors, index, index, degree + 1
        )
    )(particle_indices)
    single_denominator = safe_complex(
        jnp.einsum("nd,nd->n", basis, singles)
    )

    first_host, second_host = np.triu_indices(particles, k=1)
    pair_first = jnp.asarray(first_host, dtype=jnp.int32)
    pair_second = jnp.asarray(second_host, dtype=jnp.int32)
    pair_coefficients = jax.vmap(
        lambda first, second: _exclusion_polynomial(
            spinors, first, second, pair_length
        )
    )(pair_first, pair_second)
    identity_left = _shifted_contractions(
        basis[pair_first], pair_coefficients
    )
    identity_right = _shifted_contractions(
        basis[pair_second], pair_coefficients
    )
    cubic_coefficients = jnp.asarray(
        [1.0, -3.0, 3.0, -1.0], dtype=spinors.dtype
    )
    pair_denominator = safe_complex(
        jnp.sum(
            cubic_coefficients[None, :]
            * identity_left
            * identity_right[:, ::-1],
            axis=1,
        )
    )
    return (
        basis,
        singles,
        single_denominator,
        pair_coefficients,
        pair_first,
        pair_second,
        pair_denominator,
    )


def _coupled_density_value(
    left_matrix: Array,
    right_matrix: Array,
    basis: Array,
    singles: Array,
    single_denominator: Array,
    pair_coefficients: Array,
    pair_first: Array,
    pair_second: Array,
    pair_denominator: Array,
) -> Array:
    same = jnp.sum(
        jnp.einsum(
            "nd,de,ef,nf->n",
            basis,
            left_matrix,
            right_matrix,
            singles,
        )
        / single_denominator
    )
    different = _pair_contraction(
        left_matrix,
        right_matrix,
        basis,
        pair_coefficients,
        pair_first,
        pair_second,
        pair_denominator,
    )
    different += _pair_contraction(
        right_matrix,
        left_matrix,
        basis,
        pair_coefficients,
        pair_first,
        pair_second,
        pair_denominator,
    )
    return same + different


def _tensor_constants(
    particles: int, lmax: int
) -> tuple[dict[tuple[int, int], Array], list[tuple[int, int] | None]]:
    degree = 3 * (particles - 1)
    tensors = {
        key: jnp.asarray(value, dtype=jnp.complex128)
        for key, value in monomial_tensor_matrices(degree, lmax).items()
    }
    return tensors, channel_specifications(lmax)


def make_streaming_tensor_feature_function(
    particles: int, lmax: int
) -> tuple[Callable[[Array], Array], list[str]]:
    """Rank-2 strict SU(2) channels, with exactly the v2 normalization."""

    tensors, specifications = _tensor_constants(particles, lmax)
    labels = ["rho_2"]
    labels.extend(
        f"[rho_{left}xr_{right}]_2"
        for left, right in specifications[1:]
    )

    def one(spinors: Array) -> Array:
        (
            basis,
            singles,
            single_denominator,
            pair_coefficients,
            pair_first,
            pair_second,
            pair_denominator,
        ) = _coordinate_workspace(spinors, particles)
        rho22 = tensors[(2, 2)]
        linear = jnp.sum(
            jnp.einsum("nd,de,ne->n", basis, rho22, singles)
            / single_denominator
        )
        features = [linear]
        for specification in specifications[1:]:
            assert specification is not None
            left, right = specification
            coupled = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
            for m_left in range(-left, left + 1):
                m_right = 2 - m_left
                if abs(m_right) > right:
                    continue
                cg = clebsch_gordan2(
                    2 * left,
                    2 * m_left,
                    2 * right,
                    2 * m_right,
                    4,
                    4,
                )
                if abs(cg) < 1.0e-14:
                    continue
                coupled += cg * _coupled_density_value(
                    tensors[(left, m_left)],
                    tensors[(right, m_right)],
                    basis,
                    singles,
                    single_denominator,
                    pair_coefficients,
                    pair_first,
                    pair_second,
                    pair_denominator,
                )
            features.append(coupled)
        return jnp.stack(features)

    return jax.jit(jax.vmap(one)), labels


def make_streaming_scalar_feature_function(
    particles: int, lmax: int
) -> tuple[Callable[[Array], Array], list[str]]:
    """Strict L=0 identity plus coupled two-density scalar channels."""

    tensors, _ = _tensor_constants(particles, lmax)
    labels = ["identity"] + [
        f"[rho_{ell}xr_{ell}]_0" for ell in range(2, lmax + 1)
    ]

    def one(spinors: Array) -> Array:
        (
            basis,
            singles,
            single_denominator,
            pair_coefficients,
            pair_first,
            pair_second,
            pair_denominator,
        ) = _coordinate_workspace(spinors, particles)
        features = [jnp.asarray(1.0 + 0.0j, dtype=spinors.dtype)]
        for ell in range(2, lmax + 1):
            scalar = jnp.asarray(0.0 + 0.0j, dtype=spinors.dtype)
            for m in range(-ell, ell + 1):
                cg = clebsch_gordan2(
                    2 * ell, 2 * m, 2 * ell, -2 * m, 0, 0
                )
                if abs(cg) < 1.0e-14:
                    continue
                scalar += cg * _coupled_density_value(
                    tensors[(ell, m)],
                    tensors[(ell, -m)],
                    basis,
                    singles,
                    single_denominator,
                    pair_coefficients,
                    pair_first,
                    pair_second,
                    pair_denominator,
                )
            features.append(scalar)
        return jnp.stack(features)

    return jax.jit(jax.vmap(one)), labels

