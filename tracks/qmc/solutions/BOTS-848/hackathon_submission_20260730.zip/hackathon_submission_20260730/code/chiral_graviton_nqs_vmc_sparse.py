#!/usr/bin/env python3
"""Sparse large-system extension of the symmetry-exact tensor NQS.

The ansatz is the V2 model from ``chiral_graviton_nqs_vmc_v2.py``:

* an L=0 two-layer scalar density-tensor backbone;
* full multiplicity-channel mixing for the L=2 tensor head;
* one SVD-whitened parameter set shared by all M=-2,...,2 components.

Unlike the dense benchmark, this file never forms dense many-body operators.
Fock bases are generated with sum pruning, one-body density tensors and the
Coulomb Hamiltonian are CSR sparse matrices, and scalar/tensor operator
products are applied directly to thin feature matrices.  GPU VMC uses JAX
BCOO sparse matvecs.  The remaining non-scalable ingredient is the explicit
fixed-M basis and a sparse V1 eigensolve used to prepare the Laughlin seed.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import LinearOperator, eigsh

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import optax
from jax.experimental import sparse as jsparse

from chiral_graviton_ed import (
    _annihilate,
    _create,
    antisymmetric_pair_matrix,
    apply_pair_operator,
    clebsch_gordan2,
    interaction_pseudopotentials,
    orbital_two_m,
)
from chiral_graviton_nqs_vmc import TensorHeadTerm
from chiral_graviton_nqs_vmc_v2 import (
    tensor_head_terms,
    whiten_features,
)


jax.config.update("jax_enable_x64", True)

Array = np.ndarray
SparseMatrix = sparse.csr_matrix


def pruned_fock_basis(
    particles: int, two_q: int, M: int
) -> tuple[int, ...]:
    """Generate fixed-N, fixed-M bitstrings without scanning C(Norb,N)."""

    values = orbital_two_m(two_q)
    target = 2 * M
    result: list[int] = []
    norbitals = len(values)

    def recurse(
        start: int, left: int, remaining_sum: int, state: int
    ) -> None:
        if left == 0:
            if remaining_sum == 0:
                result.append(state)
            return
        if norbitals - start < left:
            return
        minimum = sum(values[start : start + left])
        maximum = sum(values[norbitals - left :])
        if remaining_sum < minimum or remaining_sum > maximum:
            return
        final_start = norbitals - left
        for orbital in range(start, final_start + 1):
            next_left = left - 1
            next_sum = remaining_sum - values[orbital]
            if next_left:
                next_minimum = sum(
                    values[orbital + 1 : orbital + 1 + next_left]
                )
                next_maximum = sum(values[norbitals - next_left :])
                if next_sum < next_minimum or next_sum > next_maximum:
                    continue
            elif next_sum != 0:
                continue
            recurse(
                orbital + 1,
                next_left,
                next_sum,
                state | (1 << orbital),
            )

    recurse(0, particles, target, 0)
    return tuple(result)


class SparseSectorCache:
    """Sparse fixed-M bases and LLL projected-density tensors."""

    def __init__(self, particles: int, two_q: int):
        self.particles = particles
        self.two_q = two_q
        self._bases: dict[int, tuple[int, ...]] = {}
        self._indices: dict[int, dict[int, int]] = {}
        self._rho: dict[tuple[int, int, int], SparseMatrix] = {}

    def basis(self, M: int) -> tuple[int, ...]:
        if M not in self._bases:
            self._bases[M] = pruned_fock_basis(
                self.particles, self.two_q, M
            )
        return self._bases[M]

    def index(self, M: int) -> dict[int, int]:
        if M not in self._indices:
            self._indices[M] = {
                state: index
                for index, state in enumerate(self.basis(M))
            }
        return self._indices[M]

    def rho(self, source_M: int, ell: int, m: int) -> SparseMatrix:
        key = (source_M, ell, m)
        if key in self._rho:
            return self._rho[key]
        source = self.basis(source_M)
        target = self.basis(source_M + m)
        target_index = self.index(source_M + m)
        rows: list[int] = []
        columns: list[int] = []
        data: list[float] = []
        for ket_index, state in enumerate(source):
            for orbital1 in range(self.two_q + 1):
                if not ((state >> orbital1) & 1):
                    continue
                tm1 = -self.two_q + 2 * orbital1
                tm2 = tm1 + 2 * m
                if tm2 < -self.two_q or tm2 > self.two_q:
                    continue
                orbital2 = (tm2 + self.two_q) // 2
                cg = clebsch_gordan2(
                    self.two_q,
                    tm2,
                    self.two_q,
                    -tm1,
                    2 * ell,
                    2 * m,
                )
                if abs(cg) < 1.0e-15:
                    continue
                first = _annihilate(state, orbital1)
                assert first is not None
                intermediate, sign1 = first
                second = _create(intermediate, orbital2)
                if second is None:
                    continue
                final_state, sign2 = second
                bra_index = target_index.get(final_state)
                if bra_index is None:
                    continue
                phase = (
                    -1.0
                    if ((self.two_q - tm1) // 2) % 2
                    else 1.0
                )
                rows.append(bra_index)
                columns.append(ket_index)
                data.append(phase * cg * sign1 * sign2)
        matrix = sparse.coo_matrix(
            (data, (rows, columns)),
            shape=(len(target), len(source)),
            dtype=np.float64,
        ).tocsr()
        matrix.eliminate_zeros()
        self._rho[key] = matrix
        return matrix


def apply_scalar(
    cache: SparseSectorCache, ell: int, vectors: Array
) -> Array:
    """Apply [rho_ell tensor rho_ell]_(0,0) without forming it."""

    result = np.zeros_like(vectors)
    for m in range(-ell, ell + 1):
        cg = clebsch_gordan2(
            2 * ell, 2 * m, 2 * ell, -2 * m, 0, 0
        )
        if abs(cg) < 1.0e-15:
            continue
        result += (
            cg
            * (
                cache.rho(-m, ell, m)
                @ (cache.rho(0, ell, -m) @ vectors)
            )
        )
    return result


def apply_rank2(
    cache: SparseSectorCache,
    term: TensorHeadTerm,
    M: int,
    vectors: Array,
) -> Array:
    """Apply one rank-2 tensor channel to M=0 thin vectors."""

    if term.linear:
        return cache.rho(0, 2, M) @ vectors
    result = np.zeros((len(cache.basis(M)), vectors.shape[1]))
    for m1 in range(-term.l1, term.l1 + 1):
        m2 = M - m1
        if abs(m2) > term.l2:
            continue
        cg = clebsch_gordan2(
            2 * term.l1,
            2 * m1,
            2 * term.l2,
            2 * m2,
            4,
            2 * M,
        )
        if abs(cg) < 1.0e-15:
            continue
        result += (
            cg
            * (
                cache.rho(m2, term.l1, m1)
                @ (cache.rho(0, term.l2, m2) @ vectors)
            )
        )
    return result


def sparse_many_body_hamiltonian(
    basis: tuple[int, ...],
    pairs: tuple[tuple[int, int], ...],
    pair_matrix: Array,
    two_q: int,
    column_chunk_size: int = 1024,
    progress_label: str = "H",
) -> SparseMatrix:
    """Assemble the fixed-M two-body Hamiltonian as CSR in column chunks.

    Chunking is essential beyond N=9: retaining Python ``row``, ``column``,
    and ``data`` objects for every nonzero costs much more memory than the
    final NumPy/SciPy arrays.
    """

    index = {state: i for i, state in enumerate(basis)}
    pair_to_index = {pair: i for i, pair in enumerate(pairs)}
    threshold = 1.0e-15
    transitions: list[list[tuple[int, float]]] = []
    for source_pair in range(len(pairs)):
        target_pairs = np.flatnonzero(
            np.abs(pair_matrix[:, source_pair]) > threshold
        )
        transitions.append(
            [
                (int(target_pair), float(pair_matrix[target_pair, source_pair]))
                for target_pair in target_pairs
            ]
        )

    dimension = len(basis)
    column_chunk_size = max(1, int(column_chunk_size))
    chunks: list[SparseMatrix] = []
    next_progress = 0.1
    build_start = time.perf_counter()
    raw_nnz = 0
    for chunk_start in range(0, dimension, column_chunk_size):
        chunk_stop = min(chunk_start + column_chunk_size, dimension)
        row_indices: list[int] = []
        data: list[float] = []
        indptr = [0]
        for ket_index in range(chunk_start, chunk_stop):
            state = basis[ket_index]
            occupied = [
                orbital
                for orbital in range(two_q + 1)
                if (state >> orbital) & 1
            ]
            for first_index in range(len(occupied)):
                for second_index in range(first_index + 1, len(occupied)):
                    c = occupied[first_index]
                    d = occupied[second_index]
                    source_pair = pair_to_index[(c, d)]
                    for target_pair, element in transitions[source_pair]:
                        a, b = pairs[target_pair]
                        applied = apply_pair_operator(state, a, b, c, d)
                        if applied is None:
                            continue
                        final_state, sign = applied
                        bra_index = index.get(final_state)
                        if bra_index is None:
                            continue
                        row_indices.append(bra_index)
                        data.append(sign * element)
            indptr.append(len(data))
        chunk = sparse.csc_matrix(
            (
                np.asarray(data, dtype=np.float64),
                np.asarray(row_indices, dtype=np.int32),
                np.asarray(indptr, dtype=np.int64),
            ),
            shape=(dimension, chunk_stop - chunk_start),
        )
        chunk.sum_duplicates()
        chunk.eliminate_zeros()
        chunks.append(chunk)
        raw_nnz += chunk.nnz
        fraction = chunk_stop / dimension
        if fraction >= next_progress or chunk_stop == dimension:
            print(
                f"{progress_label} build: {chunk_stop}/{dimension} "
                f"columns ({100.0*fraction:.0f}%), "
                f"raw nnz={raw_nnz}, "
                f"elapsed={time.perf_counter()-build_start:.1f}s",
                flush=True,
            )
            next_progress += 0.1
    matrix = sparse.hstack(chunks, format="csr")
    del chunks
    matrix = 0.5 * (matrix + matrix.T)
    matrix.eliminate_zeros()
    return matrix.tocsr()


def cached_hamiltonian(
    path: Path,
    basis: tuple[int, ...],
    pairs: tuple[tuple[int, int], ...],
    pair_matrix: Array,
    two_q: int,
    column_chunk_size: int,
    label: str,
) -> SparseMatrix:
    """Load a validated CSR cache or build and atomically publish it."""

    if path.exists():
        matrix = sparse.load_npz(path).tocsr()
        expected = (len(basis), len(basis))
        if matrix.shape != expected:
            raise RuntimeError(
                f"cache {path} has shape {matrix.shape}, expected {expected}"
            )
        print(
            f"loaded {label} cache: {path} (nnz={matrix.nnz})",
            flush=True,
        )
        return matrix
    matrix = sparse_many_body_hamiltonian(
        basis,
        pairs,
        pair_matrix,
        two_q,
        column_chunk_size=column_chunk_size,
        progress_label=label,
    )
    temporary = path.with_suffix(".tmp.npz")
    sparse.save_npz(temporary, matrix, compressed=True)
    temporary.replace(path)
    print(f"saved {label} cache: {path}", flush=True)
    return matrix

def sparse_raising_operator(
    cache: SparseSectorCache, source_M: int
) -> SparseMatrix:
    source = cache.basis(source_M)
    target = cache.basis(source_M + 1)
    target_index = cache.index(source_M + 1)
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    for source_index, state in enumerate(source):
        for orbital in range(cache.two_q):
            if not ((state >> orbital) & 1):
                continue
            if (state >> (orbital + 1)) & 1:
                continue
            first = _annihilate(state, orbital)
            assert first is not None
            intermediate, sign1 = first
            second = _create(intermediate, orbital + 1)
            assert second is not None
            final_state, sign2 = second
            coefficient = math.sqrt(
                (cache.two_q - orbital) * (orbital + 1)
            )
            rows.append(target_index[final_state])
            columns.append(source_index)
            data.append(sign1 * sign2 * coefficient)
    return sparse.coo_matrix(
        (data, (rows, columns)),
        shape=(len(target), len(source)),
        dtype=np.float64,
    ).tocsr()


def apply_l2(
    cache: SparseSectorCache, M: int, vector: Array
) -> Array:
    raising = sparse_raising_operator(cache, M)
    return raising.T @ (raising @ vector) + M * (M + 1) * vector


def sparse_observables(
    psi: Array,
    H: SparseMatrix,
    cache: SparseSectorCache,
    M: int,
) -> dict[str, float]:
    norm = float(np.vdot(psi, psi).real)
    hpsi = H @ psi
    l2psi = apply_l2(cache, M, psi)
    energy = float(np.vdot(psi, hpsi).real / norm)
    l2 = float(np.vdot(psi, l2psi).real / norm)
    return {
        "energy": energy,
        "energy_variance": max(
            0.0, float(np.vdot(hpsi, hpsi).real / norm - energy**2)
        ),
        "L2": l2,
        "L2_variance": max(
            0.0, float(np.vdot(l2psi, l2psi).real / norm - l2**2)
        ),
    }


def projected_state(
    H: SparseMatrix, features: Array
) -> tuple[float, Array, Array]:
    projected = features.T @ (H @ features)
    projected = 0.5 * (projected + projected.T)
    energies, vectors = np.linalg.eigh(projected)
    coefficients = vectors[:, 0]
    return float(energies[0]), coefficients, features @ coefficients


def build_scalar_features(
    cache: SparseSectorCache,
    seed: Array,
    lmax: int,
    depth: int,
) -> tuple[Array, dict[str, object]]:
    depth1 = {
        ell: apply_scalar(cache, ell, seed[:, None])[:, 0]
        for ell in range(2, lmax + 1)
    }
    columns = [seed] + list(depth1.values())
    if depth >= 2:
        for left in range(2, lmax + 1):
            for right in range(2, lmax + 1):
                columns.append(
                    apply_scalar(
                        cache, left, depth1[right][:, None]
                    )[:, 0]
                )
    raw = np.column_stack(columns)
    features, _, diagnostics = whiten_features(
        raw, relative_tolerance=1.0e-9
    )
    return features, diagnostics


def raw_excited_features(
    cache: SparseSectorCache,
    ground_features: Array,
    terms: list[TensorHeadTerm],
    M: int,
) -> Array:
    return np.column_stack(
        [
            apply_rank2(cache, term, M, ground_features)
            for term in terms
        ]
    )


def scipy_to_bcoo(matrix: SparseMatrix) -> jsparse.BCSR:
    """Transfer CSR directly, avoiding the large temporary COO row array."""

    matrix = matrix.tocsr(copy=False)
    return jsparse.BCSR(
        (
            jnp.asarray(matrix.data),
            jnp.asarray(matrix.indices, dtype=jnp.int32),
            jnp.asarray(matrix.indptr, dtype=jnp.int32),
        ),
        shape=matrix.shape,
    )

def make_sparse_vmc_step(
    ground_features: jax.Array,
    excited_features: jax.Array,
    H0: jsparse.BCOO,
    H2: jsparse.BCOO,
    samples: int,
    optimizer: optax.GradientTransformation,
) -> Callable:
    def surrogate(
        psi: jax.Array, H: jsparse.BCOO, key: jax.Array
    ) -> tuple[jax.Array, tuple[jax.Array, jax.Array]]:
        probability = jnp.square(jnp.abs(psi))
        probability /= jnp.sum(probability)
        indices = jax.random.categorical(
            key,
            jnp.log(jnp.maximum(probability, 1.0e-300)),
            shape=(samples,),
        )
        local = (H @ psi)[indices] / psi[indices]
        mean = jnp.mean(local)
        centered = jax.lax.stop_gradient(local - mean)
        log_amplitude = jnp.log(
            jnp.maximum(jnp.abs(psi[indices]), 1.0e-300)
        )
        loss = 2.0 * jnp.real(jnp.mean(centered * log_amplitude))
        variance = jnp.real(jnp.mean(jnp.square(local - mean)))
        return loss, (jnp.real(mean), variance)

    def loss(parameters: dict[str, jax.Array], key: jax.Array):
        key0, key2 = jax.random.split(key)
        psi0 = ground_features @ parameters["ground"]
        psi2 = excited_features @ parameters["excited"]
        loss0, diagnostics0 = surrogate(psi0, H0, key0)
        loss2, diagnostics2 = surrogate(psi2, H2, key2)
        return 0.5 * (loss0 + loss2), (
            diagnostics0[0],
            diagnostics2[0],
            diagnostics0[1],
            diagnostics2[1],
        )

    @jax.jit
    def step(parameters, optimizer_state, key):
        (_, diagnostics), gradient = jax.value_and_grad(
            loss, has_aux=True
        )(parameters, key)
        updates, optimizer_state = optimizer.update(
            gradient, optimizer_state, parameters
        )
        parameters = optax.apply_updates(parameters, updates)
        parameters = {
            name: value / jnp.linalg.norm(value)
            for name, value in parameters.items()
        }
        return parameters, optimizer_state, diagnostics

    return step


def sparse_mc_energy(
    psi: Array,
    H: SparseMatrix,
    samples: int,
    rng: np.random.Generator,
) -> dict[str, float]:
    probability = np.square(np.abs(psi))
    probability /= probability.sum()
    indices = rng.choice(
        len(psi), size=samples, replace=True, p=probability
    )
    local = (H @ psi)[indices] / psi[indices]
    variance = float(np.var(local).real)
    return {
        "energy": float(np.mean(local).real),
        "stderr": math.sqrt(variance / samples),
        "variance": variance,
        "samples": samples,
    }


def lowest_sparse_eigenpair(
    matrix: SparseMatrix, tolerance: float
) -> tuple[float, Array]:
    values, vectors = eigsh(
        matrix,
        k=1,
        which="SA",
        tol=tolerance,
        maxiter=max(10000, 10 * matrix.shape[0]),
    )
    return float(values[0]), vectors[:, 0]


def lowest_sparse_with_L(
    matrix: SparseMatrix,
    cache: SparseSectorCache,
    M: int,
    target_L: int,
    tolerance: float,
    eigenpairs: int,
) -> tuple[float, Array, float]:
    """Lowest sparse eigenvector in a fixed-M sector with the requested L."""

    count = min(eigenpairs, matrix.shape[0] - 2)
    if count < 1:
        raise ValueError("sector is too small for sparse diagonalization")
    values, vectors = eigsh(
        matrix,
        k=count,
        which="SA",
        tol=tolerance,
        maxiter=max(10000, 10 * matrix.shape[0]),
    )
    order = np.argsort(values)
    values = values[order]
    vectors = vectors[:, order]
    raising = sparse_raising_operator(cache, M)
    raised = raising @ vectors
    l2_values = np.sum(np.square(raised), axis=0) + M * (M + 1)
    target = target_L * (target_L + 1)
    candidates = np.flatnonzero(np.abs(l2_values - target) < 1.0e-7)
    if not len(candidates):
        labels = [
            int(round(0.5 * (math.sqrt(1.0 + 4.0 * value) - 1.0)))
            for value in l2_values
        ]
        raise RuntimeError(
            f"no L={target_L} state among {count} eigenpairs; "
            f"observed L labels={labels}"
        )
    index = int(candidates[0])
    return float(values[index]), vectors[:, index], float(l2_values[index])


def lowest_sparse_with_L_penalty(
    matrix: SparseMatrix,
    cache: SparseSectorCache,
    M: int,
    target_L: int,
    tolerance: float,
    penalty: float,
    initial_vector: Array | None = None,
) -> tuple[float, Array, float]:
    """Target one L irrep with H + penalty*(L2-L(L+1))**2."""

    raising = sparse_raising_operator(cache, M)
    constant = M * (M + 1)
    target = target_L * (target_L + 1)

    def l2_apply(vector: Array) -> Array:
        return raising.T @ (raising @ vector) + constant * vector

    def matvec(vector: Array) -> Array:
        l2_vector = l2_apply(vector)
        shifted = l2_vector - target * vector
        return matrix @ vector + penalty * (
            l2_apply(shifted) - target * shifted
        )

    penalized = LinearOperator(
        matrix.shape, matvec=matvec, dtype=np.float64
    )
    _, vectors = eigsh(
        penalized,
        k=1,
        which="SA",
        tol=tolerance,
        maxiter=max(10000, 10 * matrix.shape[0]),
        v0=initial_vector,
    )
    vector = vectors[:, 0]
    l2_value = float(np.vdot(vector, l2_apply(vector)).real)
    energy = float(np.vdot(vector, matrix @ vector).real)
    if abs(l2_value - target) > 1.0e-7:
        raise RuntimeError(
            f"penalized ED did not reach L={target_L}: L2={l2_value}"
        )
    return energy, vector, l2_value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-N", "--particles", type=int, default=8)
    parser.add_argument("--lmax", type=int, default=4)
    parser.add_argument("--scalar-depth", type=int, choices=(1, 2), default=2)
    parser.add_argument("--steps", type=int, default=50)
    parser.add_argument("--samples", type=int, default=4096)
    parser.add_argument("--eval-samples", type=int, default=262144)
    parser.add_argument("--learning-rate", type=float, default=5.0e-4)
    parser.add_argument("--seed", type=int, default=20260728)
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--ed-benchmark", action="store_true")
    parser.add_argument(
        "--ed-eigenpairs",
        type=int,
        default=48,
        help="low sparse eigenpairs used to locate the requested L sectors",
    )
    parser.add_argument(
        "--ed-penalty",
        type=float,
        default=0.05,
        help="coefficient of (L2-L(L+1))^2 for targeted sparse ED",
    )
    parser.add_argument("--multiplet-check", action="store_true")
    parser.add_argument(
        "--skip-tower-check",
        action="store_true",
        help="skip construction of M=-2,...,+1 tensor components",
    )
    parser.add_argument("--setup-only", action="store_true")
    parser.add_argument(
        "--basis-only",
        action="store_true",
        help="print sector dimensions and exit before building operators",
    )
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=None,
        help="persistent sparse Hamiltonian and Laughlin-seed cache",
    )
    parser.add_argument(
        "--hamiltonian-chunk-columns",
        type=int,
        default=1024,
        help="number of ket columns per low-memory Hamiltonian chunk",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path("runs/nqs_sparse_N8")
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.skip_tower_check and args.multiplet_check:
        raise ValueError("--skip-tower-check conflicts with --multiplet-check")
    start = time.perf_counter()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    two_q = 3 * (args.particles - 1)
    cache_dir = (
        args.cache_dir
        if args.cache_dir is not None
        else args.output_dir.parent / f"sparse_cache_N{args.particles}"
    )
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = SparseSectorCache(args.particles, two_q)
    basis0 = cache.basis(0)
    basis2 = cache.basis(2)
    print(f"JAX devices: {jax.devices()}", flush=True)
    print(
        f"N={args.particles}, 2Q={two_q}, "
        f"dim(M=0)={len(basis0)}, dim(M=2)={len(basis2)}",
        flush=True,
    )
    if args.basis_only:
        return

    pairs, coulomb_pair_matrix = antisymmetric_pair_matrix(
        two_q, interaction_pseudopotentials(two_q, "coulomb")
    )
    H0 = cached_hamiltonian(
        cache_dir / "coulomb_M0.npz",
        basis0,
        pairs,
        coulomb_pair_matrix,
        two_q,
        args.hamiltonian_chunk_columns,
        "Coulomb M=0",
    )
    H2 = cached_hamiltonian(
        cache_dir / "coulomb_M2.npz",
        basis2,
        pairs,
        coulomb_pair_matrix,
        two_q,
        args.hamiltonian_chunk_columns,
        "Coulomb M=2",
    )
    print(
        f"Coulomb nnz: H0={H0.nnz}, H2={H2.nnz}",
        flush=True,
    )

    _, v1_pair_matrix = antisymmetric_pair_matrix(
        two_q, interaction_pseudopotentials(two_q, "v1")
    )
    seed_path = cache_dir / "laughlin_M0.npy"
    if seed_path.exists():
        laughlin = np.load(seed_path)
        if laughlin.shape != (len(basis0),):
            raise RuntimeError(
                f"seed cache {seed_path} has shape {laughlin.shape}"
            )
        print(f"loaded Laughlin seed: {seed_path}", flush=True)
    else:
        H_v1 = cached_hamiltonian(
            cache_dir / "v1_M0.npz",
            basis0,
            pairs,
            v1_pair_matrix,
            two_q,
            args.hamiltonian_chunk_columns,
            "V1 M=0",
        )
        seed_energy, laughlin = lowest_sparse_eigenpair(H_v1, 1.0e-11)
        if abs(seed_energy) > 1.0e-8:
            raise RuntimeError(f"V1 seed is not a zero mode: {seed_energy}")
        laughlin *= np.sign(laughlin[np.argmax(np.abs(laughlin))])
        np.save(seed_path, laughlin)
        print(f"saved Laughlin seed: {seed_path}", flush=True)
    ground_features, scalar_diagnostics = build_scalar_features(
        cache,
        laughlin,
        args.lmax,
        args.scalar_depth,
    )
    terms = tensor_head_terms(args.lmax)
    raw_M2 = raw_excited_features(
        cache, ground_features, terms, 2
    )
    excited_features, tensor_transform, tensor_diagnostics = (
        whiten_features(raw_M2, relative_tolerance=1.0e-9)
    )
    del raw_M2
    E0, coefficients0, psi0 = projected_state(H0, ground_features)
    E2, coefficients2, psi2 = projected_state(H2, excited_features)
    observables0 = sparse_observables(psi0, H0, cache, 0)
    observables2 = sparse_observables(psi2, H2, cache, 2)
    print(
        f"feature ranks: ground={ground_features.shape[1]}, "
        f"excited={excited_features.shape[1]}",
        flush=True,
    )
    print(
        f"NQS subspace: E0={E0:.12f}, E2={E2:.12f}, "
        f"gap={E2-E0:.12f}, "
        f"var=({observables0['energy_variance']:.2e},"
        f"{observables2['energy_variance']:.2e})",
        flush=True,
    )

    ed_result = None
    if args.ed_benchmark:
        ed_E0, ed_ground, ed_l20 = lowest_sparse_with_L_penalty(
            H0,
            cache,
            0,
            0,
            1.0e-11,
            args.ed_penalty,
            psi0,
        )
        ed_E2, ed_excited, ed_l22 = lowest_sparse_with_L_penalty(
            H2,
            cache,
            2,
            2,
            1.0e-11,
            args.ed_penalty,
            psi2,
        )
        ed_result = {
            "E0": ed_E0,
            "E2": ed_E2,
            "gap": ed_E2 - ed_E0,
            "ground_L2": ed_l20,
            "excited_L2": ed_l22,
            "ground_overlap": float(abs(ed_ground @ psi0) ** 2),
            "excited_overlap": float(abs(ed_excited @ psi2) ** 2),
        }
        print(
            f"sparse ED:    E0={ed_E0:.12f}, E2={ed_E2:.12f}, "
            f"gap={ed_E2-ed_E0:.12f}, "
            f"bias={E2-E0-(ed_E2-ed_E0):+.3e}",
            flush=True,
        )

    lowering_residuals = {}
    components = {2: psi2}
    if not args.skip_tower_check:
        component_features = {}
        components = {}
        for M in range(-2, 3):
            raw_M = raw_excited_features(
                cache, ground_features, terms, M
            )
            component_features[M] = raw_M @ tensor_transform
            components[M] = component_features[M] @ coefficients2
        for M in range(-1, 3):
            lower = sparse_raising_operator(cache, M - 1).T
            lhs = lower @ components[M]
            rhs = (
                math.sqrt((2 + M) * (2 - M + 1))
                * components[M - 1]
            )
            denominator = max(
                np.linalg.norm(lhs), np.linalg.norm(rhs), 1.0e-15
            )
            lowering_residuals[f"M={M:+d}_to_{M-1:+d}"] = float(
                np.linalg.norm(lhs - rhs) / denominator
            )
    multiplet = {"M=+2": observables2}
    if args.multiplet_check:
        for M in (-2, -1, 0, 1):
            H_M = sparse_many_body_hamiltonian(
                cache.basis(M), pairs, coulomb_pair_matrix, two_q
            )
            multiplet[f"M={M:+d}"] = sparse_observables(
                components[M], H_M, cache, M
            )

    metadata = {
        "particles": args.particles,
        "two_q": two_q,
        "dimensions": {"M0": len(basis0), "M2": len(basis2)},
        "hamiltonian_nnz": {"M0": H0.nnz, "M2": H2.nnz},
        "scalar_diagnostics": scalar_diagnostics,
        "tensor_diagnostics": tensor_diagnostics,
        "lowering_residuals": lowering_residuals,
        "ed_benchmark": ed_result,
        "cache_dir": str(cache_dir),
        "cli": vars(args)
        | {
            "output_dir": str(args.output_dir),
            "cache_dir": (
                None if args.cache_dir is None else str(args.cache_dir)
            ),
        },
    }
    (args.output_dir / "metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    if args.setup_only:
        result = {
            "particles": args.particles,
            "two_q": two_q,
            "exact_ansatz": {
                "ground": observables0,
                "excited_M2": observables2,
                "gap": E2 - E0,
            },
            "ed_benchmark": ed_result,
            "multiplet": multiplet,
            "lowering_equivariance_residuals": lowering_residuals,
            "runtime_seconds": time.perf_counter() - start,
        }
        (args.output_dir / "result.json").write_text(
            json.dumps(result, indent=2), encoding="utf-8"
        )
        print(json.dumps(result, indent=2), flush=True)
        return

    cache._rho.clear()
    if args.skip_tower_check:
        del tensor_transform
    import gc
    gc.collect()
    ground_jax = jax.device_put(jnp.asarray(ground_features))
    excited_jax = jax.device_put(jnp.asarray(excited_features))
    H0_jax = scipy_to_bcoo(H0)
    H2_jax = scipy_to_bcoo(H2)
    parameters = {
        "ground": jax.device_put(jnp.asarray(coefficients0)),
        "excited": jax.device_put(jnp.asarray(coefficients2)),
    }
    schedule = optax.cosine_decay_schedule(
        args.learning_rate, max(args.steps, 1), alpha=0.05
    )
    optimizer = optax.chain(
        optax.clip_by_global_norm(10.0), optax.adam(schedule)
    )
    optimizer_state = optimizer.init(parameters)
    step = make_sparse_vmc_step(
        ground_jax,
        excited_jax,
        H0_jax,
        H2_jax,
        args.samples,
        optimizer,
    )
    key = jax.random.PRNGKey(args.seed)
    best_parameters = {
        name: np.asarray(jax.device_get(value))
        for name, value in parameters.items()
    }
    best_weighted = 0.5 * (E0 + E2)
    history = []
    for iteration in range(args.steps):
        key, step_key = jax.random.split(key)
        parameters, optimizer_state, diagnostics = step(
            parameters, optimizer_state, step_key
        )
        if iteration == 0:
            jax.block_until_ready(diagnostics)
        if iteration % args.log_every == 0 or iteration == args.steps - 1:
            host = {
                name: np.asarray(jax.device_get(value))
                for name, value in parameters.items()
            }
            candidate0 = ground_features @ host["ground"]
            candidate2 = excited_features @ host["excited"]
            obs0 = sparse_observables(candidate0, H0, cache, 0)
            obs2 = sparse_observables(candidate2, H2, cache, 2)
            weighted = 0.5 * (obs0["energy"] + obs2["energy"])
            row = {
                "step": iteration,
                "E0": obs0["energy"],
                "E2": obs2["energy"],
                "gap": obs2["energy"] - obs0["energy"],
                "variance0": obs0["energy_variance"],
                "variance2": obs2["energy_variance"],
            }
            history.append(row)
            print(
                f"step={iteration:4d} E0={row['E0']:.12f} "
                f"E2={row['E2']:.12f} gap={row['gap']:.12f} "
                f"var=({row['variance0']:.2e},{row['variance2']:.2e})",
                flush=True,
            )
            if weighted < best_weighted:
                best_weighted = weighted
                best_parameters = host
    (args.output_dir / "history.json").write_text(
        json.dumps(history, indent=2), encoding="utf-8"
    )

    psi0 = ground_features @ best_parameters["ground"]
    psi2 = excited_features @ best_parameters["excited"]
    observables0 = sparse_observables(psi0, H0, cache, 0)
    observables2 = sparse_observables(psi2, H2, cache, 2)
    rng = np.random.default_rng(args.seed + 1)
    mc0 = sparse_mc_energy(psi0, H0, args.eval_samples, rng)
    mc2 = sparse_mc_energy(psi2, H2, args.eval_samples, rng)
    result = {
        "ansatz": "sparse LLL-SU(2) tensor NQS V2",
        "particles": args.particles,
        "two_q": two_q,
        "feature_ranks": {
            "ground": ground_features.shape[1],
            "excited": excited_features.shape[1],
        },
        "exact_ansatz": {
            "ground": observables0,
            "excited_M2": observables2,
            "gap": observables2["energy"] - observables0["energy"],
        },
        "monte_carlo": {
            "ground": mc0,
            "excited_M2": mc2,
            "gap": mc2["energy"] - mc0["energy"],
            "gap_stderr": math.hypot(mc0["stderr"], mc2["stderr"]),
        },
        "ed_benchmark": ed_result,
        "multiplet": multiplet,
        "lowering_equivariance_residuals": lowering_residuals,
        "runtime_seconds": time.perf_counter() - start,
    }
    (args.output_dir / "result.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    np.savez_compressed(
        args.output_dir / "final_states.npz",
        basis_M0=np.asarray(basis0, dtype=np.uint64),
        basis_M2=np.asarray(basis2, dtype=np.uint64),
        psi_ground=psi0,
        psi_excited_M2=psi2,
    )
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
