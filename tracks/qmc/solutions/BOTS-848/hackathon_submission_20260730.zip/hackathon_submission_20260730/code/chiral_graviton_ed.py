#!/usr/bin/env python3
"""Small-system exact diagonalization benchmark for the nu=1/3 graviton.

The model follows ``chiral_graviton_nqs_research_report.md``:

* N spin-polarized fermions in the lowest Landau level on a Haldane sphere;
* 2Q = 3(N-1), with single-particle angular momentum l = Q;
* fixed-Lz occupation-number basis;
* either the V1 Laughlin parent Hamiltonian or chord-distance Coulomb;
* energies and gaps in e^2/(epsilon*l_B) for the Coulomb interaction.

The implementation intentionally favors clarity over large-system performance.  It
is meant for N=4--6 validation and for generating reference vectors for an NQS.
No external angular-momentum package is required: Wigner 3-j symbols are evaluated
with the Racah formula using doubled integer quantum numbers.

Examples
--------
Run all N=4 checks and both interactions:

    python chiral_graviton_ed.py

Run only Coulomb at N=5 and save the M=0 eigenvectors:

    python chiral_graviton_ed.py -N 5 --interaction coulomb \
        --save-npz benchmark_N5.npz

Add the uniform neutralizing-background constant and the optional density
rescaling used in some finite-size studies:

    python chiral_graviton_ed.py --background --density-correction
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import time
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.linalg import eigh


TOL = 1.0e-10


def _phase(exponent: int) -> float:
    """Return (-1)**exponent without negative-integer corner cases."""

    return -1.0 if exponent % 2 else 1.0


@lru_cache(maxsize=None)
def wigner_3j2(
    tj1: int,
    tj2: int,
    tj3: int,
    tm1: int,
    tm2: int,
    tm3: int,
) -> float:
    """Wigner 3-j symbol using doubled integer arguments.

    ``tj1`` means 2*j1 and ``tm1`` means 2*m1.  The Racah sum only contains
    factorials of non-negative integers, evaluated through ``lgamma``.
    """

    if tm1 + tm2 + tm3 != 0:
        return 0.0
    if any(abs(tm) > tj for tm, tj in ((tm1, tj1), (tm2, tj2), (tm3, tj3))):
        return 0.0
    if any((tj + tm) % 2 for tj, tm in ((tj1, tm1), (tj2, tm2), (tj3, tm3))):
        return 0.0
    if tj3 < abs(tj1 - tj2) or tj3 > tj1 + tj2:
        return 0.0
    if (tj1 + tj2 + tj3) % 2:
        return 0.0

    a = (tj1 + tj2 - tj3) // 2
    b = (tj1 - tj2 + tj3) // 2
    c = (-tj1 + tj2 + tj3) // 2
    d = (tj1 + tj2 + tj3) // 2 + 1

    j1pm1 = ((tj1 + tm1) // 2, (tj1 - tm1) // 2)
    j2pm2 = ((tj2 + tm2) // 2, (tj2 - tm2) // 2)
    j3pm3 = ((tj3 + tm3) // 2, (tj3 - tm3) // 2)

    log_prefactor = 0.5 * (
        math.lgamma(a + 1)
        + math.lgamma(b + 1)
        + math.lgamma(c + 1)
        - math.lgamma(d + 1)
        + sum(math.lgamma(x + 1) for x in j1pm1 + j2pm2 + j3pm3)
    )

    e = (tj3 - tj2 + tm1) // 2
    f = (tj3 - tj1 - tm2) // 2
    z_min = max(0, -e, -f)
    z_max = min(a, j1pm1[1], j2pm2[0])
    if z_min > z_max:
        return 0.0

    terms = []
    for z in range(z_min, z_max + 1):
        denominators = (z, a - z, j1pm1[1] - z, j2pm2[0] - z, e + z, f + z)
        log_denominator = sum(math.lgamma(x + 1) for x in denominators)
        terms.append(_phase(z) * math.exp(log_prefactor - log_denominator))

    exponent = (tj1 - tj2 - tm3) // 2
    return _phase(exponent) * math.fsum(terms)


@lru_cache(maxsize=None)
def clebsch_gordan2(
    tj1: int,
    tm1: int,
    tj2: int,
    tm2: int,
    tJ: int,
    tM: int,
) -> float:
    """Clebsch-Gordan coefficient in doubled-integer notation."""

    if tm1 + tm2 != tM:
        return 0.0
    exponent = (tj1 - tj2 + tM) // 2
    return (
        _phase(exponent)
        * math.sqrt(tJ + 1.0)
        * wigner_3j2(tj1, tj2, tJ, tm1, tm2, -tM)
    )


def orbital_two_m(two_q: int) -> tuple[int, ...]:
    """Return orbital 2m values ordered from -Q to +Q."""

    return tuple(range(-two_q, two_q + 1, 2))


def fock_basis(n_particles: int, two_q: int, M: int) -> tuple[int, ...]:
    """Enumerate fixed-N, fixed-Lz=M bitstrings."""

    target_two_m = 2 * M
    two_ms = orbital_two_m(two_q)
    basis = []
    for occupied in itertools.combinations(range(two_q + 1), n_particles):
        if sum(two_ms[i] for i in occupied) == target_two_m:
            basis.append(sum(1 << i for i in occupied))
    return tuple(basis)


def _annihilate(state: int, orbital: int) -> tuple[int, int] | None:
    if not (state >> orbital) & 1:
        return None
    sign = -1 if (state & ((1 << orbital) - 1)).bit_count() % 2 else 1
    return state ^ (1 << orbital), sign


def _create(state: int, orbital: int) -> tuple[int, int] | None:
    if (state >> orbital) & 1:
        return None
    sign = -1 if (state & ((1 << orbital) - 1)).bit_count() % 2 else 1
    return state | (1 << orbital), sign


def apply_pair_operator(
    state: int, a: int, b: int, c: int, d: int
) -> tuple[int, int] | None:
    """Apply c^dagger_a c^dagger_b c_d c_c for a<b and c<d."""

    sign = 1
    current = state
    for operation, orbital in (
        (_annihilate, c),
        (_annihilate, d),
        (_create, b),
        (_create, a),
    ):
        result = operation(current, orbital)
        if result is None:
            return None
        current, local_sign = result
        sign *= local_sign
    return current, sign


@lru_cache(maxsize=None)
def coulomb_product_element(
    two_q: int, tma: int, tmb: int, tmc: int, tmd: int
) -> float:
    """Return <ma,mb|1/r12|mc,md> in e^2/(epsilon*l_B).

    This is Eq. (A3) of Arciniaga and Peterson, Phys. Rev. B 94,
    035105 (2016), specialized to the nonrelativistic LLL (l=Q).
    The sphere radius is R=sqrt(Q)*l_B and the distance is the chord.
    """

    if tma + tmb != tmc + tmd:
        return 0.0
    if two_q <= 0:
        raise ValueError("Coulomb interaction requires Q>0")

    q = (tmc - tma) // 2
    phase_exponent = two_q - (tma + tmb) // 2
    prefactor = (two_q + 1.0) ** 2 / math.sqrt(two_q / 2.0)
    total = 0.0
    for k in range(two_q + 1):
        charge_symbol = wigner_3j2(two_q, 2 * k, two_q, -two_q, 0, two_q)
        if abs(charge_symbol) < 1.0e-16:
            continue
        first = wigner_3j2(two_q, 2 * k, two_q, tma, 2 * q, -tmc)
        second = wigner_3j2(two_q, 2 * k, two_q, tmb, -2 * q, -tmd)
        total += _phase(-q) * first * second * charge_symbol**2
    return prefactor * _phase(phase_exponent) * total


def coulomb_pseudopotentials(two_q: int) -> dict[int, float]:
    """Compute spherical Coulomb V_J for all pair angular momenta J."""

    two_ms = orbital_two_m(two_q)
    result: dict[int, float] = {}
    for J in range(two_q + 1):
        tM = 2 * J
        product_states = [
            (tma, tmb)
            for tma in two_ms
            for tmb in two_ms
            if tma + tmb == tM
        ]
        coefficients = np.array(
            [
                clebsch_gordan2(two_q, tma, two_q, tmb, 2 * J, tM)
                for tma, tmb in product_states
            ]
        )
        value = 0.0
        for i, (tma, tmb) in enumerate(product_states):
            for j, (tmc, tmd) in enumerate(product_states):
                value += (
                    coefficients[i]
                    * coulomb_product_element(two_q, tma, tmb, tmc, tmd)
                    * coefficients[j]
                )
        result[J] = float(value)
    return result


def interaction_pseudopotentials(two_q: int, interaction: str) -> dict[int, float]:
    if interaction == "coulomb":
        return coulomb_pseudopotentials(two_q)
    if interaction == "v1":
        # Relative pair angular momentum m_rel=2Q-J=1.
        return {J: float(J == two_q - 1) for J in range(two_q + 1)}
    raise ValueError(f"unknown interaction: {interaction}")


def antisymmetric_pair_matrix(
    two_q: int, pseudopotentials: dict[int, float]
) -> tuple[tuple[tuple[int, int], ...], np.ndarray]:
    """Two-fermion interaction in normalized |a wedge b>, a<b, basis."""

    pairs = tuple(itertools.combinations(range(two_q + 1), 2))
    two_ms = orbital_two_m(two_q)
    matrix = np.zeros((len(pairs), len(pairs)))

    # Fermions only admit odd relative angular momentum 2Q-J.
    allowed_J = [
        J
        for J in range(two_q + 1)
        if (two_q - J) % 2 == 1 and abs(pseudopotentials.get(J, 0.0)) > 1.0e-15
    ]
    for i, (a, b) in enumerate(pairs):
        pair_two_M = two_ms[a] + two_ms[b]
        for j, (c, d) in enumerate(pairs):
            if pair_two_M != two_ms[c] + two_ms[d]:
                continue
            value = 0.0
            for J in allowed_J:
                if abs(pair_two_M) > 2 * J:
                    continue
                cg_ab = clebsch_gordan2(
                    two_q, two_ms[a], two_q, two_ms[b], 2 * J, pair_two_M
                )
                cg_cd = clebsch_gordan2(
                    two_q, two_ms[c], two_q, two_ms[d], 2 * J, pair_two_M
                )
                value += 2.0 * pseudopotentials[J] * cg_ab * cg_cd
            matrix[i, j] = value
    return pairs, matrix


def many_body_hamiltonian(
    basis: tuple[int, ...],
    pairs: tuple[tuple[int, int], ...],
    pair_matrix: np.ndarray,
    two_q: int,
) -> np.ndarray:
    """Assemble the dense fixed-M Hamiltonian."""

    dimension = len(basis)
    index = {state: i for i, state in enumerate(basis)}
    H = np.zeros((dimension, dimension))
    two_ms = orbital_two_m(two_q)
    pairs_by_two_M: dict[int, list[int]] = {}
    for pair_index, (a, b) in enumerate(pairs):
        pairs_by_two_M.setdefault(two_ms[a] + two_ms[b], []).append(pair_index)

    for ket_index, state in enumerate(basis):
        occupied_pairs = [
            pair_index
            for pair_index, (c, d) in enumerate(pairs)
            if (state >> c) & 1 and (state >> d) & 1
        ]
        for cd_index in occupied_pairs:
            c, d = pairs[cd_index]
            pair_two_M = two_ms[c] + two_ms[d]
            for ab_index in pairs_by_two_M[pair_two_M]:
                element = pair_matrix[ab_index, cd_index]
                if abs(element) < 1.0e-15:
                    continue
                a, b = pairs[ab_index]
                result = apply_pair_operator(state, a, b, c, d)
                if result is None:
                    continue
                final_state, sign = result
                bra_index = index.get(final_state)
                if bra_index is not None:
                    H[bra_index, ket_index] += sign * element
    return 0.5 * (H + H.T)


def raising_operator(
    source_basis: tuple[int, ...], target_basis: tuple[int, ...], two_q: int
) -> np.ndarray:
    """Matrix for L_+ from an M sector to the M+1 sector."""

    target_index = {state: i for i, state in enumerate(target_basis)}
    matrix = np.zeros((len(target_basis), len(source_basis)))
    for source_index, state in enumerate(source_basis):
        for orbital in range(two_q):
            if not ((state >> orbital) & 1) or (state >> (orbital + 1)) & 1:
                continue
            first = _annihilate(state, orbital)
            assert first is not None
            intermediate, sign1 = first
            second = _create(intermediate, orbital + 1)
            assert second is not None
            final_state, sign2 = second
            coefficient = math.sqrt((two_q - orbital) * (orbital + 1))
            matrix[target_index[final_state], source_index] += (
                sign1 * sign2 * coefficient
            )
    return matrix


def angular_momentum_squared(
    basis: tuple[int, ...], n_particles: int, two_q: int, M: int
) -> np.ndarray:
    target_basis = fock_basis(n_particles, two_q, M + 1)
    L_plus = raising_operator(basis, target_basis, two_q)
    return L_plus.T @ L_plus + M * (M + 1) * np.eye(len(basis))


def infer_L(l2: float) -> int:
    return int(round(0.5 * (math.sqrt(max(0.0, 1.0 + 4.0 * l2)) - 1.0)))


@dataclass
class SectorResult:
    M: int
    dimension: int
    energies: np.ndarray
    eigenvectors: np.ndarray
    l2_expectations: np.ndarray
    l2_variances: np.ndarray
    inferred_L: np.ndarray
    hermiticity_error: float
    rotation_error: float


def solve_sector(
    n_particles: int,
    two_q: int,
    M: int,
    pairs: tuple[tuple[int, int], ...],
    pair_matrix: np.ndarray,
) -> tuple[SectorResult, tuple[int, ...], np.ndarray]:
    basis = fock_basis(n_particles, two_q, M)
    if not basis:
        raise ValueError(f"empty N={n_particles}, M={M} sector")
    H = many_body_hamiltonian(basis, pairs, pair_matrix, two_q)
    L2 = angular_momentum_squared(basis, n_particles, two_q, M)
    hermiticity_error = float(np.max(np.abs(H - H.T)))
    rotation_error = float(np.max(np.abs(H @ L2 - L2 @ H)))

    energies, eigenvectors = eigh(H, driver="evr")
    L2_vectors = L2 @ eigenvectors
    expectations = np.einsum("ij,ij->j", eigenvectors, L2_vectors)
    second_moments = np.einsum("ij,ij->j", L2_vectors, L2_vectors)
    variances = np.maximum(0.0, second_moments - expectations**2)
    labels = np.array([infer_L(value) for value in expectations], dtype=int)
    result = SectorResult(
        M=M,
        dimension=len(basis),
        energies=energies,
        eigenvectors=eigenvectors,
        l2_expectations=expectations,
        l2_variances=variances,
        inferred_L=labels,
        hermiticity_error=hermiticity_error,
        rotation_error=rotation_error,
    )
    return result, basis, H


def lowest_with_L(result: SectorResult, target_L: int) -> tuple[int, float]:
    candidates = np.flatnonzero(result.inferred_L == target_L)
    if len(candidates) == 0:
        raise RuntimeError(f"no L={target_L} state found in M={result.M} sector")
    index = int(candidates[0])
    expected = target_L * (target_L + 1)
    if abs(result.l2_expectations[index] - expected) > 1.0e-7:
        raise RuntimeError(
            f"ambiguous angular momentum: <L2>={result.l2_expectations[index]}"
        )
    return index, float(result.energies[index])


def shifted_energy(
    energy: float,
    n_particles: int,
    two_q: int,
    background: bool,
    density_correction: bool,
) -> float:
    value = energy
    if background:
        # Electron-background plus background-background for a uniform shell.
        value -= n_particles**2 / (2.0 * math.sqrt(two_q / 2.0))
    if density_correction:
        # sqrt(2Q*nu/N), with nu=1/3.
        value *= math.sqrt(two_q / (3.0 * n_particles))
    return value


def print_low_spectrum(result: SectorResult, count: int = 12) -> None:
    print(f"\nM={result.M:+d} sector: dimension={result.dimension}")
    print(" index        energy          <L^2>       var(L^2)    L")
    for i in range(min(count, len(result.energies))):
        print(
            f" {i:5d}  {result.energies[i]:14.10f}"
            f"  {result.l2_expectations[i]:12.8f}"
            f"  {result.l2_variances[i]:11.3e}  {result.inferred_L[i]:3d}"
        )


def algebra_self_test() -> None:
    """Fast convention checks independent of the many-body problem."""

    known = {
        (1, 1, 0, 1, -1, 0): 1.0 / math.sqrt(2.0),
        (1, 1, 0, -1, 1, 0): -1.0 / math.sqrt(2.0),
        (2, 2, 0, 0, 0, 0): -1.0 / math.sqrt(3.0),
    }
    for args, expected in known.items():
        value = wigner_3j2(*args)
        if abs(value - expected) > 1.0e-13:
            raise AssertionError(f"Wigner 3-j test failed: {args}, {value}, {expected}")

    # Fermionic sign: <ab|c^dagger_a c^dagger_b c_b c_a|ab> = +1.
    state = (1 << 1) | (1 << 4)
    result = apply_pair_operator(state, 1, 4, 1, 4)
    if result != (state, 1):
        raise AssertionError(f"fermion sign test failed: {result}")


def run_interaction(
    n_particles: int,
    interaction: str,
    background: bool,
    density_correction: bool,
    check_multiplet: bool,
    spectrum_count: int,
    save_npz: Path | None,
) -> dict[str, object]:
    two_q = 3 * (n_particles - 1)
    start = time.perf_counter()
    pseudopotentials = interaction_pseudopotentials(two_q, interaction)
    pairs, pair_matrix = antisymmetric_pair_matrix(two_q, pseudopotentials)

    pair_hermiticity = float(np.max(np.abs(pair_matrix - pair_matrix.T)))
    result0, basis0, H0 = solve_sector(
        n_particles, two_q, 0, pairs, pair_matrix
    )
    print(f"\n{'=' * 72}")
    print(
        f"interaction={interaction}, N={n_particles}, 2Q={two_q}, "
        f"Norb={two_q + 1}"
    )
    print_low_spectrum(result0, spectrum_count)

    index0, raw_E0 = lowest_with_L(result0, 0)
    index2, raw_E2 = lowest_with_L(result0, 2)
    E0 = shifted_energy(
        raw_E0, n_particles, two_q, background, density_correction
    )
    E2 = shifted_energy(
        raw_E2, n_particles, two_q, background, density_correction
    )
    gap = E2 - E0

    zero_count = int(np.count_nonzero(np.abs(result0.energies) < 1.0e-9))
    if interaction == "v1":
        if abs(raw_E0) > 1.0e-9 or zero_count != 1:
            raise AssertionError(
                f"V1 Laughlin test failed: E0={raw_E0}, zero_count={zero_count}"
            )

    multiplet: dict[int, float] = {0: raw_E2}
    if check_multiplet:
        for M in (-2, -1, 1, 2):
            sector, _, _ = solve_sector(
                n_particles, two_q, M, pairs, pair_matrix
            )
            _, energy = lowest_with_L(sector, 2)
            multiplet[M] = energy
    multiplet_spread = max(multiplet.values()) - min(multiplet.values())

    print("\nBenchmark summary")
    print(f"  E0(L=0)              = {E0:.12f}")
    print(f"  E2(L=2)              = {E2:.12f}")
    print(f"  Delta_2              = {gap:.12f}")
    print(f"  <L^2> for L=2        = {result0.l2_expectations[index2]:.12f}")
    print(f"  energy variance      = {np.var(H0 @ result0.eigenvectors[:, index2] - raw_E2 * result0.eigenvectors[:, index2]):.3e}")
    print(f"  pair Hermiticity err = {pair_hermiticity:.3e}")
    print(f"  H Hermiticity err    = {result0.hermiticity_error:.3e}")
    print(f"  [H,L^2] max error    = {result0.rotation_error:.3e}")
    if check_multiplet:
        formatted = ", ".join(f"M={M:+d}: {multiplet[M]:.12f}" for M in sorted(multiplet))
        print(f"  L=2 multiplet        = {formatted}")
        print(f"  multiplet spread     = {multiplet_spread:.3e}")

    if pair_hermiticity > 1.0e-11:
        raise AssertionError("pair interaction is not Hermitian")
    if result0.hermiticity_error > 1.0e-11:
        raise AssertionError("many-body Hamiltonian is not Hermitian")
    if result0.rotation_error > 2.0e-9:
        raise AssertionError("Hamiltonian does not commute with L^2")
    if check_multiplet and multiplet_spread > 2.0e-9:
        raise AssertionError("L=2 multiplet is not degenerate")

    if save_npz is not None:
        output = save_npz
        if interaction != "coulomb":
            output = output.with_name(f"{output.stem}_{interaction}{output.suffix}")
        np.savez_compressed(
            output,
            N=n_particles,
            twoQ=two_q,
            M=0,
            interaction=interaction,
            basis=np.asarray(basis0, dtype=np.uint64),
            energies=result0.energies,
            eigenvectors=result0.eigenvectors,
            L2_expectations=result0.l2_expectations,
            inferred_L=result0.inferred_L,
            hamiltonian=H0,
        )
        print(f"  saved                 = {output.resolve()}")

    elapsed = time.perf_counter() - start
    return {
        "N": n_particles,
        "twoQ": two_q,
        "M_sector": 0,
        "Hilbert_dimension": result0.dimension,
        "interaction": interaction,
        "E0_L0": E0,
        "E0_L2": E2,
        "gap": gap,
        "L2_expectation": float(result0.l2_expectations[index2]),
        "L2_variance": float(result0.l2_variances[index2]),
        "background_convention": "uniform" if background else "none",
        "density_correction": density_correction,
        "energy_unit": "V1" if interaction == "v1" else "e2_over_epsilon_lB",
        "multiplet_spread": multiplet_spread if check_multiplet else None,
        "runtime_seconds": elapsed,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Small Haldane-sphere ED benchmark for the nu=1/3 L=2 graviton"
    )
    parser.add_argument("-N", "--particles", type=int, default=4)
    parser.add_argument(
        "--interaction",
        choices=("v1", "coulomb", "both"),
        default="both",
    )
    parser.add_argument(
        "--background",
        action="store_true",
        help="add the uniform neutralizing-background constant",
    )
    parser.add_argument(
        "--density-correction",
        action="store_true",
        help="multiply energies by sqrt(2Q*nu/N), nu=1/3",
    )
    parser.add_argument(
        "--no-multiplet-check",
        action="store_true",
        help="skip separate M=-2,...,+2 diagonalizations",
    )
    parser.add_argument("--spectrum-count", type=int, default=12)
    parser.add_argument(
        "--save-npz",
        type=Path,
        default=None,
        help="save the M=0 Hamiltonian, spectrum, and eigenvectors",
    )
    parser.add_argument(
        "--json",
        type=Path,
        default=None,
        help="write benchmark summary as JSON",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.particles < 2:
        raise ValueError("N must be at least 2")
    if 3 * args.particles - 2 > 63:
        raise ValueError("this transparent bitstring implementation supports <=63 orbitals")

    algebra_self_test()
    interactions: Iterable[str]
    interactions = ("v1", "coulomb") if args.interaction == "both" else (args.interaction,)
    summaries = [
        run_interaction(
            n_particles=args.particles,
            interaction=interaction,
            background=args.background,
            density_correction=args.density_correction,
            check_multiplet=not args.no_multiplet_check,
            spectrum_count=args.spectrum_count,
            save_npz=args.save_npz,
        )
        for interaction in interactions
    ]

    if args.json is not None:
        args.json.write_text(json.dumps(summaries, indent=2) + "\n", encoding="utf-8")
        print(f"\nJSON summary saved to {args.json.resolve()}")


if __name__ == "__main__":
    main()
