from __future__ import annotations

import numpy as np

from laughlin_vmc_comparison import (
    delete_one_chain_ratio,
    paired_statistics,
)


def test_delete_one_chain_ratio_constant_values() -> None:
    value, stderr, replicates = delete_one_chain_ratio(
        np.asarray([2.0, 4.0, 6.0]),
        np.asarray([1.0, 2.0, 3.0]),
    )
    assert value == 2.0
    assert stderr == 0.0
    np.testing.assert_allclose(replicates, 2.0)


def test_paired_statistics_identical_state_has_zero_difference() -> None:
    potential = np.arange(1.0, 13.0)
    result = paired_statistics(
        potential,
        np.ones_like(potential),
        records=4,
        chains=3,
    )
    assert result["nqs_energy"] == result["laughlin_energy"]
    assert result["difference_nqs_minus_laughlin"] == 0.0
    assert result["difference_stderr_paired"] == 0.0
    assert result["importance_ess_fraction"] == 1.0


def test_paired_statistics_detects_lower_reweighted_energy() -> None:
    potential = np.asarray(
        [
            [1.0, 2.0, 3.0],
            [2.0, 3.0, 4.0],
            [3.0, 4.0, 5.0],
            [4.0, 5.0, 6.0],
        ]
    ).reshape(-1)
    weight = np.exp(-potential)
    result = paired_statistics(potential, weight, records=4, chains=3)
    assert result["nqs_energy"] < result["laughlin_energy"]
    assert result["difference_nqs_minus_laughlin"] < 0.0
    assert 0.0 < result["importance_ess_fraction"] < 1.0
