#!/usr/bin/env python3
"""Check that per-convolution normalization leaves all features unchanged."""

import jax
import jax.numpy as jnp
import numpy as np

from chiral_graviton_nqs_scaling_gpu import random_spinors
from strict_first_quantized_streaming import (
    make_streaming_scalar_feature_function,
    make_streaming_tensor_feature_function,
)


def normalized_convolve_fixed(coefficients, factor):
    result = jnp.zeros_like(coefficients)
    length = coefficients.shape[0]
    for shift in range(4):
        result = result.at[shift:].add(
            factor[shift] * coefficients[: length - shift]
        )
    return result / jnp.maximum(jnp.max(jnp.abs(result)), 1.0e-300)


def relative_residual(reference, candidate):
    return float(
        np.max(
            np.abs(reference - candidate)
            / np.maximum(np.abs(reference), 1.0e-12)
        )
    )


def main():
    import strict_first_quantized_streaming as streaming

    coordinates = random_spinors(jax.random.PRNGKey(9102), 2, 5)
    original = streaming._convolve_fixed
    scalar_reference, _ = make_streaming_scalar_feature_function(5, 5)
    tensor_reference, _ = make_streaming_tensor_feature_function(5, 5)
    scalar_before = np.asarray(scalar_reference(coordinates))
    tensor_before = np.asarray(tensor_reference(coordinates))

    streaming._convolve_fixed = normalized_convolve_fixed
    scalar_stable, _ = make_streaming_scalar_feature_function(5, 5)
    tensor_stable, _ = make_streaming_tensor_feature_function(5, 5)
    scalar_after = np.asarray(scalar_stable(coordinates))
    tensor_after = np.asarray(tensor_stable(coordinates))
    streaming._convolve_fixed = original

    scalar_error = relative_residual(scalar_before, scalar_after)
    tensor_error = relative_residual(tensor_before, tensor_after)
    print(f"scalar_relative_residual={scalar_error:.3e}")
    print(f"tensor_relative_residual={tensor_error:.3e}")
    assert scalar_error < 2.0e-10
    assert tensor_error < 2.0e-10


if __name__ == "__main__":
    main()
