# 结论、代码与证据对应表

本表是提交包的审计索引。报告中的数字以 CSV/JSON 为最高优先级；阶段 Markdown 用来解释上下文，不覆盖原始结构化数据。

## 证据优先级

1. **结构化原始结果**：`data/**/*.csv`、`data/**/*.json`、`experiments/**/results/*`。
2. **生成这些结果的科学脚本**：`code/*.py`、`experiments/**/*.py`。
3. **阶段报告**：`supporting_reports/*.md`，用于说明参数、时间线和当时的解释。
4. **最终综合解释**：`REPORT.md`，统一单位、修正含糊误差记法并标出可声称边界。

## 主结论映射

| ID | 结论 | 主要代码 | 主要数据/验证 |
|---|---|---|---|
| C1 | 体系是 Haldane 球面上的费米 \(\nu=1/3\)，\(2Q=3(N-1)\)，严格 LLL Coulomb | `code/chiral_graviton_ed.py`; `code/strict_first_quantized_tensor_nqs.py` | 每个 `results.json` 的 `geometry`、`flux`、`energy_units` 和 `arguments` |
| C2 | ansatz 是 Laughlin 核乘严格 SU(2) scalar/rank-2 density-tensor 特征的可训练复线性组合 | `code/strict_first_quantized_tensor_nqs.py`; `code/strict_first_quantized_tensor_nqs_v2.py`; `code/strict_first_quantized_tensor_nqs_v3.py`; `code/strict_first_quantized_streaming.py` | `data/main_nqs_runs/*/results.json` 中的 `lmax`、coefficients、retained rank、\(L^2\) |
| C3 | 小系统严格 tensor NQS 与 ED 一致，且 \(L^2=0/6\) | `code/chiral_graviton_su2_tensor_route.py`; `code/chiral_graviton_nqs_vmc_v2.py`; `code/chiral_graviton_nqs_vmc_sparse.py` | `data/exact_tensor_benchmark/summary.csv`; `RESULTS.md` |
| C4 | **一次量子化 NQS 的基态能量低于纯 Laughlin VMC** | `code/laughlin_vmc_comparison.py`; `code/test_laughlin_vmc_comparison.py` | `data/laughlin_comparison/laughlin_vmc_comparison_formal_20260730/first_quantized_paired.csv`; 同目录 `results.json` |
| C5 | 可信训练到 \(N=40\)，正式 gap 为 \(N=20,30,40\) 三组结果 | `code/strict_first_quantized_nqs_streaming_driver.py`; `code/strict_first_quantized_streaming.py`; `code/summarize_strict_first_quantized_runs.py` | `data/main_nqs_runs/strict_fq_streaming_N20_N40_benchmark_20260730.csv`; 各 run 的 `results.json` |
| C6 | 计算路径能到 \(N=100\)，但 \(N=80,100\) importance ESS 崩溃，物理边界仍是 \(N=40\) | `code/strict_first_quantized_nqs_stabilized_driver.py`; `code/test_strict_first_quantized_stabilized.py` | `data/failure_and_boundary/strict_fq_N100_boundary_summary_20260730.csv`; 各 stabilized run 的 `results.json` |
| C7 | 普通 Fock autoregressive NQS 可训练但出现严重 \(L^2\) 污染 | `code/chiral_graviton_fock_ar_nqs.py`; `code/chiral_graviton_fock_ar_nqs_symmetry_v3.py`; `v4.py`; `v5.py` | `data/failure_and_boundary/summary.csv`; `summary.json` |
| C8 | \(V_1\to\) Coulomb 过程中基态保持高 Laughlin fidelity，但最低 \(L=2\) 极点由暗变亮 | `experiments/geometry_chirality_study_20260729/ed_geometry_suite.py`; `story_completion_suite.py`; `endpoint_n10_suite.py` | `experiments/geometry_chirality_study_20260729/results/dense_path_N8.csv`; `dense_path_N8_crossover.csv`; `endpoint_N10_poles.csv`; `FINAL_SUMMARY.md` |
| C9 | Coulomb 的最低 \(L=2\) 极点在 \(N=6,8,9,10\) 承载约 82%-96% 权重 | 同 C8 | `spectral_poles.csv`; `endpoint_N10_poles.csv`; `krylov_convergence_N9.csv`; `krylov_convergence_N10.csv` |
| C10 | 球面 \(\rho_{2,+2}\) 与 \(\rho_{2,-2}\) 等权只是 SO(3) 协变零检验，不能当 bright/dark helicity | `experiments/case_questions_20260730/run_physics_probes_headless.py`; 几何 ED 脚本 | `experiments/case_questions_20260730/results/chirality_null_test.csv`; `physics_probes.json` |
| C11 | 有限 ED 谱的 FWHM 随人工 \(\eta\) 以约 2 的斜率变化，不能提取内禀寿命 | `experiments/case_questions_20260730/meng_lifetime_reanalysis.py` | `experiments/case_questions_20260730/results/meng_lifetime_20260730/eta_scan.csv`; `results.json`; `figures/spectral_fragmentation.png` |
| C12 | QGT 稳健结果是 \(N=8\) 的 \(L=2\to L=0\) crossing，\(\lambda_c=0.7684404954\) | `experiments/case_questions_20260730_followup/dense_qgt_scan.py`; `dense_qgt_scan_robust.py` | `experiments/case_questions_20260730_followup/results/qgt_dense_robust/summary.json`; `dense_qgt_scan.csv`; `figures/qgt_symmetry_resolved.png` |
| C13 | Moore-Read 小体系三个分支五种子达到机器精度，但不是大尺寸 SUSY 证据 | `experiments/case_questions_20260730_followup/train_moore_read_variational_nqs.py` | `experiments/case_questions_20260730_followup/results/mr_variational_nqs/summary.json`; `figures/mr_variational_convergence.png` |
| C14 | DeepHall-style 两层 pilot 没有达到目标 \(L^2=0/6\)，只能作为负结果；软化相互作用 ED 显示厚度增大时 gap 降低 | `experiments/deephall_l2_minimal_20260730/deephall_minimal.py`; `ed_softened_gap.py` | `experiments/deephall_l2_minimal_20260730/results/*/summary.json`; `ed_width_scan_extended_N4.json` |
| C15 | 当前现实实验比较只使用经验厚度缩放；显式 finite-thickness form factor 和 LL mixing 尚未进入主 Hamiltonian | 现有主代码只实现严格 LLL | `supporting_reports/Haldane_geometry_gap_constraints_LL_mixing_report.md`; `figures/haldane_nqs_du_comparison.png` |

## 代码文件说明

### 一次量化主线

- `chiral_graviton_nqs_scaling_gpu.py`：固定单头 matrix-free SMA 基线；不是最终多通道 NQS。
- `strict_first_quantized_tensor_nqs.py`：连续坐标采样、基本 density-tensor 特征和广义本征训练。
- `strict_first_quantized_tensor_nqs_v2.py` / `v3.py`：通道与数值实现演进。
- `strict_first_quantized_streaming.py`：避免显式 \(D\times D\) pair block 的流式收缩核。
- `strict_first_quantized_nqs_streaming_driver.py`：训练集/验证集、白化阈值扫描、结果输出。
- `strict_first_quantized_nqs_stabilized_driver.py`：\(N=60\) 到 \(100\) 的多项式尺度稳定化。
- `strict_first_quantized_hmc.py`：球面 geodesic HMC 研究采样器。
- `laughlin_vmc_comparison.py`：全新 Laughlin VMC、同样本 NQS 配对重加权、按独立链 jackknife。

### 小系统与失败路线

- `chiral_graviton_ed.py`：球面 LLL Coulomb、角动量算符和 ED 基础。
- `chiral_graviton_su2_tensor_route.py`：严格二次量化 SU(2) density-tensor 基准。
- `chiral_graviton_nqs_vmc*.py`：早期 rank-1 到 full-multiplicity/sparse 的演进。
- `chiral_graviton_fock_ar_nqs*.py`：可扩展但角动量污染的 autoregressive 路线。

## 未复制的内容

- `geometry_chirality_study_20260729/cache/` 约 367 MB，属于可由脚本重建的 ED cache，未放入提交包。
- `__pycache__/` 和基础设施仓库 `quantum.harness/`、`superpowers/` 未复制。
- 大量 smoke/pilot/checkpoint 只在它们直接支撑负结果时保留；主包优先保存正式 CSV/JSON。

## 阶段报告的口径提醒

部分阶段报告把中心值保留过多小数，同时用括号表示绝对误差，容易造成十进制误读。最终报告统一写成显式绝对误差。例如：

\[
\Delta_{40}=0.1499\pm0.0048_{\rm stat}\pm0.006_{\rm ansatz}\ E_C.
\]

若最终报告与阶段 Markdown 的排版写法冲突，应回到
`data/main_nqs_runs/strict_fq_streaming_N20_N40_benchmark_20260730.csv`
的 `gap_stderr` 字段。

