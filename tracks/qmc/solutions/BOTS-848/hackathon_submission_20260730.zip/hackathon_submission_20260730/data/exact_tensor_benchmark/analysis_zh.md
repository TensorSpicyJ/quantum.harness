# 严格 SU(2) 投影密度张量 NQS：GPU/ED 结果报告

## 1. 本次实现

新建的 `chiral_graviton_su2_tensor_route.py` 统一调用稀疏张量引擎
`chiral_graviton_nqs_vmc_sparse.py`。变分态为

\[
|\Psi_0\rangle=\mathcal C_\theta^{(0)}|\Psi_{\rm Laughlin}\rangle,\qquad
|\Psi_{2,M}\rangle=\mathcal O_{\theta,M}^{(2)}
\mathcal C_\theta^{(0)}|\Psi_{\rm Laughlin}\rangle .
\]

标量 backbone 和 rank-2 head 均由 LLL 投影密度
\(\bar\rho_{\ell m}\) 及 Clebsch–Gordan coupling 构造。因此基态的
\(L=0\) 与激发态的 \(L=2\) 由表示论严格保证，没有使用高方差
\(L^2\) penalty。每个尺寸都在独立进程中运行，以便释放 GPU 显存。

训练参数为 30 个 VMC step、每步 4096 samples、最终 131072 samples；
\(N=4\)–8 使用 \(\ell_{\max}=4\)，\(N=9\) 使用
\(\ell_{\max}=6\)，\(N=10\) 为控制显存恢复到 \(\ell_{\max}=4\)。

## 2. 结果

| \(N\) | tensor feature rank \(L=0/L=2\) | gap | ED gap | \({\rm Var}(E_0)\) | \({\rm Var}(E_2)\) | MC gap 标准误差 | 主程序耗时 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 4 | 2 / 2 | 0.131856755 | 0.131856755 | 0 | 0 | \(1.72\times10^{-14}\) | 1.46 s |
| 5 | 2 / 4 | 0.126172064 | 0.126172064 | \(3.55\times10^{-15}\) | \(1.78\times10^{-15}\) | \(2.26\times10^{-17}\) | 1.63 s |
| 6 | 6 / 11 | 0.131688412 | 0.131688412 | \(1.78\times10^{-15}\) | \(3.55\times10^{-15}\) | \(1.83\times10^{-12}\) | 2.20 s |
| 7 | 10 / 29 | 0.129198098 | 0.129198098 | \(7.11\times10^{-15}\) | 0 | \(1.61\times10^{-11}\) | 4.46 s |
| 8 | 13 / 91 | 0.128787201 | 0.128785288* | \(4.80\times10^{-7}\) | \(1.57\times10^{-6}\) | \(3.53\times10^{-6}\) | 12.19 s |
| 9 | 31 / 343 | 0.130509085 | — | \(7.77\times10^{-8}\) | 0 | \(6.78\times10^{-7}\) | 177.63 s |
| 10 | 13 / 91 | 0.130448924 | — | \(6.80\times10^{-6}\) | \(1.63\times10^{-4}\) | \(3.54\times10^{-5}\) | 198.91 s |

\(*\) 本次重新运行 \(N=8\) 的 tensor NQS/GPU VMC；ED 数值取自仓库中
同一 Hamiltonian、同一定义 ansatz 的既有
`runs/nqs_sparse_N8/result.json`。新 targeted ED 重算持续 8 分钟后被
主动终止，以避免重复计算。既有 ED 对照给出 ground/excited overlap
分别为 0.999997678 和 0.999993643；gap 相对偏差约
\(1.49\times10^{-5}\)。

所有完成完整 multiplet 检查的 \(N=4\)–9 均满足
\(L_0^2\) 近似 0、\(L_2^2=6\)，lowering equivariance residual 从
\(5.3\times10^{-15}\) 增至 \(9.6\times10^{-12}\)，仍接近数值精度。
\(N=10\) 因显式构造五个 \(M\) 分量的成本较高，只检查了 \(M=2\)：
\(L_2^2=5.999999999999998\)。

## 3. 可以得出的结论

1. **\(N=4\)–7 已通过严格 ED benchmark。** gap、能量和 overlap 在
   双精度数值误差内一致，说明 density-tensor ansatz 的物理构造正确。
2. **\(N=8\) 仍是高精度。** 与既有 ED 的 gap 相差
   \(1.91\times10^{-6}\)，相对偏差约 \(1.49\times10^{-5}\)，两个
   overlap 均超过 0.99999。
3. **\(N=9\) 是目前最可信的无 ED 大尺寸点。** 严格 SU(2)、完整
   五重态等价性、很小的能量方差及 \(6.8\times10^{-7}\) 的 MC gap
   误差同时成立。
4. **\(N=10\) 能算，但紧凑 ansatz 已出现精度预警。** SU(2) 没坏，
   但 excited variance 升到 \(1.63\times10^{-4}\)。因此当前代码的
   “可运行边界”为 \(N=10\)，保守的“高精度可信边界”为 \(N=9\)。
5. **普通 SGD 不适合从 Rayleigh–Ritz 最优点继续训练。** \(N=9,10\)
   的随机梯度末态比投影子空间最优态更差。后续应采用
   stochastic reconfiguration/natural gradient，并始终保存最低
   variance/best-energy checkpoint。

## 4. 扩大尺寸的下一步

显式 fixed-\(M\) Fock 基维数从 \(N=9\) 的约 4.5 万增长到 \(N=10\)
的约 24.6 万；\(N=10\) 两个 Coulomb Hamiltonian 各有约 4600 万个
非零元。这个增长已经不是 GPU 算力问题，而是显式基和稀疏矩阵的内存
复杂度问题。直接用当前实现做 \(N=12\) 不现实。

继续扩大的优先路线应为：

- 先在 \(N=10\) 增加 \(\ell_{\max}\) 或采用通道选择，确认
  excited variance 能下降；
- 把 VMC 更新改成 SR/natural gradient，并加入 best-checkpoint 回退；
- 缓存 ED 本征向量，避免每次 benchmark 重做 targeted eigensolve；
- 将 \(\bar\rho_{\ell m}\) 和 Hamiltonian 的作用改为 matrix-free，
  按采样到的 Fock configuration 生成 connected states，不再保存完整
  \(24.6\) 万维向量和 \(4600\) 万非零元矩阵；
- 只有完成 matrix-free 后，才适合进入 \(N=12,14,16,20\)，随后再评估
  \(N=30,40,60\)。

因此，本轮已经验证了“真正可训练 + 严格 SU(2)”路线的正确性，也清楚
定位了瓶颈：不是角动量约束，而是显式 Fock 表示及 \(N=10\) 的通道截断。
