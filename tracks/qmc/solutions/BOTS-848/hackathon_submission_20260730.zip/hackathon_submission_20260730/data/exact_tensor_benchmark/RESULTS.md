# Strict SU(2) density-tensor NQS benchmark

The state uses trainable scalar projected-density channels for the ground
state and a trainable rank-2 tensor head for the graviton.  Therefore
$L=0$ and $L=2$ are representation-theoretic constraints, not penalties.

| N | status | gap | ED gap | rel. gap error | var(E0) | var(E2) | $L_0^2$ | $L_2^2$ | MC gap stderr | wall time |
|---:|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 4 | ok | 0.131856755 | 0.131856755 | 5.05195062e-15 | 0 | 0 | 8.6404921e-29 | 6 | 1.7180809e-14 | 1.45818166 s |
| 5 | ok | 0.126172064 | 0.126172064 | 0 | 3.55271368e-15 | 1.77635684e-15 | 1.9810855e-27 | 6 | 2.25928105e-17 | 1.62858097 s |
| 6 | ok | 0.131688412 | 0.131688412 | 6.74454499e-15 | 1.77635684e-15 | 3.55271368e-15 | 3.70333833e-27 | 6 | 1.82618879e-12 | 2.20049583 s |
| 7 | ok | 0.129198098 | 0.129198098 | 0 | 7.10542736e-15 | 0 | 4.46269646e-27 | 6 | 1.60548641e-11 | 4.46032137 s |
| 8 | ok | 0.128787201 | — | — | 4.80116732e-07 | 1.56652873e-06 | 6.799981e-27 | 6 | 3.52547472e-06 | 12.1887978 s |
| 9 | ok | 0.130509085 | — | — | 7.76649927e-08 | 0 | 1.63757466e-25 | 6 | 6.7795516e-07 | 177.630095 s |
| 10 | ok | 0.130448924 | — | — | 6.80466e-06 | 0.000163155476 | 5.71282498e-26 | 6 | 3.53637704e-05 | 198.906885 s |

## Reliability criteria

- ED overlap and gap error test wave-function accuracy where ED is enabled.
- $L_0^2=0$, $L_2^2=6$, and the lowering-tower residual test exact SU(2).
- Energy variance tests eigenstate quality independently of ED.
- Monte Carlo standard error measures sampling noise, not ansatz bias.

A larger size is accepted only if the symmetry residual remains near machine
precision and the energy variances do not show systematic deterioration.
