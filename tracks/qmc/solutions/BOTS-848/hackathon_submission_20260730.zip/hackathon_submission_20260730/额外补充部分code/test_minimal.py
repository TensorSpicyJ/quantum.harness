from __future__ import annotations

import math

import jax
import jax.numpy as jnp
import numpy as np

from deephall_minimal import (
    DeepHallPsiformer,
    local_kinetic_and_angular,
    potential_energy,
    uniform_configurations,
)
from ed_softened_gap import (
    central_pseudopotentials,
    soft_coulomb_legendre_weights,
)
from chiral_graviton_ed import coulomb_pseudopotentials
from symmetry_anchored_nqs import (
    SymmetryAnchoredNQS,
    rank2_sma_ratio,
)


def test_soft_width_zero_weights_are_coulomb() -> None:
    np.testing.assert_array_equal(
        soft_coulomb_legendre_weights(9, 0.0), np.ones(10)
    )


def test_softening_reduces_repulsion() -> None:
    electrons = jnp.asarray(
        [[math.pi / 2, 0.0], [math.pi / 2, math.pi / 3]]
    )
    hard = potential_energy(electrons, two_q=3, width_lB=0.0)
    soft = potential_energy(electrons, two_q=3, width_lB=0.8)
    assert float(soft) < float(hard)


def test_deephall_ansatz_is_antisymmetric() -> None:
    model = DeepHallPsiformer(
        particles=4, two_q=9, num_heads=2, head_dim=4, num_layers=2
    )
    key_data, key_params = jax.random.split(jax.random.PRNGKey(7))
    electrons = uniform_configurations(key_data, 1, 4)[0]
    params = model.init(key_params, electrons)
    swapped = electrons.at[jnp.asarray([0, 1])].set(electrons[jnp.asarray([1, 0])])
    ratio = jnp.exp(model.apply(params, swapped) - model.apply(params, electrons))
    np.testing.assert_allclose(ratio, -1.0 + 0.0j, atol=2.0e-8, rtol=2.0e-8)


def test_soft_pseudopotential_is_finite() -> None:
    weights = soft_coulomb_legendre_weights(9, 0.5, quadrature_order=256)
    pseudopotentials = central_pseudopotentials(9, weights)
    assert set(pseudopotentials) == set(range(10))
    assert all(np.isfinite(list(pseudopotentials.values())))

def test_zero_width_pseudopotentials_match_coulomb() -> None:
    generalized = central_pseudopotentials(9, np.ones(10))
    reference = coulomb_pseudopotentials(9)
    np.testing.assert_allclose(
        [generalized[m] for m in range(10)],
        [reference[m] for m in range(10)],
        atol=1.0e-12,
        rtol=1.0e-12,
    )


def test_laughlin_state_has_lll_kinetic_and_zero_total_l() -> None:
    particles = 4
    two_q = 9

    def laughlin_apply(_params, electrons):
        theta, phi = electrons[..., 0], electrons[..., 1]
        u = jnp.cos(theta / 2.0) * jnp.exp(0.5j * phi)
        v = jnp.sin(theta / 2.0) * jnp.exp(-0.5j * phi)
        pair_i, pair_j = jnp.triu_indices(particles, k=1)
        pair = u[pair_i] * v[pair_j] - u[pair_j] * v[pair_i]
        return 3.0 * jnp.sum(jnp.log(pair))

    electrons = uniform_configurations(jax.random.PRNGKey(11), 1, particles)[0]
    obs = local_kinetic_and_angular(laughlin_apply, None, electrons, two_q)
    np.testing.assert_allclose(obs.kinetic, particles / 2, atol=2.0e-10)
    np.testing.assert_allclose(obs.lz, 0.0, atol=2.0e-10)
    np.testing.assert_allclose(obs.lz2, 0.0, atol=2.0e-10)
    np.testing.assert_allclose(obs.l2, 0.0, atol=2.0e-9)

def test_symmetry_anchored_states_have_exact_total_l() -> None:
    electrons = uniform_configurations(jax.random.PRNGKey(17), 1, 4)[0]
    for sector, expected_lz, expected_l2 in (
        ("ground", 0.0, 0.0),
        ("l2", 2.0, 6.0),
    ):
        model = SymmetryAnchoredNQS(
            particles=4, sector=sector, hidden_dim=4, num_layers=2
        )
        params = model.init(jax.random.PRNGKey(19), electrons)
        obs = local_kinetic_and_angular(
            model.apply, params, electrons, two_q=9
        )
        np.testing.assert_allclose(obs.kinetic, 2.0, atol=2.0e-8)
        np.testing.assert_allclose(obs.lz, expected_lz, atol=2.0e-8)
        np.testing.assert_allclose(obs.l2, expected_l2, atol=2.0e-7)


def test_rank2_ratio_is_permutation_symmetric() -> None:
    electrons = uniform_configurations(jax.random.PRNGKey(23), 1, 4)[0]
    indices = jnp.asarray([1, 0, 2, 3])
    np.testing.assert_allclose(
        rank2_sma_ratio(electrons[indices]),
        rank2_sma_ratio(electrons),
        atol=2.0e-10,
        rtol=2.0e-10,
    )

if __name__ == "__main__":
    tests = [
        value
        for name, value in sorted(globals().items())
        if name.startswith("test_") and callable(value)
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
