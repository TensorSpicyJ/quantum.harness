#!/usr/bin/env python3
"""Confirm that trained symmetry-anchored checkpoints contain nonzero dressing."""

from pathlib import Path

import jax
import jax.numpy as jnp
from flax import serialization

from deephall_minimal import uniform_configurations
from symmetry_anchored_nqs import SymmetryAnchoredNQS


def dressing_change(sector: str, checkpoint: Path) -> float:
    electrons = uniform_configurations(jax.random.PRNGKey(99), 1, 4)[0]
    model = SymmetryAnchoredNQS(4, sector, 16, 2)
    initial = model.init(jax.random.PRNGKey(1), electrons)
    trained = serialization.from_bytes(initial, checkpoint.read_bytes())
    return float(
        jnp.abs(
            model.apply(trained, electrons)
            - model.apply(initial, electrons)
        )
    )


def main() -> None:
    root = Path(__file__).resolve().parent
    ground = root / "results/symmetry_ground_coulomb_400/checkpoint.msgpack"
    excited = root / "results/symmetry_l2_coulomb_400/checkpoint.msgpack"
    print(f"ground_log_dressing={dressing_change('ground', ground):.12g}")
    print(f"l2_log_dressing={dressing_change('l2', excited):.12g}")


if __name__ == "__main__":
    main()
