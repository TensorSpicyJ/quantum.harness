#!/usr/bin/env python3
"""Two-layer invariant NQS with exact L=0 and L=2 symmetry anchors.

This is the smallest repair of the failed penalty-Psiformer experiment:

  ground:  Psi = Laughlin * exp(F_theta({r_ij}))
  excited: Psi = rho_(2,2) Laughlin * exp(F_theta({r_ij}))

F_theta is a permutation- and rotation-invariant two-layer pair network.
Consequently the trainable dressing cannot change the total-angular-momentum
irrep: the ground state is exactly L=0 and the excited state exactly L=2,
without Lz or L2 penalties.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import flax.linen as nn
import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax import serialization

from deephall_minimal import (
    adapt_step_size,
    angles_to_xyz,
    iqr_clip,
    local_energy_and_observables,
    propose_geodesic,
    uniform_configurations,
)


jax.config.update("jax_enable_x64", True)

Array = jax.Array
PyTree = Any


def spinors(electrons: Array) -> tuple[Array, Array]:
    theta, phi = electrons[..., 0], electrons[..., 1]
    u = jnp.cos(theta / 2.0) * jnp.exp(0.5j * phi)
    v = jnp.sin(theta / 2.0) * jnp.exp(-0.5j * phi)
    return u, v


def laughlin_log(electrons: Array) -> Array:
    """Log of the fermionic nu=1/3 Laughlin state."""

    u, v = spinors(electrons)
    particles = electrons.shape[0]
    pair_i, pair_j = jnp.triu_indices(particles, k=1)
    pair = u[pair_i] * v[pair_j] - v[pair_i] * u[pair_j]
    return 3.0 * jnp.sum(jnp.log(pair))


def rank2_sma_ratio(electrons: Array) -> Array:
    """Analytic rho_(2,2) Psi_L / Psi_L ratio used by the validated SMA code."""

    u, v = spinors(electrons)
    particles = electrons.shape[0]
    determinant = u[:, None] * v[None, :] - v[:, None] * u[None, :]
    diagonal = jnp.diag_indices(particles)
    safe_determinant = determinant.at[diagonal].set(1.0 + 0.0j)
    inverse = (1.0 / safe_determinant).at[diagonal].set(0.0 + 0.0j)
    first_derivative = -3.0 * jnp.sum(u[None, :] * inverse, axis=1)
    second_term = -3.0 * jnp.sum(
        jnp.square(u[None, :]) * jnp.square(inverse), axis=1
    )
    return jnp.sum(
        jnp.square(u)
        * (jnp.square(first_derivative) + second_term)
    )


class SymmetryAnchoredNQS(nn.Module):
    particles: int
    sector: str
    hidden_dim: int = 16
    num_layers: int = 2

    @nn.compact
    def __call__(self, electrons: Array) -> Array:
        base = laughlin_log(electrons)
        if self.sector == "l2":
            base = base + jnp.log(rank2_sma_ratio(electrons))

        xyz = angles_to_xyz(electrons)
        pair_i, pair_j = jnp.triu_indices(self.particles, k=1)
        chord2 = jnp.sum(
            jnp.square(xyz[pair_i] - xyz[pair_j]), axis=-1
        )
        h = jnp.stack(
            [
                jnp.mean(chord2),
                jnp.mean(chord2**2),
                jnp.mean(chord2**3),
                jnp.mean(chord2**4),
                jnp.mean(jnp.log(chord2 + 1.0e-4)),
                jnp.mean(1.0 / (chord2 + 0.25)),
            ]
        )
        for layer in range(self.num_layers):
            h = jnp.tanh(
                nn.Dense(
                    self.hidden_dim,
                    name=f"invariant_layer_{layer}",
                )(h)
            )
        dressing = nn.Dense(
            1,
            kernel_init=nn.initializers.zeros,
            bias_init=nn.initializers.zeros,
            name="dressing_output",
        )(h)[0]
        return base + dressing


@dataclass
class RunConfig:
    sector: str
    particles: int = 4
    kappa: float = 1.0
    width_lB: float = 0.0
    hidden_dim: int = 16
    num_layers: int = 2
    batch_size: int = 128
    burn_in: int = 100
    mcmc_steps: int = 5
    iterations: int = 400
    learning_rate: float = 1.0e-3
    step_size: float = 0.08
    eval_blocks: int = 60
    eval_mcmc_steps: int = 8
    seed: int = 20260730

    @property
    def two_q(self) -> int:
        return 3 * (self.particles - 1)


def make_runtime(config: RunConfig):
    model = SymmetryAnchoredNQS(
        particles=config.particles,
        sector=config.sector,
        hidden_dim=config.hidden_dim,
        num_layers=config.num_layers,
    )
    local_one = lambda params, x: local_energy_and_observables(
        model.apply,
        params,
        x,
        config.two_q,
        config.kappa,
        config.width_lB,
    )
    local_batch = jax.vmap(local_one, in_axes=(None, 0))
    log_batch = jax.vmap(model.apply, in_axes=(None, 0))

    def mcmc_step(
        params: PyTree, data: Array, key: Array, step_size: Array
    ) -> tuple[Array, Array]:
        proposal = propose_geodesic(key, data, step_size)
        old_logabs = log_batch(params, data).real
        new_logabs = log_batch(params, proposal).real
        key_accept = jax.random.fold_in(key, 1)
        log_uniform = jnp.log(
            jax.random.uniform(key_accept, old_logabs.shape)
        )
        accept = log_uniform < 2.0 * (new_logabs - old_logabs)
        selected = jnp.where(
            accept[:, None, None], proposal, data
        )
        return selected, jnp.mean(accept)

    optimizer = optax.chain(
        optax.clip_by_global_norm(5.0),
        optax.adam(config.learning_rate),
    )

    def train_step(
        params: PyTree, opt_state: PyTree, data: Array
    ) -> tuple[PyTree, PyTree, dict[str, Array]]:
        energy, angular, potential = local_batch(params, data)
        energy = jax.lax.stop_gradient(energy)
        angular = jax.tree.map(jax.lax.stop_gradient, angular)
        potential = jax.lax.stop_gradient(potential)
        clipped_mean = jnp.nanmean(iqr_clip(energy))
        centered = jax.lax.stop_gradient(iqr_clip(energy - clipped_mean))

        def surrogate(current_params: PyTree) -> Array:
            logpsi = log_batch(current_params, data)
            return 2.0 * jnp.nanmean(
                jnp.real(centered * jnp.conj(logpsi))
            )

        gradients = jax.grad(surrogate)(params)
        updates, opt_state = optimizer.update(
            gradients, opt_state, params
        )
        params = optax.apply_updates(params, updates)
        stats = {
            "energy": jnp.nanmean(energy.real),
            "energy_imag": jnp.nanmean(energy.imag),
            "variance": jnp.nanvar(energy.real),
            "kinetic": jnp.nanmean(angular.kinetic.real),
            "potential": jnp.nanmean(potential),
            "lz": jnp.nanmean(angular.lz),
            "lz2": jnp.nanmean(angular.lz2),
            "l2": jnp.nanmean(angular.l2),
        }
        return params, opt_state, stats

    return (
        model,
        local_batch,
        jax.jit(mcmc_step),
        optimizer,
        jax.jit(train_step),
    )


def run(
    config: RunConfig,
    output_dir: Path,
    restore_path: Path | None = None,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    model, local_batch, mcmc_step, optimizer, train_step = make_runtime(config)
    key = jax.random.PRNGKey(config.seed)
    key, data_key, params_key = jax.random.split(key, 3)
    data = uniform_configurations(
        data_key, config.batch_size, config.particles
    )
    params = model.init(params_key, data[0])
    if restore_path is not None:
        params = serialization.from_bytes(params, restore_path.read_bytes())
        print(f"restored parameters: {restore_path.resolve()}")
    opt_state = optimizer.init(params)
    parameter_count = sum(x.size for x in jax.tree.leaves(params))
    step_size = config.step_size

    key, subkey = jax.random.split(key)
    data, acceptance = mcmc_step(params, data, subkey, step_size)
    jax.block_until_ready(data)
    for _ in range(config.burn_in):
        key, subkey = jax.random.split(key)
        data, acceptance = mcmc_step(params, data, subkey, step_size)
        step_size = adapt_step_size(step_size, float(acceptance))

    history_path = output_dir / "training.csv"
    start = time.perf_counter()
    with history_path.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = [
            "iteration",
            "energy",
            "energy_imag",
            "variance",
            "kinetic",
            "potential",
            "lz",
            "lz2",
            "l2",
            "acceptance",
            "step_size",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for iteration in range(config.iterations):
            acceptances = []
            for _ in range(config.mcmc_steps):
                key, subkey = jax.random.split(key)
                data, acceptance = mcmc_step(
                    params, data, subkey, step_size
                )
                acceptances.append(float(acceptance))
            mean_acceptance = float(np.mean(acceptances))
            step_size = adapt_step_size(step_size, mean_acceptance)
            params, opt_state, stats = train_step(params, opt_state, data)
            stats = {
                name: float(np.asarray(value))
                for name, value in stats.items()
            }
            writer.writerow(
                {
                    "iteration": iteration,
                    **stats,
                    "acceptance": mean_acceptance,
                    "step_size": step_size,
                }
            )
            if iteration % 25 == 0 or iteration + 1 == config.iterations:
                print(
                    f"{config.sector:6s} step={iteration:4d} "
                    f"E={stats['energy']:.7f} "
                    f"K={stats['kinetic']:.6f} "
                    f"V={stats['potential']:.6f} "
                    f"<Lz>={stats['lz']:.6f} "
                    f"<L2>={stats['l2']:.6f} "
                    f"acc={mean_acceptance:.3f}"
                )

    eval_rows = []
    for block in range(config.eval_blocks):
        block_acceptance = []
        for _ in range(config.eval_mcmc_steps):
            key, subkey = jax.random.split(key)
            data, acceptance = mcmc_step(
                params, data, subkey, step_size
            )
            block_acceptance.append(float(acceptance))
        energy, angular, potential = local_batch(params, data)
        eval_rows.append(
            {
                "block": block,
                "energy": float(jnp.nanmean(energy.real)),
                "energy_imag": float(jnp.nanmean(energy.imag)),
                "kinetic": float(jnp.nanmean(angular.kinetic.real)),
                "potential": float(jnp.nanmean(potential)),
                "lz": float(jnp.nanmean(angular.lz)),
                "lz2": float(jnp.nanmean(angular.lz2)),
                "l2": float(jnp.nanmean(angular.l2)),
                "acceptance": float(np.mean(block_acceptance)),
            }
        )

    with (output_dir / "evaluation_blocks.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(eval_rows[0]))
        writer.writeheader()
        writer.writerows(eval_rows)

    def mean_error(name: str) -> tuple[float, float]:
        values = np.asarray([row[name] for row in eval_rows])
        return (
            float(values.mean()),
            float(values.std(ddof=1) / math.sqrt(len(values))),
        )

    energy_mean, energy_stderr = mean_error("energy")
    expected_lz = 0.0 if config.sector == "ground" else 2.0
    expected_l2 = 0.0 if config.sector == "ground" else 6.0
    measured_lz = mean_error("lz")[0]
    measured_l2 = mean_error("l2")[0]
    symmetry_valid = (
        abs(measured_lz - expected_lz) < 1.0e-5
        and abs(measured_l2 - expected_l2) < 1.0e-4
    )
    summary = {
        "config": asdict(config),
        "ansatz": (
            "Laughlin or rank-2 SMA symmetry anchor times a two-layer "
            "permutation/rotation-invariant neural scalar"
        ),
        "two_q": config.two_q,
        "sphere_radius_lB": math.sqrt(config.two_q / 2.0),
        "paper_density_factor": math.sqrt(
            config.two_q / (3.0 * config.particles)
        ),
        "parameter_count": parameter_count,
        "runtime_seconds": time.perf_counter() - start,
        "energy": energy_mean,
        "energy_stderr": energy_stderr,
        "kinetic": mean_error("kinetic")[0],
        "potential": mean_error("potential")[0],
        "lz": measured_lz,
        "lz2": mean_error("lz2")[0],
        "l2": measured_l2,
        "acceptance": mean_error("acceptance")[0],
        "expected_lz": expected_lz,
        "expected_l2": expected_l2,
        "symmetry_valid": symmetry_valid,
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    (output_dir / "checkpoint.msgpack").write_bytes(
        serialization.to_bytes(params)
    )
    print(json.dumps(summary, indent=2))
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sector", choices=["ground", "l2"], required=True)
    parser.add_argument("-N", "--particles", type=int, default=4)
    parser.add_argument("--kappa", type=float, default=1.0)
    parser.add_argument("--width-lB", type=float, default=0.0)
    parser.add_argument("--hidden-dim", type=int, default=16)
    parser.add_argument("--num-layers", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--burn-in", type=int, default=100)
    parser.add_argument("--mcmc-steps", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=400)
    parser.add_argument("--learning-rate", type=float, default=1.0e-3)
    parser.add_argument("--step-size", type=float, default=0.08)
    parser.add_argument("--eval-blocks", type=int, default=60)
    parser.add_argument("--eval-mcmc-steps", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260730)
    parser.add_argument("--restore", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = RunConfig(
        sector=args.sector,
        particles=args.particles,
        kappa=args.kappa,
        width_lB=args.width_lB,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        batch_size=args.batch_size,
        burn_in=args.burn_in,
        mcmc_steps=args.mcmc_steps,
        iterations=args.iterations,
        learning_rate=args.learning_rate,
        step_size=args.step_size,
        eval_blocks=args.eval_blocks,
        eval_mcmc_steps=args.eval_mcmc_steps,
        seed=args.seed,
    )
    run(config, args.output_dir, args.restore)


if __name__ == "__main__":
    main()
